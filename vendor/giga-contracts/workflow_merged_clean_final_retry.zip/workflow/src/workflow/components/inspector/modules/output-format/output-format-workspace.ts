import type { WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowInspectorModuleFieldResolverContext, WorkflowInspectorModuleViewerResolverContext } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import { WorkflowNodeFieldTypeEnum, WorkflowViewerTypeEnum, type WorkflowNodeFieldMap } from '@workflow/ui/workflow/types';

const JSON_FORMAT = 'json';
const MARKDOWN_FORMAT = 'markdown';
const RAW_FORMAT = 'raw';
const TABLE_FORMAT = 'table';

const resolveOutputFormat = (value: unknown): string => {
    const normalized = String(value ?? JSON_FORMAT)
        .trim()
        .toLowerCase();

    switch (normalized) {
        case MARKDOWN_FORMAT:
        case RAW_FORMAT:
        case TABLE_FORMAT:
            return normalized;
        default:
            return JSON_FORMAT;
    }
};

const parseBooleanValue = (value: unknown): boolean => {
    if (value === true) return true;
    return ['true', '1', 'yes', 'on'].includes(String(value ?? '').trim().toLowerCase());
};

const resolveValueFieldType = (format: string): WorkflowNodeFieldTypeEnum => {
    if (format === MARKDOWN_FORMAT) return WorkflowNodeFieldTypeEnum.Markdown;
    if (format === RAW_FORMAT) return WorkflowNodeFieldTypeEnum.Textarea;
    return WorkflowNodeFieldTypeEnum.Json;
};

const buildViewer = (id: string, label: string, type: WorkflowViewerTypeEnum, value: unknown): WorkflowInspectorViewer => ({
    id,
    label,
    type,
    value
});

const parseJsonString = (value: unknown): unknown => {
    if (typeof value !== 'string') return value;
    const normalized = value.trim();
    if (!normalized) return {};
    try {
        return JSON.parse(normalized);
    } catch {
        return {};
    }
};

const stringifyScalarValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (value === null || value === undefined) return '';
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const parseTableValue = (value: unknown): unknown => {
    if (Array.isArray(value) || (value && typeof value === 'object')) {
        return value;
    }
    if (typeof value !== 'string') {
        return [];
    }
    const normalized = value.trim();
    if (!normalized) {
        return [];
    }
    try {
        return JSON.parse(normalized);
    } catch {
        return [];
    }
};

const resolveDraftPreviewValue = (format: string, value: unknown): unknown => {
    switch (format) {
        case MARKDOWN_FORMAT:
        case RAW_FORMAT:
            return stringifyScalarValue(value);
        case TABLE_FORMAT:
            return parseTableValue(value);
        case JSON_FORMAT:
        default:
            return parseJsonString(value);
    }
};

const resolvePreviewValue = ({ propertiesEditorState, executionResult }: Pick<WorkflowInspectorModuleViewerResolverContext, 'propertiesEditorState' | 'executionResult'>): unknown => {
    if (executionResult) {
        return executionResult.output;
    }

    const format = resolveOutputFormat(propertiesEditorState.format);
    return resolveDraftPreviewValue(format, propertiesEditorState.value);
};

export const resolveOutputFormatWorkspaceFields = ({
    fields,
    propertiesEditorState
}: WorkflowInspectorModuleFieldResolverContext): WorkflowNodeFieldMap => {
    const nextFields: WorkflowNodeFieldMap = { ...fields };
    const format = resolveOutputFormat(propertiesEditorState.format);
    const useAiFormatting = parseBooleanValue(propertiesEditorState.useAiFormatting);

    if (nextFields.value) {
        nextFields.value = {
            ...nextFields.value,
            type: resolveValueFieldType(format),
            label: format === TABLE_FORMAT ? 'Rows / Data' : 'Value',
            styles: {
                ...(nextFields.value.styles ?? {}),
                layoutPreset: 'full'
            }
        };
    }

    if (nextFields.modelId) {
        const hasConnectedModels = Array.isArray(nextFields.modelId.options) && nextFields.modelId.options.length > 0;
        nextFields.modelId = {
            ...nextFields.modelId,
            hidden: !useAiFormatting || !hasConnectedModels
        };
    }

    if (nextFields.aiPrompt) {
        nextFields.aiPrompt = {
            ...nextFields.aiPrompt,
            hidden: !useAiFormatting
        };
    }

    return nextFields;
};

export const resolveOutputFormatWorkspaceViewers = (context: WorkflowInspectorModuleViewerResolverContext): WorkflowInspectorViewer[] => {
    const format = resolveOutputFormat(context.propertiesEditorState.format);
    const previewValue = resolvePreviewValue(context);

    switch (format) {
        case MARKDOWN_FORMAT:
            return [
                buildViewer('markdown', 'Markdown', WorkflowViewerTypeEnum.Markdown, previewValue),
                buildViewer('raw', 'Raw', WorkflowViewerTypeEnum.Raw, previewValue)
            ];
        case RAW_FORMAT:
            return [buildViewer('raw', 'Raw', WorkflowViewerTypeEnum.Raw, previewValue)];
        case TABLE_FORMAT:
            return [
                buildViewer('table', 'Table', WorkflowViewerTypeEnum.Table, previewValue),
                buildViewer('json', 'JSON', WorkflowViewerTypeEnum.Json, previewValue)
            ];
        case JSON_FORMAT:
        default:
            return [
                buildViewer('json', 'JSON', WorkflowViewerTypeEnum.Json, previewValue),
                buildViewer('raw', 'Raw', WorkflowViewerTypeEnum.Raw, previewValue)
            ];
    }
};
