import React from 'react';
import { Dropdown } from 'primereact/dropdown';
import type { ManualHeaderRow } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';
import WorkflowSettingsSectionCard from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsSectionCard';
import { WorkflowSettingsManualHeaders } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsManualHeaders';

interface WorkflowSettingsExecutionCardProps {
    readOnly?: boolean;
    authMode: string;
    authModeIsManual: boolean;
    maxExecutionSeconds: number;
    authOptions: Array<{ label: string; value: string }>;
    timeoutOptions: Array<{ label: string; value: number }>;
    manualHeaderRows: ManualHeaderRow[];
    onAuthModeChange: (value: string) => void;
    onMaxExecutionSecondsChange: (value: number) => void;
    onManualHeaderChange: (rowId: string, key: 'header' | 'value', value: string) => void;
    onAddManualHeader: () => void;
    onRemoveManualHeader: (rowId: string) => void;
}

export const WorkflowSettingsExecutionCard: React.FC<WorkflowSettingsExecutionCardProps> = ({
    readOnly = false,
    authMode,
    authModeIsManual,
    maxExecutionSeconds,
    authOptions,
    timeoutOptions,
    manualHeaderRows,
    onAuthModeChange,
    onMaxExecutionSecondsChange,
    onManualHeaderChange,
    onAddManualHeader,
    onRemoveManualHeader
}) => (
    <WorkflowSettingsSectionCard icon="pi pi-play" title="Execution" description="Authentication and time limits for the active workspace.">
        <label className="wf-workspace-settings__field-label">Authentication</label>
        <Dropdown data-cy="workflow-settings-auth-mode" value={authMode} options={authOptions} onChange={(event) => onAuthModeChange(String(event.value))} disabled={readOnly} className="wf-workspace-settings__select" />
        <span className="wf-workspace-settings__field-note">Applies the active session token to runtime requests.</span>
        {authModeIsManual ? (
            <WorkflowSettingsManualHeaders
                readOnly={readOnly}
                manualHeaderRows={manualHeaderRows}
                onManualHeaderChange={onManualHeaderChange}
                onAddManualHeader={onAddManualHeader}
                onRemoveManualHeader={onRemoveManualHeader}
            />
        ) : null}
        <label className="wf-workspace-settings__field-label">Max execution time</label>
        <Dropdown data-cy="workflow-settings-timeout" value={maxExecutionSeconds} options={timeoutOptions} onChange={(event) => onMaxExecutionSecondsChange(Number(event.value))} disabled={readOnly} className="wf-workspace-settings__select" />
        <span className="wf-workspace-settings__field-note">Hard timeout enforced for workflow runs.</span>
    </WorkflowSettingsSectionCard>
);
