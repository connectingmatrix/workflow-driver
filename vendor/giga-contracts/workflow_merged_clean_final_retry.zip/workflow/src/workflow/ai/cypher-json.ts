export const parseCypherJson = (value: string): Record<string, unknown> => {
    const normalized = value.trim();
    if (!normalized) return {};
    const parsed = JSON.parse(normalized) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('Cypher properties must be a JSON object.');
    }
    return parsed as Record<string, unknown>;
};

export const stringifyCypherJson = (value: unknown): string => JSON.stringify(value || {}, null, 0);
