import { io, Socket } from "socket.io-client";
import { readWorkflowActionCatalog } from "../api/readWorkflowActionCatalog";
import {
  readWorkflowEditorUrl,
  readWorkflowExcerpt,
  readWorkflowShape,
} from "../api/readWorkflowSummary";
import {
  workflowCatalogRoom,
  workflowExecutionRoom,
  workflowLogsRoom,
  workflowUserRoom,
} from "../pubsub/rooms";
import {
  normalizeWorkflowQueueDefinition,
  normalizeWorkflowQueueLogEvent,
  normalizeWorkflowQueueLogs,
} from "../queue/normalizeWorkflowQueuePayload";
import { createWorkflowQueueRequestContextSnapshot } from "../queue/request-context-snapshot";
import {
  resolveWorkflowQueueCompletion,
  waitForWorkflowQueueCompletion,
} from "../queue/workflowQueueCompletion";
import {
  createWorkflowQueueTimingPayload,
  isWorkflowQueueExecutionStalled,
  mergeWorkflowQueueTimingPayload,
  resolveWorkflowQueueTiming,
  withWorkflowQueueExecutionStarted,
  withWorkflowQueueTimingPayload,
} from "../queue/workflowQueueTiming";
import type { WorkflowPubsubEvent, WorkflowPubsubHandler } from "../pubsub/types";
import type {
  WorkflowDefinition,
  WorkflowPreviewLogEvent,
  WorkflowPreviewStateEvent,
  WorkflowRuntimeSettings,
  WorkflowRunLogEvent,
} from "../types";
import type {
  ExecutorChatAdapter,
  ExecutorEventEnvelope,
  ExecutorPublishEventName,
  ExecutorRunningState,
} from "../service/types";

type ExecuteMode = "WAIT" | "ASYNC";
type PreviewResult = {
  request_id?: string | null;
  run_id?: string;
  workflow?: WorkflowDefinition;
  node?: unknown;
  result?: { output: unknown; status?: string; logs?: string[] };
};
type PreviewStop = {
  request_id?: string | null;
  run_id?: string;
  reason?: "completed" | "cancelled" | "failed";
};
type StepParams = {
  workflow: WorkflowDefinition;
  nodeId: string;
  settings: WorkflowRuntimeSettings;
  runId?: string;
  overrides?: Record<string, unknown>;
};
type StepResult = {
  request_id: string;
  run_id: string;
  workflow: WorkflowDefinition;
  node: unknown;
  result: { output: unknown; status?: string; logs?: string[] };
  logs: WorkflowRunLogEvent[];
  logs_jsonl: string;
};

export type WorkflowExecutorBrowserBindings = {
  socketUrl: string;
  readAccessToken: () => string;
  readUserId: () => string;
  executeBrowser?: (
    id: string,
    options: Record<string, unknown>,
    workflow: WorkflowDefinition,
  ) => Promise<unknown>;
};

type PendingRequest<T> = {
  reject: (error: Error) => void;
  resolve: (payload: T) => void;
  timeoutId: number;
};

const STEP_TIMEOUT = 90_000;
const nextId = (prefix: string) =>
  `${prefix}_${globalThis.crypto?.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`}`;
const watch = <T>(
  set: Set<(payload: T) => void>,
  handler: (payload: T) => void,
) => (set.add(handler), () => set.delete(handler));
const text = (value: unknown) => String(value || "").trim();
const payload = (value: unknown) =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};

export class WorkflowExecutorBrowserClient {
  private bindings: WorkflowExecutorBrowserBindings | null = null;
  private socket: Socket | null = null;
  private connectPromise: Promise<void> | null = null;
  private requests = new Map<string, PendingRequest<any>>();
  private anyHandlers = new Set<(event: ExecutorEventEnvelope) => void>();
  private eventHandlers = new Map<string, Set<(payload: unknown) => void>>();
  private workflowEventHandlers = new Set<
    (event: WorkflowRunLogEvent) => void
  >();
  private webhookInvokeHandlers = new Set<(payload: unknown) => void>();
  private catalogStatusHandlers = new Set<(payload: unknown) => void>();
  private executionUpdateHandlers = new Set<(payload: unknown) => void>();
  private previewLogHandlers = new Set<
    (event: WorkflowPreviewLogEvent) => void
  >();
  private previewStateHandlers = new Set<
    (event: WorkflowPreviewStateEvent) => void
  >();
  private previewResultHandlers = new Set<(value: PreviewResult) => void>();
  private previewStopHandlers = new Set<(value: PreviewStop) => void>();
  private previewErrorHandlers = new Set<
    (value: {
      request_id?: string | null;
      run_id?: string | null;
      error?: string;
    }) => void
  >();

  setup(bindings: WorkflowExecutorBrowserBindings) {
    this.bindings = bindings;
    return undefined;
  }
  start() {
    return this.connect();
  }
  async stop(targetRunId?: string) {
    if (!targetRunId) return (this.disconnect(), undefined);
    return this.stopRun(targetRunId);
  }
  async restart() {
    this.disconnect();
    await this.connect();
  }
  catalogRoom(userId: string, channelName = "workflow-socket") {
    return workflowCatalogRoom(userId, channelName);
  }
  workflowRoom(userId: string, workflowId: string) {
    return workflowExecutionRoom(userId, workflowId);
  }
  logsRoom(userId: string, runId: string) {
    return workflowLogsRoom(userId, runId);
  }
  userRoom(userId: string) {
    return workflowUserRoom(userId);
  }
  compileWorkflowCypher(_input: Record<string, unknown>) {
    throw new Error(
      "Executor.compileWorkflowCypher is only available in the server runtime.",
    );
  }
  compileWorkflow(_input: Record<string, unknown>) {
    throw new Error(
      "Executor.compileWorkflow is only available in the server runtime.",
    );
  }
  compileNode(_input: Record<string, unknown>) {
    throw new Error(
      "Executor.compileNode is only available in the server runtime.",
    );
  }
  createQueuedWorkflowRequestExecutor() {
    throw new Error(
      "Executor.createQueuedWorkflowRequestExecutor is only available in the server runtime.",
    );
  }
  createWorkflowQueueEventApplier() {
    throw new Error(
      "Executor.createWorkflowQueueEventApplier is only available in the server runtime.",
    );
  }
  createWorkflowQueueRequestContextSnapshot(
    params: Parameters<typeof createWorkflowQueueRequestContextSnapshot>[0],
  ) {
    return createWorkflowQueueRequestContextSnapshot(params);
  }
  consumeWorkflowExecutionEvents() {
    throw new Error(
      "Executor.consumeWorkflowExecutionEvents is only available in the server runtime.",
    );
  }
  runWorkflowExecutionQueue() {
    throw new Error(
      "Executor.runWorkflowExecutionQueue is only available in the server runtime.",
    );
  }
  createWorkflowQueueTimingPayload(queuedAt: string) {
    return createWorkflowQueueTimingPayload(queuedAt);
  }
  startWorkflowExecutionPubsub() {
    throw new Error(
      "Executor.startWorkflowExecutionPubsub is only available in the server runtime.",
    );
  }
  isWorkflowQueueExecutionStalled(
    params: Parameters<typeof isWorkflowQueueExecutionStalled>[0],
  ) {
    return isWorkflowQueueExecutionStalled(params);
  }
  mergeWorkflowQueueTimingPayload(
    payloadValue: unknown,
    currentPayload: unknown,
    fallbackQueuedAt?: string | null,
  ) {
    return mergeWorkflowQueueTimingPayload(
      payloadValue,
      currentPayload,
      fallbackQueuedAt,
    );
  }
  normalizeWorkflowQueueDefinition(workflow: WorkflowDefinition) {
    return normalizeWorkflowQueueDefinition(workflow);
  }
  normalizeWorkflowQueueLogEvent(event: WorkflowRunLogEvent) {
    return normalizeWorkflowQueueLogEvent(event);
  }
  normalizeWorkflowQueueLogs(logs: WorkflowRunLogEvent[]) {
    return normalizeWorkflowQueueLogs(logs);
  }
  readWorkflowActionCatalog() {
    return readWorkflowActionCatalog();
  }
  readWorkflowEditorUrl(workflowId?: string | null) {
    return readWorkflowEditorUrl(workflowId);
  }
  readWorkflowExcerpt(value: unknown, limit?: number) {
    return readWorkflowExcerpt(value, limit);
  }
  readWorkflowNodeCatalog() {
    throw new Error(
      "Executor.readWorkflowNodeCatalog is only available in the server runtime.",
    );
  }
  readWorkflowNodeDetails(_modelIds: string[]) {
    throw new Error(
      "Executor.readWorkflowNodeDetails is only available in the server runtime.",
    );
  }
  readWorkflowPlannerContext(_message: string) {
    throw new Error(
      "Executor.readWorkflowPlannerContext is only available in the server runtime.",
    );
  }
  readWorkflowShape(workflow: WorkflowDefinition | null | undefined) {
    return readWorkflowShape(workflow);
  }
  readChatAdapter(): ExecutorChatAdapter {
    throw new Error(
      "Executor.readChatAdapter is only available in the server runtime.",
    );
  }
  resolveWorkflowQueueCompletion(
    event: Parameters<typeof resolveWorkflowQueueCompletion>[0],
  ) {
    return resolveWorkflowQueueCompletion(event);
  }
  resolveWorkflowQueueTiming(
    params: Parameters<typeof resolveWorkflowQueueTiming>[0],
  ) {
    return resolveWorkflowQueueTiming(params);
  }
  validateJSON(input: string) {
    return JSON.parse(String(input || "null"));
  }
  validateCypher(_input: Record<string, unknown>) {
    throw new Error(
      "Executor.validateCypher is only available in the server runtime.",
    );
  }
  waitForWorkflowQueueCompletion(executionId: string, signal?: AbortSignal) {
    return waitForWorkflowQueueCompletion(executionId, signal);
  }
  withWorkflowQueueExecutionStarted(payloadValue: unknown, startedAt: string) {
    return withWorkflowQueueExecutionStarted(payloadValue, startedAt);
  }
  withWorkflowQueueTimingPayload(
    payloadValue: unknown,
    queuedAt: string,
    executionStartedAt?: string | null,
  ) {
    return withWorkflowQueueTimingPayload(
      payloadValue,
      queuedAt,
      executionStartedAt,
    );
  }
  errorMessage(error: unknown) {
    return error instanceof Error
      ? error.message
      : text(error) || "Workflow execution failed.";
  }
  on(
    eventName: ExecutorPublishEventName,
    handler: (event: ExecutorEventEnvelope) => void,
  ) {
    const wrap = (event: unknown) => handler(event as ExecutorEventEnvelope);
    return watch(
      this.anyHandlers,
      (event) => event.eventName === eventName && wrap(event),
    );
  }
  listen(
    roomName: string,
    handler: WorkflowPubsubHandler,
  ): Promise<() => void> {
    const userId = this.readUserId();
    if (!userId) throw new Error("Missing workflow user id.");
    if (roomName === this.catalogRoom(userId, "workflow-socket")) {
      const offStatus = this.addCatalogStatusHandler((value) =>
        handler(
          roomName,
          this.event(roomName, "workflow:catalog:status", value),
        ),
      );
      const offExecution = this.addExecutionUpdateHandler((value) =>
        handler(
          roomName,
          this.event(roomName, "workflow:execution:update", value),
        ),
      );
      return this.subscribeCatalogChannel({
        broadcastId: userId,
        channelName: "workflow-socket",
      }).then(() => () => {
        offStatus();
        offExecution();
        this.unsubscribeCatalogChannel({
          broadcastId: userId,
          channelName: "workflow-socket",
        });
      });
    }
    if (roomName.startsWith(this.logsRoom(userId, ""))) {
      const runId = roomName.slice(this.logsRoom(userId, "").length).trim();
      const off = this.addEventHandler(
        (value) =>
          text(value.runId) === runId &&
          handler(roomName, this.event(roomName, "workflow:event", value)),
      );
      return this.joinRun(runId).then(() => () => off());
    }
    const workflowId = roomName.startsWith(`${userId}-`)
      ? roomName.slice(`${userId}-`.length).trim()
      : "";
    if (!workflowId) throw new Error(`Unsupported executor room: ${roomName}`);
    const off = this.addEventHandler(
      (value) =>
        text(value.workflowId) === workflowId &&
        handler(roomName, this.event(roomName, "workflow:event", value)),
    );
    return this.subscribeWorkflowExecution({
      broadcastId: userId,
      workflowId,
    }).then(() => () => {
      off();
      this.unsubscribeWorkflowExecution({ broadcastId: userId, workflowId });
    });
  }

  async execute(
    id: string,
    options: {
      mode?: ExecuteMode;
      requestId?: string;
      settings: WorkflowRuntimeSettings;
    },
    workflow: WorkflowDefinition,
  ) {
    const requestId = options.requestId || nextId("execute");
    const runId = options.mode === "ASYNC" ? undefined : nextId("run");
    return this.request("workflow:execute", requestId, {
      mode: options.mode || "WAIT",
      options: { runId, settings: options.settings },
      workflow,
    });
  }
  executeBrowser(
    id: string,
    options: Record<string, unknown>,
    workflow: WorkflowDefinition,
  ) {
    const execute = this.requireBindings().executeBrowser;
    if (!execute)
      throw new Error("Workflow browser execution is not configured.");
    return execute(id, options, workflow);
  }
  enqueue(
    id: string,
    options: { requestId?: string; settings: WorkflowRuntimeSettings },
    workflow: WorkflowDefinition,
  ) {
    return this.execute(
      id,
      {
        mode: "ASYNC",
        requestId: options.requestId,
        settings: options.settings,
      },
      workflow,
    );
  }
  stopRun(runId: string) {
    return this.request(
      "workflow:stop",
      nextId("stop"),
      { run_id: runId },
      "workflow:stop:result",
    ).then((value) => Number(payload(value).stopped || 0));
  }
  stopWorkflow(workflowId: string) {
    return this.request(
      "workflow:workflow:stop",
      nextId("stop_workflow"),
      { workflow_id: workflowId },
      "workflow:workflow:stop:result",
    ).then((value) => Number(payload(value).stopped || 0));
  }
  getRunning(workflowId?: string) {
    return this.request(
      "workflow:running",
      nextId("running"),
      { workflow_id: workflowId || null },
      "workflow:running:result",
    ).then((value) => (payload(value).running || []) as ExecutorRunningState[]);
  }

  addEventHandler(handler: (event: WorkflowRunLogEvent) => void) {
    return watch(this.workflowEventHandlers, handler);
  }
  addWebhookTestInvokeHandler(handler: (value: unknown) => void) {
    return watch(this.webhookInvokeHandlers, handler);
  }
  addCatalogStatusHandler(handler: (value: unknown) => void) {
    return watch(this.catalogStatusHandlers, handler);
  }
  addExecutionUpdateHandler(handler: (value: unknown) => void) {
    return watch(this.executionUpdateHandlers, handler);
  }
  addPreviewLogHandler(handler: (value: WorkflowPreviewLogEvent) => void) {
    return watch(this.previewLogHandlers, handler);
  }
  addPreviewStateHandler(handler: (value: WorkflowPreviewStateEvent) => void) {
    return watch(this.previewStateHandlers, handler);
  }
  addPreviewResultHandler(handler: (value: PreviewResult) => void) {
    return watch(this.previewResultHandlers, handler);
  }
  addPreviewStopHandler(handler: (value: PreviewStop) => void) {
    return watch(this.previewStopHandlers, handler);
  }
  addPreviewErrorHandler(
    handler: (value: {
      request_id?: string | null;
      run_id?: string | null;
      error?: string;
    }) => void,
  ) {
    return watch(this.previewErrorHandlers, handler);
  }

  async connect() {
    if (this.connectPromise) return this.connectPromise;
    if (this.socket?.connected) return;
    const token = text(this.requireBindings().readAccessToken());
    if (!token) throw new Error("Missing workflow access token.");
    const socket = io(this.socketOrigin(), {
      auth: { token },
      path: "/ws/workflow",
      transports: ["websocket"],
    });
    this.socket = socket;
    this.connectPromise = new Promise<void>((resolve, reject) => {
      const done = (error?: Error) => {
        socket.off("disconnect", onClose);
        socket.off("connect_error", onError);
        this.off("workflow:ready", onReady);
        this.off("workflow:error", onWorkflowError);
        if (error) reject(error);
        else resolve();
      };
      const onReady = () => done();
      const onClose = () =>
        done(new Error("Could not connect to workflow websocket."));
      const onError = () =>
        done(new Error("Could not connect to workflow websocket."));
      const onWorkflowError = (value: unknown) =>
        done(
          new Error(
            text(payload(value).error) ||
              "Could not authorize workflow websocket.",
          ),
        );
      socket.once("disconnect", onClose);
      socket.once("connect_error", onError);
      this.onEvent("workflow:ready", onReady);
      this.onEvent("workflow:error", onWorkflowError);
      socket.onAny((eventName: string, value: unknown) =>
        this.consume(eventName, value),
      );
    }).finally(() => {
      this.connectPromise = null;
    });
    return this.connectPromise;
  }

  disconnect() {
    this.socket?.disconnect();
    this.socket = null;
    this.connectPromise = null;
    this.requests.forEach(
      (waiter) => (
        window.clearTimeout(waiter.timeoutId),
        waiter.reject(new Error("Workflow websocket disconnected."))
      ),
    );
    this.requests.clear();
  }

  async joinRun(runId: string) {
    if (!text(runId)) return;
    await this.connect();
    this.send("workflow:join", { run_id: runId });
  }
  async subscribeCatalogChannel(params: {
    broadcastId: string;
    channelName: string;
  }) {
    if (!text(params.broadcastId) || !text(params.channelName)) return;
    await this.connect();
    this.send("workflow:catalog:subscribe", {
      broadcast_id: text(params.broadcastId),
      channel_name: text(params.channelName),
    });
  }
  unsubscribeCatalogChannel(params: {
    broadcastId: string;
    channelName: string;
  }) {
    if (!text(params.broadcastId) || !text(params.channelName)) return;
    this.emit("workflow:catalog:unsubscribe", {
      broadcast_id: text(params.broadcastId),
      channel_name: text(params.channelName),
    });
  }
  async subscribeWorkflowExecution(params: {
    broadcastId: string;
    workflowId: string;
  }) {
    if (!text(params.broadcastId) || !text(params.workflowId)) return;
    await this.connect();
    this.send("workflow:execution:subscribe", {
      broadcast_id: text(params.broadcastId),
      workflow_id: text(params.workflowId),
    });
  }
  unsubscribeWorkflowExecution(params: {
    broadcastId: string;
    workflowId: string;
  }) {
    if (!text(params.broadcastId) || !text(params.workflowId)) return;
    this.emit("workflow:execution:unsubscribe", {
      broadcast_id: text(params.broadcastId),
      workflow_id: text(params.workflowId),
    });
  }
  async openEditorSession(params: { workflowId: string; editable?: boolean }) {
    if (!text(params.workflowId)) return;
    await this.connect();
    this.send("workflow:editor:open", {
      editable: params.editable !== false,
      workflow_id: text(params.workflowId),
    });
  }
  async heartbeatEditorSession(params: {
    workflowId: string;
    editable?: boolean;
  }) {
    if (!text(params.workflowId)) return;
    await this.connect();
    this.send("workflow:editor:heartbeat", {
      editable: params.editable !== false,
      workflow_id: text(params.workflowId),
    });
  }
  closeEditorSession(params: { workflowId: string }) {
    if (!text(params.workflowId)) return;
    this.emit("workflow:editor:close", {
      workflow_id: text(params.workflowId),
    });
  }
  emitWebhookTestResult(value: {
    requestId: string;
    workflowId: string;
    output: unknown;
    logs?: unknown[];
  }) {
    this.emit("workflow:webhook:test:result", {
      logs: value.logs || [],
      output: value.output,
      request_id: value.requestId,
      workflow_id: value.workflowId,
    });
  }
  emitWebhookTestError(value: {
    requestId: string;
    workflowId: string;
    error: string;
    logs?: unknown[];
    output?: unknown;
  }) {
    this.emit("workflow:webhook:test:error", {
      error: value.error,
      logs: value.logs || [],
      output: value.output || null,
      request_id: value.requestId,
      workflow_id: value.workflowId,
    });
  }

  async executeStep(params: StepParams): Promise<StepResult> {
    const requestId = nextId("step");
    return this.request(
      "workflow:step",
      requestId,
      {
        node_id: params.nodeId,
        overrides: params.overrides,
        run_id: params.runId,
        settings: params.settings,
        workflow: params.workflow,
      },
      "workflow:step:result",
    );
  }

  async startPreview(params: StepParams) {
    const runId = text(params.runId) || nextId("preview");
    await this.connect();
    this.send("workflow:preview:start", {
      node_id: params.nodeId,
      overrides: params.overrides,
      request_id: nextId("preview"),
      run_id: runId,
      settings: params.settings,
      workflow: params.workflow,
    });
    return runId;
  }
  cancelPreview(runId: string) {
    if (!text(runId)) return;
    this.emit("workflow:preview:cancel", { run_id: text(runId) });
  }

  private consume(eventNameValue: unknown, value: unknown) {
    const eventName = text(eventNameValue);
    if (!eventName) return;
    this.eventHandlers.get(eventName)?.forEach((handler) => handler(value));
    if (eventName === "workflow:event")
      this.workflowEventHandlers.forEach((handler) =>
        handler(value as WorkflowRunLogEvent),
      );
    if (eventName === "workflow:webhook:test:invoke")
      this.webhookInvokeHandlers.forEach((handler) => handler(value));
    if (eventName === "workflow:catalog:status")
      this.catalogStatusHandlers.forEach((handler) => handler(value));
    if (eventName === "workflow:execution:update")
      this.executionUpdateHandlers.forEach((handler) => handler(value));
    if (eventName === "workflow:preview:log")
      this.previewLogHandlers.forEach((handler) =>
        handler(value as WorkflowPreviewLogEvent),
      );
    if (eventName === "workflow:preview:state")
      this.previewStateHandlers.forEach((handler) =>
        handler(value as WorkflowPreviewStateEvent),
      );
    if (eventName === "workflow:preview:result")
      this.previewResultHandlers.forEach((handler) =>
        handler(value as PreviewResult),
      );
    if (eventName === "workflow:preview:stop")
      this.previewStopHandlers.forEach((handler) =>
        handler(value as PreviewStop),
      );
    if (eventName === "workflow:preview:error")
      this.previewErrorHandlers.forEach((handler) =>
        handler(
          value as {
            request_id?: string | null;
            run_id?: string | null;
            error?: string;
          },
        ),
      );
    this.anyHandlers.forEach((handler) =>
      handler({
        eventName: eventName as ExecutorPublishEventName,
        payload: value,
        roomName: text(payload(value).roomName),
      }),
    );
    const requestId = text(payload(value).request_id);
    if (!requestId) return;
    if (eventName === "workflow:error")
      return this.rejectRequest(
        requestId,
        new Error(text(payload(value).error) || "Workflow request failed."),
      );
    if (eventName.endsWith(":result"))
      return this.resolveRequest(requestId, value);
  }

  private event(
    roomName: string,
    eventName: WorkflowPubsubEvent["eventName"],
    value: unknown,
  ): WorkflowPubsubEvent {
    return { eventName, payload: value, roomName };
  }
  private off(eventName: string, handler: (value: unknown) => void) {
    this.eventHandlers.get(eventName)?.delete(handler);
  }
  private onEvent(eventName: string, handler: (value: unknown) => void) {
    const handlers = this.eventHandlers.get(eventName) || new Set();
    handlers.add(handler);
    this.eventHandlers.set(eventName, handlers);
    return () => this.off(eventName, handler);
  }
  private async request<T>(
    eventName: string,
    requestId: string,
    value: Record<string, unknown>,
    resultEventName?: string,
  ): Promise<T> {
    await this.connect();
    return new Promise<T>((resolve, reject) => {
      const timeoutId = window.setTimeout(() => {
        this.requests.delete(requestId);
        reject(new Error("Workflow websocket request timed out."));
      }, STEP_TIMEOUT);
      this.requests.set(requestId, { resolve, reject, timeoutId });
      this.send(eventName, {
        ...value,
        request_id: requestId,
        result_event_name: resultEventName || null,
      });
    });
  }
  private readUserId() {
    return text(this.requireBindings().readUserId());
  }
  private rejectRequest(requestId: string, error: Error) {
    const waiter = this.requests.get(requestId);
    if (!waiter) return;
    window.clearTimeout(waiter.timeoutId);
    this.requests.delete(requestId);
    waiter.reject(error);
  }
  private resolveRequest(requestId: string, value: unknown) {
    const waiter = this.requests.get(requestId);
    if (!waiter) return;
    window.clearTimeout(waiter.timeoutId);
    this.requests.delete(requestId);
    waiter.resolve(value);
  }
  private requireBindings() {
    if (!this.bindings)
      throw new Error("Executor.setup(...) must be called first.");
    return this.bindings;
  }
  private emit(eventName: string, value: Record<string, unknown>) {
    if (!this.socket?.connected) return false;
    this.socket.emit(eventName, value);
    return true;
  }
  private send(eventName: string, value: Record<string, unknown>) {
    if (!this.emit(eventName, value))
      throw new Error("Workflow websocket is not connected.");
  }
  private socketOrigin() {
    const raw = text(this.requireBindings().socketUrl);
    const value = raw.startsWith("ws://")
      ? `http://${raw.slice(5)}`
      : raw.startsWith("wss://")
        ? `https://${raw.slice(6)}`
        : raw;
    const parsed = new URL(value);
    return `${parsed.protocol}//${parsed.host}`;
  }
}
