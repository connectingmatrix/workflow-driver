import type { WorkflowCanvasSettings, WorkflowDefinition, WorkflowRuntimeSettings } from '@workflow/ui/workflow/types';

interface WorkflowSettingsUpdate {
    workflowName: string;
    workflowDescription: string;
    settings: WorkflowRuntimeSettings;
    canvasSettings: WorkflowCanvasSettings;
}

export const applyWorkflowSettingsChange = (workflow: WorkflowDefinition, update: WorkflowSettingsUpdate): WorkflowDefinition => ({
    ...workflow,
    metadata: {
        ...workflow.metadata,
        name: update.workflowName.trim() || workflow.metadata.name,
        description: update.workflowDescription,
        runtime: {
            ...(workflow.metadata.runtime ?? {}),
            settings: update.settings
        },
        ui: {
            ...(workflow.metadata.ui ?? {}),
            canvas: update.canvasSettings
        }
    }
});
