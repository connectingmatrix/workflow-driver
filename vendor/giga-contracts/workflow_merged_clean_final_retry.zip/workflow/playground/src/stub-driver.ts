import type {
    WorkflowDefinition,
    WorkflowPreviewLogEvent,
    WorkflowPreviewStateEvent,
    WorkflowRealtimeClient,
    WorkflowRuntimeSettings,
    WorkflowSocketErrorPayload,
    WorkflowStepSocketResult,
    WorkflowUiDriver,
    WorkflowWebhookTestInvokePayload
} from '@workflow/ui';
import { WorkflowExecutionModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui';
import type {
    WorkflowPreviewResultPayload,
    WorkflowPreviewStopPayload
} from '@workflow/ui/workflow/driver/types';
import { executeBrowserWorkflowPreview } from './preview-runtime';
import { requestNodeWorkflowPreview } from './node-preview-client';

const createRequestId = (): string => {
    const time = Date.now().toString(36);
    const nonce = Math.random().toString(36).slice(2, 10);
    return `stub_${time}_${nonce}`;
};

const copyWorkflowAsPassed = (workflow: WorkflowDefinition): WorkflowDefinition => ({
    ...workflow,
    nodes: workflow.nodes.map((node) => ({
        ...node,
        status: WorkflowNodeStatusEnum.Passed
    }))
});

class StubWorkflowRealtimeClient implements WorkflowRealtimeClient {
    private eventHandlers = new Set<(event: any) => void>();
    private webhookTestInvokeHandlers = new Set<(payload: WorkflowWebhookTestInvokePayload) => void>();
    private previewLogHandlers = new Set<(event: WorkflowPreviewLogEvent) => void>();
    private previewStateHandlers = new Set<(event: WorkflowPreviewStateEvent) => void>();
    private previewResultHandlers = new Set<(payload: WorkflowPreviewResultPayload) => void>();
    private previewStopHandlers = new Set<(payload: WorkflowPreviewStopPayload) => void>();
    private previewErrorHandlers = new Set<(payload: WorkflowSocketErrorPayload) => void>();
    private previewAbortControllers = new Map<string, AbortController>();

    async connect(): Promise<void> {
        return Promise.resolve();
    }

    disconnect(): void {
        this.eventHandlers.clear();
        this.webhookTestInvokeHandlers.clear();
        this.previewLogHandlers.clear();
        this.previewStateHandlers.clear();
        this.previewResultHandlers.clear();
        this.previewStopHandlers.clear();
        this.previewErrorHandlers.clear();
        this.previewAbortControllers.forEach((controller) => controller.abort());
        this.previewAbortControllers.clear();
    }

    async joinRun(_runId: string): Promise<void> {
        return Promise.resolve();
    }

    addEventHandler(handler: (event: any) => void): () => void {
        this.eventHandlers.add(handler);
        return () => this.eventHandlers.delete(handler);
    }

    addWebhookTestInvokeHandler(handler: (payload: WorkflowWebhookTestInvokePayload) => void): () => void {
        this.webhookTestInvokeHandlers.add(handler);
        return () => this.webhookTestInvokeHandlers.delete(handler);
    }

    emitWebhookTestResult(_payload: { requestId: string; workflowId: string; workflow: WorkflowDefinition; output: unknown; logs?: unknown[] }): void {
        return;
    }

    emitWebhookTestError(_payload: { requestId: string; workflowId: string; error: string }): void {
        return;
    }

    async openEditorSession(_params: { workflowId: string; editable?: boolean }): Promise<void> {
        return Promise.resolve();
    }

    async heartbeatEditorSession(_params: { workflowId: string; editable?: boolean }): Promise<void> {
        return Promise.resolve();
    }

    closeEditorSession(_params: { workflowId: string }): void {
        return;
    }

    async executeStep(params: {
        workflow: WorkflowDefinition;
        nodeId: string;
        settings: WorkflowRuntimeSettings;
        runId?: string;
        overrides?: {
            properties?: Record<string, unknown>;
            code?: string;
            markdown?: string;
            sourceFiles?: Record<string, string>;
            previewRuntime?: 'auto' | 'browser' | 'node';
            previewInput?: Record<string, unknown>;
            previewMode?: 'designer';
        };
    }): Promise<WorkflowStepSocketResult> {
        const activeNode = params.workflow.nodes.find((node) => node.id === params.nodeId);
        if (!activeNode) {
            throw new Error(`Node ${params.nodeId} is missing in stub step execution.`);
        }
        return {
            request_id: createRequestId(),
            run_id: params.runId ?? createRequestId(),
            workflow: copyWorkflowAsPassed(params.workflow),
            node: {
                ...activeNode,
                status: WorkflowNodeStatusEnum.Passed
            },
            result: {
                output: {
                    stub: true,
                    nodeId: activeNode.id
                },
                status: WorkflowNodeStatusEnum.Passed,
                logs: []
            },
            logs: [],
            logs_jsonl: ''
        };
    }

    async startPreview(params: {
        workflow: WorkflowDefinition;
        nodeId: string;
        settings: WorkflowRuntimeSettings;
        runId?: string;
        overrides?: {
            properties?: Record<string, unknown>;
            code?: string;
            markdown?: string;
            sourceFiles?: Record<string, string>;
            previewRuntime?: 'auto' | 'browser' | 'node';
            previewInput?: Record<string, unknown>;
            previewMode?: 'designer';
        };
    }): Promise<string> {
        const runId = params.runId ?? createRequestId();
        const abortController = new AbortController();
        this.previewAbortControllers.set(runId, abortController);
        const emitPreviewLog = (event: WorkflowPreviewLogEvent) => {
            this.previewLogHandlers.forEach((handler) => handler(event));
        };
        const emitPreviewState = (event: WorkflowPreviewStateEvent) => {
            this.previewStateHandlers.forEach((handler) => handler(event));
        };

        const finishPreview = (reason: 'completed' | 'cancelled' | 'failed') => {
            this.previewStopHandlers.forEach((handler) =>
                handler({
                    run_id: runId,
                    reason
                })
            );
        };

        const previewPromise =
            params.overrides?.previewRuntime === 'node'
                ? requestNodeWorkflowPreview(
                      {
                          workflow: params.workflow,
                          nodeId: params.nodeId,
                          settings: params.settings,
                          runId,
                          overrides: params.overrides
                      },
                      abortController.signal
                  ).then((response) => {
                      response.logs.forEach(emitPreviewLog);
                      response.states.forEach(emitPreviewState);
                      if (!response.ok) {
                          throw new Error(response.error);
                      }
                      return response.result;
                  })
                : executeBrowserWorkflowPreview({
                      workflow: params.workflow,
                      nodeId: params.nodeId,
                      settings: params.settings,
                      runId,
                      overrides: params.overrides,
                      signal: abortController.signal,
                      emitLog: emitPreviewLog,
                      emitState: emitPreviewState
                  });

        void previewPromise
            .then((result) => {
                this.previewResultHandlers.forEach((handler) =>
                    handler({
                        run_id: runId,
                        result: result.result,
                        workflow: result.workflow,
                        node: result.node
                    })
                );
                finishPreview('completed');
            })
            .catch((error) => {
                const message = error instanceof Error ? error.message : String(error);
                this.previewErrorHandlers.forEach((handler) =>
                    handler({
                        run_id: runId,
                        error: message
                    })
                );
                finishPreview(abortController.signal.aborted ? 'cancelled' : 'failed');
            })
            .finally(() => {
                this.previewAbortControllers.delete(runId);
            });
        return runId;
    }

    cancelPreview(runId: string): void {
        this.previewAbortControllers.get(runId)?.abort();
    }

    addPreviewLogHandler(handler: (event: WorkflowPreviewLogEvent) => void): () => void {
        this.previewLogHandlers.add(handler);
        return () => this.previewLogHandlers.delete(handler);
    }

    addPreviewStateHandler(handler: (event: WorkflowPreviewStateEvent) => void): () => void {
        this.previewStateHandlers.add(handler);
        return () => this.previewStateHandlers.delete(handler);
    }

    addPreviewResultHandler(handler: (payload: WorkflowPreviewResultPayload) => void): () => void {
        this.previewResultHandlers.add(handler);
        return () => this.previewResultHandlers.delete(handler);
    }

    addPreviewStopHandler(handler: (payload: WorkflowPreviewStopPayload) => void): () => void {
        this.previewStopHandlers.add(handler);
        return () => this.previewStopHandlers.delete(handler);
    }

    addPreviewErrorHandler(handler: (payload: WorkflowSocketErrorPayload) => void): () => void {
        this.previewErrorHandlers.add(handler);
        return () => this.previewErrorHandlers.delete(handler);
    }
}

export const createStubWorkflowDriver = (): WorkflowUiDriver => ({
    createRequestId,
    getDefaultRuntimeSettings: () => ({
        graphqlUrl: 'http://127.0.0.1:9999/stub/graphql',
        httpBaseUrl: 'http://127.0.0.1:9999/stub/api/v2',
        authMode: 'none',
        manualHeaders: {},
        maxExecutionSeconds: 300
    }),
    createRealtimeClient: () => new StubWorkflowRealtimeClient(),
    buildWorkflowWebhookUrls: (workflowId: string) => ({
        testUrl: `http://127.0.0.1:9999/stub/workflows/${workflowId}/test`,
        publishedUrl: `http://127.0.0.1:9999/stub/workflows/${workflowId}/published`
    }),
    fetchCredentials: async () => [],
    fetchNodeFieldOptions: async (request) => {
        if (request.optionsSource === 'tree-subjects') return [{ label: 'Retention', value: 'subject-retention' }, { label: 'Churn', value: 'subject-churn' }];
        if (request.optionsSource === 'tree-posts') return [{ label: 'Q1 Notes', value: 'post-q1' }, { label: 'Support Digest', value: 'post-support' }];
        if (request.optionsSource === 'tree-tags') return [{ label: 'research', value: 'research' }, { label: 'urgent', value: 'urgent' }];
        if (request.optionsSource === 'chat-subjects') return [{ label: 'All', value: '__all__' }, { label: 'Retention', value: 'subject-retention' }, { label: 'Churn', value: 'subject-churn' }];
        if (request.optionsSource === 'chat-tags') return [{ label: 'All', value: '__all__' }, { label: 'research', value: 'research' }, { label: 'urgent', value: 'urgent' }];
        if (request.optionsSource === 'connected-command-tools') return [{ label: 'Action Router', value: 'action-router' }, { label: 'Chart', value: 'chart' }];
        return [];
    },
    executeWorkflowOnServer: async (params) => {
        return {
            accepted: true,
            run_id: params.requestId ?? createRequestId(),
            stopped: false,
            workflow: copyWorkflowAsPassed(params.workflow),
            logs: [
                {
                    timestamp: new Date().toISOString(),
                    level: 'info',
                    event: 'workflow.server.stub',
                    workflowId: params.workflow.metadata.id,
                    runId: params.requestId ?? createRequestId(),
                    mode: params.mode ?? WorkflowExecutionModeEnum.Wait
                }
            ]
        };
    },
    requestWorkflowAi: async () => ({
        reply: 'Stub AI response from workflow playground driver.',
        actions: [],
        diagnostics: {
            summary: 'AI is stubbed in this local playground.'
        }
    }),
    listWorkflowUserNodes: async () => [],
    createWorkflowUserNode: async (input) => ({
        id: createRequestId(),
        userId: 'stub-user',
        name: input.name,
        slug: input.slug ?? input.name.trim().toLowerCase().replace(/\s+/g, '-'),
        description: input.description ?? null,
        groupName: input.groupName ?? null,
        nodeSchema: input.nodeSchema ?? {},
        sourceFiles: {
            'worker.ts': input.sourceFiles?.['worker.ts'] ?? 'export default async () => ({})',
            ...(input.sourceFiles?.['validate.ts'] ? { 'validate.ts': input.sourceFiles['validate.ts'] } : {})
        },
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        modelId: 'user-node-stub'
    }),
    updateWorkflowUserNode: async (params) => ({
        id: params.id,
        userId: 'stub-user',
        name: params.input.name ?? 'Stub User Node',
        slug: params.input.slug ?? 'stub-user-node',
        description: params.input.description ?? null,
        groupName: params.input.groupName ?? null,
        nodeSchema: params.input.nodeSchema ?? {},
        sourceFiles: {
            'worker.ts': params.input.sourceFiles?.['worker.ts'] ?? 'export default async () => ({})',
            ...(params.input.sourceFiles?.['validate.ts'] ? { 'validate.ts': params.input.sourceFiles['validate.ts'] } : {})
        },
        isActive: params.input.isActive ?? true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        modelId: 'user-node-stub'
    }),
    deleteWorkflowUserNode: async () => true
});
