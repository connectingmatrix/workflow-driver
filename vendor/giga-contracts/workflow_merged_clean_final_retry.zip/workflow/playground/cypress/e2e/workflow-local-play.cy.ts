/// <reference types="cypress" />

const TYPESCRIPT_FAILURE_MARKERS = ['TypeScript module is missing transpileModule', '[custom-loader]', '[import("typescript")]'];
const WORKFLOW_IMPORT_PATH = '/Users/abeer/Downloads/0f711eb4-7f83-40db-9928-49ade24c0b42-with-data (1).json';
const STEP_DELAY_MS = 1500;

const assertNoTypescriptBootstrapErrors = (text: string): void => {
    TYPESCRIPT_FAILURE_MARKERS.forEach((marker) => {
        expect(text, `expected logs to not include ${marker}`).not.to.contain(marker);
    });
};

describe('workflow-ui local runtime bootstrap', () => {
    it('imports the provided workflow and runs Play Local without TypeScript transpile bootstrap failures', () => {
        cy.visit('/');
        cy.contains('Workflow UI Playground').should('exist');
        cy.wait(STEP_DELAY_MS);

        cy.get('[data-cy="workflow-import-json-input"]').selectFile(WORKFLOW_IMPORT_PATH, { force: true });
        cy.get('[data-cy="workflow-run-menu"]').should('exist');
        cy.wait(STEP_DELAY_MS);

        cy.window().then((win) => {
            cy.spy(win.console, 'error').as('consoleError');
        });

        cy.get('[data-cy="workflow-run-menu"]').click();
        cy.wait(STEP_DELAY_MS);
        cy.contains('.p-menuitem-text', 'Play Local').click();
        cy.wait(STEP_DELAY_MS);
        cy.get('[data-cy="workflow-run-menu"]', { timeout: 20_000 }).should('exist');
        cy.wait(STEP_DELAY_MS);

        cy.get('button[aria-label="View workflow logs"]').click();
        cy.wait(STEP_DELAY_MS);
        cy.get('.wf-workspace-logs__viewer-scroll', { timeout: 20_000 })
            .should('be.visible')
            .invoke('text')
            .then((jsonl) => {
                expect(jsonl).to.contain('"event":"node.started"');
                expect(jsonl).not.to.contain('"event":"node.failed"');
                assertNoTypescriptBootstrapErrors(jsonl);
                cy.task('log', `Workflow JSONL Logs:\n${jsonl}`);
            });

        cy.get('@consoleError').then((spyObject) => {
            const spy = spyObject as any;
            const mergedErrors = spy.getCalls().map((call) => call.args.map((value) => String(value)).join(' ')).join('\n');
            assertNoTypescriptBootstrapErrors(mergedErrors);
        });
    });
});
