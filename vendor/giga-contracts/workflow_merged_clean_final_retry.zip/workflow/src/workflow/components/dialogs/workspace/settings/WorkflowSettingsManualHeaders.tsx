import React from 'react';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import type { ManualHeaderRow } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';

interface WorkflowSettingsManualHeadersProps {
    readOnly?: boolean;
    manualHeaderRows: ManualHeaderRow[];
    onManualHeaderChange: (rowId: string, key: 'header' | 'value', value: string) => void;
    onAddManualHeader: () => void;
    onRemoveManualHeader: (rowId: string) => void;
}

export const WorkflowSettingsManualHeaders: React.FC<WorkflowSettingsManualHeadersProps> = ({
    readOnly = false,
    manualHeaderRows,
    onManualHeaderChange,
    onAddManualHeader,
    onRemoveManualHeader
}) => (
    <div className="wf-workspace-settings__manual-headers">
        <label className="wf-workspace-settings__field-label">Manual headers</label>
        <span className="wf-workspace-settings__field-note">Add the request headers that should be sent with runtime calls when manual auth is selected.</span>
        {manualHeaderRows.map((row) => (
            <div key={row.id} className="wf-workspace-settings__header-row">
                <InputText value={row.header} onChange={(event) => onManualHeaderChange(row.id, 'header', event.target.value)} readOnly={readOnly} placeholder="Header" className="wf-workspace-settings__input" />
                <InputText value={row.value} onChange={(event) => onManualHeaderChange(row.id, 'value', event.target.value)} readOnly={readOnly} placeholder="Value" className="wf-workspace-settings__input" />
                <Button type="button" icon="pi pi-plus" outlined onClick={onAddManualHeader} aria-label="Add header" disabled={readOnly} />
                <Button type="button" icon="pi pi-minus" outlined onClick={() => onRemoveManualHeader(row.id)} aria-label="Remove header" disabled={readOnly} />
            </div>
        ))}
    </div>
);
