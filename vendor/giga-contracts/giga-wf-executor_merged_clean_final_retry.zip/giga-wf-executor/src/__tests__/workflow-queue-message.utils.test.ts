import { describe, expect, it } from 'vitest';
import { parseWorkflowQueueEvent, parseWorkflowQueueRequest, toWorkflowQueueEventMessage, toWorkflowQueueRequestMessage } from '../queue/workflowQueueMessage';

describe('workflow queue message utils', () => {
  it('preserves broadcast metadata on queue requests', () => {
    const message = toWorkflowQueueRequestMessage({
      executionId: 'execution-1',
      runId: 'run-1',
      queueKey: 'user-1',
      userId: 'user-1',
      broadcastId: 'user-1',
      broadcastChannelName: 'workflow-socket',
      triggerType: 'designer',
      workflowReference: { workflowId: 'workflow-1', scope: 'user', ownerUserId: 'user-1' },
      workflowVersionId: null,
      workflow: { metadata: { id: 'workflow-1', name: 'Workflow 1' }, nodes: [], connections: [] },
      settings: { graphqlUrl: 'http://localhost:3001/api/v2/graphql', authMode: 'auto-from-current-session' },
      requestContext: { mode: 'user', userId: 'user-1', headers: {} },
      metadata: null,
    });

    expect(parseWorkflowQueueRequest(message.value)).toMatchObject({
      broadcastId: 'user-1',
      broadcastChannelName: 'workflow-socket',
      triggerType: 'designer',
    });
  });

  it('preserves broadcast metadata on queue events', () => {
    const message = toWorkflowQueueEventMessage({
      type: 'started',
      timestamp: '2026-04-24T00:00:00.000Z',
      executionId: 'execution-1',
      runId: 'run-1',
      workflowId: 'workflow-1',
      userId: 'user-1',
      broadcastId: 'user-1',
      broadcastChannelName: 'workflow-socket',
      triggerType: 'designer',
      workflowReference: { workflowId: 'workflow-1', scope: 'user', ownerUserId: 'user-1' },
    });

    expect(parseWorkflowQueueEvent(message.value)).toMatchObject({
      broadcastId: 'user-1',
      broadcastChannelName: 'workflow-socket',
      triggerType: 'designer',
    });
  });
});
