import * as ElkBundle from 'elkjs/lib/elk.bundled.js';
import type { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { WORKFLOW_LAYOUT_START_X, WORKFLOW_LAYOUT_START_Y } from '@workflow/ui/workflow/layout/layout-constants';
import { placeElkCommandNodes } from '@workflow/ui/workflow/layout/elk-command-layout';
import { buildElkNode } from '@workflow/ui/workflow/layout/elk-node.utils';

type ElkGraphLayout = { children?: Array<{ id?: string | number; x?: number; y?: number }> };
type ElkLayout = { layout: (graph: object) => Promise<ElkGraphLayout> };
type ElkConstructor = new () => ElkLayout;

const ElkRuntime = ((ElkBundle as { default?: ElkConstructor }).default || (globalThis as typeof globalThis & { ELK?: ElkConstructor }).ELK) as ElkConstructor;
const elk = new ElkRuntime();
const layoutOptions = {
    'elk.algorithm': 'layered',
    'elk.direction': 'RIGHT',
    'elk.edgeRouting': 'ORTHOGONAL',
    'elk.layered.considerModelOrder': 'NODES_AND_EDGES',
    'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
    'elk.layered.spacing.nodeNodeBetweenLayers': '180',
    'elk.spacing.nodeNode': '100',
    'elk.padding': '[top=80,left=120,bottom=80,right=120]'
};

const resolveHandleId = (handleId: string | undefined, fallback: string): string => handleId || fallback;

export const layoutWorkflowWithElk = async (workflow: WorkflowDefinition): Promise<WorkflowDefinition> => {
    if (!(workflow.nodes || []).length) return workflow;
    const graph = await elk.layout({
        id: 'workflow',
        layoutOptions,
        children: workflow.nodes.map((node) => buildElkNode(workflow, node)),
        edges: workflow.connections.map((connection) => ({
            id: connection.id,
            sources: [connection.from],
            targets: [connection.to],
            sourcePort: resolveHandleId(connection.sourceHandle, 'out:output'),
            targetPort: resolveHandleId(connection.targetHandle, 'in:input')
        }))
    });
    const elkPositions = (graph.children || []).reduce<Record<string, { x: number; y: number }>>((record, node) => {
        record[String(node.id)] = { x: Number(node.x || 0), y: Number(node.y || 0) };
        return record;
    }, {});
    const positions = placeElkCommandNodes(workflow, elkPositions);
    const minX = Math.min(...Object.values(positions).map((point) => point.x), 0);
    const minY = Math.min(...Object.values(positions).map((point) => point.y), 0);

    return {
        ...workflow,
        nodes: workflow.nodes.map((node) => ({
            ...node,
            position: positions[node.id] ? { x: WORKFLOW_LAYOUT_START_X + positions[node.id].x - minX, y: WORKFLOW_LAYOUT_START_Y + positions[node.id].y - minY } : node.position
        }))
    };
};
