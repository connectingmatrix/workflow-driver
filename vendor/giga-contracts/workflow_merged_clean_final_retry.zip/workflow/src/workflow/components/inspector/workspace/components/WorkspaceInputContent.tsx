import React from 'react';
import type { WorkspaceInputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { WorkspaceActionButton } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceActionButton';
import JsonViewer from '@workflow/ui/workflow/components/viewers/JsonViewer';

interface WorkspaceInputContentProps {
    model: WorkspaceInputPanelModel;
    onAction: (actionId: string) => void;
}

const renderDocumentation = (model: WorkspaceInputPanelModel): React.ReactNode => {
    const documentation = model.documentation;
    return (
        <div className="cnw-doc-panel">
            <div className="cnw-doc-panel__title">{documentation?.nodeTypeLabel ?? model.nodeTypeLabel}</div>
            <p className="cnw-doc-panel__copy">{documentation?.summary ?? `${model.nodeTypeLabel} workflow node.`}</p>
            <p className="cnw-doc-panel__copy">{documentation?.usage ?? 'No usage notes provided for this node yet.'}</p>
            <div className="cnw-doc-panel__section-title">Inputs</div>
            {documentation?.inputs?.length ? (
                <ul className="cnw-doc-panel__list">
                    {documentation.inputs.map((input) => (
                        <li key={input.key}>
                            <strong>{input.label}</strong>
                            {`: ${input.description}`}
                        </li>
                    ))}
                </ul>
            ) : (
                <div className="cnw-doc-panel__hint">No documented inputs.</div>
            )}
            <div className="cnw-doc-panel__section-title">Outputs</div>
            {documentation?.outputs?.length ? (
                <ul className="cnw-doc-panel__list">
                    {documentation.outputs.map((output) => (
                        <li key={output.key}>
                            <strong>{output.label}</strong>
                            {`: ${output.description}`}
                        </li>
                    ))}
                </ul>
            ) : (
                <div className="cnw-doc-panel__hint">No documented outputs.</div>
            )}
            {documentation?.examples?.length ? (
                <>
                    <div className="cnw-doc-panel__section-title">Examples</div>
                    <div className="cnw-doc-panel__list">
                        {documentation.examples.map((example) => (
                            <div key={example.title} className="cnw-doc-panel__copy">
                                <strong>{example.title}</strong>
                                {example.description ? <div>{example.description}</div> : null}
                                {example.setup ? <pre>{example.setup}</pre> : null}
                                {example.output ? <pre>{example.output}</pre> : null}
                            </div>
                        ))}
                    </div>
                </>
            ) : null}
        </div>
    );
};

export const WorkspaceInputContent: React.FC<WorkspaceInputContentProps> = ({ model, onAction }) => {
    const renderJsonViewer = (value: unknown, label: string, draggableKeys: boolean): React.ReactNode => (
        <div className="cnw-input-json-shell">
            <div className="cnw-json-block">
                <div className="cnw-json-block__toolbar">
                    <span className="cnw-json-block__label">{label}</span>
                </div>
                <div className="cnw-json-block__viewer">
                    <JsonViewer value={value} draggableKeys={draggableKeys} rootPath={label === 'Control Nodes' ? 'controlNodes' : undefined} />
                </div>
            </div>
        </div>
    );

    if (model.activeTab === 'json') {
        return renderJsonViewer(model.jsonValue, 'JSON', true);
    }

    if (model.activeTab === 'document') {
        return renderDocumentation(model);
    }

    if (model.activeTab === 'control-nodes') {
        return renderJsonViewer(model.controlNodes ?? {}, 'Control Nodes', false);
    }

    if (model.tableRows.length === 0) {
        return (
            <div className="cnw-empty-state">
                <div className="cnw-empty-state__icon-shell">
                    <WorkspaceGlyph name={model.emptyState.icon ?? 'document'} className="cnw-empty-state__icon" />
                </div>
                <h4 className="cnw-empty-state__title">{model.emptyState.title}</h4>
                {model.emptyState.description ? <p className="cnw-empty-state__description">{model.emptyState.description}</p> : null}
                {model.emptyState.action ? <WorkspaceActionButton action={model.emptyState.action} onClick={onAction} className="cnw-empty-state__action" /> : null}
            </div>
        );
    }

    return (
        <div className="cnw-table-shell">
            <table className="cnw-table">
                <thead>
                    <tr>
                        <th>Key</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    {model.tableRows.map((row) => (
                        <tr key={row.key}>
                            <td>{row.key}</td>
                            <td>{row.value}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
