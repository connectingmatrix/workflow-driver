/** @vitest-environment jsdom */
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import SettingsDialog from '@workflow/ui/workflow/components/dialogs/SettingsDialog';
import { WorkflowAuthModeEnum } from '@workflow/ui/workflow/types';

afterEach(() => cleanup());

vi.mock('primereact/dialog', () => ({
    Dialog: ({ visible, children }: { visible: boolean; children: React.ReactNode }) => (visible ? <div>{children}</div> : null)
}));

vi.mock('primereact/button', () => ({
    Button: ({ children, label, onClick, icon, 'aria-label': ariaLabel, ...props }: { children?: React.ReactNode; label?: string; onClick?: () => void; icon?: string; 'aria-label'?: string; [key: string]: unknown }) => (
        <button type="button" onClick={onClick} aria-label={ariaLabel} {...props}>
            {icon ? <span aria-hidden>{icon}</span> : null}
            {label ?? children}
        </button>
    )
}));

vi.mock('primereact/dropdown', () => ({
    Dropdown: ({ 'data-cy': dataCy, disabled, onChange, options, value }: { 'data-cy'?: string; disabled?: boolean; onChange?: (event: { value: string | number }) => void; options: Array<{ label: string; value: string | number }>; value: string | number }) => (
        <select data-cy={dataCy} disabled={disabled} value={String(value)} onChange={(event) => onChange?.({ value: Number.isNaN(Number(event.target.value)) ? event.target.value : Number(event.target.value) })}>
            {options.map((option) => (
                <option key={String(option.value)} value={String(option.value)}>
                    {option.label}
                </option>
            ))}
        </select>
    )
}));

vi.mock('primereact/inputtext', () => ({
    InputText: ({ readOnly, value, onChange, placeholder }: { readOnly?: boolean; value: string; onChange?: (event: { target: { value: string } }) => void; placeholder?: string }) => (
        <input readOnly={readOnly} value={value} placeholder={placeholder} onChange={(event) => onChange?.({ target: { value: event.target.value } })} />
    )
}));

vi.mock('primereact/inputtextarea', () => ({
    InputTextarea: ({ readOnly, value, onChange, placeholder }: { readOnly?: boolean; value: string; onChange?: (event: { target: { value: string } }) => void; placeholder?: string }) => (
        <textarea readOnly={readOnly} value={value} placeholder={placeholder} onChange={(event) => onChange?.({ target: { value: event.target.value } })} />
    )
}));

describe('SettingsDialog', () => {
    it('saves the selected max execution timeout', () => {
        const onHide = vi.fn();
        const onSave = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: 'https://example.test/graphql',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {},
                    maxExecutionSeconds: 300
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow A"
                workflowDescription="Desc A"
                onHide={onHide}
                onSave={onSave}
            />
        );

        fireEvent.change(screen.getByDisplayValue('300 seconds'), { target: { value: '50' } });
        fireEvent.click(screen.getByText('Save changes'));

        expect(onSave).toHaveBeenCalledWith(
            expect.objectContaining({
                settings: expect.objectContaining({
                    maxExecutionSeconds: 50
                })
            })
        );
        expect(onHide).toHaveBeenCalled();
    });

    it('defaults max execution timeout to 300 seconds when unset', () => {
        const onSave = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: '',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {}
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow B"
                workflowDescription=""
                onHide={vi.fn()}
                onSave={onSave}
            />
        );

        fireEvent.click(screen.getByText('Save changes'));

        expect(onSave).toHaveBeenCalledWith(
            expect.objectContaining({
                settings: expect.objectContaining({
                    maxExecutionSeconds: 300
                })
            })
        );
    });

    it('serializes manual headers from header and value rows', () => {
        const onSave = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: 'https://example.test/api/v2/graphql',
                    authMode: WorkflowAuthModeEnum.Manual,
                    manualHeaders: {
                        Authorization: 'Bearer abc'
                    },
                    maxExecutionSeconds: 300
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow C"
                workflowDescription=""
                onHide={vi.fn()}
                onSave={onSave}
            />
        );

        fireEvent.change(screen.getByDisplayValue('Authorization'), { target: { value: 'x-org-id' } });
        fireEvent.change(screen.getByDisplayValue('Bearer abc'), { target: { value: 'org_123' } });
        fireEvent.click(screen.getByText('Save changes'));

        expect(onSave).toHaveBeenCalledWith(
            expect.objectContaining({
                settings: expect.objectContaining({
                    manualHeaders: {
                        'x-org-id': 'org_123'
                    }
                })
            })
        );
    });

    it('derives the HTTP base URL from GraphQL when one is not provided', () => {
        const onSave = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: 'https://example.test/api/v2/graphql',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {}
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow D"
                workflowDescription=""
                onHide={vi.fn()}
                onSave={onSave}
            />
        );

        fireEvent.click(screen.getByText('Save changes'));

        expect(onSave).toHaveBeenCalledWith(
            expect.objectContaining({
                settings: expect.objectContaining({
                    httpBaseUrl: 'https://example.test/api/v2'
                })
            })
        );
    });

    it('serializes the selected canvas settings', () => {
        const onSave = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: 'https://example.test/api/v2/graphql',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {}
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow E"
                workflowDescription=""
                onHide={vi.fn()}
                onSave={onSave}
            />
        );

        fireEvent.change(document.querySelector('[data-cy="workflow-settings-layout-engine"]') as Element, { target: { value: 'elk' } });
        fireEvent.change(document.querySelector('[data-cy="workflow-settings-edge-style"]') as Element, { target: { value: 'smoothstep' } });
        fireEvent.click(screen.getByText('Save changes'));

        expect(onSave).toHaveBeenCalledWith(
            expect.objectContaining({
                canvasSettings: {
                    layoutEngine: 'elk',
                    edgeStyle: 'smoothstep'
                }
            })
        );
    });

    it('resets layout with the selected layout engine from settings', () => {
        const onResetLayout = vi.fn();

        render(
            <SettingsDialog
                visible
                settings={{
                    graphqlUrl: 'https://example.test/api/v2/graphql',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {}
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow F"
                workflowDescription=""
                onHide={vi.fn()}
                onSave={vi.fn()}
                onResetLayout={onResetLayout}
            />
        );

        fireEvent.change(document.querySelector('[data-cy="workflow-settings-layout-engine"]') as Element, { target: { value: 'elk' } });
        fireEvent.click(screen.getByRole('button', { name: 'Reset Layout' }));

        expect(onResetLayout).toHaveBeenCalledWith({
            layoutEngine: 'elk',
            edgeStyle: 'legacy'
        });
    });

    it('hides save actions and locks fields in read-only mode', () => {
        render(
            <SettingsDialog
                visible
                readOnly
                settings={{
                    graphqlUrl: 'https://example.test/api/v2/graphql',
                    authMode: WorkflowAuthModeEnum.AutoFromCurrentSession,
                    manualHeaders: {}
                }}
                canvasSettings={{ layoutEngine: 'legacy', edgeStyle: 'legacy' }}
                workflowName="Workflow G"
                workflowDescription="Read only"
                onHide={vi.fn()}
                onSave={vi.fn()}
            />
        );

        expect(screen.queryByText('Save changes')).toBeNull();
        expect(screen.queryByText('Discard')).toBeNull();
        expect(screen.getByDisplayValue('Workflow G')).toHaveAttribute('readonly');
        expect(document.querySelector('[data-cy="workflow-settings-layout-engine"]')).toBeDisabled();
        expect(document.querySelector('[data-cy="workflow-settings-timeout"]')).toBeDisabled();
        expect(screen.getByText('Execution settings are read-only.')).toBeInTheDocument();
    });
});
