import { execFile } from 'node:child_process';
import { mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { promisify } from 'node:util';
import { readDynamicDependencyPolicyFromEnv, validateDynamicDependencies } from './dependency-policy';

const execFileAsync = promisify(execFile);

export type InstallDynamicNodeDependenciesInput = {
  dependencies: string[];
  sandboxRoot: string;
  timeoutMs?: number;
};

export type InstallDynamicNodeDependenciesResult = {
  installed: string[];
  nodeModulesPath: string;
  packageRoot: string;
};

export const installDynamicNodeDependencies = async (
  input: InstallDynamicNodeDependenciesInput,
): Promise<InstallDynamicNodeDependenciesResult> => {
  const policy = validateDynamicDependencies({ ...readDynamicDependencyPolicyFromEnv(), dependencies: input.dependencies });
  if (!policy.ok) throw new Error(policy.denied.map((item) => `${item.dependency}: ${item.reason}`).join('\n'));

  const packageRoot = resolve(input.sandboxRoot, 'dynamic-node-deps');
  await mkdir(packageRoot, { recursive: true });
  if (policy.allowed.length) {
    await execFileAsync('npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', '--package-lock=false', '--prefix', packageRoot, ...policy.allowed], {
      cwd: packageRoot,
      env: { PATH: process.env.PATH || '', HOME: process.env.HOME || '' },
      timeout: input.timeoutMs || 120000,
      windowsHide: true,
    });
  }

  return { installed: policy.allowed, nodeModulesPath: join(packageRoot, 'node_modules'), packageRoot };
};
