import type { WorkflowPubsub, WorkflowPubsubHandler } from './types';

export const createWorkflowPubsub = (): WorkflowPubsub => {
  const listeners = new Map<string, Set<WorkflowPubsubHandler>>();
  const readListeners = (roomName: string) => listeners.get(roomName) || new Set<WorkflowPubsubHandler>();

  return {
    clear: () => listeners.clear(),
    listen: (roomName, handler) => {
      const normalizedRoomName = String(roomName || '').trim();
      if (!normalizedRoomName) return () => undefined;
      const nextListeners = readListeners(normalizedRoomName);
      nextListeners.add(handler);
      listeners.set(normalizedRoomName, nextListeners);
      return () => {
        const currentListeners = listeners.get(normalizedRoomName);
        if (!currentListeners) return;
        currentListeners.delete(handler);
        if (!currentListeners.size) listeners.delete(normalizedRoomName);
      };
    },
    publish: (roomName, eventName, payload) => {
      const normalizedRoomName = String(roomName || '').trim();
      if (!normalizedRoomName) return;
      readListeners(normalizedRoomName).forEach((handler) => {
        handler(normalizedRoomName, { eventName, payload, roomName: normalizedRoomName });
      });
    },
  };
};
