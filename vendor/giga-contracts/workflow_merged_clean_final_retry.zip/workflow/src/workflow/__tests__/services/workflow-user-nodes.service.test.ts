import { beforeEach, describe, expect, it, vi } from 'vitest';

const { graphqlRequestMock } = vi.hoisted(() => ({
    graphqlRequestMock: vi.fn()
}));

vi.mock('@/graphql/client', () => ({
    graphqlRequest: graphqlRequestMock
}));

import { createWorkflowUserNode, deleteWorkflowUserNode, listWorkflowUserNodes, updateWorkflowUserNode } from '@/modules/workflow-driver/services/workflow-user-nodes.service';

const createGraphqlRow = () => ({
    id: 'def_1',
    userId: 'user_1',
    name: 'Custom Node',
    slug: 'custom-node',
    description: 'A custom node',
    groupName: 'User Nodes',
    nodeSchema: { fields: {} },
    sourceFiles: {
        'worker.ts': '  export const execute = async () => ({ output: { ok: true }, status: "passed", logs: [] });  ',
        'validate.ts': ' export const validate = async () => ({ ok: true, errors: [], warnings: [] }); '
    },
    isActive: true,
    createdAt: '2026-03-23T00:00:00.000Z',
    updatedAt: '2026-03-23T00:00:00.000Z',
    modelId: 'user-node:def_1'
});

describe('workflow user node service', () => {
    beforeEach(() => {
        graphqlRequestMock.mockReset();
    });

    it('normalizes and returns user node definitions from list query', async () => {
        graphqlRequestMock.mockResolvedValueOnce({
            workflowUserNodes: [createGraphqlRow()]
        });

        const rows = await listWorkflowUserNodes(false);
        expect(rows).toHaveLength(1);
        expect(rows[0]?.id).toBe('def_1');
        expect(rows[0]?.sourceFiles['worker.ts']).toContain('execute');
        expect(rows[0]?.sourceFiles['validate.ts']).toContain('validate');
    });

    it('passes payloads through create and update mutations', async () => {
        graphqlRequestMock.mockResolvedValueOnce({
            workflowCreateUserNode: createGraphqlRow()
        });
        graphqlRequestMock.mockResolvedValueOnce({
            workflowUpdateUserNode: createGraphqlRow()
        });

        await createWorkflowUserNode({
            name: 'Custom Node',
            sourceFiles: {
                'worker.ts': 'export const execute = async () => ({ output: { ok: true }, status: "passed", logs: [] });'
            }
        });
        await updateWorkflowUserNode({
            id: 'def_1',
            input: {
                name: 'Updated',
                sourceFiles: {
                    'worker.ts': 'export const execute = async () => ({ output: { ok: true }, status: "passed", logs: [] });'
                }
            }
        });

        expect(graphqlRequestMock.mock.calls[0]?.[0]).toContain('mutation WorkflowCreateUserNode');
        expect(graphqlRequestMock.mock.calls[1]?.[0]).toContain('mutation WorkflowUpdateUserNode');
    });

    it('maps delete mutation response to boolean', async () => {
        graphqlRequestMock.mockResolvedValueOnce({
            workflowDeleteUserNode: {
                id: 'def_1',
                deleted: true
            }
        });

        const deleted = await deleteWorkflowUserNode('def_1');
        expect(deleted).toBe(true);
    });
});
