import fs from 'node:fs';
import fsPromises from 'node:fs/promises';
import path from 'node:path';
import { builtinModules, createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import ivm from 'isolated-vm';
import ts from 'typescript';

const BLOCKED_BUILTINS = new Set(['child_process', 'node:child_process']);
const FS_SPECIFIERS = new Set(['fs', 'node:fs']);
const FS_PROMISES_SPECIFIERS = new Set(['fs/promises', 'node:fs/promises']);
const NODE_BUILTIN_SET = new Set(builtinModules.flatMap((entry) => [entry, entry.startsWith('node:') ? entry.slice(5) : `node:${entry}`]));
const FUNCTION_BRIDGE_MODE = Symbol('workflow.executor.functionBridgeMode');

const waitForRunRequest = (readyType = 'ready') =>
    new Promise((resolve, reject) => {
        const onMessage = (message) => {
            if (message && message.type === 'run') {
                cleanup();
                resolve(message);
                return;
            }
            if (message && message.type === 'shutdown') {
                cleanup();
                resolve(null);
            }
        };
        const onDisconnect = () => {
            cleanup();
            reject(new Error('Sandbox parent disconnected before sending run payload.'));
        };
        const cleanup = () => {
            process.off('message', onMessage);
            process.off('disconnect', onDisconnect);
        };
        process.on('message', onMessage);
        process.on('disconnect', onDisconnect);
        void sendProcessMessage({ type: readyType }).catch((error) => {
            cleanup();
            reject(error);
        });
    });

const sendProcessMessage = async (message) =>
    await new Promise((resolve, reject) => {
        if (typeof process.send !== 'function') {
            resolve();
            return;
        }
        process.send(message, (error) => {
            if (error) {
                reject(error);
                return;
            }
            resolve();
        });
    });

const waitForProcessDrain = async () =>
    await new Promise((resolve) => {
        setTimeout(resolve, 25);
    });

const materializeFetchBody = async (value) => {
    if (!value || typeof value === 'string' || Buffer.isBuffer(value) || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
        return value;
    }
    const record = toRecord(value);
    if (record.__wfBodyType === 'url-search-params') {
        return new URLSearchParams(Array.isArray(record.entries) ? record.entries : []);
    }
    if (record.__wfBodyType === 'blob') {
        return new Blob([Uint8Array.from(Array.isArray(record.bytes) ? record.bytes : [])], { type: typeof record.type === 'string' ? record.type : '' });
    }
    if (record.__wfBodyType === 'form-data') {
        const form = new FormData();
        const entries = Array.isArray(record.entries) ? record.entries : [];
        entries.forEach((entry) => {
            const item = toRecord(entry);
            const name = typeof item.name === 'string' ? item.name : '';
            if (!name) return;
            if (item.kind === 'file') {
                form.append(name, new Blob([Uint8Array.from(Array.isArray(item.bytes) ? item.bytes : [])], { type: typeof item.type === 'string' ? item.type : '' }), typeof item.filename === 'string' ? item.filename : 'attachment.bin');
                return;
            }
            form.append(name, typeof item.value === 'string' ? item.value : String(item.value ?? ''));
        });
        return form;
    }
    return value;
};

const createFetchResponseRecord = async (response) => ({
    ok: response.ok,
    status: response.status,
    statusText: response.statusText,
    url: response.url,
    redirected: response.redirected,
    headers: [...response.headers.entries()],
    bodyText: await response.text()
});

const WEB_RUNTIME_SHIM_SOURCE = `
class Headers {
  constructor(init = undefined) {
    this._entries = [];
    if (init instanceof Headers) init.entriesArray().forEach(([key, value]) => this.append(key, value));
    else if (Array.isArray(init)) init.forEach((entry) => Array.isArray(entry) && this.append(entry[0], entry[1]));
    else if (init && typeof init === 'object') Object.entries(init).forEach(([key, value]) => this.append(key, value));
  }
  append(name, value) { this._entries.push([String(name).toLowerCase(), String(value)]); }
  set(name, value) { const key = String(name).toLowerCase(); this._entries = this._entries.filter(([entry]) => entry !== key); this.append(key, value); }
  get(name) { const key = String(name).toLowerCase(); const match = this._entries.find(([entry]) => entry === key); return match ? match[1] : null; }
  has(name) { return this.get(name) !== null; }
  entries() { return this._entries[Symbol.iterator](); }
  entriesArray() { return [...this._entries]; }
  forEach(callback, thisArg = undefined) { this._entries.forEach(([key, value]) => callback.call(thisArg, value, key, this)); }
  [Symbol.iterator]() { return this.entries(); }
}
class AbortSignal { constructor() { this.aborted = false; this.reason = undefined; } }
class AbortController { constructor() { this.signal = new AbortSignal(); } abort(reason = undefined) { this.signal.aborted = true; this.signal.reason = reason; } }
class URLSearchParams {
  constructor(init = undefined) {
    this._entries = [];
    if (init instanceof URLSearchParams) init.entriesArray().forEach(([key, value]) => this.append(key, value));
    else if (Array.isArray(init)) init.forEach((entry) => Array.isArray(entry) && this.append(entry[0], entry[1]));
    else if (init && typeof init === 'object') Object.entries(init).forEach(([key, value]) => this.append(key, value));
  }
  append(key, value) { this._entries.push([String(key), String(value)]); }
  set(key, value) { const name = String(key); this._entries = this._entries.filter(([entry]) => entry !== name); this.append(name, value); }
  entries() { return this._entries[Symbol.iterator](); }
  entriesArray() { return [...this._entries]; }
  toString() { return this._entries.map(([key, value]) => \`\${encodeURIComponent(key)}=\${encodeURIComponent(value)}\`).join('&'); }
  [Symbol.iterator]() { return this.entries(); }
}
class Blob {
  constructor(parts = [], options = {}) { this._parts = Array.isArray(parts) ? parts : [parts]; this.type = typeof options.type === 'string' ? options.type : ''; }
  async text() { return this._parts.map((entry) => typeof entry === 'string' ? entry : ArrayBuffer.isView(entry) ? Array.from(entry).map((byte) => String.fromCharCode(byte)).join('') : '').join(''); }
  async arrayBuffer() { const text = await this.text(); const bytes = Uint8Array.from(Array.from(text).map((entry) => entry.charCodeAt(0))); return bytes.buffer; }
}
class FormData {
  constructor() { this._entries = []; }
  append(name, value, filename = undefined) {
    if (value instanceof Blob) { this._entries.push({ kind: 'file', name: String(name), filename: typeof filename === 'string' ? filename : 'attachment.bin', type: value.type || '', blob: value }); return; }
    this._entries.push({ kind: 'field', name: String(name), value: String(value) });
  }
}
class Response {
  constructor(record) {
    this.ok = !!record.ok;
    this.status = Number(record.status || 0);
    this.statusText = typeof record.statusText === 'string' ? record.statusText : '';
    this.url = typeof record.url === 'string' ? record.url : '';
    this.redirected = !!record.redirected;
    this.headers = new Headers(Array.isArray(record.headers) ? record.headers : []);
    this._bodyText = typeof record.bodyText === 'string' ? record.bodyText : '';
  }
  async text() { return this._bodyText; }
  async json() { return JSON.parse(this._bodyText || 'null'); }
}
class Request { constructor(input, init = {}) { this.url = typeof input === 'string' ? input : input?.url || ''; this.method = init.method || 'GET'; this.headers = new Headers(init.headers); this.body = init.body; this.signal = init.signal; } }
const serializeBody = async (body) => {
  if (body == null || typeof body === 'string') return body;
  if (body instanceof URLSearchParams) return { __wfBodyType: 'url-search-params', entries: body.entriesArray() };
  if (body instanceof Blob) return { __wfBodyType: 'blob', type: body.type || '', bytes: Array.from(new Uint8Array(await body.arrayBuffer())) };
  if (body instanceof FormData) return { __wfBodyType: 'form-data', entries: await Promise.all(body._entries.map(async (entry) => entry.kind === 'file' ? ({ kind: 'file', name: entry.name, filename: entry.filename, type: entry.type, bytes: Array.from(new Uint8Array(await entry.blob.arrayBuffer())) }) : entry)) };
  return body;
};
globalThis.Headers = globalThis.Headers || Headers;
globalThis.AbortController = globalThis.AbortController || AbortController;
globalThis.URLSearchParams = globalThis.URLSearchParams || URLSearchParams;
globalThis.Blob = globalThis.Blob || Blob;
globalThis.FormData = globalThis.FormData || FormData;
globalThis.Request = globalThis.Request || Request;
globalThis.Response = globalThis.Response || Response;
globalThis.fetch = async (input, init = {}) => {
  const request = input instanceof Request ? { url: input.url, method: input.method, headers: input.headers, body: input.body, signal: input.signal } : { url: typeof input === 'string' ? input : input?.url || String(input), ...init };
  if (request.signal?.aborted) throw request.signal.reason || new Error('The operation was aborted.');
  const response = await globalThis.__wf_fetch.apply(undefined, [request.url, { ...request, headers: request.headers instanceof Headers ? request.headers.entriesArray() : request.headers, body: await serializeBody(request.body), signal: request.signal ? { aborted: !!request.signal.aborted, reason: request.signal.reason } : null }], { arguments: { copy: true }, result: { promise: true, copy: true } });
  return new Response(response);
};
`;

const createRequestReplyChannel = () => {
    let nextId = 0;
    const pending = new Map();

    process.on('message', (message) => {
        if (!message || message.type !== 'helper_response') return;
        const entry = pending.get(message.callId);
        if (!entry) return;
        pending.delete(message.callId);
        if (message.ok) {
            entry.resolve(message.value ?? null);
            return;
        }
        entry.reject(new Error(typeof message.error === 'string' && message.error.length > 0 ? message.error : 'Sandbox helper call failed.'));
    });

    return {
        async call(helper, args) {
            const callId = `sandbox-${Date.now().toString(36)}-${(nextId += 1).toString(36)}`;
            return await new Promise((resolve, reject) => {
                pending.set(callId, { resolve, reject });
                void sendProcessMessage({
                    type: 'helper_request',
                    callId,
                    helper,
                    args
                }).catch((error) => {
                    pending.delete(callId);
                    reject(error);
                });
            });
        }
    };
};

const toRecord = (value) => (value && typeof value === 'object' && !Array.isArray(value) ? value : {});

const normalizeStatus = (status) => {
    if (status === 'failed') return 'failed';
    if (status === 'warning') return 'warning';
    if (status === 'running') return 'running';
    if (status === 'stopped') return 'stopped';
    return 'passed';
};

const normalizeResult = (result) => {
    if (!result || typeof result !== 'object' || Array.isArray(result)) {
        return {
            output: result ?? null,
            status: 'passed',
            logs: []
        };
    }

    const record = result;
    const logs = Array.isArray(record.logs)
        ? record.logs.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
        : [];

    return {
        output: Object.prototype.hasOwnProperty.call(record, 'output') ? record.output : record,
        status: normalizeStatus(record.status),
        logs,
        ...(record.skipCommandPeerAutoRun === true ? { skipCommandPeerAutoRun: true } : {})
    };
};

const toErrorResult = (message, logs = [], previewValidation = null) => ({
    output: { error: String(message) },
    status: 'failed',
    logs: [...logs, String(message)],
    previewValidation
});

const normalizeValidationResult = (result) => {
    if (result === true || typeof result === 'undefined') {
        return { ok: true, errors: [], warnings: [] };
    }

    if (result === false) {
        return {
            ok: false,
            errors: ['Worker validation failed.'],
            warnings: []
        };
    }

    const record = toRecord(result);
    return {
        ok: typeof record.ok === 'boolean' ? record.ok : true,
        errors: Array.isArray(record.errors)
            ? record.errors.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
            : [],
        warnings: Array.isArray(record.warnings)
            ? record.warnings.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
            : [],
        normalizedRuntime: toRecord(record.normalizedRuntime)
    };
};

const normalizeUpdateResult = (result) => {
    if (result === false) {
        return {
            ok: false,
            error: 'Worker onUpdate returned false.'
        };
    }

    if (result === true || typeof result === 'undefined') {
        return { ok: true };
    }

    const record = toRecord(result);
    return {
        ok: typeof record.ok === 'boolean' ? record.ok : true,
        error: typeof record.error === 'string' ? record.error : undefined
    };
};

const mergePreviewValidation = (base, next) => {
    const warnings = [...(base?.warnings ?? []), ...(next.warnings ?? [])];
    const errors = [...(base?.errors ?? []), ...(next.errors ?? [])];
    return {
        ok: (base?.ok ?? true) && next.ok,
        warnings,
        errors,
        normalizedRuntime: Object.keys(next.normalizedRuntime ?? {}).length > 0 ? next.normalizedRuntime : base?.normalizedRuntime
    };
};

const toNodePortsFacade = (node) => {
    const portsIn = toRecord(node.ports?.in);
    const portsOut = toRecord(node.ports?.out);
    const facade = {
        IN: portsIn,
        OUT: portsOut
    };

    Object.entries(portsIn).forEach(([portId, value]) => {
        facade[portId.toUpperCase()] = value;
    });

    return facade;
};

const BI_DIRECTIONAL_PORT_TYPE = 'bi-directional';

const parseHandle = (handle) => {
    if (!handle || typeof handle !== 'string') return { prefix: '', portName: null };
    const [prefix, rawPortName] = handle.split(':');
    return {
        prefix: prefix?.trim() ?? '',
        portName: rawPortName?.trim() ? rawPortName.trim() : null
    };
};

const toPortRules = (value) => (value && typeof value === 'object' && !Array.isArray(value) ? value : {});

const getNodeSchema = (workflow, nodeId) => {
    const node = workflow.nodes.find((entry) => entry.id === nodeId);
    if (!node) return null;
    const schema = workflow.nodeModels?.[node.modelId];
    return schema && typeof schema === 'object' && !Array.isArray(schema) ? schema : null;
};

const getNormalizedCommandPorts = (schema) => {
    if (!schema) return {};
    const explicitCommands = toPortRules(schema.commands);
    const inputs = toPortRules(schema.inputs);
    const outputs = toPortRules(schema.outputs);
    const normalized = { ...explicitCommands };
    const mergeLegacy = (portId, rules, side) => {
        if (!rules || rules.portType !== BI_DIRECTIONAL_PORT_TYPE) return;
        const existing = normalized[portId] ?? {};
        normalized[portId] = {
            ...rules,
            ...existing,
            side: existing.side ?? rules.side ?? side,
            portType: BI_DIRECTIONAL_PORT_TYPE
        };
    };
    Object.entries(inputs).forEach(([portId, rules]) => mergeLegacy(portId, rules, 'left'));
    Object.entries(outputs).forEach(([portId, rules]) => mergeLegacy(portId, rules, 'right'));
    return normalized;
};

const isCommandPortId = (schema, portId) => Boolean(portId) && Object.prototype.hasOwnProperty.call(getNormalizedCommandPorts(schema), portId);

const getLegacyPortType = (schema, direction, portId) => {
    if (!schema || !portId) return undefined;
    return toPortRules(schema[direction])[portId]?.portType;
};

const parseInputPortName = (connection) => parseHandle(connection.targetHandle).portName ?? 'input';
const parseOutputPortName = (connection) => parseHandle(connection.sourceHandle).portName ?? 'output';

const resolveCommandPortIdFromHandle = (schema, handle, direction, fallbackPort) => {
    const parsed = parseHandle(handle);
    if (parsed.prefix === 'cmd' && isCommandPortId(schema, parsed.portName)) return parsed.portName;
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && isCommandPortId(schema, parsed.portName)) return parsed.portName;
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && getLegacyPortType(schema, direction, parsed.portName) === BI_DIRECTIONAL_PORT_TYPE) return parsed.portName;
    if (!parsed.portName && fallbackPort && isCommandPortId(schema, fallbackPort)) return fallbackPort;
    return null;
};

const getCommandConnectionPortId = (workflow, connection, nodeId) => {
    const sourceSchema = getNodeSchema(workflow, connection.from);
    const targetSchema = getNodeSchema(workflow, connection.to);
    const sourcePortId = resolveCommandPortIdFromHandle(sourceSchema, connection.sourceHandle, 'outputs', parseOutputPortName(connection));
    const targetPortId = resolveCommandPortIdFromHandle(targetSchema, connection.targetHandle, 'inputs', parseInputPortName(connection));
    if (!sourcePortId || !targetPortId) return null;
    if (nodeId === connection.to) return targetPortId;
    if (nodeId === connection.from) return sourcePortId;
    return sourcePortId;
};

const buildPeerKeys = (nodes) => {
    const counts = new Map();
    nodes.forEach((node) => counts.set(node.name, (counts.get(node.name) ?? 0) + 1));
    return new Map(nodes.map((node) => [node.id, (counts.get(node.name) ?? 0) > 1 ? `${node.name}__${node.id.slice(0, 8)}` : node.name]));
};

const createControlNodeSpecs = (context) => {
    const schema = getNodeSchema(context.workflow, context.node.id);
    const commands = getNormalizedCommandPorts(schema);
    return Object.keys(commands).reduce((acc, commandPortId) => {
        const peers = context.workflow.connections
            .filter((connection) => {
                if (connection.from !== context.node.id && connection.to !== context.node.id) return false;
                return getCommandConnectionPortId(context.workflow, connection, context.node.id) === commandPortId;
            })
            .map((connection) => {
                const peerId = connection.from === context.node.id ? connection.to : connection.from;
                return context.workflow.nodes.find((node) => node.id === peerId);
            })
            .filter((node, index, list) => node && list.findIndex((entry) => entry?.id === node.id) === index);
        const peerKeys = buildPeerKeys(peers);
        acc[commandPortId] = peers.reduce((group, peerNode) => {
            const key = peerKeys.get(peerNode.id) ?? peerNode.name;
            group[key] = peerNode.id;
            return group;
        }, {});
        return acc;
    }, {});
};

const toNodeFacade = (node, credential = null, controlNodes = {}) => ({
    ...node,
    PORTS: toNodePortsFacade(node),
    PROPERTIES: toRecord(node.runtime),
    OUTPUT: toRecord(node.ports?.out).output ?? null,
    CREDENTIAL: credential ?? null,
    CONTROL_NODES: controlNodes
});

const buildWorkerPayload = (context, scope, outputValue, runtimeEnvironment, nodeOverride, controlNodes = {}) => {
    const node = nodeOverride ?? context.node;
    const executionNode = {
        ...node,
        ports: {
            in: Object.keys(context.input ?? {}).length > 0 ? context.input : toRecord(node.ports?.in),
            out: toRecord(node.ports?.out)
        }
    };
    const workflowMetadata = {
        ...(context.workflow.metadata ?? {}),
        runtime: {
            ...toRecord(context.workflow.metadata?.runtime),
            settings: context.settings
        }
    };

    return {
        workflow: {
            ...context.workflow,
            metadata: workflowMetadata
        },
        ENVIRONMENT: runtimeEnvironment,
        EXECUTOR: {
            environment: runtimeEnvironment
        },
        HOST_CONTEXT: context.hostContext,
        NODE_SCOPE: scope,
        NODE: toNodeFacade(executionNode, context.credential ?? null, controlNodes),
        self: {
            status: node.status,
            PORTS: executionNode.ports,
            OUTPUT: outputValue
        }
    };
};

const toRuntimePatchedNode = (node, normalizedRuntime) => {
    if (!normalizedRuntime || Object.keys(normalizedRuntime).length === 0) return node;
    return {
        ...node,
        runtime: {
            ...(node.runtime ?? {}),
            ...normalizedRuntime
        }
    };
};

const isValidIdentifier = (value) => /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(value);

const createBridgeCloneSource = () => `
const __cloneBridgeArg = (value) => {
  if (value == null) return value;
  if (typeof value === 'function') return undefined;
  if (Array.isArray(value)) {
    const entries = [];
    for (let index = 0; index < value.length; index += 1) {
      entries.push(__cloneBridgeArg(value[index]));
    }
    return entries;
  }
  if (value instanceof Date) return new Date(value.getTime());
	  if (typeof value === 'object') {
	    const record = {};
	    for (const [key, entry] of Object.entries(value)) {
	      const next = __cloneBridgeArg(entry);
	      if (typeof next !== 'undefined') {
	        record[key] = next;
      }
    }
    return record;
  }
  return value;
};

const __cloneBridgeArgs = (args) => {
  const entries = [];
  for (let index = 0; index < args.length; index += 1) {
    entries.push(__cloneBridgeArg(args[index]));
  }
  return entries;
};
`;

const createVirtualExecuteModuleSource = () => `
${createBridgeCloneSource()}
export const executeGigaService = (...args) => globalThis.__wf_executeGigaService.apply(undefined, __cloneBridgeArgs(args), {
  arguments: { copy: true },
  result: { promise: true, copy: true }
});
export const executeBackend = (...args) => executeGigaService(...args);
export const invokeConnectedNode = (...args) => globalThis.__wf_invokeConnectedNode.apply(undefined, __cloneBridgeArgs(args), {
  arguments: { copy: true },
  result: { promise: true, copy: true }
});
export const updateNode = (...args) => globalThis.__wf_updateNode.apply(undefined, __cloneBridgeArgs(args), {
  arguments: { copy: true },
  result: { promise: true, copy: true }
});
export const compileWorkflowCypher = (...args) => globalThis.__wf_compileWorkflowCypher.apply(undefined, __cloneBridgeArgs(args), {
  arguments: { copy: true },
  result: { promise: true, copy: true }
});
`;

const createWorkerInvokerModuleSource = (workerSpecifier, validatorSpecifier) => `
import * as __workerModule from ${JSON.stringify(workerSpecifier)};
${validatorSpecifier ? `import * as __validatorModule from ${JSON.stringify(validatorSpecifier)};` : `const __validatorModule = null;`}

${createBridgeCloneSource()}
const __callBridge = (ref, args) => ref.apply(undefined, __cloneBridgeArgs(args), {
  arguments: { copy: true },
  result: { promise: true, copy: true }
});

const __toRecord = (value) => (value && typeof value === 'object' && !Array.isArray(value) ? value : {});

const __buildControlNodes = (specs) => {
  const groups = {};
  const specRecord = __toRecord(specs);
  for (const [portId, peers] of Object.entries(specRecord)) {
    const peerRecord = __toRecord(peers);
    const group = {};
    for (const [peerKey, peerNodeId] of Object.entries(peerRecord)) {
      group[peerKey] = {
        get: () => __callBridge(globalThis.__wf_controlNodeGet, [peerNodeId]),
        getSchema: () => __callBridge(globalThis.__wf_controlNodeGetSchema, [peerNodeId]),
        set: (patch) => __callBridge(globalThis.__wf_controlNodeSet, [peerNodeId, patch]),
        validate: (args) => __callBridge(globalThis.__wf_controlNodeValidate, [peerNodeId, args ?? null]),
        executeInputs: (args) => __callBridge(globalThis.__wf_controlNodeExecuteInputs, [peerNodeId, args ?? null]),
        commandToolSpec: () => __callBridge(globalThis.__wf_controlNodeCommandToolSpec, [peerNodeId]),
        execute: (args) => __callBridge(globalThis.__wf_controlNodeExecute, [peerNodeId, args ?? null])
      };
    }
    groups[portId] = group;
  }
  return groups;
};

const __withControlNodes = (payload, controlNodeSpecs) => ({
  ...payload,
  NODE: {
    ...__toRecord(payload?.NODE),
    CONTROL_NODES: __buildControlNodes(controlNodeSpecs)
  }
});

const __requireWorkerExport = (exportName) => {
  const candidate = __workerModule?.[exportName];
  if (typeof candidate !== 'function') {
    throw new Error(\`Worker export "\${exportName}" is missing.\`);
  }
  return candidate;
};

const __resolveValidatorExport = () => {
  if (!__validatorModule) return null;
  if (typeof __validatorModule.validate === 'function') return __validatorModule.validate;
  if (typeof __validatorModule.default === 'function') return __validatorModule.default;
  return null;
};

export const invokeWorkerValidate = async (payload, controlNodeSpecs) => await __requireWorkerExport('validate')(__withControlNodes(payload, controlNodeSpecs));
export const invokeWorkerInit = async (payload, controlNodeSpecs) => await __requireWorkerExport('init')(__withControlNodes(payload, controlNodeSpecs));
export const invokeWorkerOnUpdate = async (payload, controlNodeSpecs) => await __requireWorkerExport('onUpdate')(__withControlNodes(payload, controlNodeSpecs));
export const invokeWorkerExecute = async (payload, controlNodeSpecs) => await __requireWorkerExport('execute')(__withControlNodes(payload, controlNodeSpecs));
export const invokeWorkerCommandToolSpec = async (payload, controlNodeSpecs) => {
  const candidate = __workerModule?.commandToolSpec;
  if (typeof candidate !== 'function') return null;
  return await candidate(__withControlNodes(payload, controlNodeSpecs));
};
export const invokeValidatorValidate = async (payload, controlNodeSpecs) => {
  const validator = __resolveValidatorExport();
  if (!validator) return undefined;
  return await validator(__withControlNodes(payload, controlNodeSpecs));
};
`;

const createVirtualExecutorModuleSource = () => `
const toRecord = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const parseStringValue = (value) => String(value ?? '').trim();
const parseJsonValue = (value) => {
  if (typeof value !== 'string') return value;
  const normalized = value.trim();
  if (!normalized) return {};
  try {
    return JSON.parse(normalized);
  } catch {
    return {};
  }
};
const parseBooleanValue = (value, fallback) => {
  if (typeof value === 'boolean') return value;
  const normalized = parseStringValue(value).toLowerCase();
  if (!normalized) return fallback;
  return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
};
const WORKFLOW_CONTEXT_PATTERN = /\\b(workflow|node|cypher|execute|run)\\b/i;
const CHAT_PARITY_CONTEXT_PATTERN = /\\b(chat parity|chat pipeline|giga|agent action|action node|backend action|run-[a-z0-9-]+)\\b/i;
export const workflowPlannerContext = (message) => {
  const text = parseStringValue(message);
  if (!WORKFLOW_CONTEXT_PATTERN.test(text)) return '';
  const lower = text.toLowerCase();
  const hints = [
    'Workflow Cypher authoring context:',
    'Use Workflow for creation, update, publish, fetch, and delete operations. Use Execute Workflow for published execution.',
    'If the user asks to create and execute, plan Workflow with publishAfterSave=true, then Execute Workflow using workflowActionId from the prior Workflow action id.',
    'Cypher grammar:',
    '(alias:modelId {"name":"Name","runtime":{...}})',
    '(from)-[:CONNECT {"source":"out:output","target":"in:input"}]->(to)',
    'Executable workflows require exactly one start node and at least one respond-end node.',
    'Hello world template:',
    '(start:start {"name":"Start","runtime":{}})',
    '(hello:code {"name":"Hello World","runtime":{"code":"return \\"hello world\\";"}})',
    '(end:respond-end {"name":"Respond End","runtime":{"response":"{{hello.output}}"}})',
    '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(hello)',
    '(hello)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)'
  ];
  if (CHAT_PARITY_CONTEXT_PATTERN.test(lower)) {
    hints.push(
      'For chat action parity, use current-chat for input, context, history, and pending state bundles.',
      'Use text-analysis for confirmation, workflow-request, explanation, reference-sync, and workflow-followup detection.',
      'Use ai-governor with executionMode "plan-only"; it must not execute tools before Planner confirmation policy runs.',
      'Use grouped Action Router nodes as AI Governor tools only for Channel, Category, Subject, Post, User Tree, and Chat actions.',
      'Connect grouped action nodes into Action Router on cmd:actions. Approved plans should target router node ids and pass input.action plus input.actionInput.',
      'Use output-format with AI formatting for chat responses, then respond-end.'
    );
  }
  return hints.join('\\n');
};
const normalizeStatus = (status) => {
  if (status === 'failed') return 'failed';
  if (status === 'warning') return 'warning';
  if (status === 'running') return 'running';
  if (status === 'stopped') return 'stopped';
  return 'passed';
};
export const WorkflowNodeStatusEnum = {
  Passed: 'passed',
  Failed: 'failed',
  Warning: 'warning',
  Running: 'running',
  Stopped: 'stopped'
};
export const normalizeResult = (result) => {
  if (!result || typeof result !== 'object' || Array.isArray(result)) {
    return { output: result ?? null, status: 'passed', logs: [] };
  }
  const record = result;
  const logs = Array.isArray(record.logs)
    ? record.logs.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
    : [];
  return {
    output: Object.prototype.hasOwnProperty.call(record, 'output') ? record.output : record,
    status: normalizeStatus(record.status),
    logs
  };
};
export const toErrorResult = (message, logs = []) => ({
  output: { error: String(message) },
  status: 'failed',
  logs: [...logs, String(message)]
});
export const toNode = (payload) => toRecord(toRecord(payload).NODE);
const isWorkflowExecutionHostContext = (value) => typeof toRecord(value).executeWorkflowReference === 'function';
const isWorkflowManagementHostContext = (value) =>
  typeof toRecord(value).listWorkflowDefinitions === 'function' ||
  typeof toRecord(value).getWorkflowDefinition === 'function' ||
  typeof toRecord(value).saveWorkflowDefinition === 'function' ||
  typeof toRecord(value).deleteWorkflowDefinition === 'function' ||
  typeof toRecord(value).publishWorkflowDefinition === 'function';
export const getWorkflowExecutionHostContext = (hostContext) => {
  if (isWorkflowExecutionHostContext(hostContext)) return hostContext;
  const nested = toRecord(hostContext).workflows;
  return isWorkflowExecutionHostContext(nested) ? nested : null;
};
export const getWorkflowManagementHostContext = (hostContext) => {
  if (isWorkflowManagementHostContext(hostContext)) return hostContext;
  const nested = toRecord(hostContext).workflows;
  return isWorkflowManagementHostContext(nested) ? nested : null;
};
const normalizeWorkflowMcpRuntime = (runtime) => {
  const record = toRecord(runtime);
  const maxLoopPasses = Number(record.maxLoopPasses ?? 3);
  return {
    credentialId: parseStringValue(record.credentialId),
    capabilityQuery: parseStringValue(record.capabilityQuery),
    outputContract: toRecord(parseJsonValue(record.outputContract)),
    forwardNonMcpWork: parseBooleanValue(record.forwardNonMcpWork, true),
    loopNonMcpWork: parseBooleanValue(record.loopNonMcpWork, true),
    maxLoopPasses: Math.max(1, Math.min(6, Math.round(Number.isFinite(maxLoopPasses) ? maxLoopPasses : 3)))
  };
};
const resolveWorkflowMcpCredentialServer = (credential) => {
  const values = toRecord(credential?.values);
  const servers = toRecord(values.mcpServers);
  const entries = Object.entries(servers);
  if (!entries.length) {
    throw new Error('Selected MCP credential does not define an MCP server.');
  }
  const [serverKey, serverValue] = entries[0];
  const config = toRecord(serverValue);
  const transport = parseStringValue(config.type);
  const serverUrl = parseStringValue(config.url);
  if (!parseStringValue(serverKey)) {
    throw new Error('Selected MCP credential is missing the server key.');
  }
  if (transport !== 'streamable-http') {
    throw new Error('Selected MCP credential must use "streamable-http".');
  }
  if (!serverUrl) {
    throw new Error('Selected MCP credential is missing the server URL.');
  }
  return {
    serverKey,
    serverUrl,
    transport: 'streamable-http',
    headers: toRecord(config.headers)
  };
};
export const validateWorkflowMcpRuntime = (runtime) => {
  const record = toRecord(runtime);
  const normalized = normalizeWorkflowMcpRuntime(runtime);
  const errors = [];
  if (!normalized.credentialId) errors.push('MCP credential is required.');
  if (parseStringValue(record.maxLoopPasses) && (Number(record.maxLoopPasses) < 1 || Number(record.maxLoopPasses) > 6 || !Number.isFinite(Number(record.maxLoopPasses)))) {
    errors.push('Max Loop Passes must be between 1 and 6.');
  }
  return { ok: errors.length === 0, errors, normalizedRuntime: normalized };
};
export const getWorkflowMcpRuntimeManager = (hostContext) => {
  const nested = toRecord(toRecord(hostContext).mcp);
  if (typeof nested.resolveNodeServer === 'function' && typeof nested.listTools === 'function' && typeof nested.callTool === 'function') {
    return nested;
  }
  throw new Error('MCP runtime manager is not available in worker host context.');
};
const resolveWorkflowMcpToolCall = (input) => {
  const payload = toRecord(input);
  const candidates = [];
  const skipKeys = new Set(['payload', 'toolName', 'toolArguments', 'current', 'input']);
  const appendCandidate = (value, source) => {
    const record = toRecord(value);
    const envelope = toRecord(record.payload);
    const toolName = parseStringValue(record.toolName || envelope.toolName);
    if (!toolName) return;
    const directArguments = toRecord(record.toolArguments);
    candidates.push({
      source,
      toolName,
      toolArguments: Object.keys(directArguments).length > 0 ? directArguments : toRecord(envelope.toolArguments)
    });
  };
  appendCandidate(payload, 'root');
  appendCandidate(payload.current, 'current');
  appendCandidate(payload.input, 'input');
  Object.entries(toRecord(payload.input)).forEach(([key, value]) => appendCandidate(value, 'input.' + key));
  Object.entries(toRecord(payload.current)).forEach(([key, value]) => appendCandidate(value, 'current.' + key));
  Object.entries(payload).forEach(([key, value]) => {
    if (skipKeys.has(key)) return;
    appendCandidate(value, key);
  });
  if (candidates.length > 1) {
    return {
      payload,
      toolName: '',
      toolArguments: {},
      error: 'Received multiple MCP tool call candidates from ' + candidates.map((candidate) => candidate.source).join(', ') + '. Keep exactly one upstream MCP tool payload.'
    };
  }
  if (!candidates.length) {
    return {
      payload,
      toolName: '',
      toolArguments: {},
      error: ''
    };
  }
  const candidate = candidates[0];
  return {
    payload,
    toolName: candidate?.toolName || '',
    toolArguments: candidate?.toolArguments || {},
    error: ''
  };
};
const resolveWorkflowMcpServer = (manager, runtime, credential) => {
  const serverConfig = resolveWorkflowMcpCredentialServer(credential);
  const server = manager.resolveNodeServer({
    credentialId: runtime.credentialId,
    serverKey: serverConfig.serverKey,
    serverUrl: serverConfig.serverUrl,
    transport: serverConfig.transport,
    headers: serverConfig.headers
  });
  if (!server) throw new Error('MCP server configuration could not be resolved.');
  return server;
};
export const executeWorkflowMcpCapabilitiesNode = async (params) => {
  const runtime = normalizeWorkflowMcpRuntime(params.runtime);
  const listed = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential || null) });
  return {
    output: {
      capabilityQuery: runtime.capabilityQuery,
      tools: listed.tools,
      capabilities: listed.capabilities,
      serverInfo: listed.serverInfo,
      protocolVersion: listed.protocolVersion,
      __activeOutputs: ['output']
    },
    status: 'passed',
    logs: ['MCP capabilities resolved.']
  };
};
export const executeWorkflowMcpRuntimeNode = async (params) => {
  const runtime = normalizeWorkflowMcpRuntime(params.runtime);
  const resolved = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential || null) });
  const toolCall = resolveWorkflowMcpToolCall(params.input);
  if (toolCall.error) {
    return {
      output: {
        error: toolCall.error,
        __activeOutputs: ['output']
      },
      status: 'failed',
      logs: [toolCall.error]
    };
  }
  if (!toolCall.toolName) {
    const loopPass = Math.max(0, Math.round(Number(toolCall.payload.__loopPass ?? 0) || 0));
    const shouldLoop = runtime.loopNonMcpWork && loopPass < runtime.maxLoopPasses;
    const forwardedPayload = runtime.forwardNonMcpWork
      ? {
          ...toolCall.payload,
          __loopPass: loopPass + 1,
          __loopBudgetRemaining: Math.max(runtime.maxLoopPasses - (loopPass + 1), 0)
        }
      : {};
    return {
      output: {
        capabilityQuery: runtime.capabilityQuery,
        outputContract: runtime.outputContract,
        toolCall: null,
        toolResult: null,
        tools: resolved.tools,
        serverInfo: resolved.serverInfo,
        protocolVersion: resolved.protocolVersion,
        forwardedPayload,
        nonMcpRouting: {
          hasToolCall: false,
          loopEnabled: runtime.loopNonMcpWork,
          forwarded: runtime.forwardNonMcpWork,
          maxLoopPasses: runtime.maxLoopPasses,
          currentLoopPass: loopPass,
          hasLoopBudget: loopPass < runtime.maxLoopPasses
        },
        __activeOutputs: [shouldLoop ? 'loop' : 'output']
      },
      status: 'passed',
      logs: [shouldLoop ? 'Loop route selected because no MCP tool call was provided.' : 'No MCP tool call was provided.']
    };
  }
  const called = await params.manager.callTool({
    server: resolved.server,
    toolName: toolCall.toolName,
    toolArguments: toolCall.toolArguments
  });
  return {
    output: {
      capabilityQuery: runtime.capabilityQuery,
      outputContract: runtime.outputContract,
      toolCall: called.toolCall,
      toolResult: called.toolResult,
      tools: called.tools,
      serverInfo: called.serverInfo,
      protocolVersion: called.protocolVersion,
      __activeOutputs: ['output']
    },
    status: 'passed',
    logs: [\`MCP tool "\${called.toolCall.name}" executed.\`]
  };
};
export { toRecord };
`;

const createHostModuleSource = (globalKey, exportNames) => {
    const lines = [`const mod = globalThis[${JSON.stringify(globalKey)}];`];
    lines.push(`
const wrapDefaultModule = (value) => {
  if (!value || (typeof value !== 'object' && typeof value !== 'function')) {
    return value;
  }
  const lowerKeyMap = new Map(
    Reflect.ownKeys(value)
      .filter((key) => typeof key === 'string')
      .map((key) => [key.toLowerCase(), key])
  );
  return new Proxy(value, {
    get(target, property, receiver) {
      if (typeof property !== 'string') {
        return Reflect.get(target, property, receiver);
      }
      if (Reflect.has(target, property)) {
        return Reflect.get(target, property, receiver);
      }
      const matchedKey = lowerKeyMap.get(property.toLowerCase());
      return matchedKey ? Reflect.get(target, matchedKey, receiver) : undefined;
    },
    has(target, property) {
      if (typeof property !== 'string') {
        return Reflect.has(target, property);
      }
      return Reflect.has(target, property) || lowerKeyMap.has(property.toLowerCase());
    }
  });
};
`);
    lines.push(`const defaultModule = (mod && Object.prototype.hasOwnProperty.call(mod, 'default')) ? mod.default : mod;`);
    lines.push(`export default wrapDefaultModule(defaultModule);`);
    exportNames
        .filter((name) => name !== 'default' && isValidIdentifier(name))
        .forEach((name) => {
            lines.push(`export const ${name} = mod[${JSON.stringify(name)}];`);
        });
    return lines.join('\n');
};

const createSandboxPathResolver = (rootDir, drive = null) => {
    const normalizedRoot = path.resolve(rootDir);
    const driveRoot = drive?.path ? path.resolve(drive.path) : '';
    return (value) => {
        if (typeof value !== 'string' && !(value instanceof URL)) {
            return value;
        }
        const stringValue = value instanceof URL ? fileURLToPath(value) : value;
        if (driveRoot && (stringValue === '/drive' || stringValue.startsWith('/drive/'))) {
            const resolvedDrive = path.resolve(driveRoot, stringValue.slice('/drive'.length));
            const driveRelative = path.relative(driveRoot, resolvedDrive);
            if (driveRelative.startsWith('..') || path.isAbsolute(driveRelative)) {
                throw new Error('Sandbox /drive access escaped the shared drive.');
            }
            return resolvedDrive;
        }
        const resolved = path.resolve(normalizedRoot, stringValue);
        const relative = path.relative(normalizedRoot, resolved);
        if (relative.startsWith('..') || path.isAbsolute(relative)) {
            throw new Error(`Sandbox filesystem access is restricted to ${normalizedRoot}.`);
        }
        return resolved;
    };
};

const FS_PATH_ARG_POSITIONS = {
    access: [0], accessSync: [0], appendFile: [0], appendFileSync: [0], chmod: [0], chmodSync: [0],
    chown: [0], chownSync: [0], copyFile: [0, 1], copyFileSync: [0, 1], cp: [0, 1], cpSync: [0, 1],
    createReadStream: [0], createWriteStream: [0], existsSync: [0], link: [0, 1], linkSync: [0, 1],
    lstat: [0], lstatSync: [0], mkdir: [0], mkdirSync: [0], mkdtemp: [0], mkdtempSync: [0],
    open: [0], openSync: [0], opendir: [0], opendirSync: [0], readFile: [0], readFileSync: [0],
    readdir: [0], readdirSync: [0], readlink: [0], readlinkSync: [0], realpath: [0], realpathSync: [0],
    rename: [0, 1], renameSync: [0, 1], rm: [0], rmSync: [0], rmdir: [0], rmdirSync: [0],
    stat: [0], statSync: [0], symlink: [0, 1], symlinkSync: [0, 1], truncate: [0], truncateSync: [0],
    unlink: [0], unlinkSync: [0], utimes: [0], utimesSync: [0], watch: [0], watchFile: [0],
    writeFile: [0], writeFileSync: [0]
};

const DRIVE_WRITE_PATH_INDEXES = new Set([0, 1]);
const DRIVE_BLOCKED_EXTENSIONS = new Set(['.bat', '.cmd', '.com', '.cjs', '.exe', '.js', '.mjs', '.ps1', '.sh', '.ts']);
const drivePath = (value) => typeof value === 'string' && (value === '/drive' || value.startsWith('/drive/'));
const driveWriteTarget = (name, index) => name === 'rename' || name === 'renameSync' ? index === 1 : DRIVE_WRITE_PATH_INDEXES.has(index);
const driveBlockedName = (value) => DRIVE_BLOCKED_EXTENSIONS.has(path.extname(path.basename(String(value || ''))).toLowerCase());
const assertDriveWrite = (name, args) => {
    if ((name === 'symlink' || name === 'symlinkSync' || name === 'link' || name === 'linkSync') && args.some(drivePath)) throw new Error('Sandbox cannot create links in /drive.');
    if ((name === 'chmod' || name === 'chmodSync') && drivePath(args[0]) && (Number(args[1]) & 0o111) !== 0) throw new Error('Executable chmod is not allowed in /drive.');
    (FS_PATH_ARG_POSITIONS[name] ?? []).forEach((index) => {
        if (driveWriteTarget(name, index) && drivePath(args[index]) && driveBlockedName(args[index])) throw new Error('Executable script files are not allowed in /drive.');
    });
};

const setFunctionBridgeMode = (fn, mode) => {
    Object.defineProperty(fn, FUNCTION_BRIDGE_MODE, {
        value: mode,
        configurable: false,
        enumerable: false,
        writable: false
    });
    return fn;
};

const inferFunctionBridgeMode = (value) => {
    if (typeof value !== 'function') {
        return 'sync';
    }

    if (value[FUNCTION_BRIDGE_MODE] === 'async' || value[FUNCTION_BRIDGE_MODE] === 'sync') {
        return value[FUNCTION_BRIDGE_MODE];
    }

    if (typeof value.name === 'string' && value.name.endsWith('Sync')) {
        return 'sync';
    }

    if (
        value.constructor?.name === 'AsyncFunction' ||
        value[Symbol.toStringTag] === 'AsyncFunction'
    ) {
        return 'async';
    }

    return 'sync';
};

const wrapFsModule = (moduleValue, rootDir, defaultBridgeMode = 'sync', drive = null) => {
    const resolveSandboxPath = createSandboxPathResolver(rootDir, drive);
    const wrapFunction = (name, fn) => {
        const pathIndexes = FS_PATH_ARG_POSITIONS[name] ?? [];
        const bridgeMode = name.endsWith('Sync') ? 'sync' : defaultBridgeMode;
        const invokeWithResolvedArgs = (args) => {
            const nextArgs = [...args];
            assertDriveWrite(name, nextArgs);
            pathIndexes.forEach((index) => {
                if (index < nextArgs.length) {
                    nextArgs[index] = resolveSandboxPath(nextArgs[index]);
                }
            });
            return fn(...nextArgs);
        };
        const wrapped =
            bridgeMode === 'async'
                ? async (...args) => await invokeWithResolvedArgs(args)
                : (...args) => invokeWithResolvedArgs(args);
        return setFunctionBridgeMode(wrapped, bridgeMode);
    };

    const wrapped = {};
    Object.entries(moduleValue).forEach(([key, value]) => {
        if (typeof value === 'function') {
            wrapped[key] = wrapFunction(key, value.bind(moduleValue));
            return;
        }
        wrapped[key] = value;
    });
    if (moduleValue.promises && typeof moduleValue.promises === 'object') {
        wrapped.promises = wrapFsModule(moduleValue.promises, rootDir, 'async', drive);
    }
    return wrapped;
};

const toBridgeValue = (value, owner, seen = new WeakMap()) => {
    if (value == null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        return value;
    }
    if (typeof value === 'bigint') {
        return Number(value);
    }
    if (value instanceof Date) {
        return new Date(value.getTime());
    }
    if (Buffer.isBuffer(value) || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
        return new ivm.ExternalCopy(value).copyInto();
    }
    if (typeof value === 'function') {
        const bound = owner ? value.bind(owner) : value;
        const bridgeMode = inferFunctionBridgeMode(value);
        if (bridgeMode === 'async') {
            return new ivm.Callback(async (...args) => await bound(...args), { async: true });
        }
        return new ivm.Callback((...args) => bound(...args), { sync: true });
    }
    if (Array.isArray(value)) {
        if (seen.has(value)) return seen.get(value);
        const out = [];
        seen.set(value, out);
        value.forEach((entry) => out.push(toBridgeValue(entry, undefined, seen)));
        return out;
    }
    if (typeof value === 'object') {
        if (seen.has(value)) return seen.get(value);
        const out = {};
        seen.set(value, out);
        Reflect.ownKeys(value).forEach((key) => {
            if (typeof key !== 'string') return;
            try {
                out[key] = toBridgeValue(value[key], value, seen);
            } catch {
                out[key] = undefined;
            }
        });
        return out;
    }
    return undefined;
};

const readTextFile = async (filePath) => await fsPromises.readFile(filePath, 'utf8');

const transpileTypeScriptModule = (source, filePath) => {
    const transpileResult = ts.transpileModule(source, {
        fileName: filePath,
        reportDiagnostics: true,
        compilerOptions: {
            target: ts.ScriptTarget.ES2022,
            module: ts.ModuleKind.ESNext,
            moduleResolution: ts.ModuleResolutionKind.Bundler,
            importsNotUsedAsValues: ts.ImportsNotUsedAsValues.Remove,
            isolatedModules: true,
            skipLibCheck: true,
            esModuleInterop: true,
            allowSyntheticDefaultImports: true,
            resolveJsonModule: true,
            strict: true
        }
    });
    const diagnostics = Array.isArray(transpileResult.diagnostics) ? transpileResult.diagnostics : [];
    const hasError = diagnostics.some((diagnostic) => diagnostic.category === ts.DiagnosticCategory.Error);
    if (hasError) {
        const formatted = diagnostics
            .map((diagnostic) => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))
            .join(' | ');
        throw new Error(`Sandbox TypeScript compile failed for ${filePath}: ${formatted}`);
    }
    return transpileResult.outputText;
};

const resolveWorkspaceModulePath = async (specifier, referrerPath, tempDir) => {
    const normalizedReferrerPath = referrerPath.startsWith('workspace:') ? referrerPath.slice('workspace:'.length) : referrerPath;
    const baseDir = path.dirname(normalizedReferrerPath);
    const requested = specifier.startsWith('file:') ? fileURLToPath(specifier) : path.resolve(baseDir, specifier);
    const candidates = [requested];
    if (!path.extname(requested)) {
        candidates.push(`${requested}.ts`, `${requested}.mts`, `${requested}.js`, `${requested}.mjs`, `${requested}.json`);
        candidates.push(path.join(requested, 'index.ts'), path.join(requested, 'index.mjs'), path.join(requested, 'index.js'));
    }
    const resolveSandboxPath = createSandboxPathResolver(tempDir);
    for (const candidate of candidates) {
        try {
            const safePath = resolveSandboxPath(candidate);
            await fsPromises.access(safePath, fs.constants.R_OK);
            return safePath;
        } catch {
            // keep looking
        }
    }
    throw new Error(`Unable to resolve workspace module "${specifier}" from ${referrerPath}.`);
};

const findPackageRoot = (entryPath, packageName) => {
    let current = path.dirname(entryPath);
    while (true) {
        const packageJsonPath = path.join(current, 'package.json');
        if (fs.existsSync(packageJsonPath)) {
            try {
                const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
                if (pkg.name === packageName) return current;
            } catch {
                return null;
            }
        }
        const parent = path.dirname(current);
        if (parent === current) return null;
        current = parent;
    }
};

const findNodeModulePackageRoot = (startDir, packageName) => {
    let current = path.resolve(startDir);
    while (true) {
        const packageJsonPath = path.join(current, 'node_modules', packageName, 'package.json');
        if (fs.existsSync(packageJsonPath)) return path.dirname(packageJsonPath);
        const parent = path.dirname(current);
        if (parent === current) return null;
        current = parent;
    }
};

const resolveApprovedHostModulePath = (specifier, resolutionBaseDir) => {
    if (specifier !== '@workflow/charts' && !specifier.startsWith('@workflow/charts/')) return null;
    const packageRoot = findNodeModulePackageRoot(resolutionBaseDir, '@workflow/charts');
    if (!packageRoot) return null;
    const subpath = specifier === '@workflow/charts' ? 'index' : specifier.slice('@workflow/charts/'.length);
    if (!['index', 'catalog', 'markdown', 'react'].includes(subpath)) return null;
    return path.join(packageRoot, 'dist', `${subpath}.js`);
};

const resolveWorkflowNodesSourceModulePath = async (specifier, resolutionRequire) => {
    if (!specifier.startsWith('@workflow/nodes/')) return null;
    const entryPath = resolutionRequire.resolve('@workflow/nodes');
    const packageRoot = findPackageRoot(entryPath, '@workflow/nodes');
    if (!packageRoot) return null;
    const subpath = specifier.slice('@workflow/nodes/'.length);
    const requested = path.join(packageRoot, 'src', subpath);
    const candidates = requested.endsWith('.js')
        ? [requested.slice(0, -3) + '.ts', requested]
        : [requested, requested + '.ts', path.join(requested, 'index.ts')];
    for (const candidate of candidates) {
        try {
            await fsPromises.access(candidate, fs.constants.R_OK);
            return candidate;
        } catch {
            // keep looking
        }
    }
    return null;
};

const formatLoadError = (moduleLabel, request, error) => {
    const message = error instanceof Error ? error.message : String(error);
    return `Unable to load ${moduleLabel} module for model "${request.modelId}": ${message}`;
};

const createWorkerModuleRunner = async (request) => {
    const helperChannel = createRequestReplyChannel();
    const isolate = new ivm.Isolate({ memoryLimit: 128 });
    const context = await isolate.createContext();
    const globalRef = context.global;
    globalRef.setSync('global', globalRef.derefInto());
    globalRef.setSync('globalThis', globalRef.derefInto());
    globalRef.setSync('self', globalRef.derefInto());
    const moduleTimeout = Number.isFinite(Number(request.timeoutMs)) && Number(request.timeoutMs) > 0 ? Number(request.timeoutMs) : undefined;

    globalRef.setSync(
        '__wf_delay',
        new ivm.Reference((delay = 0) =>
            new Promise((resolve) => {
                globalThis.setTimeout(resolve, Number.isFinite(Number(delay)) ? Number(delay) : 0);
            })
        )
    );
    await context.eval(`
globalThis.__wf_timerCounter = 0;
globalThis.__wf_timeoutState = new Map();
globalThis.__wf_intervalState = new Map();
globalThis.setTimeout = (callback, delay = 0, ...args) => {
  if (typeof callback !== 'function') {
    throw new TypeError('Callback must be a function.');
  }
  const timerId = ++globalThis.__wf_timerCounter;
  globalThis.__wf_timeoutState.set(timerId, { cleared: false });
  globalThis.__wf_delay.apply(undefined, [delay], {
    arguments: { copy: true },
    result: { promise: true, copy: true }
  }).then(() => {
    const state = globalThis.__wf_timeoutState.get(timerId);
    if (!state || state.cleared) {
      return;
    }
    globalThis.__wf_timeoutState.delete(timerId);
    callback(...args);
  });
  return timerId;
};
globalThis.clearTimeout = (timerId) => {
  const state = globalThis.__wf_timeoutState.get(timerId);
  if (!state) {
    return;
  }
  state.cleared = true;
  globalThis.__wf_timeoutState.delete(timerId);
};
globalThis.setInterval = (callback, delay = 0, ...args) => {
  if (typeof callback !== 'function') {
    throw new TypeError('Callback must be a function.');
  }
  const timerId = ++globalThis.__wf_timerCounter;
  const state = { cleared: false };
  const tick = () => {
    globalThis.__wf_delay.apply(undefined, [delay], {
      arguments: { copy: true },
      result: { promise: true, copy: true }
    }).then(() => {
      const currentState = globalThis.__wf_intervalState.get(timerId);
      if (!currentState || currentState.cleared) {
        return;
      }
      callback(...args);
      tick();
    });
  };
  globalThis.__wf_intervalState.set(timerId, state);
  tick();
  return timerId;
};
globalThis.clearInterval = (timerId) => {
  const state = globalThis.__wf_intervalState.get(timerId);
  if (!state) {
    return;
  }
  state.cleared = true;
  globalThis.__wf_intervalState.delete(timerId);
};
`, moduleTimeout ? { timeout: moduleTimeout } : undefined);
    globalRef.setSync(
        '__wf_fetch',
        new ivm.Reference(async (resource, init = {}) => {
            const request = toRecord(init);
            const signal = toRecord(request.signal);
            if (signal.aborted === true) {
                throw new Error(typeof signal.reason === 'string' && signal.reason.length > 0 ? signal.reason : 'The operation was aborted.');
            }
            const response = await fetch(String(resource || ''), {
                ...request,
                signal: undefined,
                body: await materializeFetchBody(request.body)
            });
            return await createFetchResponseRecord(response);
        })
    );
    globalRef.setSync('__wf_executeGigaService', new ivm.Reference((...args) => helperChannel.call('executeGigaService', args)));
    globalRef.setSync('__wf_executeBackend', new ivm.Reference((...args) => helperChannel.call('executeBackend', args)));
    globalRef.setSync('__wf_invokeConnectedNode', new ivm.Reference((...args) => helperChannel.call('invokeConnectedNode', args)));
    globalRef.setSync('__wf_updateNode', new ivm.Reference((...args) => helperChannel.call('updateNode', args)));
    globalRef.setSync('__wf_compileWorkflowCypher', new ivm.Reference((...args) => helperChannel.call('compileWorkflowCypher', args)));
    globalRef.setSync('__wf_controlNodeGet', new ivm.Reference((nodeId) => helperChannel.call('controlNodeGet', [nodeId])));
    globalRef.setSync('__wf_controlNodeGetSchema', new ivm.Reference((nodeId) => helperChannel.call('controlNodeGetSchema', [nodeId])));
    globalRef.setSync('__wf_controlNodeSet', new ivm.Reference((nodeId, patch) => helperChannel.call('controlNodeSet', [nodeId, patch])));
    globalRef.setSync('__wf_controlNodeValidate', new ivm.Reference((nodeId, args) => helperChannel.call('controlNodeValidate', [nodeId, args ?? null])));
    globalRef.setSync('__wf_controlNodeExecuteInputs', new ivm.Reference((nodeId, args) => helperChannel.call('controlNodeExecuteInputs', [nodeId, args ?? null])));
    globalRef.setSync('__wf_controlNodeCommandToolSpec', new ivm.Reference((nodeId) => helperChannel.call('controlNodeCommandToolSpec', [nodeId])));
    globalRef.setSync('__wf_controlNodeExecute', new ivm.Reference((nodeId, args) => helperChannel.call('controlNodeExecute', [nodeId, args ?? null])));
    await context.eval(WEB_RUNTIME_SHIM_SOURCE, moduleTimeout ? { timeout: moduleTimeout } : undefined);

    const moduleCache = new Map();
    const moduleIdByObject = new WeakMap();
    const resolutionRequire = createRequire(path.join(request.resolutionBaseDir, '__workflow_sandbox_resolution__.mjs'));
    const sharedDrive = request.context?.settings?.sharedDrive || null;
    const sandboxFs = wrapFsModule(fs, request.tempDir, 'sync', sharedDrive);
    const sandboxFsPromises = wrapFsModule(fsPromises, request.tempDir, 'async', sharedDrive);
    const hostModuleGlobals = new Map();

    const registerHostModule = async (cacheKey, namespace) => {
        const existing = hostModuleGlobals.get(cacheKey);
        if (existing) return existing;
        const globalKey = `__wf_host_module_${hostModuleGlobals.size}`;
        const bridged = toBridgeValue(namespace, undefined);
        globalRef.setSync(globalKey, bridged, { copy: true });
        const exportNames = Object.keys(namespace);
        const registered = { globalKey, exportNames };
        hostModuleGlobals.set(cacheKey, registered);
        return registered;
    };

    const loadHostModuleNamespace = async (specifier) => {
        if (FS_SPECIFIERS.has(specifier)) {
            return { default: sandboxFs, ...sandboxFs };
        }
        if (FS_PROMISES_SPECIFIERS.has(specifier)) {
            return { default: sandboxFsPromises, ...sandboxFsPromises };
        }
        if (BLOCKED_BUILTINS.has(specifier)) {
            throw new Error(`Sandbox import of "${specifier}" is blocked.`);
        }
        if (NODE_BUILTIN_SET.has(specifier)) {
            const normalized = specifier.startsWith('node:') ? specifier : `node:${specifier}`;
            const namespace = await import(normalized);
            return { default: namespace.default ?? namespace, ...namespace };
        }

        const resolvedPath = resolveApprovedHostModulePath(specifier, request.resolutionBaseDir) ?? resolutionRequire.resolve(specifier);
        const namespace = await import(pathToFileURL(resolvedPath).href);
        return { default: namespace.default ?? namespace, ...namespace };
    };

    const compileModule = async (identifier, source) => {
        let compiled = moduleCache.get(identifier);
        if (compiled) return compiled;
        compiled = await isolate.compileModule(source, { filename: identifier });
        moduleCache.set(identifier, compiled);
        moduleIdByObject.set(compiled, identifier);
        return compiled;
    };

    const resolveModule = async (specifier, referrer) => {
        const referrerId = moduleIdByObject.get(referrer) ?? request.workerEntryPath;

        if (specifier === '@workflow/execute') {
            const cacheKey = 'virtual:@workflow/execute';
            const compiled = await compileModule(cacheKey, createVirtualExecuteModuleSource());
            await compiled.instantiate(context, resolveModule);
            return compiled;
        }

        if (specifier === '@workflow/executor') {
            const cacheKey = 'virtual:@workflow/executor';
            const compiled = await compileModule(cacheKey, createVirtualExecutorModuleSource());
            await compiled.instantiate(context, resolveModule);
            return compiled;
        }

        if (specifier.startsWith('./') || specifier.startsWith('../') || specifier.startsWith('/') || specifier.startsWith('file:')) {
            const workspacePath = await resolveWorkspaceModulePath(specifier, referrerId, request.tempDir);
            const cacheKey = `workspace:${workspacePath}`;
            let source;
            if (workspacePath.endsWith('.json')) {
                source = `export default ${await readTextFile(workspacePath)};`;
            } else {
                const fileSource = await readTextFile(workspacePath);
                source = /\.(ts|mts|tsx|cts)$/i.test(workspacePath)
                    ? transpileTypeScriptModule(fileSource, workspacePath)
                    : fileSource;
            }
            const compiled = await compileModule(cacheKey, source);
            await compiled.instantiate(context, resolveModule);
            return compiled;
        }

        const workflowNodesPath = await resolveWorkflowNodesSourceModulePath(specifier, resolutionRequire);
        if (workflowNodesPath) {
            const cacheKey = `workflow-nodes:${workflowNodesPath}`;
            const source = transpileTypeScriptModule(await readTextFile(workflowNodesPath), workflowNodesPath);
            const compiled = await compileModule(cacheKey, source);
            await compiled.instantiate(context, resolveModule);
            return compiled;
        }

        const hostCacheKey = `host:${specifier}`;
        const registered = await registerHostModule(hostCacheKey, await loadHostModuleNamespace(specifier));
        const compiled = await compileModule(hostCacheKey, createHostModuleSource(registered.globalKey, registered.exportNames));
        await compiled.instantiate(context, resolveModule);
        return compiled;
    };

    const loadRootModule = async (entryPath) => {
        const source = transpileTypeScriptModule(await readTextFile(entryPath), entryPath);
        const compiled = await compileModule(entryPath, source);
        await compiled.instantiate(context, resolveModule);
        await compiled.evaluate(moduleTimeout ? { timeout: moduleTimeout } : undefined);
        return compiled.namespace;
    };

    const getExportRef = (namespaceRef, exportName) => {
        const exportRef = namespaceRef.getSync(exportName, { reference: true });
        if (!exportRef || exportRef.typeof !== 'function') {
            return null;
        }
        return exportRef;
    };

    await loadRootModule(request.workerEntryPath).catch((error) => {
        throw new Error(formatLoadError('worker', request, error));
    });
    if (request.validatorEntryPath) {
        await loadRootModule(request.validatorEntryPath).catch((error) => {
            throw new Error(formatLoadError('validator', request, error));
        });
    }
    const invokerCacheKey = `virtual:worker-invoker:${request.workerEntryPath}:${request.validatorEntryPath ?? 'none'}`;
    const invokerModule = await compileModule(invokerCacheKey, createWorkerInvokerModuleSource(request.workerEntryPath, request.validatorEntryPath));
    await invokerModule.instantiate(context, resolveModule);
    await invokerModule.evaluate(moduleTimeout ? { timeout: moduleTimeout } : undefined);

    const validatorRef = getExportRef(invokerModule.namespace, 'invokeValidatorValidate');
    const validateRef = getExportRef(invokerModule.namespace, 'invokeWorkerValidate');
    const initRef = getExportRef(invokerModule.namespace, 'invokeWorkerInit');
    const onUpdateRef = getExportRef(invokerModule.namespace, 'invokeWorkerOnUpdate');
    const executeRef = getExportRef(invokerModule.namespace, 'invokeWorkerExecute');
    const commandToolSpecRef = getExportRef(invokerModule.namespace, 'invokeWorkerCommandToolSpec');

    if (!validateRef || !initRef || !onUpdateRef || !executeRef || (request.validatorEntryPath && !validatorRef)) {
        throw new Error(`Worker exports are incomplete for model "${request.modelId}".`);
    }

    let previewValidationSummary = null;
    const nodeScope = {};
    const runtimeEnvironment = 'node';
    const controlNodeSpecs = createControlNodeSpecs(request.context);
    const invokeExport = async (exportRef, payload) =>
        await exportRef.apply(undefined, [payload, controlNodeSpecs], {
            timeout: moduleTimeout,
            arguments: { copy: true },
            result: { copy: true, promise: true }
        });
    const initPayload = buildWorkerPayload(request.context, nodeScope, null, runtimeEnvironment);

    try {
        if (request.mode === 'validate') {
            if (validatorRef) {
                const previewValidationResult = normalizeValidationResult(await invokeExport(validatorRef, initPayload));
                if (!previewValidationResult.ok) {
                    return previewValidationResult;
                }
            }
            return normalizeValidationResult(await invokeExport(validateRef, buildWorkerPayload(request.context, nodeScope, null, runtimeEnvironment)));
        }

        if (request.mode === 'commandToolSpec') {
            if (!commandToolSpecRef) return null;
            return (await invokeExport(commandToolSpecRef, initPayload)) ?? null;
        }

        if (validatorRef) {
            const previewValidationResult = normalizeValidationResult(await invokeExport(validatorRef, initPayload));
            previewValidationSummary = mergePreviewValidation(previewValidationSummary, previewValidationResult);
            if (!previewValidationResult.ok) {
                const firstError = previewValidationResult.errors[0] ?? `Preview validation failed for node "${request.context.node.name}".`;
                return toErrorResult(firstError, previewValidationSummary.warnings ?? [], previewValidationSummary);
            }
        }

        await invokeExport(initRef, initPayload);
        await invokeExport(onUpdateRef, initPayload);

        const validationResult = normalizeValidationResult(await invokeExport(validateRef, buildWorkerPayload(request.context, nodeScope, null, runtimeEnvironment)));
        previewValidationSummary = mergePreviewValidation(previewValidationSummary, validationResult);
        if (!validationResult.ok) {
            const firstError = validationResult.errors[0] ?? `Worker validation failed for node "${request.context.node.name}".`;
            return toErrorResult(firstError, previewValidationSummary.warnings ?? [], previewValidationSummary);
        }

        const executionNode = toRuntimePatchedNode(request.context.node, validationResult.normalizedRuntime);
        const warningLogs = (previewValidationSummary?.warnings ?? []).map((entry) => `WARN ${entry}`);
        const preUpdateResult = normalizeUpdateResult(await invokeExport(onUpdateRef, buildWorkerPayload(request.context, nodeScope, null, runtimeEnvironment, executionNode)));
        if (!preUpdateResult.ok) {
            const message = preUpdateResult.error ?? `Worker onUpdate rejected node "${request.context.node.name}" before execute.`;
            return toErrorResult(message, warningLogs, previewValidationSummary);
        }

        let attempts = 0;
        let result = toErrorResult('Worker execution did not produce a result.', warningLogs, previewValidationSummary);
        while (attempts < 6) {
            attempts += 1;
            result = normalizeResult(await invokeExport(executeRef, buildWorkerPayload(request.context, nodeScope, result.output ?? null, runtimeEnvironment, executionNode)));
            const postUpdateResult = normalizeUpdateResult(await invokeExport(onUpdateRef, buildWorkerPayload(request.context, nodeScope, result.output ?? null, runtimeEnvironment, executionNode)));
            if (postUpdateResult.ok) {
                break;
            }
            if (attempts >= 6) {
                return toErrorResult(`Worker execute reentry limit (6) reached for node "${request.context.node.name}".`, warningLogs, previewValidationSummary);
            }
        }

        return {
            ...result,
            logs: [...warningLogs, ...(result.logs ?? [])],
            previewValidation: previewValidationSummary
        };
    } finally {
        isolate.dispose();
    }
};

const main = async () => {
    try {
        let readyType = 'ready';
        while (true) {
            const request = await waitForRunRequest(readyType);
            if (!request) break;
            try {
                const result = await createWorkerModuleRunner(request);
                await sendProcessMessage({ type: 'result', result });
            } catch (error) {
                await sendProcessMessage({
                    type: 'error',
                    error: error instanceof Error ? `${error.message}${error.stack ? `\n${error.stack}` : ''}` : 'Sandbox worker execution failed.'
                });
            }
            await waitForProcessDrain();
            readyType = 'idle';
        }
    } catch (error) {
        await sendProcessMessage({
            type: 'error',
            error: error instanceof Error ? `${error.message}${error.stack ? `\n${error.stack}` : ''}` : 'Sandbox worker execution failed.'
        });
        await waitForProcessDrain();
    } finally {
        setImmediate(() => process.exit(0));
    }
};

main();
