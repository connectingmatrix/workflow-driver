import React from 'react';
import type { NodeLibraryProps } from '@workflow/ui/workflow/components/node-library/node-library.types';
import WorkspaceNodeLibrary from '@workflow/ui/workflow/components/node-library/workspace/WorkspaceNodeLibrary';

const NodeLibrary: React.FC<NodeLibraryProps> = (props) => <WorkspaceNodeLibrary {...props} />;

export { DRAG_MIME_TYPE } from '@workflow/ui/workflow/components/node-library/node-library.constants';
export type { NodeLibraryProps };
export default NodeLibrary;
