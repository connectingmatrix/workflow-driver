import type { WorkflowMcpServerRegistration } from './mcp-runtime.types';
import { buildEndpointUrl, parseStringValue, resolveRuntimeHeaders, toRecordValue } from './mcp-runtime.utils';

interface WorkflowMcpHttpResult {
    headers: Headers;
    payload: Record<string, unknown>;
}

export const sendMcpRequest = async (params: {
    server: WorkflowMcpServerRegistration;
    sessionId?: string;
    body: Record<string, unknown>;
    signal?: AbortSignal;
}): Promise<WorkflowMcpHttpResult> => {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...resolveRuntimeHeaders(params.server)
    };
    if (params.sessionId) {
        headers['mcp-session-id'] = params.sessionId;
    }

    const response = await fetch(buildEndpointUrl(params.server), {
        method: 'POST',
        headers,
        body: JSON.stringify(params.body),
        signal: params.signal
    });

    const text = await response.text();
    let payload: Record<string, unknown> = {};
    if (text) {
        try {
            payload = toRecordValue(JSON.parse(text));
        } catch {
            payload = {};
        }
    }
    const error = toRecordValue(payload.error);
    if (Object.keys(error).length > 0) {
        const message = parseStringValue(error.message) || 'MCP request failed.';
        const code = parseStringValue(error.code);
        throw new Error(code ? `${message} (MCP ${code})` : message);
    }
    if (!response.ok) {
        const message = parseStringValue(payload.message) || response.statusText || 'MCP request failed.';
        throw new Error(message);
    }

    return {
        headers: response.headers,
        payload
    };
};
