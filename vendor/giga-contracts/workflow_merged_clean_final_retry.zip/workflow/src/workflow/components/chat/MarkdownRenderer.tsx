import React, { useMemo } from 'react';
import { marked } from 'marked';

interface MarkdownRendererProps {
    content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
    const html = useMemo(() => {
        const rendered = marked.parse(content ?? '', { async: false });
        return typeof rendered === 'string' ? rendered : '';
    }, [content]);

    return <div className="wf-markdown-renderer" dangerouslySetInnerHTML={{ __html: html }} />;
};

export default MarkdownRenderer;
