import type { WorkflowAiResponse } from '@workflow/ui/workflow/ai/types';
import type { WorkflowNodeModule } from '@workflow/nodes/node-utils/node-module.types';
import type {
    WorkflowCredentialOption,
    WorkflowResolvedCredential,
    WorkflowExecutableOption,
    WorkflowDefinition,
    WorkflowNodeFieldOption,
    WorkflowNodeFieldOptionsRequest,
    WorkflowNodeLibraryItem,
    WorkflowNodeModel,
    WorkflowNodeSchema,
    WorkflowNodeStatusEnum,
    WorkflowPreviewLogEvent,
    WorkflowPreviewRuntime,
    WorkflowPreviewStateEvent,
    WorkflowRunLogEvent,
    WorkflowRuntimeSettings,
    WorkflowSourceFiles,
    WorkflowUserNodeDefinition
} from '../types';

export enum WorkflowExecutionModeEnum {
    Wait = 'WAIT',
    Async = 'ASYNC'
}

export interface WorkflowStepSocketResult {
    request_id: string;
    run_id: string;
    workflow: WorkflowDefinition;
    node: WorkflowNodeModel;
    result: {
        output: unknown;
        status?: WorkflowNodeStatusEnum;
        logs?: string[];
    };
    logs: WorkflowRunLogEvent[];
    logs_jsonl: string;
}

export interface WorkflowPreviewResultPayload {
    request_id?: string | null;
    run_id?: string;
    workflow?: WorkflowDefinition;
    node?: WorkflowNodeModel;
    result?: {
        output: unknown;
        status?: WorkflowNodeStatusEnum;
        logs?: string[];
    };
}

export interface WorkflowPreviewStopPayload {
    request_id?: string | null;
    run_id?: string;
    reason?: 'completed' | 'cancelled' | 'failed';
}

export interface WorkflowSocketErrorPayload {
    request_id?: string | null;
    run_id?: string | null;
    error?: string;
}

export interface WorkflowWebhookTestInvokePayload {
    request_id: string;
    workflow_id: string;
    route_type: 'test' | 'published';
    request: Record<string, unknown>;
}

export interface WorkflowRealtimeClient {
    connect: () => Promise<void>;
    disconnect: () => void;
    joinRun: (runId: string) => Promise<void>;
    subscribeWorkflowExecution: (params: { broadcastId: string; workflowId: string }) => Promise<void>;
    unsubscribeWorkflowExecution: (params: { broadcastId: string; workflowId: string }) => void;
    addEventHandler: (handler: (event: WorkflowRunLogEvent) => void) => () => void;
    addWebhookTestInvokeHandler: (handler: (payload: WorkflowWebhookTestInvokePayload) => void) => () => void;
    emitWebhookTestResult: (payload: { requestId: string; workflowId: string; output: unknown; logs?: unknown[] }) => void;
    emitWebhookTestError: (payload: { requestId: string; workflowId: string; error: string; logs?: unknown[]; output?: unknown }) => void;
    openEditorSession: (params: { workflowId: string; editable?: boolean }) => Promise<void>;
    heartbeatEditorSession: (params: { workflowId: string; editable?: boolean }) => Promise<void>;
    closeEditorSession: (params: { workflowId: string }) => void;
    executeStep: (params: {
        workflow: WorkflowDefinition;
        nodeId: string;
        settings: WorkflowRuntimeSettings;
        runId?: string;
        overrides?: {
            properties?: Record<string, unknown>;
            code?: string;
            markdown?: string;
            sourceFiles?: WorkflowSourceFiles;
            previewRuntime?: WorkflowPreviewRuntime;
            previewInput?: Record<string, unknown>;
            previewMode?: 'designer';
        };
    }) => Promise<WorkflowStepSocketResult>;
    startPreview: (params: {
        workflow: WorkflowDefinition;
        nodeId: string;
        settings: WorkflowRuntimeSettings;
        runId?: string;
        overrides?: {
            properties?: Record<string, unknown>;
            code?: string;
            markdown?: string;
            sourceFiles?: WorkflowSourceFiles;
            previewRuntime?: WorkflowPreviewRuntime;
            previewInput?: Record<string, unknown>;
            previewMode?: 'designer';
        };
    }) => Promise<string>;
    cancelPreview: (runId: string) => void;
    addPreviewLogHandler: (handler: (event: WorkflowPreviewLogEvent) => void) => () => void;
    addPreviewStateHandler: (handler: (event: WorkflowPreviewStateEvent) => void) => () => void;
    addPreviewResultHandler: (handler: (payload: WorkflowPreviewResultPayload) => void) => () => void;
    addPreviewStopHandler: (handler: (payload: WorkflowPreviewStopPayload) => void) => () => void;
    addPreviewErrorHandler: (handler: (payload: WorkflowSocketErrorPayload) => void) => () => void;
}

export interface WorkflowNodeCatalog {
    modules: WorkflowNodeModule[];
    getAllNodeSchemas: () => Record<string, WorkflowNodeSchema>;
    getNodeLibraryItems: () => WorkflowNodeLibraryItem[];
    getNodeModuleById: (modelId: string | undefined) => WorkflowNodeModule | null;
    resolveNodeSchema: (modelId: string | undefined, nodeModels: Record<string, WorkflowNodeSchema>) => WorkflowNodeSchema;
    isLocalCapableNodeModel: (modelId: string | undefined) => boolean;
}

export interface WorkflowUiDriver {
    createRequestId: () => string;
    getDefaultRuntimeSettings: () => WorkflowRuntimeSettings;
    createRealtimeClient: () => WorkflowRealtimeClient;
    buildWorkflowWebhookUrls: (workflowId: string) => { testUrl: string; publishedUrl: string };
    executeWorkflowOnServer: (params: {
        workflow: WorkflowDefinition;
        settings: WorkflowRuntimeSettings;
        mode?: WorkflowExecutionModeEnum;
        requestId?: string;
    }) => Promise<{
        accepted: boolean;
        run_id: string;
        stopped: boolean;
        workflow: WorkflowDefinition;
        logs: Array<Record<string, unknown>>;
    }>;
    requestWorkflowAi: (prompt: string) => Promise<WorkflowAiResponse>;
    fetchCredentials: (serviceId: string) => Promise<WorkflowCredentialOption[]>;
    fetchCredentialById: (credentialId: string) => Promise<WorkflowResolvedCredential | null>;
    openCredentialManager: () => void;
    fetchExecutableWorkflows: () => Promise<WorkflowExecutableOption[]>;
    fetchNodeFieldOptions?: (request: WorkflowNodeFieldOptionsRequest) => Promise<WorkflowNodeFieldOption[]>;
    listWorkflowUserNodes: (includeInactive?: boolean) => Promise<WorkflowUserNodeDefinition[]>;
    createWorkflowUserNode: (input: {
        description?: string | null;
        groupName?: string | null;
        name: string;
        nodeSchema?: Record<string, unknown>;
        slug?: string;
        sourceFiles: WorkflowSourceFiles;
    }) => Promise<WorkflowUserNodeDefinition>;
    updateWorkflowUserNode: (params: {
        id: string;
        input: {
            description?: string | null;
            groupName?: string | null;
            isActive?: boolean;
            name?: string;
            nodeSchema?: Record<string, unknown>;
            slug?: string;
            sourceFiles?: WorkflowSourceFiles;
        };
    }) => Promise<WorkflowUserNodeDefinition>;
    deleteWorkflowUserNode: (id: string) => Promise<boolean>;
}
