/// <reference types="cypress" />

beforeEach(() => {
    cy.viewport(1600, 950);
});
