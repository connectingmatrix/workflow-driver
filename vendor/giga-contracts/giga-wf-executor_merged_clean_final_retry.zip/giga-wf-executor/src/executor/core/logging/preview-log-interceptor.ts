import { WorkflowPreviewLogSource } from '../../../types';
import { createPreviewLogBuffer } from './preview-log-buffer';

interface PreviewLogInterceptor {
    flush: () => void;
    restore: () => void;
}

type PreviewRuntime = 'browser' | 'node';

const toLogLine = (parts: unknown[]): string =>
    parts
        .map((part) => {
            if (typeof part === 'string') return part;
            try {
                return JSON.stringify(part);
            } catch {
                return String(part);
            }
        })
        .join(' ')
        .trim();

const createNoopInterceptor = (): PreviewLogInterceptor => ({
    flush: () => undefined,
    restore: () => undefined
});

const createBrowserConsoleInterceptor = (emitLine: (source: WorkflowPreviewLogSource, line: string, stream?: string) => void): PreviewLogInterceptor => {
    const original = {
        log: console.log,
        warn: console.warn,
        error: console.error
    };

    console.log = (...args: unknown[]) => {
        const line = toLogLine(args);
        if (line) emitLine('browser', line, 'stdout');
        original.log(...args);
    };
    console.warn = (...args: unknown[]) => {
        const line = toLogLine(args);
        if (line) emitLine('browser', line, 'stderr');
        original.warn(...args);
    };
    console.error = (...args: unknown[]) => {
        const line = toLogLine(args);
        if (line) emitLine('browser', line, 'stderr');
        original.error(...args);
    };

    return {
        flush: () => undefined,
        restore: () => {
            console.log = original.log;
            console.warn = original.warn;
            console.error = original.error;
        }
    };
};

const createNodeStdIoInterceptor = (emitLine: (source: WorkflowPreviewLogSource, line: string, stream?: string) => void): PreviewLogInterceptor => {
    const processLike = (globalThis as { process?: unknown }).process as
        | {
              stdout?: { write?: (...args: unknown[]) => unknown };
              stderr?: { write?: (...args: unknown[]) => unknown };
          }
        | undefined;
    if (!processLike?.stdout || !processLike?.stderr) return createNoopInterceptor();
    const stdoutWrite = processLike?.stdout?.write;
    const stderrWrite = processLike?.stderr?.write;
    if (typeof stdoutWrite !== 'function' || typeof stderrWrite !== 'function') return createNoopInterceptor();

    const stdout = processLike.stdout;
    const stderr = processLike.stderr;
    const stdoutBuffer = createPreviewLogBuffer((line) => emitLine('stdout', line, 'stdout'));
    const stderrBuffer = createPreviewLogBuffer((line) => emitLine('stderr', line, 'stderr'));
    const originalStdoutWrite = stdoutWrite.bind(stdout);
    const originalStderrWrite = stderrWrite.bind(stderr);

    (stdout as { write: (...args: unknown[]) => unknown }).write = ((chunk: unknown, ...args: unknown[]) => {
        stdoutBuffer.push(chunk);
        return originalStdoutWrite(chunk, ...args);
    }) as typeof stdoutWrite;

    (stderr as { write: (...args: unknown[]) => unknown }).write = ((chunk: unknown, ...args: unknown[]) => {
        stderrBuffer.push(chunk);
        return originalStderrWrite(chunk, ...args);
    }) as typeof stderrWrite;

    return {
        flush: () => {
            stdoutBuffer.flush();
            stderrBuffer.flush();
        },
        restore: () => {
            (stdout as { write: (...args: unknown[]) => unknown }).write = originalStdoutWrite as typeof stdoutWrite;
            (stderr as { write: (...args: unknown[]) => unknown }).write = originalStderrWrite as typeof stderrWrite;
        }
    };
};

export const createPreviewLogInterceptor = (params: {
    runtime: PreviewRuntime;
    emitLine: (source: WorkflowPreviewLogSource, line: string, stream?: string) => void;
}): PreviewLogInterceptor =>
    params.runtime === 'browser'
        ? createBrowserConsoleInterceptor(params.emitLine)
        : createNodeStdIoInterceptor(params.emitLine);
