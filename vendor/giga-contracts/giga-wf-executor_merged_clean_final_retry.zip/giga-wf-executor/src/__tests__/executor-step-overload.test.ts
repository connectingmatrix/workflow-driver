import { describe, expect, it, vi } from 'vitest';
import { WorkflowNodeKindEnum, WorkflowNodeStatusEnum } from '../types';
import type { ExecutorStepOptions } from '../service/types';
import { createExecutor } from '../service/createExecutor';
import type { WorkflowDefinition, WorkflowNodeModel, WorkflowStepExecutorResult } from '../types';

type CapturedWorkflowStepOptions = ExecutorStepOptions & {
  nodeId?: string;
  nodeModels?: { 'current-chat'?: { id?: string } };
  workflow: WorkflowDefinition;
};

describe('Executor.executeStep overloads', () => {
  it('keeps workflow+nodeId execution unchanged', async () => {
    const node: WorkflowNodeModel = {
      id: 'node-1',
      gigaId: 'StartNode',
      modelId: 'start',
      type: 'workflowStep',
      name: 'Start',
      description: 'Start node',
      kind: WorkflowNodeKindEnum.Process,
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: {},
      ports: { in: {}, out: {} },
    };
    const workflow: WorkflowDefinition = { metadata: { id: 'wf-1', name: 'Workflow 1' }, input: {}, nodes: [node], connections: [] };
    const captured: CapturedWorkflowStepOptions[] = [];
    const executeStep = vi.fn(async (_id: string, options: ExecutorStepOptions): Promise<WorkflowStepExecutorResult> => {
      captured.push(options as CapturedWorkflowStepOptions);
      return {
        events: [],
        node,
        result: { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed },
        workflow,
      };
    });
    const executor = createExecutor();

    executor.setup({
      executeBackend: {
        execute: vi.fn(async () => ({ events: [], stopped: false, workflow })),
        executeStep,
      },
    });

    await executor.executeStep('user-1', {
      nodeId: 'node-1',
      settings: { authMode: 'none', graphqlUrl: 'http://localhost/graphql' },
      workflow,
    });

    expect(executeStep).toHaveBeenCalledTimes(1);
    expect(captured[0].workflow).toBe(workflow);
    expect(captured[0].nodeId).toBe('node-1');
  });

  it('builds a single-node workflow for node-only execution', async () => {
    const captured: CapturedWorkflowStepOptions[] = [];
    const executeStep = vi.fn(async (_id: string, options: ExecutorStepOptions): Promise<WorkflowStepExecutorResult> => {
      const workflowOptions = options as CapturedWorkflowStepOptions;
      captured.push(workflowOptions);
      return {
        events: [],
        node: workflowOptions.workflow.nodes[0],
        result: { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed },
        workflow: workflowOptions.workflow,
      };
    });
    const executor = createExecutor();
    const node: WorkflowNodeModel = {
      id: 'chat-step',
      gigaId: 'CurrentChatNode',
      modelId: 'current-chat',
      type: 'workflowStep',
      name: 'Current Chat',
      description: 'Single node step',
      kind: WorkflowNodeKindEnum.Process,
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: { chatId: '{{workflow.input.chatId}}', operation: 'pending' },
      ports: { in: {}, out: {} },
    };

    executor.setup({
      executeBackend: {
        execute: vi.fn(async () => ({ events: [], stopped: false, workflow: { metadata: { id: 'noop', name: 'noop' }, nodes: [], connections: [] } })),
        executeStep,
      },
    });

    await executor.executeStep('user-1', {
      node,
      nodeModels: { 'current-chat': { id: 'current-chat' } },
      runtimeInput: { operation: 'get_or_create_chat' },
      settings: { authMode: 'none', graphqlUrl: 'http://localhost/graphql' },
      workflowInput: { chatId: 'chat-1' },
    });

    expect(executeStep).toHaveBeenCalledTimes(1);
    expect(captured[0].nodeId).toBe('chat-step');
    expect(captured[0].workflow.input).toEqual({ chatId: 'chat-1' });
    expect(captured[0].workflow.nodes[0].runtime.operation).toBe('get_or_create_chat');
    expect(captured[0].nodeModels?.['current-chat']?.id || captured[0].workflow.nodeModels?.['current-chat'].id).toBe('current-chat');
  });
});
