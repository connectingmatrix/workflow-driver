import fs from 'node:fs';
import readline from 'node:readline';
import path from 'node:path';

export type InlineSqlManifest = { id: string; sourcePath: string; databasePath: string; tableName: string; columns: string[]; sampledRows: string[][]; totalRows: number; status: 'created' | 'manifest-only'; engine: 'duckdb' | 'sqlite' | 'manifest'; reason?: string | null };
const text = (value: unknown): string => String(value ?? '').trim();
const safeTable = (value: string): string => value.replace(/[^a-zA-Z0-9_]+/g, '_').replace(/^_+|_+$/g, '') || 'data';
const splitCsvLine = (line: string): string[] => {
  const cells: string[] = [];
  let current = '';
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    if (char === '"') { quoted = !quoted; continue; }
    if (char === ',' && !quoted) { cells.push(current); current = ''; continue; }
    current += char;
  }
  cells.push(current);
  return cells.map((cell) => cell.trim());
};

export const createInlineSqlManifestFromCsv = async (input: { sourcePath: string; outputDir: string; tableName?: string; sampleRows?: number; preferredEngine?: 'duckdb' | 'sqlite' }): Promise<InlineSqlManifest> => {
  await fs.promises.mkdir(input.outputDir, { recursive: true });
  const tableName = safeTable(text(input.tableName) || path.basename(input.sourcePath));
  const engine = input.preferredEngine || 'duckdb';
  const databasePath = path.join(input.outputDir, `${tableName}.${engine === 'duckdb' ? 'duckdb' : 'sqlite'}`);
  const stream = fs.createReadStream(input.sourcePath, { encoding: 'utf8' });
  const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
  let columns: string[] = [];
  const sampledRows: string[][] = [];
  let totalRows = 0;
  for await (const line of rl) {
    if (!columns.length) { columns = splitCsvLine(line).map((col, index) => safeTable(col || `column_${index + 1}`)); continue; }
    totalRows += 1;
    if (sampledRows.length < Number(input.sampleRows || 100)) sampledRows.push(splitCsvLine(line));
  }
  const manifest = { sourcePath: input.sourcePath, tableName, columns, sampledRows, totalRows, engine, databasePath, nextStep: engine === 'duckdb' ? 'Use allowlisted duckdb package to materialize/query this source.' : 'Use allowlisted sqlite package to materialize/query this source.' };
  await fs.promises.writeFile(databasePath + '.manifest.json', JSON.stringify(manifest, null, 2));
  return { id: `${tableName}-${Date.now()}`, sourcePath: input.sourcePath, databasePath, tableName, columns, sampledRows, totalRows, status: 'manifest-only', engine, reason: 'Materialization is performed by a dynamic database driver node when the package is allowlisted and cached.' };
};

export const queryInlineSqlManifest = async (input: { manifestPath: string; sql: string }) => {
  const manifest = JSON.parse(await fs.promises.readFile(input.manifestPath, 'utf8')) as InlineSqlManifest;
  return { status: 'planned', manifest, sql: input.sql, reason: 'The executor command port should run this SQL through an allowlisted DuckDB/SQLite driver node.' };
};
