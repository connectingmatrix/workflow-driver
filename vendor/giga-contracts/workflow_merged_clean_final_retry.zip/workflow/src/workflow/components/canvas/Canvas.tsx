import React from 'react';
import { Background, NodeMouseHandler, OnConnect, OnEdgesChange, OnNodesChange, OnSelectionChangeParams, ReactFlow } from '@xyflow/react';
import { DRAG_MIME_TYPE } from '@workflow/ui/workflow/components/node-library/NodeLibrary';
import { WorkflowFlowEdge, WorkflowFlowInstance, WorkflowFlowNode } from '@workflow/ui/workflow/components/canvas/workflow-flow.types';
import Edge from '@workflow/ui/workflow/components/canvas/Edge';
import CanvasInternalsSync from '@workflow/ui/workflow/components/canvas/CanvasInternalsSync';
import BaseNode from '@workflow/ui/workflow/nodes/BaseNode';
import SubworkflowCollapsedNode from '@workflow/ui/workflow/components/canvas/SubworkflowCollapsedNode';
import SubworkflowBoxNode from '@workflow/ui/workflow/components/canvas/SubworkflowBoxNode';
import CanvasInteractionControls, { CanvasInteractionMode } from '@workflow/ui/workflow/components/canvas/CanvasInteractionControls';
import { WorkflowCanvasEdgeStyle, WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';
import { resolveConnectionLineType } from '@workflow/ui/workflow/utils/workflow-canvas-settings.utils';

interface CanvasProps {
    nodes: WorkflowFlowNode[];
    edges: WorkflowFlowEdge[];
    edgeStyle: WorkflowCanvasEdgeStyle;
    isEditable: boolean;
    isInteractive: boolean;
    interactionMode: CanvasInteractionMode;
    nodeLibraryItems: WorkflowNodeLibraryItem[];
    onNodeClick: NodeMouseHandler;
    onNodeDoubleClick?: NodeMouseHandler;
    onNodeContextMenu?: NodeMouseHandler;
    onInit: (instance: WorkflowFlowInstance) => void;
    onConnect: OnConnect;
    onNodesChange: OnNodesChange<WorkflowFlowNode>;
    onEdgesChange: OnEdgesChange<WorkflowFlowEdge>;
    onNodeDragStart?: NodeMouseHandler;
    onNodeDragStop: NodeMouseHandler;
    onDropNode: (nodeLibraryItem: WorkflowNodeLibraryItem, x: number, y: number) => void;
    onInteractiveChange: (interactive: boolean) => void;
    onInteractionModeChange: (mode: CanvasInteractionMode) => void;
    onSelectionChange?: (selection: OnSelectionChangeParams) => void;
    onSelectionContextMenu?: (event: React.MouseEvent<Element, MouseEvent>, nodes: WorkflowFlowNode[]) => void;
    onPaneContextMenu?: (event: MouseEvent | React.MouseEvent) => void;
    onPaneClick?: (event: MouseEvent | React.MouseEvent) => void;
    children?: React.ReactNode;
}

const nodeTypes = {
    workflowStep: BaseNode,
    subworkflowCollapsed: SubworkflowCollapsedNode,
    subworkflowBox: SubworkflowBoxNode
};
const edgeTypes = { workflowEdge: Edge };

const Canvas: React.FC<CanvasProps> = ({
    nodes,
    edges,
    edgeStyle,
    isEditable,
    isInteractive,
    interactionMode,
    nodeLibraryItems,
    onNodeClick,
    onNodeDoubleClick,
    onNodeContextMenu,
    onInit,
    onConnect,
    onNodesChange,
    onEdgesChange,
    onNodeDragStart,
    onNodeDragStop,
    onDropNode,
    onInteractiveChange,
    onInteractionModeChange,
    onSelectionChange,
    onSelectionContextMenu,
    onPaneContextMenu,
    onPaneClick,
    children
}) => {
    return (
        <div
            className={`wf-designer__canvas wf-designer__canvas--${interactionMode}-mode`}
            data-cy="workflow-canvas"
            onDragOver={(event) => {
                if (isEditable) event.preventDefault();
            }}
            onDrop={(event) => {
                if (!isEditable) return;
                event.preventDefault();
                const nodeLibraryId = event.dataTransfer.getData(DRAG_MIME_TYPE);
                const nodeLibraryItem = nodeLibraryItems.find((item) => item.id === nodeLibraryId);
                if (!nodeLibraryItem) return;
                onDropNode(nodeLibraryItem, event.clientX, event.clientY);
            }}
        >
            <ReactFlow
                nodes={nodes}
                edges={edges}
                nodeTypes={nodeTypes}
                edgeTypes={edgeTypes}
                minZoom={0.25}
                maxZoom={1.75}
                onNodeClick={onNodeClick}
                onNodeDoubleClick={onNodeDoubleClick}
                onNodeContextMenu={onNodeContextMenu}
                onInit={onInit}
                onConnect={onConnect}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onNodeDragStart={onNodeDragStart}
                onNodeDragStop={onNodeDragStop}
                onSelectionChange={onSelectionChange}
                onSelectionContextMenu={onSelectionContextMenu}
                onPaneContextMenu={onPaneContextMenu}
                onPaneClick={onPaneClick}
                nodesDraggable={isEditable && isInteractive}
                nodesConnectable={isEditable && isInteractive}
                elementsSelectable={isEditable && isInteractive}
                edgesFocusable
                deleteKeyCode={null}
                selectionKeyCode={null}
                multiSelectionKeyCode={null}
                zoomActivationKeyCode={null}
                disableKeyboardA11y
                defaultEdgeOptions={{ selectable: true }}
                connectionLineType={resolveConnectionLineType(edgeStyle)}
                panOnScroll
                panOnDrag={isEditable && isInteractive && interactionMode === 'pan'}
                panActivationKeyCode={null}
                zoomOnPinch
                zoomOnScroll={false}
                selectionOnDrag={isEditable && isInteractive && interactionMode === 'select'}
                proOptions={{ hideAttribution: true }}
            >
                <CanvasInternalsSync nodes={nodes} edges={edges} />
                <Background />
                <CanvasInteractionControls
                    isEditable={isEditable}
                    isInteractive={isInteractive}
                    interactionMode={interactionMode}
                    onInteractiveChange={onInteractiveChange}
                    onInteractionModeChange={onInteractionModeChange}
                />
            </ReactFlow>
            {children}
        </div>
    );
};

export default Canvas;
