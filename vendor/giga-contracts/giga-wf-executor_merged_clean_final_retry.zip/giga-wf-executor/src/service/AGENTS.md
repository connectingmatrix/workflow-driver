# Executor Service Contracts

## Folder Purpose

- Orchestrate local or queue-based workflow execution backends.
- Expose execution, pubsub, and queue hooks to runtime callers.

## Core Contracts

- `createExecutor().setup()` receives `ExecutorSetup` and wires:
  - `execute` / `executeBrowser` for immediate execution
  - optional `workflowExecutionQueue` for async queue path.
- `enqueue(id, options, workflow)` returns `{ executionId, runId, status, workflowId }`.
- `start()` starts transport server and queue publisher/consumer when `workflowExecutionQueue` is present.
- `stop()` without `runId` shuts down active runs and queue/pubsub services.
- `listen(roomName, handler)` and `publish` must use workflow pubsub contract channels.

## Queue + Event Boundary

- Queue-backed execution path uses:
  - `createQueuedWorkflowRequestExecutor`
  - `runWorkflowExecutionQueue`
  - `consumeWorkflowExecutionEvents`
- Ensure `runExecutionRequest` receives both `request` and abort-aware `publishEvent`.
- Executor state `getRunning` must surface local and queued running records consistently.

## Local Rules

- Keep queue transport and execution transport concerns separate; do not collapse queued execution into local executor paths.
- No additional execution mode inference outside the configured backend strategy.
- Use typed interfaces from `src/service/types.ts` and `src/queue/types.ts`.
