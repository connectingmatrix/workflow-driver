import { WorkflowLogLevelEnum, WorkflowRunLogEvent } from '@workflow/ui/workflow/types';

export interface CompatWorkflowLogger {
    entries: WorkflowRunLogEvent[];
    push: (event: Omit<WorkflowRunLogEvent, 'timestamp'> | WorkflowRunLogEvent) => void;
}

export const buildJsonlOutput = (entries: unknown[]): string => {
    return entries
        .map((entry) => {
            try {
                return JSON.stringify(entry ?? {});
            } catch {
                return JSON.stringify({ error: 'Unable to serialize log entry.' });
            }
        })
        .join('\n');
};

export const parseRunLogEvent = (value: unknown): WorkflowRunLogEvent | null => {
    if (!value || typeof value !== 'object') return null;
    const candidate = value as WorkflowRunLogEvent;
    if (typeof candidate.event !== 'string') return null;
    if (typeof candidate.workflowId !== 'string') return null;
    if (typeof candidate.runId !== 'string') return null;

    return {
        timestamp: typeof candidate.timestamp === 'string' ? candidate.timestamp : new Date().toISOString(),
        level: candidate.level === WorkflowLogLevelEnum.Error || candidate.level === WorkflowLogLevelEnum.Warn || candidate.level === WorkflowLogLevelEnum.Info ? candidate.level : WorkflowLogLevelEnum.Info,
        event: candidate.event,
        workflowId: candidate.workflowId,
        runId: candidate.runId,
        nodeId: typeof candidate.nodeId === 'string' ? candidate.nodeId : undefined,
        message: typeof candidate.message === 'string' ? candidate.message : undefined,
        data: candidate.data
    };
};

export const createCompatWorkflowLogger = (): CompatWorkflowLogger => {
    const entries: WorkflowRunLogEvent[] = [];
    return {
        entries,
        push: (event) => {
            const normalized = parseRunLogEvent(event);
            if (!normalized) return;
            entries.push(normalized);
        }
    };
};

export const resolveLegacyExecutionEvents = (result: unknown): WorkflowRunLogEvent[] => {
    if (!result || typeof result !== 'object' || Array.isArray(result)) return [];
    const candidate = result as { events?: unknown; logs?: unknown };
    const source = Array.isArray(candidate.events) ? candidate.events : Array.isArray(candidate.logs) ? candidate.logs : [];
    return source.map((entry) => parseRunLogEvent(entry)).filter((entry): entry is WorkflowRunLogEvent => Boolean(entry));
};
