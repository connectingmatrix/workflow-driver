import { CSSProperties } from 'react';
import { Position } from '@xyflow/react';
import { WorkflowNodePortProperty, WorkflowNodePortSideEnum } from '@workflow/ui/workflow/types';

interface PortLike {
    rules: WorkflowNodePortProperty;
}

export interface PortPlacement<TPort extends PortLike> {
    port: TPort;
    side: WorkflowNodePortSideEnum;
    index: number;
    total: number;
}

export const getOffset = (index: number, total: number): string => `${((index + 1) / (total + 1)) * 100}%`;

export const resolvePortSide = (port: PortLike): WorkflowNodePortSideEnum => {
    switch (port.rules.side) {
        case WorkflowNodePortSideEnum.Right:
            return WorkflowNodePortSideEnum.Right;
        case WorkflowNodePortSideEnum.Top:
            return WorkflowNodePortSideEnum.Top;
        case WorkflowNodePortSideEnum.Bottom:
            return WorkflowNodePortSideEnum.Bottom;
        case WorkflowNodePortSideEnum.Left:
        default:
            return WorkflowNodePortSideEnum.Left;
    }
};

export const resolvePortPosition = (side: WorkflowNodePortSideEnum): Position => {
    switch (side) {
        case WorkflowNodePortSideEnum.Right:
            return Position.Right;
        case WorkflowNodePortSideEnum.Top:
            return Position.Top;
        case WorkflowNodePortSideEnum.Bottom:
            return Position.Bottom;
        case WorkflowNodePortSideEnum.Left:
        default:
            return Position.Left;
    }
};

export const sortPortsByOrder = <TPort extends PortLike>(ports: TPort[]): TPort[] => [...ports].sort((left, right) => Number(left.rules.order ?? 0) - Number(right.rules.order ?? 0));

export const buildPortPlacement = <TPort extends PortLike>(ports: TPort[]): Array<PortPlacement<TPort>> => {
    const counts: Record<WorkflowNodePortSideEnum, number> = {
        [WorkflowNodePortSideEnum.Left]: 0,
        [WorkflowNodePortSideEnum.Right]: 0,
        [WorkflowNodePortSideEnum.Top]: 0,
        [WorkflowNodePortSideEnum.Bottom]: 0
    };
    ports.forEach((port) => {
        counts[resolvePortSide(port)] += 1;
    });
    const seen: Record<WorkflowNodePortSideEnum, number> = {
        [WorkflowNodePortSideEnum.Left]: 0,
        [WorkflowNodePortSideEnum.Right]: 0,
        [WorkflowNodePortSideEnum.Top]: 0,
        [WorkflowNodePortSideEnum.Bottom]: 0
    };
    return ports.map((port) => {
        const side = resolvePortSide(port);
        const index = seen[side];
        seen[side] += 1;
        return { port, side, index, total: counts[side] };
    });
};

export const buildPortHandleStyle = (side: WorkflowNodePortSideEnum, index: number, total: number): CSSProperties =>
    side === WorkflowNodePortSideEnum.Left || side === WorkflowNodePortSideEnum.Right ? { top: getOffset(index, total) } : { left: getOffset(index, total) };

export const buildCommandHandleStyle = (side: WorkflowNodePortSideEnum, index: number, total: number): CSSProperties => {
    const baseStyle = buildPortHandleStyle(side, index, total);

    if (side === WorkflowNodePortSideEnum.Top) {
        return {
            ...baseStyle,
            top: '0%',
            bottom: 'auto'
        };
    }

    if (side === WorkflowNodePortSideEnum.Bottom) {
        return {
            ...baseStyle,
            top: '100%',
            bottom: 'auto'
        };
    }

    return baseStyle;
};

export const isBottomPortSide = (side: WorkflowNodePortSideEnum): boolean => side === WorkflowNodePortSideEnum.Bottom;
