import { describe, expect, it, vi } from 'vitest';
import { getWorkflowExecutionHostContext, getWorkflowManagementHostContext } from '../executor/workflows/workflow-host';

describe('getWorkflowExecutionHostContext', () => {
    it('reads a direct workflow execution host', () => {
        const executeWorkflowReference = vi.fn();
        expect(getWorkflowExecutionHostContext({ executeWorkflowReference })).toEqual({ executeWorkflowReference });
    });

    it('reads a nested workflows host', () => {
        const executeWorkflowReference = vi.fn();
        expect(getWorkflowExecutionHostContext({ workflows: { executeWorkflowReference } })).toEqual({ executeWorkflowReference });
    });

    it('returns null when no workflow execution host exists', () => {
        expect(getWorkflowExecutionHostContext({ workflows: {} })).toBeNull();
    });
});

describe('getWorkflowManagementHostContext', () => {
    it('reads a direct workflow management host', () => {
        const listWorkflowDefinitions = vi.fn();
        expect(getWorkflowManagementHostContext({ listWorkflowDefinitions })).toEqual({ listWorkflowDefinitions });
    });

    it('reads a nested workflows management host', () => {
        const publishWorkflowDefinition = vi.fn();
        expect(getWorkflowManagementHostContext({ workflows: { publishWorkflowDefinition } })).toEqual({ publishWorkflowDefinition });
    });

    it('returns null when no workflow management host exists', () => {
        expect(getWorkflowManagementHostContext({ workflows: {} })).toBeNull();
    });
});
