const escapeForTemplateLiteral = (value: string): string => {
    return value.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
};

const unescapeFromTemplateLiteral = (value: string): string => {
    return value
        .replace(/\\`/g, '`')
        .replace(/\\\$\{/g, '${')
        .replace(/\\\\/g, '\\');
};

export const buildInstructionCodeFromMarkdown = (markdown: string): string => {
    const escapedMarkdown = escapeForTemplateLiteral(markdown || '');
    return `const instruction = \`${escapedMarkdown}\`;

return {
  input,
  properties,
  instruction
};`;
};

export const extractInstructionMarkdownFromCode = (code: string): string | null => {
    if (!code.trim()) {
        return null;
    }

    const match = code.match(/\b(?:const|let|var)\s+instruction\s*=\s*`([\s\S]*?)`\s*;?/m);
    if (!match || typeof match[1] !== 'string') {
        return null;
    }

    return unescapeFromTemplateLiteral(match[1]);
};
