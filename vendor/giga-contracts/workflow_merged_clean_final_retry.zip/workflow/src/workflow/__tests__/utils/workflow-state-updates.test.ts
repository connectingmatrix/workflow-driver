import { describe, expect, it } from 'vitest';
import { getNodeLibraryItems } from '@workflow/nodes/node-utils';
import { addDroppedNode, insertNodeAfterOutputPort, insertNodeOnEdge, renameNodeInWorkflow, toggleNodeEnabled, updateNodeInspectorInWorkflow } from '@workflow/ui/workflow/utils/workflow-state-updates.utils';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('workflow state updates', () => {
    it('enforces unique names on rename', () => {
        const workflow = createEmptyWorkflow('wf_rename_unique');
        const firstNode = createWorkflowNode(workflow, 'code', 'Node A', 1);
        const secondNode = createWorkflowNode(workflow, 'code', 'Node B', 2);
        workflow.nodes = [firstNode, secondNode];

        const updated = renameNodeInWorkflow(workflow, secondNode.id, 'Node A');
        const renamedNode = updated.nodes.find((node) => node.id === secondNode.id);
        expect(renamedNode?.name).toBe('Node A 2');
    });

    it('enforces unique names when adding dropped node', () => {
        const workflow = createEmptyWorkflow('wf_drop_unique');
        const existingNode = createWorkflowNode(workflow, 'metadata', 'Metadata 1', 1);
        workflow.nodes = [existingNode];

        const metadataLibraryItem = getNodeLibraryItems().find((item) => item.modelId === 'metadata');
        expect(metadataLibraryItem).toBeTruthy();
        const updated = addDroppedNode(workflow, metadataLibraryItem!, { x: 100, y: 100 });
        const latest = updated.nodes[updated.nodes.length - 1];
        expect(latest.name).toBe('Metadata 2');
        expect(latest.id).toBe('metadata-2');
    });

    it('uses kebab-case node type segment when label includes spaces', () => {
        const workflow = createEmptyWorkflow('wf_drop_type_spaces');
        const item = getNodeLibraryItems().find((entry) => entry.modelId === 'run-subject-action');
        expect(item).toBeTruthy();

        const updated = addDroppedNode(workflow, item!, { x: 120, y: 80 });
        expect(updated.nodes).toHaveLength(1);
        expect(updated.nodes[0]?.id).toBe('run-subject-action-1');
    });

    it('enforces unique names when saving inspector updates', () => {
        const workflow = createEmptyWorkflow('wf_inspector_unique');
        const firstNode = createWorkflowNode(workflow, 'code', 'Alpha', 1);
        const secondNode = createWorkflowNode(workflow, 'metadata', 'Beta', 2);
        workflow.nodes = [firstNode, secondNode];

        const updated = updateNodeInspectorInWorkflow(
            workflow,
            secondNode.id,
            {
                title: secondNode.name,
                input: {},
                properties: {},
                fields: {},
                viewers: []
            },
            {
                ...(secondNode.properties ?? {}),
                name: 'Alpha',
                description: 'Updated by inspector'
            }
        );

        const targetNode = updated.nodes.find((node) => node.id === secondNode.id);
        expect(targetNode?.name).toBe('Alpha 2');
        expect(targetNode?.description).toBe('Updated by inspector');
    });

    it('inserts a node after specific output port', () => {
        const workflow = createEmptyWorkflow('wf_insert_port');
        const loopNode = createWorkflowNode(workflow, 'loop-over-items', 'Loop', 1);
        workflow.nodes = [loopNode];
        const replaceMeItem = getNodeLibraryItems().find((item) => item.modelId === 'replace-me');

        expect(replaceMeItem).toBeTruthy();
        const updated = insertNodeAfterOutputPort(workflow, loopNode.id, 'done', replaceMeItem!);

        expect(updated.nodes.length).toBe(2);
        expect(updated.nodes[1]?.id).toBe('replace-me-2');
        expect(updated.connections.length).toBe(1);
        expect(updated.connections[0].sourceHandle).toBe('out:done');
    });

    it('inserts a node on edge and replaces the old connection', () => {
        const workflow = createEmptyWorkflow('wf_insert_edge');
        const sourceNode = createWorkflowNode(workflow, 'replace-me', 'Source', 1);
        const targetNode = createWorkflowNode(workflow, 'respond-end', 'End', 2);
        workflow.nodes = [sourceNode, targetNode];
        workflow.connections = [createConnection('edge_1', sourceNode.id, targetNode.id, 'out:output', 'in:input')];
        const replaceMeItem = getNodeLibraryItems().find((item) => item.modelId === 'replace-me');

        expect(replaceMeItem).toBeTruthy();
        const updated = insertNodeOnEdge(workflow, 'edge_1', replaceMeItem!);

        expect(updated.nodes.length).toBe(3);
        expect(updated.nodes[2]?.id).toBe('replace-me-3');
        expect(updated.connections.length).toBe(2);
        expect(updated.connections.some((connection) => connection.from === sourceNode.id)).toBe(true);
        expect(updated.connections.some((connection) => connection.to === targetNode.id)).toBe(true);
    });

    it('keeps workflow unchanged when node sequence exceeds 999', () => {
        const workflow = createEmptyWorkflow('wf_node_limit');
        workflow.nodes = [
            {
                ...createWorkflowNode(workflow, 'metadata', 'Metadata 1', 1),
                id: 'metadata-999'
            }
        ];

        const metadataLibraryItem = getNodeLibraryItems().find((item) => item.modelId === 'metadata');
        expect(metadataLibraryItem).toBeTruthy();

        const updated = addDroppedNode(workflow, metadataLibraryItem!, { x: 100, y: 100 });
        expect(updated.nodes).toHaveLength(1);
        expect(updated.nodes[0].id).toBe('metadata-999');
    });

    it('toggles node enabled state', () => {
        const workflow = createEmptyWorkflow('wf_toggle_node_enabled');
        const node = createWorkflowNode(workflow, 'replace-me', 'Replace', 1);
        workflow.nodes = [node];

        const disabled = toggleNodeEnabled(workflow, node.id, false);
        expect(disabled.nodes[0].properties?.enabled).toBe(false);
        const enabled = toggleNodeEnabled(disabled, node.id, true);
        expect(enabled.nodes[0].properties?.enabled).toBe(true);
    });
});
