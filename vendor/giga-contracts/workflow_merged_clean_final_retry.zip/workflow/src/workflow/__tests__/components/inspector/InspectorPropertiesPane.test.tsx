// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import InspectorPropertiesPane from '@workflow/ui/workflow/components/inspector/InspectorPropertiesPane';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import { WORKFLOW_FAILURE_MITIGATION_RETRY, WORKFLOW_FAILURE_MITIGATION_STOP } from '@workflow/ui/workflow/utils/workflow-failure-mitigation.utils';

vi.mock('@workflow/ui/workflow/components/inspector/CodeEditor', () => ({
    default: ({ value }: { value: string }) => <div data-testid="code-editor">{value}</div>
}));

vi.mock('@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor', () => ({
    default: ({ value }: { value: string }) => <div data-testid="markdown-editor">{value}</div>
}));

describe('InspectorPropertiesPane', () => {
    afterEach(() => {
        cleanup();
    });

    it('renders code-only pane for if-else node', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: true, markdown: false }}
                instructionOnly
                fields={{
                    description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true, styles: { layoutPreset: 'full' } }
                }}
                propertiesEditorState={{ description: 'Code-only branch node' }}
                code="return { true: input };"
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.getByTestId('code-editor')).toBeInTheDocument();
        expect(screen.queryByText('Properties')).not.toBeInTheDocument();
        expect(screen.queryByText('Instruction')).not.toBeInTheDocument();
    });

    it('does not render hidden nodeLibraryId field', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    nodeLibraryId: { type: WorkflowNodeFieldTypeEnum.String, editable: false, hidden: true },
                    description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true, styles: { layoutPreset: 'full' } }
                }}
                propertiesEditorState={{ nodeLibraryId: 'metadata-node', description: 'Visible description' }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.queryByText('Node Library Id')).not.toBeInTheDocument();
        expect(screen.getByText('Description')).toBeInTheDocument();
        expect(screen.getByText('Description').closest('.wf-inspector__property-row')).toHaveClass('wf-inspector__property-row--floating');
    });

    it('renders string fields with floating label rows', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{ name: { type: WorkflowNodeFieldTypeEnum.String, editable: true } }}
                propertiesEditorState={{ name: 'Node 1' }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        const row = screen.getByText('Name').closest('.wf-inspector__property-row');
        expect(row).toHaveClass('wf-inspector__property-row--floating');
        expect(screen.getAllByText('Name', { selector: 'label' })).toHaveLength(1);
    });

    it('applies schema column layout metadata for inline row rendering', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    method: {
                        type: WorkflowNodeFieldTypeEnum.Method,
                        editable: true,
                        styles: {
                            layoutPreset: 'inline',
                            columns: 12,
                            labelCols: 4,
                            controlCols: 8
                        }
                    }
                }}
                propertiesEditorState={{ method: 'GET' }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        const row = screen.getByText('Method').closest('.wf-inspector__property-row');
        expect(row).toHaveClass('wf-inspector__property-row--inline');
        expect(row).toHaveClass('grid');
    });

    it('shows retry dropdown only when failure mitigation is set to retry', () => {
        const baseProps = {
            instruction: { code: false, markdown: false },
            fields: {
                failureMitigation: {
                    type: WorkflowNodeFieldTypeEnum.Select,
                    editable: true,
                    styles: { layoutPreset: 'mitigation' },
                    options: [
                        { label: 'Retry Node', value: WORKFLOW_FAILURE_MITIGATION_RETRY },
                        { label: 'Stop Workflow', value: WORKFLOW_FAILURE_MITIGATION_STOP }
                    ]
                },
                retryCount: {
                    type: WorkflowNodeFieldTypeEnum.Select,
                    editable: true,
                    options: Array.from({ length: 6 }, (_, index) => ({ label: String(index + 1), value: String(index + 1) }))
                }
            },
            code: '',
            markdown: '',
            onPropertyChange: vi.fn(),
            onCodeChange: vi.fn(),
            onMarkdownChange: vi.fn(),
            onExecuteStep: vi.fn(),
            isExecuting: false
        };

        const { rerender } = render(<InspectorPropertiesPane {...baseProps} propertiesEditorState={{ failureMitigation: WORKFLOW_FAILURE_MITIGATION_STOP, retryCount: '3' }} />);

        expect(screen.getByText('Failure Mitigation')).toBeInTheDocument();
        expect(screen.getByText('Failure Mitigation').closest('.wf-inspector__property-row')).toHaveClass('wf-inspector__property-row--mitigation');
        expect(screen.getAllByRole('textbox')).toHaveLength(1);

        rerender(<InspectorPropertiesPane {...baseProps} propertiesEditorState={{ failureMitigation: WORKFLOW_FAILURE_MITIGATION_RETRY, retryCount: '3' }} />);

        expect(screen.getAllByRole('textbox')).toHaveLength(2);
    });

    it('infers boolean fields from runtime values and renders toggle controls', () => {
        const onPropertyChange = vi.fn();
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    forwardSessionLogs: {
                        type: WorkflowNodeFieldTypeEnum.Boolean,
                        editable: true,
                        styles: {
                            layoutPreset: 'switch',
                            showBooleanState: false
                        }
                    }
                }}
                propertiesEditorState={{ forwardSessionLogs: false }}
                code=""
                markdown=""
                onPropertyChange={onPropertyChange}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.getByText('Forward Session Logs')).toBeInTheDocument();
        expect(screen.getByText('Forward Session Logs').closest('.wf-inspector__property-row')).toHaveClass('wf-inspector__property-row--switch');
        expect(screen.queryByText('Off')).not.toBeInTheDocument();
        expect(screen.queryByRole('combobox')).not.toBeInTheDocument();

        fireEvent.click(screen.getByRole('checkbox'));
        expect(onPropertyChange).toHaveBeenCalledWith('forwardSessionLogs', true);
    });

    it('renders wait time as an entity depending field with no slider and dynamic clamp', async () => {
        const onPropertyChange = vi.fn();
        const { container } = render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    time: {
                        type: WorkflowNodeFieldTypeEnum.Number,
                        label: 'Wait Time',
                        editable: true,
                        styles: { floatingLabel: true, showSlider: false },
                        dependsOn: {
                            field: 'unit',
                            entityField: true,
                            fallback: { min: 0, max: 300, step: 1 },
                            map: {
                                seconds: { min: 0, max: 300, step: 1 },
                                minutes: { min: 0, max: 5, step: 1 }
                            }
                        }
                    },
                    unit: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        label: 'Unit',
                        editable: true,
                        styles: { floatingLabel: true },
                        options: [
                            { label: 'Second', value: 'seconds' },
                            { label: 'Minutes', value: 'minutes' }
                        ]
                    }
                }}
                propertiesEditorState={{ time: 300000, unit: 'seconds' }}
                code=""
                markdown=""
                onPropertyChange={onPropertyChange}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(container.querySelector('.wf-inspector__property-row--depending')).toBeInTheDocument();
        expect(container.querySelector('.wf-depending-field__separator')).toBeInTheDocument();
        expect(screen.queryByRole('slider')).not.toBeInTheDocument();
        expect(screen.getByRole('spinbutton')).toBeInTheDocument();
        expect(screen.getByRole('textbox', { name: 'Unit' })).toBeInTheDocument();

        await waitFor(() => {
            expect(onPropertyChange).toHaveBeenCalledWith('time', 300);
        });
    });

    it('renders prompt fields with markdown editor', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{ prompt: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true } }}
                propertiesEditorState={{ prompt: 'Write me a summary.' }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.getByTestId('markdown-editor')).toBeInTheDocument();
    });

    it('renders number fields with slider when min/max bounds are provided', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    temperature: {
                        type: WorkflowNodeFieldTypeEnum.Number,
                        editable: true,
                        min: 0,
                        max: 99,
                        step: 1
                    }
                }}
                propertiesEditorState={{ temperature: 0.2 }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.getByRole('slider')).toBeInTheDocument();
        expect(screen.getAllByRole('spinbutton')).toHaveLength(1);
    });

    it('moves forward session logs field to the end of properties', () => {
        const { container } = render(
            <InspectorPropertiesPane
                instruction={{ code: false, markdown: false }}
                fields={{
                    forwardSessionLogs: {
                        type: WorkflowNodeFieldTypeEnum.Boolean,
                        editable: true,
                        styles: {
                            layoutPreset: 'switch',
                            showBooleanState: false
                        }
                    },
                    failureMitigation: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        editable: true,
                        options: [{ label: 'Stop Workflow', value: WORKFLOW_FAILURE_MITIGATION_STOP }]
                    },
                    retryCount: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        editable: true,
                        options: [{ label: '1', value: '1' }]
                    }
                }}
                propertiesEditorState={{ forwardSessionLogs: false, failureMitigation: WORKFLOW_FAILURE_MITIGATION_STOP, retryCount: '1' }}
                code=""
                markdown=""
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        const labels = Array.from(container.querySelectorAll('.wf-inspector__property-label'))
            .map((node) => node.textContent?.trim())
            .filter(Boolean);
        expect(labels.at(-1)).toBe('Forward Session Logs');
    });

    it('omits code node payload, code, and markdown fields from properties tab', () => {
        render(
            <InspectorPropertiesPane
                instruction={{ code: true, markdown: true }}
                hiddenFieldKeys={['payload']}
                fields={{
                    payload: { type: WorkflowNodeFieldTypeEnum.Json, editable: true },
                    description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true }
                }}
                propertiesEditorState={{
                    payload: '{"foo":"bar"}',
                    code: 'return input;',
                    markdown: '**summary**',
                    description: 'Code node'
                }}
                code="return input;"
                markdown="**summary**"
                onPropertyChange={vi.fn()}
                onCodeChange={vi.fn()}
                onMarkdownChange={vi.fn()}
                onExecuteStep={vi.fn()}
                isExecuting={false}
            />
        );

        expect(screen.queryByText('Payload', { selector: 'label' })).not.toBeInTheDocument();
        expect(screen.queryByText('Code', { selector: 'label' })).not.toBeInTheDocument();
        expect(screen.queryByText('Markdown', { selector: 'label' })).not.toBeInTheDocument();
        expect(screen.getByText('Description', { selector: 'label' })).toBeInTheDocument();
    });
});
