import { describe, expect, it } from 'vitest';
import { buildWorkspaceInspectorModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-inspector-model';
import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import { WorkflowNodeFieldTypeEnum, WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';

const buildConfig = (overrides: Partial<WorkflowInspectorConfig> = {}): WorkflowInspectorConfig => ({
    nodeId: 'node_1',
    modelId: 'code',
    nodeTypeLabel: 'Code Node',
    instruction: { code: true, markdown: true },
    name: 'Code Node 1',
    title: 'Code Node 1',
    input: {},
    workflow: {},
    properties: {
        name: 'Code Node 1',
        description: 'Transforms input into output.',
        failureMitigation: 'stop',
        retryCount: 1,
        forwardSessionLogs: false
    },
    fields: {
        name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
        description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
        failureMitigation: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Stop workflow', value: 'stop' }] },
        retryCount: { type: WorkflowNodeFieldTypeEnum.Number, editable: true },
        forwardSessionLogs: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true }
    },
    viewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: {} }],
    documentation: {
        summary: 'Code node summary',
        usage: 'Use this node to execute code.',
        inputs: [],
        outputs: []
    },
    code: 'return input;',
    markdown: 'Return the transformed payload.',
    ...overrides
});

describe('buildWorkspaceInspectorModel', () => {
    it('builds the workspace model for code nodes using module metadata', () => {
        const config = buildConfig({
            controlNodes: {
                llm: {
                    openai: { modelId: 'openai' }
                }
            }
        });

        const model = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: config.properties,
            activeInputTab: 'table',
            activeParametersTab: 'properties',
            activeInstructionTab: 'code',
            activeOutputTab: 'json',
            executionResult: {
                output: {},
                logs: ['node completed'],
                error: null,
                renderedMarkdown: 'Rendered markdown'
            },
            renderedMarkdown: 'Rendered markdown',
            hasUnsavedChanges: true
        });

        expect(model.header.title).toBe('Code Node 1');
        expect(model.header.primaryAction?.label).toBe('Run Node');
        expect(model.input.tabs.map((tab) => tab.id)).toContain('control-nodes');
        expect(model.input.acceptedFormats).toEqual(['CSV', 'JSON', 'PDF', 'Docs']);
        expect(model.parameters.heroCard?.title).toBe('Node settings');
        expect(model.parameters.sections.map((section) => section.id)).toEqual(['general', 'execution']);
        expect(model.parameters.footerAction?.disabled).toBe(false);
        expect(model.output.summary?.title).toBe('Output summary');
        expect(model.output.activities?.[0]?.title).toBe('Execution complete');
    });

    it('uses start-node workspace sections when start metadata is available', () => {
        const config = buildConfig({
            modelId: 'start',
            nodeTypeLabel: 'Start',
            instruction: { code: false, markdown: false },
            properties: {
                triggerSource: 'webhook',
                webhookMethod: 'POST',
                description: 'Entry point',
                prompt: 'Run',
                variables: '{}',
                forwardSessionLogs: true
            },
            fields: {
                triggerSource: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Webhook', value: 'webhook' }] },
                webhookMethod: { type: WorkflowNodeFieldTypeEnum.Method, editable: true },
                description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                prompt: { type: WorkflowNodeFieldTypeEnum.Markdown, editable: true },
                variables: { type: WorkflowNodeFieldTypeEnum.Json, editable: true },
                forwardSessionLogs: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true }
            },
            code: '',
            markdown: ''
        });

        const model = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: config.properties,
            activeInputTab: 'table',
            activeParametersTab: 'properties',
            activeInstructionTab: 'code',
            activeOutputTab: 'json',
            executionResult: null,
            renderedMarkdown: '',
            hasUnsavedChanges: false
        });

        expect(model.parameters.sections.map((section) => section.id)).toEqual(['general', 'webhook', 'execution']);
        expect(model.parameters.heroCard?.title).toBe('Node settings');
    });

    it('uses output-format workspace metadata and overlays live execution output into viewers', () => {
        const config = buildConfig({
            modelId: 'output-format',
            nodeTypeLabel: 'Output Format',
            properties: {
                name: 'Output Format 1',
                description: 'Shape the payload',
                format: 'markdown',
                value: '# Heading',
                useAiFormatting: true,
                modelId: 'llm_1',
                aiPrompt: 'Improve the response',
                failureMitigation: 'stop-workflow',
                forwardSessionLogs: true
            },
            fields: {
                name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                format: {
                    type: WorkflowNodeFieldTypeEnum.Select,
                    editable: true,
                    options: [
                        { label: 'JSON', value: 'json' },
                        { label: 'Markdown', value: 'markdown' },
                        { label: 'Raw', value: 'raw' },
                        { label: 'Table', value: 'table' }
                    ]
                },
                value: { type: WorkflowNodeFieldTypeEnum.Json, editable: true },
                useAiFormatting: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true },
                modelId: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'LLM 1', value: 'llm_1' }] },
                aiPrompt: { type: WorkflowNodeFieldTypeEnum.Markdown, editable: true },
                failureMitigation: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Stop workflow', value: 'stop-workflow' }] },
                forwardSessionLogs: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true }
            }
        });

        const model = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: config.properties,
            activeInputTab: 'json',
            activeParametersTab: 'properties',
            activeInstructionTab: 'code',
            activeOutputTab: 'json',
            executionResult: null,
            renderedMarkdown: '',
            hasUnsavedChanges: false
        });

        expect(model.parameters.sections.map((section) => section.id)).toEqual(['general', 'payload', 'ai', 'execution']);
        expect(model.parameters.sections.find((section) => section.id === 'ai')?.fields.find((field) => field.key === 'useAiFormatting')?.presentation).toBe('execution-toggle');
        expect(model.parameters.sections.find((section) => section.id === 'payload')?.fields.find((field) => field.key === 'value')?.definition.type).toBe(WorkflowNodeFieldTypeEnum.Markdown);
        expect(model.parameters.sections.find((section) => section.id === 'execution')?.fields.map((field) => field.key)).toEqual(['failureMitigation', 'forwardSessionLogs']);
        expect(model.output.tabs.map((tab) => tab.id)).toEqual(['markdown', 'raw']);
        expect(model.output.activeViewer?.type).toBe(WorkflowViewerTypeEnum.Markdown);
        expect(model.output.activeViewer?.value).toBe('# Heading');
    });

    it('uses ai-governor workspace metadata for selection prompt execution', () => {
        const config = buildConfig({
            modelId: 'ai-governor',
            nodeTypeLabel: 'AI Governor',
            properties: {
                name: 'AI Governor 1',
                description: 'Plan connected actions',
                selectionPromptMd: 'Plan the workflow actions',
                failureMitigation: 'stop-workflow'
            },
            fields: {
                name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                selectionPromptMd: { type: WorkflowNodeFieldTypeEnum.Markdown, editable: true },
                failureMitigation: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Stop workflow', value: 'stop-workflow' }] }
            }
        });

        const model = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: config.properties,
            activeInputTab: 'json',
            activeParametersTab: 'properties',
            activeInstructionTab: 'code',
            activeOutputTab: 'json',
            executionResult: null,
            renderedMarkdown: '',
            hasUnsavedChanges: false
        });

        expect(model.parameters.sections.map((section) => section.id)).toEqual(['general', 'prompts', 'execution']);
        expect(model.parameters.sections.find((section) => section.id === 'prompts')?.fields.map((field) => field.key)).toEqual(['selectionPromptMd']);
        expect(model.parameters.heroCard?.title).toBe('AI action planner');
    });

    it('uses ai-agent workspace metadata for workflow-aware execution', () => {
        const config = buildConfig({
            modelId: 'ai-agent',
            nodeTypeLabel: 'AI Agent',
            properties: {
                name: 'AI Agent 1',
                description: 'Plan and answer',
                selectionPromptMd: 'Plan workflow actions',
                executionMode: 'plan-and-run',
                confirmationPolicy: 'mutations-only',
                modelActionPolicy: 'prefer-direct-replies',
                workflowToolAllowlist: ['workflow_1'],
                analysisSummary: 'Summarize the plan',
                confirmed: false,
                context: 'General context',
                failureMitigation: 'stop-workflow'
            },
            fields: {
                name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                selectionPromptMd: { type: WorkflowNodeFieldTypeEnum.Markdown, editable: true },
                executionMode: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Plan And Run', value: 'plan-and-run' }] },
                confirmationPolicy: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Mutations Only', value: 'mutations-only' }] },
                modelActionPolicy: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Prefer Direct Replies', value: 'prefer-direct-replies' }] },
                workflowToolAllowlist: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Workflow 1', value: 'workflow_1' }] },
                analysisSummary: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                confirmed: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true },
                context: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                failureMitigation: { type: WorkflowNodeFieldTypeEnum.Select, editable: true, options: [{ label: 'Stop workflow', value: 'stop-workflow' }] }
            }
        });

        const model = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: config.properties,
            activeInputTab: 'json',
            activeParametersTab: 'properties',
            activeInstructionTab: 'code',
            activeOutputTab: 'json',
            executionResult: null,
            renderedMarkdown: '',
            hasUnsavedChanges: false
        });

        expect(model.parameters.sections.map((section) => section.id)).toEqual(['general', 'planning', 'workflow-tools', 'more', 'execution']);
        expect(model.parameters.sections.find((section) => section.id === 'workflow-tools')?.fields.map((field) => field.key)).toEqual(['workflowToolAllowlist']);
        expect(model.parameters.heroCard?.title).toBe('AI workflow agent');
    });
});
