import { randomUUID } from 'node:crypto';

export type CompiledWorkflowNode = {
  id: string;
  modelId: string;
  type: string;
  name: string;
  runtime: Record<string, unknown>;
  position?: { x: number; y: number };
};
export type CompiledWorkflowEdge = { from: string; to: string; label?: string; condition?: Record<string, unknown> };
export type CompiledWorkflowDraft = {
  id: string;
  name: string;
  description: string;
  workflow: { nodes: CompiledWorkflowNode[]; edges: CompiledWorkflowEdge[]; metadata: Record<string, unknown> };
  metadata: Record<string, unknown>;
  validation: { ok: boolean; errors: string[]; warnings: string[] };
};

const text = (value: unknown): string => String(value ?? '').trim();
const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
const list = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);
const slug = (value: string): string => value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 90) || 'workflow';
const includes = (haystack: string, pattern: RegExp) => pattern.test(haystack.toLowerCase());

const node = (id: string, type: string, name: string, runtime: Record<string, unknown>, index: number): CompiledWorkflowNode => ({
  id, type, modelId: type, name, runtime, position: { x: 100 + index * 300, y: 180 + (index % 2) * 140 },
});
const linearEdges = (nodes: CompiledWorkflowNode[]): CompiledWorkflowEdge[] => nodes.slice(1).map((item, index) => ({ from: nodes[index].id, to: item.id }));

const validateDraft = (nodes: CompiledWorkflowNode[], edges: CompiledWorkflowEdge[]) => {
  const errors: string[] = [];
  const warnings: string[] = [];
  const ids = new Set<string>();
  for (const n of nodes) {
    if (!n.id) errors.push('Workflow node is missing id.');
    if (ids.has(n.id)) errors.push(`Duplicate node id: ${n.id}`);
    ids.add(n.id);
    if (!n.modelId) errors.push(`Node ${n.id} is missing modelId.`);
  }
  for (const e of edges) {
    if (!ids.has(e.from)) errors.push(`Edge references missing source ${e.from}.`);
    if (!ids.has(e.to)) errors.push(`Edge references missing target ${e.to}.`);
  }
  if (!nodes.length) errors.push('Workflow must have at least one node.');
  if (nodes.length > 1 && !edges.length) warnings.push('Workflow has multiple nodes but no edges.');
  return { ok: errors.length === 0, errors, warnings };
};

const nodesFromPrompt = (prompt: string, input: Record<string, unknown>): CompiledWorkflowNode[] => {
  const explicit = list(input.nodes).map(record);
  if (explicit.length) return explicit.map((n, index) => node(text(n.id) || `node_${index + 1}`, text(n.modelId || n.type || n.kind || 'ai-agent'), text(n.name || n.title || `Step ${index + 1}`), record(n.runtime || n.config || n.properties || n), index));
  const p = prompt.toLowerCase();
  if (includes(p, /create.*workflow.*create.*workflow|workflow.*to.*create.*workflow/))
    return [node('start', 'start', 'Start', { prompt }, 0), node('compile_child_workflow', 'workflow', 'Compile child workflow', { operation: 'compile', prompt: 'Create the requested child workflow.' }, 1), node('create_child_workflow', 'workflow', 'Create child workflow', { operation: 'create', fromPrevious: true }, 2), node('confirm_destructive', 'if-else', 'Confirm destructive action if needed', { confirmationRequired: /delete|remove|cleanup/.test(p) }, 3), node('output', 'response', 'Response', { mode: 'workflow-card' }, 4)];
  if (includes(p, /empty.*channel|empty.*tree|remove.*empty|clean.*tree/))
    return [node('start', 'start', 'Start', { prompt }, 0), node('fetch_tree', 'tree', 'Fetch tree', { operation: 'list', includeChats: true, includePosts: true }, 1), node('filter_empty', 'code', 'Find empty paths', { codeIntent: 'Find branches with no chats, categories, subjects, posts, or attachments.' }, 2), node('confirm', 'if-else', 'Confirm removal', { confirmationRequired: true }, 3), node('delete_empty', 'tree', 'Delete empty paths', { operation: 'delete', destructive: true }, 4), node('refetch_tree', 'output', 'Refetch tree', { refetch: ['user-tree'] }, 5)];
  if (includes(p, /chart|plot|map|population|blue shades|visual/))
    return [node('start', 'start', 'Start', { prompt }, 0), node('load_data', 'loader', 'Load or synthesize data', { prompt, requiredData: /pakistan|us|usa|map/.test(p) ? 'map-region-population' : 'chart-data' }, 1), node('chart', 'chart', 'Render chart', { prompt, inferLabels: true, colorScale: /blue/.test(p) ? 'blue-choropleth' : 'auto' }, 2), node('publish', 'artifact-publish', 'Publish chart artifact', { type: 'chart' }, 3), node('output', 'response', 'Response', { mode: 'chart-card' }, 4)];
  if (includes(p, /rcm|training|train|analysis|manager|swarm/))
    return [node('start', 'start', 'Start', { prompt }, 0), node('create_rcm_channel', 'tree', 'Create RCM channel structure', { operation: 'create', entity: 'Channel', name: 'RCM' }, 1), node('manager_workflow', 'workflow', 'Create RCM Manager workflow', { operation: 'create', temporary: false }, 2), node('training_workflow', 'workflow', 'Create RCM Training workflow', { operation: 'create', purpose: 'training' }, 3), node('analysis_workflow', 'workflow', 'Create RCM Data Analysis workflow', { operation: 'create', purpose: 'analysis' }, 4), node('test_data', 'file-output', 'Generate test data', { sizeMb: 3, type: 'rcm-test-data' }, 5), node('execute_training', 'workflow', 'Execute training workflow', { operation: 'execute' }, 6), node('output', 'response', 'Training response', { mode: 'report-and-artifacts' }, 7)];
  if (includes(p, /world politics|region|country|genre|tree structure|content structure/))
    return [node('start', 'start', 'Start', { prompt }, 0), node('taxonomy', 'ai-agent', 'Build taxonomy', { prompt, todo: 'Create regions, countries, genres without duplication.' }, 1), node('lookup_existing', 'tree', 'Find existing tree nodes', { operation: 'find', matchBy: ['slug', 'name'] }, 2), node('create_missing', 'tree', 'Create missing nodes', { operation: 'create_or_get', linkExisting: true }, 3), node('link_nodes', 'tree', 'Link existing nodes', { operation: 'link', avoidDuplicates: true }, 4), node('refetch_tree', 'output', 'Refetch tree', { refetch: ['user-tree'] }, 5)];
  return [node('start', 'start', 'Start', { prompt }, 0), node('agent', 'ai-agent', 'AI Agent', { prompt, mode: 'capability-driven' }, 1), node('output', 'response', 'Response', { mode: 'markdown-and-artifacts' }, 2)];
};

export const compileWorkflowFromAgentPrompt = (input: Record<string, unknown>): CompiledWorkflowDraft => {
  const prompt = text(input.prompt || input.message || input.description || input.name || 'Generated workflow');
  const id = text(input.id) || randomUUID();
  const name = text(input.name) || prompt.slice(0, 70) || 'Generated workflow';
  const nodes = nodesFromPrompt(prompt, input);
  const explicitEdges = list(input.edges).map(record).map((e) => ({ from: text(e.from), to: text(e.to), label: text(e.label), condition: record(e.condition) })).filter((e) => e.from && e.to);
  const edges = explicitEdges.length ? explicitEdges : linearEdges(nodes);
  const validation = validateDraft(nodes, edges);
  return {
    id,
    name,
    description: prompt,
    workflow: { nodes, edges, metadata: { generatedBy: 'ai-agent', compiler: 'r14-capability-workflow-compiler', prompt } },
    metadata: { generatedBy: 'ai-agent', prompt, slug: slug(name), temporary: input.temporary === true },
    validation,
  };
};
