# workflow

## Giga product/runtime documentation

See [docs/giga-workflow/README.md](docs/giga-workflow/README.md) for the current Giga feature rules, role boundaries, AI Agent decision chains, ingestion chains, and process-monitor interconnects.
