import { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodePortSchema, WorkflowNodeSchema } from '../../../types';

export const BI_DIRECTIONAL_PORT_TYPE = 'bi-directional';
export const COMMAND_HANDLE_PREFIX = 'cmd:';

const toPortMap = (value: unknown): Record<string, WorkflowNodePortSchema> =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, WorkflowNodePortSchema>)
        : {};

const parseHandle = (handle: string | undefined): { prefix: string; portName: string | null } => {
    if (!handle || typeof handle !== 'string') return { prefix: '', portName: null };
    const [prefix, rawPortName] = handle.split(':');
    const portName = rawPortName?.trim() ? rawPortName.trim() : null;
    return {
        prefix: prefix?.trim() ?? '',
        portName
    };
};

export const getNodeSchema = (workflow: WorkflowDefinition, nodeId: string): WorkflowNodeSchema | null => {
    const node = workflow.nodes.find((item) => item.id === nodeId);
    if (!node) return null;
    const schema = workflow.nodeModels?.[node.modelId];
    return schema && typeof schema === 'object' && !Array.isArray(schema) ? schema : null;
};

export const getNormalizedCommandPorts = (schema: WorkflowNodeSchema | null | undefined): Record<string, WorkflowNodePortSchema> => {
    if (!schema) return {};
    const explicitCommands = toPortMap(schema.commands);
    const inputPorts = toPortMap(schema.inputs);
    const outputPorts = toPortMap(schema.outputs);
    const normalized: Record<string, WorkflowNodePortSchema> = { ...explicitCommands };

    const mergeLegacyPort = (portId: string, rules: WorkflowNodePortSchema | undefined, legacySide: 'left' | 'right') => {
        if (!rules || rules.portType !== BI_DIRECTIONAL_PORT_TYPE) return;
        const existing = normalized[portId] ?? {};
        normalized[portId] = {
            ...rules,
            ...existing,
            side: existing.side ?? rules.side ?? legacySide,
            portType: BI_DIRECTIONAL_PORT_TYPE
        };
    };

    Object.entries(inputPorts).forEach(([portId, rules]) => mergeLegacyPort(portId, rules, 'left'));
    Object.entries(outputPorts).forEach(([portId, rules]) => mergeLegacyPort(portId, rules, 'right'));

    return normalized;
};

export const isCommandPortId = (schema: WorkflowNodeSchema | null | undefined, portId: string | null | undefined): boolean => {
    if (!portId) return false;
    return Object.prototype.hasOwnProperty.call(getNormalizedCommandPorts(schema), portId);
};

export const getLegacyPortType = (
    schema: WorkflowNodeSchema | null | undefined,
    direction: 'inputs' | 'outputs',
    portId: string | null | undefined
): string | undefined => {
    if (!schema || !portId) return undefined;
    const ports = toPortMap(schema[direction]);
    return ports[portId]?.portType;
};

export const resolveCommandPortIdFromHandle = (
    schema: WorkflowNodeSchema | null | undefined,
    handle: string | undefined,
    direction: 'inputs' | 'outputs',
    fallbackPort?: string
): string | null => {
    const parsed = parseHandle(handle);
    if (parsed.prefix === 'cmd' && isCommandPortId(schema, parsed.portName)) {
        return parsed.portName;
    }
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && isCommandPortId(schema, parsed.portName)) {
        return parsed.portName;
    }
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && getLegacyPortType(schema, direction, parsed.portName) === BI_DIRECTIONAL_PORT_TYPE) {
        return parsed.portName;
    }
    if (!parsed.portName && fallbackPort && isCommandPortId(schema, fallbackPort)) {
        return fallbackPort;
    }
    return null;
};

export const toCanonicalCommandHandle = (portId: string): string => `${COMMAND_HANDLE_PREFIX}${portId}`;

export const parseInputPortName = (connection: WorkflowConnectionModel): string => {
    const parsed = parseHandle(connection.targetHandle);
    return parsed.portName ?? 'input';
};

export const parseOutputPortName = (connection: WorkflowConnectionModel): string => {
    const parsed = parseHandle(connection.sourceHandle);
    return parsed.portName ?? 'output';
};

export const isCommandConnection = (workflow: WorkflowDefinition, connection: WorkflowConnectionModel): boolean => {
    const sourceSchema = getNodeSchema(workflow, connection.from);
    const targetSchema = getNodeSchema(workflow, connection.to);
    const sourcePortId = resolveCommandPortIdFromHandle(sourceSchema, connection.sourceHandle, 'outputs', parseOutputPortName(connection));
    const targetPortId = resolveCommandPortIdFromHandle(targetSchema, connection.targetHandle, 'inputs', parseInputPortName(connection));
    return Boolean(sourcePortId && targetPortId);
};

export const getCommandConnectionPortId = (workflow: WorkflowDefinition, connection: WorkflowConnectionModel, nodeId?: string): string | null => {
    if (!isCommandConnection(workflow, connection)) return null;
    if (nodeId === connection.to) {
        const targetSchema = getNodeSchema(workflow, connection.to);
        return resolveCommandPortIdFromHandle(targetSchema, connection.targetHandle, 'inputs', parseInputPortName(connection));
    }
    if (nodeId === connection.from) {
        const sourceSchema = getNodeSchema(workflow, connection.from);
        return resolveCommandPortIdFromHandle(sourceSchema, connection.sourceHandle, 'outputs', parseOutputPortName(connection));
    }
    const sourceSchema = getNodeSchema(workflow, connection.from);
    return resolveCommandPortIdFromHandle(sourceSchema, connection.sourceHandle, 'outputs', parseOutputPortName(connection));
};

export const getCommandPeerNodeIds = (workflow: WorkflowDefinition, nodeId: string): string[] => {
    const peers = new Set<string>();
    workflow.connections.forEach((connection) => {
        if (!isCommandConnection(workflow, connection)) return;
        if (connection.from === nodeId) peers.add(connection.to);
        if (connection.to === nodeId) peers.add(connection.from);
    });
    peers.delete(nodeId);
    return [...peers];
};

export const getCommandPeersForPort = (workflow: WorkflowDefinition, nodeId: string, commandPortId: string): WorkflowConnectionModel[] =>
    workflow.connections.filter((connection) => {
        if (connection.from !== nodeId && connection.to !== nodeId) return false;
        return getCommandConnectionPortId(workflow, connection, nodeId) === commandPortId;
    });
