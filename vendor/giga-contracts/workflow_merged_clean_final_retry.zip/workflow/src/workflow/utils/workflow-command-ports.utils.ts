import { getAllNodeSchemas, resolveNodeSchema } from '@workflow/nodes/node-utils';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodePortProperty, WorkflowNodeSchema } from '@workflow/ui/workflow/types';

export const BI_DIRECTIONAL_PORT_TYPE = 'bi-directional';
export const COMMAND_HANDLE_PREFIX = 'cmd:';

const toPortMap = (value: unknown): Record<string, WorkflowNodePortProperty> =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, WorkflowNodePortProperty>)
        : {};

const parseHandle = (handleId: string | null | undefined): { prefix: string; portName: string | null } => {
    if (!handleId) return { prefix: '', portName: null };
    const [prefix, rawPortName] = handleId.split(':');
    return {
        prefix: prefix?.trim() ?? '',
        portName: rawPortName?.trim() ? rawPortName.trim() : null
    };
};

export const parseHandlePortName = (handleId: string | null | undefined, fallbackPort: string): string => parseHandle(handleId).portName ?? fallbackPort;

export const toCanonicalCommandHandle = (portId: string): string => `${COMMAND_HANDLE_PREFIX}${portId}`;

export const getNormalizedCommandPorts = (schema: WorkflowNodeSchema | null | undefined): Record<string, WorkflowNodePortProperty> => {
    if (!schema) return {};
    const explicitCommands = toPortMap(schema.commands);
    const inputs = toPortMap(schema.inputs);
    const outputs = toPortMap(schema.outputs);
    const normalized: Record<string, WorkflowNodePortProperty> = { ...explicitCommands };

    const mergeLegacyPort = (portId: string, rules: WorkflowNodePortProperty | undefined, side: WorkflowNodePortProperty['side']) => {
        if (!rules || rules.portType !== BI_DIRECTIONAL_PORT_TYPE) return;
        const existing = normalized[portId] ?? {};
        normalized[portId] = {
            ...rules,
            ...existing,
            side: existing.side ?? rules.side ?? side,
            portType: BI_DIRECTIONAL_PORT_TYPE
        };
    };

    Object.entries(inputs).forEach(([portId, rules]) => mergeLegacyPort(portId, rules, 'left'));
    Object.entries(outputs).forEach(([portId, rules]) => mergeLegacyPort(portId, rules, 'right'));
    return normalized;
};

export const getSortedCommandPortIds = (schema: WorkflowNodeSchema | null | undefined): string[] =>
    Object.entries(getNormalizedCommandPorts(schema))
        .sort((left, right) => Number(left[1].order ?? 0) - Number(right[1].order ?? 0) || left[0].localeCompare(right[0]))
        .map(([portId]) => portId);

const getLegacyPortType = (schema: WorkflowNodeSchema | null | undefined, direction: 'inputs' | 'outputs', portId: string | null): string | undefined => {
    if (!schema || !portId) return undefined;
    return toPortMap(schema[direction])[portId]?.portType;
};

export const resolveCommandPortIdFromHandle = (
    schema: WorkflowNodeSchema | null | undefined,
    handleId: string | null | undefined,
    direction: 'inputs' | 'outputs',
    fallbackPort?: string
): string | null => {
    const parsed = parseHandle(handleId);
    const commands = getNormalizedCommandPorts(schema);
    if (parsed.prefix === 'cmd' && parsed.portName && commands[parsed.portName]) {
        return parsed.portName;
    }
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && parsed.portName && commands[parsed.portName]) {
        return parsed.portName;
    }
    if ((parsed.prefix === 'in' || parsed.prefix === 'out') && getLegacyPortType(schema, direction, parsed.portName) === BI_DIRECTIONAL_PORT_TYPE) {
        return parsed.portName;
    }
    if (!parsed.portName && fallbackPort && commands[fallbackPort]) {
        return fallbackPort;
    }
    return null;
};

export const isCommandConnection = (workflow: WorkflowDefinition, connection: WorkflowConnectionModel): boolean => {
    const sourceNode = workflow.nodes.find((node) => node.id === connection.from);
    const targetNode = workflow.nodes.find((node) => node.id === connection.to);
    if (!sourceNode || !targetNode) return false;
    const schemas = workflow.nodeModels || getAllNodeSchemas();
    const sourceSchema = resolveNodeSchema(sourceNode.modelId, schemas);
    const targetSchema = resolveNodeSchema(targetNode.modelId, schemas);
    const sourcePortId = resolveCommandPortIdFromHandle(sourceSchema, connection.sourceHandle, 'outputs');
    const targetPortId = resolveCommandPortIdFromHandle(targetSchema, connection.targetHandle, 'inputs');
    return Boolean(sourcePortId && targetPortId);
};
