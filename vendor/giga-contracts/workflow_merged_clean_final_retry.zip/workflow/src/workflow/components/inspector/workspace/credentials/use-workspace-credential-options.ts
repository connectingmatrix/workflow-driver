import React from 'react';
import type { WorkflowCredentialOption } from '@workflow/ui/workflow/types';
import { useWorkspaceAsyncSelectorOptions, type WorkspaceAsyncSelectorOptionsState } from '@workflow/ui/workflow/components/inspector/workspace/selectors/use-workspace-async-selector-options';

export type WorkspaceCredentialOptionsState = WorkspaceAsyncSelectorOptionsState<WorkflowCredentialOption>;

interface UseWorkspaceCredentialOptionsArgs {
    visible: boolean;
    serviceId: string | null;
    fetchCredentials?: (serviceId: string) => Promise<WorkflowCredentialOption[]>;
}

const SORT_ORDER: Record<string, number> = {
    PERSONAL: 0,
    ORGANIZATION: 1,
    GLOBAL: 2
};

const sortCredentialOptions = (options: WorkflowCredentialOption[]): WorkflowCredentialOption[] =>
    [...options].sort((left, right) => {
        const scopeOrder = (SORT_ORDER[left.scope] ?? 99) - (SORT_ORDER[right.scope] ?? 99);
        if (scopeOrder !== 0) {
            return scopeOrder;
        }
        return left.credentialName.localeCompare(right.credentialName);
    });

export const useWorkspaceCredentialOptions = ({ visible, serviceId, fetchCredentials }: UseWorkspaceCredentialOptionsArgs): WorkspaceCredentialOptionsState => {
    const normalizedServiceId = typeof serviceId === 'string' ? serviceId.trim() : '';
    const loadOptions = React.useCallback(() => (fetchCredentials && normalizedServiceId ? fetchCredentials(normalizedServiceId) : Promise.resolve([])), [fetchCredentials, normalizedServiceId]);
    return useWorkspaceAsyncSelectorOptions({
        visible,
        enabled: Boolean(normalizedServiceId),
        emptyMessage: 'No credential service is configured for this node.',
        missingFetcherMessage: `The workflow host did not provide fetchCredentials() for ${normalizedServiceId}.`,
        emptyFetcherResultMessage: `No allowed credentials were returned for ${normalizedServiceId}.`,
        loadOptions: fetchCredentials && normalizedServiceId ? loadOptions : undefined,
        normalizeOptions: sortCredentialOptions
    });
};
