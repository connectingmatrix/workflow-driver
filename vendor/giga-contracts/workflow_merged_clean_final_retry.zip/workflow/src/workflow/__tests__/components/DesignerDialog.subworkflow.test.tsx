/** @vitest-environment jsdom */
import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { getAllNodeSchemas, getNodeLibraryItems, getNodeModuleById, resolveNodeSchema } from '@workflow/nodes/node-utils';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import { WorkflowDefinition } from '@workflow/ui/workflow/types';

const createMouseEvent = (type: string, options?: MouseEventInit): MouseEvent => new MouseEvent(type, { bubbles: true, cancelable: true, ...options });

const driver: WorkflowUiDriver = {
    createRequestId: () => 'req_1',
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({ connect: vi.fn(), disconnect: vi.fn(), startPreview: vi.fn(async () => undefined), cancelPreview: vi.fn(), addPreviewLogHandler: vi.fn(() => () => undefined), addPreviewStateHandler: vi.fn(() => () => undefined), addPreviewResultHandler: vi.fn(() => () => undefined), addPreviewErrorHandler: vi.fn(() => () => undefined), addPreviewStopHandler: vi.fn(() => () => undefined) }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: createEmptyWorkflow('wf_1'), logs: [] })),
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};

const nodeCatalog: WorkflowNodeCatalog = {
    modules: [],
    getAllNodeSchemas,
    getNodeLibraryItems,
    getNodeModuleById,
    resolveNodeSchema,
    isLocalCapableNodeModel: () => true
};

const { prewarmJavascriptRuntimeFrameMock } = vi.hoisted(() => ({
    prewarmJavascriptRuntimeFrameMock: vi.fn(async () => undefined)
}));

vi.mock('@workflow/ui/workflow/components/toolbar/Toolbar', () => ({
    default: () => <div data-testid="toolbar" />
}));

vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({
    default: () => null
}));

vi.mock('@/common/components/logs/JsonlLogsDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({
    default: (props: { visible: boolean; config?: { nodeId?: string }; onHide: () => void }) =>
        props.visible ? (
            <div data-testid="workflow-node-inspector">
                <span data-testid="workflow-node-inspector-node-id">{props.config?.nodeId ?? ''}</span>
                <button type="button" onClick={props.onHide}>
                    Close Inspector
                </button>
            </div>
        ) : null
}));

vi.mock('primereact/contextmenu', () => {
    const ReactModule = require('react') as typeof React;

    const MockContextMenu = ReactModule.forwardRef(({ model = [], onHide }: { model?: Array<{ label?: string; visible?: boolean; command?: () => void }>; onHide?: () => void }, ref) => {
        const [visible, setVisible] = ReactModule.useState(false);

        ReactModule.useImperativeHandle(ref, () => ({
            show: () => setVisible(true),
            hide: () => {
                setVisible(false);
                onHide?.();
            }
        }));

        if (!visible) return null;
        return (
            <div data-testid="subworkflow-context-menu">
                {model
                    .filter((item) => item?.visible !== false)
                    .map((item, index) => (
                        <button
                            type="button"
                            key={`${item.label ?? 'item'}-${index}`}
                            onClick={() => {
                                item.command?.();
                                setVisible(false);
                                onHide?.();
                            }}
                        >
                            {item.label}
                        </button>
                    ))}
            </div>
        );
    });

    MockContextMenu.displayName = 'MockContextMenu';
    return { ContextMenu: MockContextMenu };
});

vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({
    default: (props: {
        nodes: Array<{ id: string; position: { x: number; y: number } }>;
        nodeLibraryItems: Array<{ id: string }>;
        onNodeClick?: (event: MouseEvent, node: { id: string; position: { x: number; y: number } }) => void;
        onNodeDoubleClick?: (event: MouseEvent, node: { id: string; position: { x: number; y: number } }) => void;
        onNodeContextMenu?: (event: MouseEvent, node: { id: string; position: { x: number; y: number } }) => void;
        onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number }; fitView?: () => void; setCenter?: () => void }) => void;
        onSelectionChange?: (selection: { nodes: Array<{ id: string }> }) => void;
        onSelectionContextMenu?: (event: MouseEvent, nodes: Array<{ id: string }>) => void;
        onPaneContextMenu?: (event: MouseEvent) => void;
        onPaneClick?: (event: MouseEvent) => void;
        onDropNode: (item: { id: string }, x: number, y: number) => void;
        onNodeDragStart?: (event: unknown, node: { id: string; position: { x: number; y: number } }) => void;
        onNodeDragStop: (event: unknown, node: { id: string; position: { x: number; y: number } }) => void;
    }) => {
        React.useEffect(() => {
            props.onInit({
                screenToFlowPosition: ({ x, y }) => ({ x, y }),
                fitView: () => undefined,
                setCenter: () => undefined
            });
        }, [props.onInit]);

        const triggerPaneClick = (): void => {
            props.onPaneClick?.(createMouseEvent('click', { button: 0, clientX: 120, clientY: 80 }));
        };
        const triggerPaneContextMenu = (): void => {
            props.onPaneContextMenu?.(createMouseEvent('contextmenu', { button: 2, clientX: 120, clientY: 80 }));
        };

        const triggerDropInside = (): void => {
            const sampleNode = props.nodes.find((node) => node.id === 'node_2') ?? props.nodes.find((node) => !node.id.startsWith('subworkflow:'));
            const item = props.nodeLibraryItems[0];
            if (!sampleNode || !item) return;
            props.onDropNode(item, sampleNode.position.x + 16, sampleNode.position.y + 16);
        };

        const triggerSubworkflowDrag = (): void => {
            const boxNode = props.nodes.find((node) => node.id.startsWith('subworkflow:box:'));
            if (!boxNode) return;
            props.onNodeDragStart?.({}, { id: boxNode.id, position: boxNode.position });
            props.onNodeDragStop({}, { id: boxNode.id, position: { x: boxNode.position.x + 30, y: boxNode.position.y + 20 } });
        };

        const triggerNodeSingleClick = (): void => {
            const sampleNode = props.nodes.find((node) => node.id === 'node_2');
            if (!sampleNode) return;
            props.onNodeClick?.(createMouseEvent('click', { button: 0 }), sampleNode);
        };

        const triggerNodeDoubleClick = (): void => {
            const sampleNode = props.nodes.find((node) => node.id === 'node_2');
            if (!sampleNode) return;
            props.onNodeDoubleClick?.(createMouseEvent('dblclick', { button: 0 }), sampleNode);
        };

        const triggerSelectionContextMenu = (): void => {
            props.onSelectionContextMenu?.(createMouseEvent('contextmenu', { button: 2, clientX: 110, clientY: 82 }), [{ id: 'node_3' }]);
        };
        const triggerSubworkflowNodeContextMenu = (): void => {
            const subworkflowNode = props.nodes.find((node) => node.id.startsWith('subworkflow:box:') || node.id.startsWith('subworkflow:collapsed:'));
            if (!subworkflowNode) return;
            props.onNodeContextMenu?.(createMouseEvent('contextmenu', { button: 2, clientX: 150, clientY: 120 }), subworkflowNode);
        };

        return (
            <div data-testid="workflow-canvas">
                <button type="button" onClick={() => props.onSelectionChange?.({ nodes: [{ id: 'node_3' }] })}>
                    Select End Node
                </button>
                <button type="button" onClick={() => props.onSelectionChange?.({ nodes: [{ id: 'node_3' }, { id: 'subworkflow:box:sw_1' }] })}>
                    Select End + Subworkflow
                </button>
                <button type="button" onClick={() => props.onSelectionChange?.({ nodes: [] })}>
                    Clear Selection
                </button>
                <button type="button" onClick={triggerPaneClick}>
                    Pane Left Click
                </button>
                <button type="button" onClick={triggerPaneContextMenu}>
                    Pane Right Click
                </button>
                <button type="button" onClick={triggerSelectionContextMenu}>
                    Selection Context Menu
                </button>
                <button type="button" onClick={triggerSubworkflowNodeContextMenu}>
                    Subworkflow Node Context Menu
                </button>
                <button type="button" onClick={triggerDropInside}>
                    Drop Inside Subworkflow
                </button>
                <button type="button" onClick={triggerSubworkflowDrag}>
                    Drag Subworkflow
                </button>
                <button type="button" onClick={triggerNodeSingleClick}>
                    Single Click Node
                </button>
                <button type="button" onClick={triggerNodeDoubleClick}>
                    Double Click Node
                </button>
            </div>
        );
    }
}));

vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({
    listWorkflowUserNodes: vi.fn(async () => [])
}));

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (importOriginal) => {
    const originalModule = await importOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>();
    return {
        ...originalModule,
        prewarmJavascriptRuntimeFrame: prewarmJavascriptRuntimeFrameMock
    };
});

const createWorkflowFixture = (): WorkflowDefinition => {
    const workflow = createEmptyWorkflow('wf_subworkflow_dialog');
    const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
    const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
    const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
    workflow.nodes = [startNode, codeNode, endNode];
    workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];
    workflow.metadata.ui = {
        subworkflows: [{ id: 'sw_1', name: 'Main Group', nodeIds: [codeNode.id], collapsed: false }]
    };
    return workflow;
};

afterEach(() => {
    cleanup();
    document.body.innerHTML = '';
    document.body.className = '';
    document.body.removeAttribute('style');
});

describe('DesignerDialog subworkflow interactions', () => {
    it('opens context menu on right-click and creates a new subworkflow from selection', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        fireEvent.click(screen.getByRole('button', { name: 'Select End Node' }));
        fireEvent.click(screen.getByRole('button', { name: 'Pane Right Click' }));
        fireEvent.click(await screen.findByRole('button', { name: 'Create Subworkflow' }));

        await waitFor(() => {
            const subworkflows = latestWorkflow?.metadata.ui?.subworkflows ?? [];
            expect(subworkflows.length).toBe(2);
            expect(subworkflows.some((entry) => entry.id !== 'sw_1' && entry.nodeIds.includes('node_3'))).toBe(true);
        });
    });

    it('hides create action when context target is a subworkflow', async () => {
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Subworkflow Node Context Menu' }));

        await waitFor(() => {
            expect(screen.queryByRole('button', { name: 'Create Subworkflow' })).toBeNull();
            expect(screen.getByRole('button', { name: 'Ungroup Subworkflow' })).toBeTruthy();
            expect(screen.queryByRole('button', { name: 'Add Nodes to Subworkflow' })).toBeNull();
        });
    });

    it('auto-members dropped nodes into containing subworkflow', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        const beforeDropCount = (latestWorkflow as WorkflowDefinition | null)?.metadata.ui?.subworkflows?.find((entry: { id: string; nodeIds: string[] }) => entry.id === 'sw_1')?.nodeIds.length ?? 0;
        fireEvent.click(screen.getByRole('button', { name: 'Drop Inside Subworkflow' }));

        await waitFor(() => {
            const afterDropCount = (latestWorkflow as WorkflowDefinition | null)?.metadata.ui?.subworkflows?.find((entry: { id: string; nodeIds: string[] }) => entry.id === 'sw_1')?.nodeIds.length ?? 0;
            expect(afterDropCount).toBeGreaterThan(beforeDropCount);
        });
    });

    it('shows ungroup action for subworkflow node right-click and removes only subworkflow metadata', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        fireEvent.click(screen.getByRole('button', { name: 'Subworkflow Node Context Menu' }));
        fireEvent.click(await screen.findByRole('button', { name: 'Ungroup Subworkflow' }));

        await waitFor(() => {
            expect((latestWorkflow?.metadata.ui?.subworkflows ?? []).some((entry) => entry.id === 'sw_1')).toBe(false);
            expect(latestWorkflow?.nodes.some((node) => node.id === 'node_2')).toBe(true);
            expect((latestWorkflow?.connections ?? []).length).toBeGreaterThan(0);
        });
    });

    it('keeps pending create action valid even if selection clears after menu opens', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        fireEvent.click(screen.getByRole('button', { name: 'Select End Node' }));
        fireEvent.click(screen.getByRole('button', { name: 'Pane Right Click' }));
        fireEvent.click(screen.getByRole('button', { name: 'Clear Selection' }));
        fireEvent.click(await screen.findByRole('button', { name: 'Create Subworkflow' }));

        await waitFor(() => {
            const subworkflows = latestWorkflow?.metadata.ui?.subworkflows ?? [];
            expect(subworkflows.some((entry) => entry.id !== 'sw_1' && entry.nodeIds.includes('node_3'))).toBe(true);
        });
    });

    it('supports selection context menu path for create action', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        fireEvent.click(screen.getByRole('button', { name: 'Selection Context Menu' }));
        fireEvent.click(await screen.findByRole('button', { name: 'Create Subworkflow' }));

        await waitFor(() => {
            const subworkflows = latestWorkflow?.metadata.ui?.subworkflows ?? [];
            expect(subworkflows.some((entry) => entry.id !== 'sw_1' && entry.nodeIds.includes('node_3'))).toBe(true);
        });
    });

    it('keeps selected canvas nodes when backspace is pressed inside an input', () => {
        const handleWorkflowChange = vi.fn();
        const searchInput = document.createElement('input');
        document.body.appendChild(searchInput);

        try {
            render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible initialEditable workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={handleWorkflowChange} />);

            handleWorkflowChange.mockClear();
            fireEvent.click(screen.getByRole('button', { name: 'Select End Node' }));
            searchInput.focus();
            fireEvent.keyDown(searchInput, { key: 'Backspace' });

            expect(handleWorkflowChange).not.toHaveBeenCalled();
        } finally {
            searchInput.remove();
        }
    });

    it('deletes selected canvas nodes when backspace is pressed outside editable fields', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible initialEditable workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={(workflow) => (latestWorkflow = workflow)} />);

        fireEvent.click(screen.getByRole('button', { name: 'Select End Node' }));
        fireEvent.keyDown(window, { key: 'Backspace' });

        await waitFor(() => {
            expect(latestWorkflow?.nodes.some((node) => node.id === 'node_3')).toBe(false);
        });
    });

    it('moves subworkflow member nodes when the synthetic subworkflow box is dragged', async () => {
        const workflow = createWorkflowFixture();
        let latestWorkflow: WorkflowDefinition | null = workflow;
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={workflow} onHide={vi.fn()} onWorkflowChange={(nextWorkflow) => (latestWorkflow = nextWorkflow)} />);

        const before = workflow.nodes.find((node: { id: string; position: { x: number; y: number } }) => node.id === 'node_2')?.position;
        fireEvent.click(screen.getByRole('button', { name: 'Drag Subworkflow' }));

        await waitFor(() => {
            const after = (latestWorkflow as WorkflowDefinition | null)?.nodes.find((node: { id: string; position: { x: number; y: number } }) => node.id === 'node_2')?.position;
            expect(before).toBeTruthy();
            expect(after).toEqual({
                x: (before?.x ?? 0) + 30,
                y: (before?.y ?? 0) + 20
            });
        });
    });

    it('applies single-click selection only and opens inspector on double-click', async () => {
        render(<DesignerDialog driver={driver} nodeCatalog={nodeCatalog} visible workflow={createWorkflowFixture()} onHide={vi.fn()} onWorkflowChange={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Single Click Node' }));
        expect(screen.queryByTestId('workflow-node-inspector')).toBeNull();

        fireEvent.click(screen.getByRole('button', { name: 'Double Click Node' }));
        await waitFor(() => {
            expect(screen.getByTestId('workflow-node-inspector')).toBeTruthy();
            expect(screen.getByTestId('workflow-node-inspector-node-id').textContent).toBe('node_2');
        });
    });
});
