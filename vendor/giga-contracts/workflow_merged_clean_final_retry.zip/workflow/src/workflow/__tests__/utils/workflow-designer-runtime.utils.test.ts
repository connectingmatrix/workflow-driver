import { describe, expect, it } from 'vitest';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { clearNodeExecutionArtifacts } from '@workflow/ui/workflow/utils/workflow-designer-runtime.utils';
import { WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

describe('workflow designer runtime helpers', () => {
    it('clears previous output and error artifacts before a new execution pass', () => {
        const workflow = createEmptyWorkflow('wf_runtime_clear');
        const node = createWorkflowNode(workflow, 'code', 'Code', 1);

        node.output = { stale: true };
        node.runtime = {
            enabled: true,
            keep: 'value',
            lastError: 'Old error',
            error: 'Old error payload',
            stack: 'trace'
        };
        node.ports = {
            in: node.ports?.in ?? {},
            out: {
                ...(node.ports?.out as Record<string, unknown>),
                output: { stale: true },
                __activeOutputs: ['output'],
                command: { STATE: { ping: true } }
            }
        };

        const nextNode = clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Running);
        const nextRuntime = nextNode.runtime as Record<string, unknown>;
        const nextPortsOut = nextNode.ports.out as Record<string, unknown>;

        expect(nextNode.status).toBe(WorkflowNodeStatusEnum.Running);
        expect(nextNode.output).toBeNull();
        expect(nextRuntime.keep).toBe('value');
        expect(nextRuntime.lastError).toBeUndefined();
        expect(nextRuntime.error).toBeUndefined();
        expect(nextRuntime.stack).toBeUndefined();
        expect(nextPortsOut.output).toBeNull();
        expect(nextPortsOut.__activeOutputs).toEqual([]);
        expect(nextPortsOut.command).toEqual({ STATE: { ping: true } });
    });

    it('does not mutate the source node while clearing execution artifacts', () => {
        const workflow = createEmptyWorkflow('wf_runtime_clear_clone');
        const node = createWorkflowNode(workflow, 'code', 'Code', 1);
        node.runtime = { keep: 'value', lastError: 'Old error' };
        node.ports = {
            in: {},
            out: { output: { stale: true }, __activeOutputs: ['output'] }
        };

        const nextNode = clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Running);

        expect(nextNode.runtime.lastError).toBeUndefined();
        expect(node.runtime.lastError).toBe('Old error');
        expect(nextNode.ports.out.output).toBeNull();
        expect(node.ports.out.output).toEqual({ stale: true });
        expect(node.ports.out.__activeOutputs).toEqual(['output']);
    });

    it('syncs inspector properties with cleaned runtime artifacts', () => {
        const workflow = createEmptyWorkflow('wf_runtime_clear_inspector');
        const node = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 1);
        node.runtime = { selectionPromptMd: '{{code_5.query}}', error: 'Old error' };
        node.properties = node.runtime;
        node.inspector = { ...(node.inspector ?? { title: node.name, input: {}, viewers: [] }), properties: { selectionPromptMd: '{{code\\_5.query}}', error: 'Old error' } };

        const nextNode = clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Stopped);

        expect(nextNode.inspector?.properties).toEqual(nextNode.runtime);
        expect((nextNode.inspector?.properties as Record<string, unknown>).selectionPromptMd).toBe('{{code_5.query}}');
        expect((nextNode.inspector?.properties as Record<string, unknown>).error).toBeUndefined();
    });
});
