import { describe, expect, it } from 'vitest';
import { buildWorkflowEdgePath } from '@workflow/ui/workflow/components/canvas/workflow-edge-path.utils';

describe('workflow edge path utils', () => {
    it('routes smoothstep edges through sibling lanes and keeps controls off the stroke', () => {
        const result = buildWorkflowEdgePath('smoothstep', {
            sourceX: 0,
            sourceY: 24,
            targetX: 260,
            targetY: 144,
            sourcePosition: 'right',
            targetPosition: 'left',
            sourceLaneOffset: -18,
            targetLaneOffset: 18
        });

        expect(result.path).toContain('Q');
        expect(result.controlsX).not.toBe(result.labelX);
    });

    it('keeps straight-edge controls offset from the line midpoint', () => {
        const result = buildWorkflowEdgePath('straight', {
            sourceX: 20,
            sourceY: 40,
            targetX: 180,
            targetY: 40,
            sourcePosition: 'right',
            targetPosition: 'left'
        });

        expect(result.path).toBe('M 20 40 L 180 40');
        expect(result.controlsX).toBe(result.labelX);
        expect(result.controlsY).not.toBe(result.labelY);
    });
});
