import { describe, expect, it } from 'vitest';
import { ConnectionLineType } from '@xyflow/react';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { resolveConnectionLineType, resolveWorkflowCanvasSettings } from '@workflow/ui/workflow/utils/workflow-canvas-settings.utils';

describe('workflow canvas settings utils', () => {
    it('defaults existing workflows to legacy canvas settings', () => {
        expect(resolveWorkflowCanvasSettings(createEmptyWorkflow('wf_canvas_defaults'))).toEqual({ layoutEngine: 'legacy', edgeStyle: 'legacy' });
    });

    it('maps edge styles to react-flow connection preview types', () => {
        expect(resolveConnectionLineType('legacy')).toBe(ConnectionLineType.Bezier);
        expect(resolveConnectionLineType('straight')).toBe(ConnectionLineType.Straight);
        expect(resolveConnectionLineType('step')).toBe(ConnectionLineType.Step);
        expect(resolveConnectionLineType('smoothstep')).toBe(ConnectionLineType.SmoothStep);
    });
});
