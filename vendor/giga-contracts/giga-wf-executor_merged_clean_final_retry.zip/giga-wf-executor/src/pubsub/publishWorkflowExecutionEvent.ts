import { CompressionTypes, type Producer } from "kafkajs";
import { readWorkflowQueueRedpandaConfig } from "../queue";
import { toWorkflowQueueEventMessage } from "../queue/workflowQueueMessage";
import { createWorkflowExecutionPubsubClient } from "./createWorkflowExecutionPubsubClient";
import type {
  WorkflowQueueEventProducer,
  WorkflowQueueRedpandaConfig,
} from "../queue/types";

export const publishWorkflowExecutionEvent = (
  config?: WorkflowQueueRedpandaConfig,
): WorkflowQueueEventProducer => {
  const resolvedConfig = config || readWorkflowQueueRedpandaConfig(process.env);
  const producer: Producer =
    createWorkflowExecutionPubsubClient(resolvedConfig).producer();
  return {
    connect: async () => producer.connect(),
    disconnect: async () => producer.disconnect(),
    publish: async (executionEvent) => {
      await producer.send({
        compression: CompressionTypes.GZIP,
        topic: resolvedConfig.eventsTopic,
        messages: [toWorkflowQueueEventMessage(executionEvent)],
      });
    },
  };
};
