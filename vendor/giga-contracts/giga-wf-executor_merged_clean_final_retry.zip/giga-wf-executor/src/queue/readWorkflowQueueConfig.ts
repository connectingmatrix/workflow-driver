import type { WorkflowQueueRedpandaConfig } from './types';

const DEFAULT_BROKERS = ['localhost:19092', 'localhost:29092', 'localhost:39092'];
const DEFAULT_REQUEST_TOPIC = 'workflow-execution-requests';
const DEFAULT_EVENTS_TOPIC = 'workflow-execution-events';

const parseBoolean = (value: string | undefined, fallback: boolean): boolean => {
  const normalized = String(value || '').trim().toLowerCase();
  if (!normalized) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(normalized);
};

const parseCsv = (value: string | undefined, fallback: string[]): string[] => {
  const entries = String(value || '').split(',').map((entry) => entry.trim()).filter(Boolean);
  return entries.length ? entries : fallback;
};

export const readWorkflowQueueRedpandaConfig = (env: NodeJS.ProcessEnv = process.env): WorkflowQueueRedpandaConfig => ({
  brokers: parseCsv(env.WORKFLOW_QUEUE_BROKERS, DEFAULT_BROKERS),
  clientId: String(env.WORKFLOW_QUEUE_CLIENT_ID || 'workflow-queue').trim() || 'workflow-queue',
  ssl: parseBoolean(env.WORKFLOW_QUEUE_SSL, false),
  username: String(env.WORKFLOW_QUEUE_USERNAME || '').trim() || undefined,
  password: String(env.WORKFLOW_QUEUE_PASSWORD || '').trim() || undefined,
  requestTopic: String(env.WORKFLOW_QUEUE_REQUEST_TOPIC || DEFAULT_REQUEST_TOPIC).trim() || DEFAULT_REQUEST_TOPIC,
  eventsTopic: String(env.WORKFLOW_QUEUE_EVENTS_TOPIC || DEFAULT_EVENTS_TOPIC).trim() || DEFAULT_EVENTS_TOPIC,
  requestConsumerGroupId: String(env.WORKFLOW_QUEUE_REQUEST_CONSUMER_GROUP_ID || 'workflow-queue-worker').trim() || 'workflow-queue-worker',
  eventConsumerGroupId: String(env.WORKFLOW_QUEUE_EVENT_CONSUMER_GROUP_ID || 'workflow-queue-events').trim() || 'workflow-queue-events',
});
