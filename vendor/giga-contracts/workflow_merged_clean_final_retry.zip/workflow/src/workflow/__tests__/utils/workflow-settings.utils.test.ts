import { describe, expect, it } from 'vitest';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { applyWorkflowSettingsChange } from '@workflow/ui/workflow/utils/workflow-settings.utils';

describe('workflow settings utils', () => {
    it('merges canvas settings without dropping subworkflow UI state', () => {
        const workflow = createEmptyWorkflow('wf_settings_utils');
        workflow.metadata.ui = { subworkflows: [{ id: 'sw_1', name: 'Group', nodeIds: ['node_1'], collapsed: false }] };
        const next = applyWorkflowSettingsChange(workflow, {
            workflowName: 'Workflow Saved',
            workflowDescription: 'Updated',
            settings: { graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 },
            canvasSettings: { layoutEngine: 'legacy', edgeStyle: 'straight' }
        });

        expect(next.metadata.ui?.subworkflows).toEqual([{ id: 'sw_1', name: 'Group', nodeIds: ['node_1'], collapsed: false }]);
        expect(next.metadata.ui?.canvas).toEqual({ layoutEngine: 'legacy', edgeStyle: 'straight' });
        expect(next.metadata.name).toBe('Workflow Saved');
    });
});
