import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { classNames } from 'primereact/utils';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import FloatingFieldShell from '@workflow/ui/workflow/components/form/floating-field-shell';
import VariableSuggestionsPopover, { useWorkflowVariableSuggestionController } from '@workflow/ui/workflow/components/inspector/VariableSuggestionsPopover';
import { WorkflowVariableSuggestion, WorkflowVariableTokenState, buildVariableToken, formatWorkflowVariablePreviewValue, filterVariableSuggestions, getVariableTokenStates } from '@workflow/ui/workflow/utils/workflow-variables.utils';

interface VariableTextFieldProps {
    id: string;
    value: string;
    onChange: (nextValue: string) => void;
    allowVariables?: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowVariableSuggestion[];
    disabled?: boolean;
    multiline?: boolean;
    rows?: number;
    className?: string;
    placeholder?: string;
    label?: string;
}

interface VariableQueryState {
    open: boolean;
    query: string;
    tokenStart: number;
    tokenEnd: number;
}

const EMPTY_QUERY_STATE: VariableQueryState = {
    open: false,
    query: '',
    tokenStart: -1,
    tokenEnd: -1
};

const INPUT_CONTROL_PROPS = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing', 'textTransform', 'textIndent'] as const;

const getDropToken = (event: React.DragEvent<HTMLElement>): string => {
    const variablePath = event.dataTransfer.getData('application/x-workflow-variable-path').trim();
    if (variablePath) {
        return buildVariableToken(variablePath);
    }
    return event.dataTransfer.getData('text/plain').trim();
};

const resolveQueryState = (value: string, cursorOffset: number): VariableQueryState => {
    const prefix = value.slice(0, cursorOffset);
    const openIndex = prefix.lastIndexOf('{{');
    if (openIndex < 0) return EMPTY_QUERY_STATE;
    const closeIndex = prefix.lastIndexOf('}}');
    if (closeIndex > openIndex) return EMPTY_QUERY_STATE;
    const query = prefix.slice(openIndex + 2);
    if (/[\r\n{}]/.test(query)) return EMPTY_QUERY_STATE;
    return {
        open: true,
        query,
        tokenStart: openIndex,
        tokenEnd: cursorOffset
    };
};

const resolveTokenHoverTitle = (token: WorkflowVariableTokenState): string => {
    if (token.status === 'unresolved') return `Unresolved variable: ${token.path}`;
    return `Current value: ${formatWorkflowVariablePreviewValue(token.value)}`;
};

const buildOverlayStyle = (inputElement: HTMLInputElement | HTMLTextAreaElement, multiline: boolean): React.CSSProperties => {
    const computedStyle = window.getComputedStyle(inputElement);
    const style: React.CSSProperties = {
        whiteSpace: multiline ? 'pre-wrap' : 'pre',
        overflowWrap: multiline ? 'anywhere' : 'normal'
    };

    INPUT_CONTROL_PROPS.forEach((prop) => {
        style[prop] = computedStyle[prop];
    });

    return style;
};

const renderHighlightedSegments = (value: string, tokenStates: WorkflowVariableTokenState[]): React.ReactNode => {
    if (!value.length) {
        return <span className="wf-variable-field__placeholder">{'\u00a0'}</span>;
    }

    const segments: React.ReactNode[] = [];
    let cursor = 0;
    tokenStates.forEach((token, index) => {
        if (token.start > cursor) {
            segments.push(
                <span key={`plain-${index}-${cursor}`} className="wf-variable-field__segment">
                    {value.slice(cursor, token.start)}
                </span>
            );
        }
        const hoverTitle = resolveTokenHoverTitle(token);
        segments.push(
            <span
                key={`token-${token.path}-${token.start}-${index}`}
                className={`wf-variable-field__token ${token.status === 'resolved' ? 'wf-variable-field__token--resolved' : 'wf-variable-field__token--unresolved'}`}
                title={hoverTitle}
                data-hover-title={hoverTitle}
            >
                {value.slice(token.start, token.end)}
            </span>
        );
        cursor = token.end;
    });
    if (cursor < value.length) {
        segments.push(
            <span key={`plain-tail-${cursor}`} className="wf-variable-field__segment">
                {value.slice(cursor)}
            </span>
        );
    }
    return segments;
};

const VariableTextField: React.FC<VariableTextFieldProps> = ({ id, value, onChange, allowVariables = true, variableContext = {}, variableSuggestions = [], disabled = false, multiline = false, rows = 3, className, placeholder, label }) => {
    const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
    const overlayRef = useRef<HTMLDivElement | null>(null);
    const hoverOverlayRef = useRef<HTMLDivElement | null>(null);
    const [queryState, setQueryState] = useState<VariableQueryState>(EMPTY_QUERY_STATE);
    const [isFocused, setIsFocused] = useState<boolean>(false);
    const [overlayStyle, setOverlayStyle] = useState<React.CSSProperties>({});
    const tokenStates = useMemo(() => (allowVariables ? getVariableTokenStates(value, variableContext) : []), [allowVariables, value, variableContext]);
    const visibleSuggestions = useMemo(() => filterVariableSuggestions(variableSuggestions, queryState.query), [queryState.query, variableSuggestions]);
    const listboxId = `${id}-variable-suggestions`;

    const syncOverlayStyle = useCallback((): void => {
        if (!allowVariables || !inputRef.current) return;
        setOverlayStyle(buildOverlayStyle(inputRef.current, multiline));
    }, [allowVariables, multiline]);

    const closeSuggestions = useCallback(() => {
        setQueryState(EMPTY_QUERY_STATE);
    }, []);

    const syncOverlayScroll = (): void => {
        if (!inputRef.current) return;
        if (overlayRef.current) {
            overlayRef.current.scrollTop = inputRef.current.scrollTop;
            overlayRef.current.scrollLeft = inputRef.current.scrollLeft;
        }
        if (hoverOverlayRef.current) {
            hoverOverlayRef.current.scrollTop = inputRef.current.scrollTop;
            hoverOverlayRef.current.scrollLeft = inputRef.current.scrollLeft;
        }
    };

    const syncQueryFromInput = (): void => {
        if (!allowVariables || !inputRef.current) {
            setQueryState(EMPTY_QUERY_STATE);
            return;
        }
        const cursorOffset = inputRef.current.selectionStart ?? value.length;
        setQueryState(resolveQueryState(value, cursorOffset));
        syncOverlayScroll();
        syncOverlayStyle();
    };

    const handleSuggestionSelect = useCallback(
        (suggestion: WorkflowVariableSuggestion): void => {
            if (!inputRef.current) return;
            const nextToken = suggestion.token;
            const start = queryState.tokenStart >= 0 ? queryState.tokenStart : inputRef.current.selectionStart ?? value.length;
            const end = queryState.tokenEnd >= 0 ? queryState.tokenEnd : inputRef.current.selectionStart ?? value.length;
            const nextValue = `${value.slice(0, start)}${nextToken}${value.slice(end)}`;
            onChange(nextValue);
            closeSuggestions();
            window.requestAnimationFrame(() => {
                if (!inputRef.current) return;
                const nextCursor = start + nextToken.length;
                inputRef.current.focus();
                inputRef.current.setSelectionRange(nextCursor, nextCursor);
                syncOverlayScroll();
                syncOverlayStyle();
            });
        },
        [closeSuggestions, onChange, queryState.tokenEnd, queryState.tokenStart, syncOverlayStyle, value]
    );

    const suggestionsOpen = allowVariables && queryState.open && visibleSuggestions.length > 0;
    const { activeIndex, setActiveIndex, handleKeyDown } = useWorkflowVariableSuggestionController({
        open: suggestionsOpen,
        suggestions: visibleSuggestions,
        onSelect: handleSuggestionSelect,
        onClose: closeSuggestions
    });

    const handleInputKeyDown = (event: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>): void => {
        handleKeyDown(event);
    };

    useEffect(() => {
        if (!allowVariables || !inputRef.current || typeof ResizeObserver === 'undefined') return;
        const observer = new ResizeObserver(() => syncOverlayStyle());
        observer.observe(inputRef.current);
        syncOverlayStyle();
        return () => observer.disconnect();
    }, [allowVariables, syncOverlayStyle]);

    useEffect(() => {
        syncOverlayStyle();
    }, [syncOverlayStyle, value, queryState.open]);

    const handleDrop = (event: React.DragEvent<HTMLElement>): void => {
        if (!allowVariables) return;
        event.preventDefault();
        const token = getDropToken(event);
        if (!token || !inputRef.current) return;
        const selectionStart = inputRef.current.selectionStart ?? value.length;
        const selectionEnd = inputRef.current.selectionEnd ?? selectionStart;
        const nextValue = `${value.slice(0, selectionStart)}${token}${value.slice(selectionEnd)}`;
        onChange(nextValue);
        window.requestAnimationFrame(() => {
            if (!inputRef.current) return;
            const nextCursor = selectionStart + token.length;
            inputRef.current.focus();
            inputRef.current.setSelectionRange(nextCursor, nextCursor);
            syncOverlayScroll();
            syncOverlayStyle();
        });
    };
    const handleDragOver = (event: React.DragEvent<HTMLElement>): void => {
        if (!allowVariables) return;
        event.preventDefault();
    };

    const overlayMarkup = renderHighlightedSegments(value, tokenStates);
    const hasValue = value.trim().length > 0;

    const inputClassName = classNames(className, {
        'wf-variable-field__control': allowVariables,
        'wf-variable-field__control--multiline': multiline,
        'wf-variable-field__control--floating': Boolean(label)
    });

    const fieldContent = (
        <div className={`wf-variable-field ${multiline ? 'wf-variable-field--textarea' : 'wf-variable-field--input'} ${isFocused ? 'wf-variable-field--focused' : ''}`}>
            {allowVariables && (
                <div ref={overlayRef} className={classNames('wf-variable-field__overlay', { 'wf-variable-field__overlay--textarea': multiline })} style={overlayStyle} aria-hidden>
                    {overlayMarkup}
                </div>
            )}
            {allowVariables && (
                <div
                    ref={hoverOverlayRef}
                    className={classNames('wf-variable-field__overlay wf-variable-field__overlay--hover', {
                        'wf-variable-field__overlay--textarea': multiline,
                        'wf-variable-field__overlay--interactive': !disabled && !isFocused && !multiline
                    })}
                    style={overlayStyle}
                    aria-hidden
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onMouseDown={(event) => {
                        const targetElement = event.target as HTMLElement | null;
                        if (targetElement?.closest('.wf-variable-field__token')) {
                            return;
                        }
                        event.preventDefault();
                        inputRef.current?.focus();
                    }}
                >
                    {overlayMarkup}
                </div>
            )}

            {multiline ? (
                <InputTextarea
                    id={id}
                    value={value}
                    onChange={(event) => {
                        onChange(event.target.value);
                        window.requestAnimationFrame(syncQueryFromInput);
                    }}
                    rows={rows}
                    autoResize
                    className={inputClassName}
                    disabled={disabled}
                    placeholder={placeholder}
                    aria-controls={suggestionsOpen ? listboxId : undefined}
                    aria-expanded={suggestionsOpen}
                    aria-haspopup={allowVariables ? 'listbox' : undefined}
                    onFocus={() => {
                        setIsFocused(true);
                        syncQueryFromInput();
                    }}
                    onKeyUp={syncQueryFromInput}
                    onKeyDown={handleInputKeyDown}
                    onClick={syncQueryFromInput}
                    onBlur={() => {
                        setIsFocused(false);
                        window.setTimeout(closeSuggestions, 120);
                    }}
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onScroll={syncOverlayScroll}
                    ref={inputRef as React.RefObject<HTMLTextAreaElement>}
                />
            ) : (
                <InputText
                    id={id}
                    value={value}
                    onChange={(event) => {
                        onChange(event.target.value);
                        window.requestAnimationFrame(syncQueryFromInput);
                    }}
                    className={inputClassName}
                    disabled={disabled}
                    placeholder={placeholder}
                    aria-controls={suggestionsOpen ? listboxId : undefined}
                    aria-expanded={suggestionsOpen}
                    aria-haspopup={allowVariables ? 'listbox' : undefined}
                    onFocus={() => {
                        setIsFocused(true);
                        syncQueryFromInput();
                    }}
                    onKeyUp={syncQueryFromInput}
                    onKeyDown={handleInputKeyDown}
                    onClick={syncQueryFromInput}
                    onBlur={() => {
                        setIsFocused(false);
                        window.setTimeout(closeSuggestions, 120);
                    }}
                    onDragOver={handleDragOver}
                    onDrop={handleDrop}
                    onScroll={syncOverlayScroll}
                    ref={inputRef as React.RefObject<HTMLInputElement>}
                />
            )}

            {suggestionsOpen && <VariableSuggestionsPopover suggestions={visibleSuggestions} activeIndex={activeIndex} onActiveIndexChange={setActiveIndex} onSelect={handleSuggestionSelect} listboxId={listboxId} />}
        </div>
    );

    if (!label) return fieldContent;

    return (
        <FloatingFieldShell id={id} label={label} active={isFocused || hasValue || suggestionsOpen} disabled={disabled} multiline={multiline}>
            {fieldContent}
        </FloatingFieldShell>
    );
};

export default VariableTextField;
