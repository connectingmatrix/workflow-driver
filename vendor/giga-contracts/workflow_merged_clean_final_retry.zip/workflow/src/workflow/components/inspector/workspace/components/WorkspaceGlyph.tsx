import type { CSSProperties } from 'react';
import type { WorkspaceIconName } from '../types';

interface WorkspaceGlyphProps {
  name: WorkspaceIconName;
  className?: string;
  style?: CSSProperties;
}

export function WorkspaceGlyph({ name, className, style }: WorkspaceGlyphProps) {
  switch (name) {
    case 'desktop':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M4 5h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-5l1 2H8l1-2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Zm0 2v9h16V7H4Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'server':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M5 4h14a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Zm0 2v3h14V6H5Zm0 6h14a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2Zm2 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm0-8a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'share':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M14 4v2h-3.59L20 15.59 18.59 17 8 6.41V10H6V4h8Zm-8 8h2v6h12v-6h2v8H6v-8Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'upload':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M12 3 6 9h4v6h4V9h4l-6-6Zm-8 14h16v2H4v-2Z" fill="currentColor" />
        </svg>
      );
    case 'download':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M12 21 6 15h4V9h4v6h4l-6 6ZM4 3h16v2H4V3Z" fill="currentColor" />
        </svg>
      );
    case 'info':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M11 10h2v8h-2v-8Zm0-4h2v2h-2V6Zm1-4a10 10 0 1 0 0 20 10 10 0 0 0 0-20Z" fill="currentColor" />
        </svg>
      );
    case 'settings':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="m19.14 12.94.04-.94-.04-.94 2.08-1.62-1.98-3.43-2.53 1.03-.77-.44-.26-2.69H8.32l-.26 2.69-.77.44-2.53-1.03-1.98 3.43L4.86 11.06 4.82 12l.04.94-2.08 1.62 1.98 3.43 2.53-1.03.77.44.26 2.69h6.54l.26-2.69.77-.44 2.53 1.03 1.98-3.43-2.08-1.62ZM12 16.5A4.5 4.5 0 1 1 12 7a4.5 4.5 0 0 1 0 9.5Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'trash':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M9 3h6l1 1h4v2H4V4h4l1-1Zm1 6h2v8h-2V9Zm4 0h2v8h-2V9ZM6 7h12l-1 14H7L6 7Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'folder':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M3 5h6l2 2h10v10a2 2 0 0 1-2 2H3V5Zm2 4v8h14V9H5Z" fill="currentColor" />
        </svg>
      );
    case 'sitemap':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M10 4h4v4h-4V4ZM4 16h4v4H4v-4Zm12 0h4v4h-4v-4ZM6 8h12v2H6V8Zm5 2h2v4h-2v-4ZM9 14h6v2H9v-2Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'ellipsis':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <circle cx="6" cy="12" r="2" fill="currentColor" />
          <circle cx="12" cy="12" r="2" fill="currentColor" />
          <circle cx="18" cy="12" r="2" fill="currentColor" />
        </svg>
      );
    case 'save':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M5 4h11l3 3v13H5V4Zm2 2v14h10V8.5L14.5 6H7Zm1 1h6v4H8V7Z" fill="currentColor" />
        </svg>
      );
    case 'send':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="m3 21 18-9L3 3v7l12 2-12 2v7Z" fill="currentColor" />
        </svg>
      );
    case 'stop':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" />
        </svg>
      );
    case 'spinner':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M12 4a8 8 0 1 0 6.32 3.12L16.9 9.1A6 6 0 1 1 12 6V4Zm0 0V1m0 22v-3"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'play':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M8 6.5V17.5L17 12L8 6.5Z" fill="currentColor" />
        </svg>
      );
    case 'refresh':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M17.65 6.35A7.95 7.95 0 0 0 12 4a8 8 0 1 0 7.75 10h-2.1A6 6 0 1 1 12 6c1.3 0 2.5.42 3.47 1.13L13 10h7V3l-2.35 3.35Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'x':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M18.3 5.71 12 12l6.3 6.29-1.41 1.41L10.59 13.4 4.29 19.7 2.88 18.29 9.17 12 2.88 5.71 4.29 4.29l6.3 6.3 6.29-6.3 1.42 1.42Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'database':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M12 3c-4.42 0-8 1.57-8 3.5v11C4 19.43 7.58 21 12 21s8-1.57 8-3.5v-11C20 4.57 16.42 3 12 3Zm0 2c3.87 0 6 .97 6 1.5S15.87 8 12 8 6 7.03 6 6.5 8.13 5 12 5Zm0 14c-3.87 0-6-.97-6-1.5V15.4c1.46.93 3.94 1.6 6 1.6s4.54-.67 6-1.6v2.1c0 .53-2.13 1.5-6 1.5Zm0-5c-3.87 0-6-.97-6-1.5V10.4c1.46.93 3.94 1.6 6 1.6s4.54-.67 6-1.6v2.1c0 .53-2.13 1.5-6 1.5Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'document':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M14 2H7a2 2 0 0 0-2 2v16c0 1.11.89 2 2 2h10a2 2 0 0 0 2-2V7l-5-5Zm1 7V3.5L18.5 9H15Zm-6 4h6v2H9v-2Zm0 4h6v2H9v-2Zm0-8h3v2H9V9Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'inspect':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M10 2a8 8 0 1 0 5.29 14l4.35 4.36 1.41-1.42-4.36-4.35A8 8 0 0 0 10 2Zm0 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12Zm1 2H9v3H6v2h3v3h2v-3h3V9h-3V6Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'json':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M8.5 7.5c-.97 0-1.5.53-1.5 1.5v1c0 .41-.17.82-.47 1.12L5 12.5l1.53 1.38c.3.3.47.71.47 1.12v1c0 .97.53 1.5 1.5 1.5V19c-2.1 0-3.5-1.4-3.5-3.5v-.75c0-.2-.08-.39-.22-.53L2.75 12.5l2.03-1.72c.14-.14.22-.33.22-.53V9c0-2.1 1.4-3.5 3.5-3.5v2Zm7 10c.97 0 1.5-.53 1.5-1.5v-1c0-.41.17-.82.47-1.12L19 12.5l-1.53-1.38a1.59 1.59 0 0 1-.47-1.12V9c0-.97-.53-1.5-1.5-1.5V5c2.1 0 3.5 1.4 3.5 3.5v.75c0 .2.08.39.22.53l2.03 1.72-2.03 1.72a.74.74 0 0 0-.22.53v.75c0 2.1-1.4 3.5-3.5 3.5v-2ZM13 8h-2v8h2V8Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'eye':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M12 5C6.5 5 2.06 8.11.25 12c1.81 3.89 6.25 7 11.75 7s9.94-3.11 11.75-7C21.94 8.11 17.5 5 12 5Zm0 12c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5Zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'node':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M7 7h4v4H7V7Zm6 0h4v4h-4V7Zm-6 6h4v4H7v-4Zm6 6h4v-4h-4v4Zm-1-6h1a2 2 0 0 1 2 2v1h-2v-1h-2v-2h1Zm-2 0H9v-2h2V9H9V7h2a2 2 0 0 1 2 2v2h-2v2Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'bolt':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path d="M11 21h-1l1-7H7l6-11h1l-1 7h4l-6 11Z" fill="currentColor" />
        </svg>
      );
    case 'sparkles':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="m12 2 1.76 4.24L18 8l-4.24 1.76L12 14l-1.76-4.24L6 8l4.24-1.76L12 2Zm7 11 .94 2.06L22 16l-2.06.94L19 19l-.94-2.06L16 16l2.06-.94L19 13ZM5 14l1.17 2.83L9 18l-2.83 1.17L5 22l-1.17-2.83L1 18l2.83-1.17L5 14Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'terminal':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Zm0 2v10h16V7H4Zm3.71 2.29L10.41 12l-2.7 2.71-1.42-1.42L7.59 12 6.29 10.71l1.42-1.42ZM11 14h6v2h-6v-2Z"
            fill="currentColor"
          />
        </svg>
      );
    case 'braces':
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <path
            d="M9 4v2H8a1 1 0 0 0-1 1v2.5A2.5 2.5 0 0 1 5.5 12 2.5 2.5 0 0 1 7 14.5V17a1 1 0 0 0 1 1h1v2H8a3 3 0 0 1-3-3v-2.5c0-.83-.67-1.5-1.5-1.5V11c.83 0 1.5-.67 1.5-1.5V7a3 3 0 0 1 3-3h1Zm6 0h1a3 3 0 0 1 3 3v2.5c0 .83.67 1.5 1.5 1.5v2c-.83 0-1.5.67-1.5 1.5V17a3 3 0 0 1-3 3h-1v-2h1a1 1 0 0 0 1-1v-2.5A2.5 2.5 0 0 1 18.5 12 2.5 2.5 0 0 1 17 9.5V7a1 1 0 0 0-1-1h-1V4Z"
            fill="currentColor"
          />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
          <circle cx="12" cy="12" r="8" fill="currentColor" />
        </svg>
      );
  }
}
