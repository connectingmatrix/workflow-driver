import React from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import { WorkflowDefinition, WorkflowLogLevelEnum, WorkflowNodeStatusEnum, WorkflowRunLogEvent } from '@workflow/ui/workflow/types';

const createDeferred = <T,>() => {
    let resolve: (value: T | PromiseLike<T>) => void = () => undefined;
    let reject: (reason?: unknown) => void = () => undefined;
    const promise = new Promise<T>((resolvePromise, rejectPromise) => {
        resolve = resolvePromise;
        reject = rejectPromise;
    });
    return { promise, resolve, reject };
};

const { connectMock, joinRunMock, subscribeWorkflowExecutionMock, unsubscribeWorkflowExecutionMock, addEventHandlerMock, executeWorkflowOnServerMock, createRequestIdMock, emitWorkflowEvent, clearWorkflowEventHandler, prewarmJavascriptRuntimeFrameMock } = vi.hoisted(() => {
    let workflowEventHandler: ((event: WorkflowRunLogEvent) => void) | null = null;
    return {
        connectMock: vi.fn(async () => undefined),
        joinRunMock: vi.fn(async () => undefined),
        subscribeWorkflowExecutionMock: vi.fn(async () => undefined),
        unsubscribeWorkflowExecutionMock: vi.fn(),
        addEventHandlerMock: vi.fn((handler: (event: WorkflowRunLogEvent) => void) => {
            workflowEventHandler = handler;
            return () => {
                workflowEventHandler = null;
            };
        }),
        executeWorkflowOnServerMock: vi.fn(),
        createRequestIdMock: vi.fn(() => 'run_test_1'),
        emitWorkflowEvent: (event: WorkflowRunLogEvent) => {
            workflowEventHandler?.(event);
        },
        clearWorkflowEventHandler: () => {
            workflowEventHandler = null;
        },
        prewarmJavascriptRuntimeFrameMock: vi.fn(async () => undefined)
    };
});

vi.mock('@workflow/ui/workflow/components/toolbar/Toolbar', () => ({
    default: (props: { playLifecycle: string; playMode: string; isPlaying: boolean; onPlayServer: () => void; onStop: () => void }) => (
        <div data-testid="workflow-toolbar">
            <span data-testid="toolbar-play-lifecycle">{props.playLifecycle}</span>
            <span data-testid="toolbar-play-mode">{props.playMode}</span>
            <span data-testid="toolbar-is-playing">{String(props.isPlaying)}</span>
            <button type="button" onClick={props.onPlayServer}>
                Play Server
            </button>
            <button type="button" onClick={props.onStop}>
                Stop
            </button>
        </div>
    )
}));

vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({
    default: () => null
}));

vi.mock('@/common/components/logs/JsonlLogsDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({
    default: () => null
}));

vi.mock('primereact/contextmenu', () => {
    const ReactModule = require('react') as typeof React;
    const MockContextMenu = ReactModule.forwardRef((_: unknown, ref) => {
        ReactModule.useImperativeHandle(ref, () => ({
            show: () => undefined,
            hide: () => undefined
        }));
        return null;
    });
    MockContextMenu.displayName = 'MockContextMenu';
    return { ContextMenu: MockContextMenu };
});

vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({
    default: (props: { onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number }; fitView?: () => void; setCenter?: () => void }) => void }) => {
        React.useEffect(() => {
            props.onInit({
                screenToFlowPosition: ({ x, y }) => ({ x, y }),
                fitView: () => undefined,
                setCenter: () => undefined
            });
        }, [props.onInit]);
        return <div data-testid="workflow-canvas" />;
    }
}));

vi.mock('@workflow/ui/workflow/services/SocketClient', () => ({
    WorkflowSocketClient: class MockWorkflowSocketClient {
        connect = connectMock;
        joinRun = joinRunMock;
        addEventHandler = addEventHandlerMock;
        executeStep = vi.fn();
        disconnect = vi.fn();
    }
}));

vi.mock('@/graphql/client', async (importOriginal) => {
    const originalModule = await importOriginal<typeof import('@/graphql/client')>();
    return {
        ...originalModule,
        createRequestId: createRequestIdMock
    };
});

vi.mock('@workflow/ui/workflow/services/workflow-execution.service', async (importOriginal) => {
    const originalModule = await importOriginal<typeof import('@workflow/ui/workflow/services/workflow-execution.service')>();
    return {
        ...originalModule,
        executeWorkflowOnServer: executeWorkflowOnServerMock
    };
});

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (importOriginal) => {
    const originalModule = await importOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>();
    return {
        ...originalModule,
        prewarmJavascriptRuntimeFrame: prewarmJavascriptRuntimeFrameMock
    };
});

vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({
    listWorkflowUserNodes: vi.fn(async () => [])
}));

const createWorkflowFixture = (): WorkflowDefinition => {
    const workflow = createEmptyWorkflow('wf_server_play_dialog');
    const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
    const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
    const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
    workflow.nodes = [startNode, codeNode, endNode];
    workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];
    return workflow;
};

const buildServerExecuteResponse = (workflow: WorkflowDefinition) => ({
    accepted: true,
    run_id: 'run_test_1',
    stopped: false,
    workflow,
    logs: []
});

const driver: WorkflowUiDriver = {
    createRequestId: createRequestIdMock,
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({
        connect: connectMock,
        disconnect: vi.fn(),
        joinRun: joinRunMock,
        subscribeWorkflowExecution: subscribeWorkflowExecutionMock,
        unsubscribeWorkflowExecution: unsubscribeWorkflowExecutionMock,
        addEventHandler: addEventHandlerMock,
        addWebhookTestInvokeHandler: vi.fn(() => () => undefined),
        emitWebhookTestResult: vi.fn(),
        emitWebhookTestError: vi.fn(),
        openEditorSession: vi.fn(async () => undefined),
        heartbeatEditorSession: vi.fn(async () => undefined),
        closeEditorSession: vi.fn(),
        executeStep: vi.fn(async () => ({ request_id: '', run_id: '', workflow: createEmptyWorkflow('wf_step'), node: createWorkflowNode(createEmptyWorkflow('wf_step'), 'code', 'Code', 1), result: { output: null }, logs: [], logs_jsonl: '' })),
        startPreview: vi.fn(async () => 'preview-run'),
        cancelPreview: vi.fn(),
        addPreviewLogHandler: vi.fn(() => () => undefined),
        addPreviewStateHandler: vi.fn(() => () => undefined),
        addPreviewResultHandler: vi.fn(() => () => undefined),
        addPreviewStopHandler: vi.fn(() => () => undefined),
        addPreviewErrorHandler: vi.fn(() => () => undefined)
    }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    executeWorkflowOnServer: executeWorkflowOnServerMock,
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};

const nodeCatalog: WorkflowNodeCatalog = { modules: [], getAllNodeSchemas: () => ({}), getNodeLibraryItems: () => [], getNodeModuleById: () => null, resolveNodeSchema: () => ({ documentation: {} }) as never, isLocalCapableNodeModel: () => true };

beforeEach(() => {
    connectMock.mockReset();
    joinRunMock.mockReset();
    subscribeWorkflowExecutionMock.mockReset();
    unsubscribeWorkflowExecutionMock.mockReset();
    addEventHandlerMock.mockClear();
    executeWorkflowOnServerMock.mockReset();
    createRequestIdMock.mockReset();
    clearWorkflowEventHandler();
    prewarmJavascriptRuntimeFrameMock.mockReset();

    connectMock.mockResolvedValue(undefined);
    joinRunMock.mockResolvedValue(undefined);
    subscribeWorkflowExecutionMock.mockResolvedValue(undefined);
    createRequestIdMock.mockReturnValue('run_test_1');
    executeWorkflowOnServerMock.mockResolvedValue(buildServerExecuteResponse(createWorkflowFixture()));
    prewarmJavascriptRuntimeFrameMock.mockResolvedValue(undefined);
});

afterEach(() => {
    cleanup();
    vi.clearAllMocks();
});

describe('DesignerDialog server play lifecycle', () => {
    it('shows starting state immediately and allows stop during server bootstrap', async () => {
        const deferredConnect = createDeferred<undefined>();
        connectMock.mockReturnValueOnce(deferredConnect.promise);

        render(<DesignerDialog visible workflow={createWorkflowFixture()} driver={driver} nodeCatalog={nodeCatalog} broadcastId="user-1" onHide={vi.fn()} onWorkflowChange={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Play Server' }));
        expect(screen.getByTestId('toolbar-play-mode').textContent).toBe('server');
        expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('starting');
        expect(screen.getByTestId('toolbar-is-playing').textContent).toBe('true');

        fireEvent.click(screen.getByRole('button', { name: 'Stop' }));
        expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('idle');
        expect(screen.getByTestId('toolbar-is-playing').textContent).toBe('false');

        await act(async () => {
            deferredConnect.resolve(undefined);
            await Promise.resolve();
            await Promise.resolve();
        });

        expect(subscribeWorkflowExecutionMock).not.toHaveBeenCalled();
        expect(executeWorkflowOnServerMock).not.toHaveBeenCalled();
    });

    it('resets previously passed node state before sending workflow to server so runs can be repeated', async () => {
        const completedWorkflow = createWorkflowFixture();
        completedWorkflow.nodes = completedWorkflow.nodes.map((node) => ({
            ...node,
            status: WorkflowNodeStatusEnum.Passed,
            output: { stale: true },
            ports: {
                ...(node.ports ?? { in: {}, out: {} }),
                out: {
                    ...((node.ports?.out as Record<string, unknown>) ?? {}),
                    output: { stale: true },
                    __activeOutputs: ['output']
                }
            }
        }));

        render(<DesignerDialog visible workflow={completedWorkflow} driver={driver} nodeCatalog={nodeCatalog} broadcastId="user-1" onHide={vi.fn()} onWorkflowChange={vi.fn()} />);
        fireEvent.click(screen.getByRole('button', { name: 'Play Server' }));

        await waitFor(() => {
            expect(executeWorkflowOnServerMock).toHaveBeenCalledTimes(1);
        });

        const executionArgs = executeWorkflowOnServerMock.mock.calls[0]?.[0] as { workflow: WorkflowDefinition };
        expect(executionArgs.workflow.nodes.every((node) => node.status === WorkflowNodeStatusEnum.Stopped)).toBe(true);
        expect(executionArgs.workflow.nodes.every((node) => node.output === null)).toBe(true);
        expect(executionArgs.workflow.nodes.every((node) => ((node.ports?.out as Record<string, unknown> | undefined)?.output ?? null) === null)).toBe(true);
    });

    it('applies realtime node.delta updates and preserves fresher delta over stale final response', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        const deferredServerResponse = createDeferred<ReturnType<typeof buildServerExecuteResponse>>();
        executeWorkflowOnServerMock.mockReturnValueOnce(deferredServerResponse.promise);

        render(
            <DesignerDialog
                visible
                workflow={createWorkflowFixture()}
                driver={driver}
                nodeCatalog={nodeCatalog}
                broadcastId="user-1"
                onHide={vi.fn()}
                onWorkflowChange={(workflow) => {
                    latestWorkflow = workflow;
                }}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Play Server' }));

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('running');
        });

        expect(subscribeWorkflowExecutionMock).toHaveBeenCalledWith({
            broadcastId: 'user-1',
            workflowId: 'wf_server_play_dialog'
        });
        const runId = 'run_test_1';

        await act(async () => {
            emitWorkflowEvent({
                timestamp: new Date().toISOString(),
                level: WorkflowLogLevelEnum.Info,
                event: 'node.started',
                workflowId: 'wf_server_play_dialog',
                runId,
                nodeId: 'node_2'
            });
        });

        await waitFor(() => {
            const codeNode = latestWorkflow?.nodes.find((node) => node.id === 'node_2');
            expect(codeNode?.status).toBe(WorkflowNodeStatusEnum.Running);
        });

        const currentWorkflow = latestWorkflow ?? createWorkflowFixture();
        const currentCodeNode = currentWorkflow.nodes.find((node) => node.id === 'node_2') ?? createWorkflowFixture().nodes[1];

        const deltaNode = {
            ...currentCodeNode,
            status: WorkflowNodeStatusEnum.Passed,
            runtime: {
                ...((currentCodeNode.runtime as Record<string, unknown>) ?? {}),
                debug: 'delta'
            },
            output: { source: 'delta' },
            ports: {
                ...(currentCodeNode.ports ?? { in: {}, out: {} }),
                out: {
                    ...((currentCodeNode.ports?.out as Record<string, unknown>) ?? {}),
                    output: { source: 'delta' }
                }
            }
        };

        await act(async () => {
            emitWorkflowEvent({
                timestamp: new Date().toISOString(),
                level: WorkflowLogLevelEnum.Info,
                event: 'node.delta',
                workflowId: 'wf_server_play_dialog',
                runId,
                nodeId: 'node_2',
                data: { node: deltaNode }
            });
        });

        await waitFor(() => {
            const codeNode = latestWorkflow?.nodes.find((node) => node.id === 'node_2');
            expect(codeNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
            expect((codeNode?.ports.out.output as { source?: string }).source).toBe('delta');
        });

        const staleFinalWorkflow = createWorkflowFixture();
        staleFinalWorkflow.nodes = staleFinalWorkflow.nodes.map((node) => {
            if (node.id === 'node_2') {
                return {
                    ...node,
                    status: WorkflowNodeStatusEnum.Failed,
                    output: { source: 'stale-final' },
                    ports: {
                        ...node.ports,
                        out: {
                            ...node.ports.out,
                            output: { source: 'stale-final' }
                        }
                    }
                };
            }
            if (node.id === 'node_3') {
                return {
                    ...node,
                    output: { source: 'server-final-end' },
                    ports: {
                        ...node.ports,
                        out: {
                            ...node.ports.out,
                            output: { source: 'server-final-end' }
                        }
                    }
                };
            }
            return node;
        });

        await act(async () => {
            deferredServerResponse.resolve(buildServerExecuteResponse(staleFinalWorkflow));
            await Promise.resolve();
        });

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('idle');
        });

        expect(latestWorkflow).toBeTruthy();
        const workflowAfterFinalMerge: WorkflowDefinition = latestWorkflow ?? createWorkflowFixture();
        const codeNodeAfterFinalMerge = workflowAfterFinalMerge.nodes.find((node) => node.id === 'node_2');
        const endNodeAfterFinalMerge = workflowAfterFinalMerge.nodes.find((node) => node.id === 'node_3');

        expect(codeNodeAfterFinalMerge?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((codeNodeAfterFinalMerge?.ports.out.output as { source?: string }).source).toBe('delta');
        expect((endNodeAfterFinalMerge?.ports.out.output as { source?: string }).source).toBe('server-final-end');
    });

    it('preserves failed node status when node.failed event is observed before final server payload merge', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        const deferredServerResponse = createDeferred<ReturnType<typeof buildServerExecuteResponse>>();
        executeWorkflowOnServerMock.mockReturnValueOnce(deferredServerResponse.promise);

        render(
            <DesignerDialog
                visible
                workflow={createWorkflowFixture()}
                driver={driver}
                nodeCatalog={nodeCatalog}
                broadcastId="user-1"
                onHide={vi.fn()}
                onWorkflowChange={(workflow) => {
                    latestWorkflow = workflow;
                }}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Play Server' }));

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('running');
        });

        expect(subscribeWorkflowExecutionMock).toHaveBeenCalledWith({
            broadcastId: 'user-1',
            workflowId: 'wf_server_play_dialog'
        });
        const runId = 'run_test_1';
        await act(async () => {
            emitWorkflowEvent({
                timestamp: new Date().toISOString(),
                level: WorkflowLogLevelEnum.Error,
                event: 'node.failed',
                workflowId: 'wf_server_play_dialog',
                runId,
                nodeId: 'node_2',
                data: { error: 'node failed' }
            });
        });

        await waitFor(() => {
            const codeNode = latestWorkflow?.nodes.find((node) => node.id === 'node_2');
            expect(codeNode?.status).toBe(WorkflowNodeStatusEnum.Failed);
        });

        const finalWorkflow = createWorkflowFixture();
        finalWorkflow.nodes = finalWorkflow.nodes.map((node) => (node.id === 'node_2' ? { ...node, status: WorkflowNodeStatusEnum.Passed } : node));

        await act(async () => {
            deferredServerResponse.resolve(buildServerExecuteResponse(finalWorkflow));
            await Promise.resolve();
        });

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('idle');
        });

        expect(latestWorkflow?.nodes.find((node) => node.id === 'node_2')?.status).toBe(WorkflowNodeStatusEnum.Failed);
    });

    it('subscribes live execution replay with the persisted workflow id instead of the snapshot id', async () => {
        const workflow = createWorkflowFixture();
        workflow.metadata.id = 'snapshot-workflow-id';

        render(
            <DesignerDialog
                visible
                mode="execution"
                workflow={workflow}
                driver={driver}
                nodeCatalog={nodeCatalog}
                broadcastId="user-1"
                executionWorkflowId="persisted-workflow-id"
                executionRunId="run_test_1"
                executionLive
                onHide={vi.fn()}
            />
        );

        await waitFor(() => {
            expect(subscribeWorkflowExecutionMock).toHaveBeenCalledWith({
                broadcastId: 'user-1',
                workflowId: 'persisted-workflow-id'
            });
        });
    });
});
