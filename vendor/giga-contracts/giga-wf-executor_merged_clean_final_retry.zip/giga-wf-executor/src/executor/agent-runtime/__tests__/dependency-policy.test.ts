import { describe, expect, it } from 'vitest';
import { validateDynamicDependencies } from '../dependency-policy';

describe('dynamic dependency policy', () => {
  it('allows only allowlisted npm packages', () => {
    const result = validateDynamicDependencies({ allowInstall: true, allowedPackages: ['lodash'], dependencies: ['lodash'] });
    expect(result.ok).toBe(true);
  });

  it('denies URL and file dependencies', () => {
    const result = validateDynamicDependencies({ allowInstall: true, allowedPackages: ['lodash'], dependencies: ['https://example.com/pkg.tgz', 'file:../x'] });
    expect(result.ok).toBe(false);
    expect(result.denied.length).toBe(2);
  });
});
