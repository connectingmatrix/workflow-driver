import { WorkerExecuteHelpers, WorkerRuntimeEnvironmentEnum, WorkflowControlNodePatch, WorkflowNodeHandler, WorkflowNodeModel, WorkflowStepOverrides } from '../../types';
import { executeControlPeerInputs } from '../core/compiler/control-node-input-execution';
import { executeControlPeer } from '../core/compiler/control-node-peer-execution';
import { buildRuntimeControlNodeGroups } from '../core/compiler/control-node-runtime';
import { resolveNodeCredentialBinding } from '../credentials/resolve-node-credential';
import { recordNodeCredentialExecutionResult } from '../credentials/report-credential-execution';
import { TypeScriptModuleLoader } from '../core/compiler/typescript-compiler';
import {
    createRegisteredWorkerRuntimeHelpers,
    createWorkerHelperId,
    executeLoadedWorkerModuleLifecycle,
    loadPreviewValidator,
    loadWorkerModule,
    registerWorkerRuntimeHelpers,
    resolveNodeSourceFilesFromHelper,
    toErrorResult,
    unregisterWorkerRuntimeHelpers
} from '../core/compiler/worker-module-loader';
import { loadBrowserCompiledModule } from './browser-compiler';

export interface BrowserWorkerNodeHandlerArgs {
    modelId: string;
    executeHelpers?: WorkerExecuteHelpers;
    typescriptModuleLoader?: TypeScriptModuleLoader;
}

const buildControlPeerOverrides = (patch?: WorkflowControlNodePatch): WorkflowStepOverrides | undefined =>
    patch
        ? {
              ...(patch.runtime ? { runtime: patch.runtime } : {}),
              ...(patch.properties ? { properties: patch.properties } : {}),
              ...(patch.code != null ? { code: patch.code } : {}),
              ...(patch.markdown != null ? { markdown: patch.markdown } : {}),
              ...(patch.sourceFiles ? { sourceFiles: patch.sourceFiles } : {})
          }
        : undefined;

const syncControlPeerNode = (workflow: { nodes: WorkflowNodeModel[] }, node: WorkflowNodeModel, preserveRuntime = false): void => {
    const index = workflow.nodes.findIndex((entry) => entry.id === node.id);
    if (index >= 0) {
        const current = workflow.nodes[index];
        workflow.nodes[index] = preserveRuntime
            ? {
                  ...node,
                  runtime: current.runtime,
                  properties: current.properties
              }
            : node;
    }
};

export const createBrowserWorkerNodeHandler = (args: BrowserWorkerNodeHandlerArgs): WorkflowNodeHandler => {
    return async (context) => {
        const credentialBinding = await resolveNodeCredentialBinding(context);
        if (credentialBinding.error) {
            const result = toErrorResult(credentialBinding.error);
            await recordNodeCredentialExecutionResult({
                credentialId: credentialBinding.credentialId,
                host: credentialBinding.host,
                result
            });
            return result;
        }

        const helperId = createWorkerHelperId(context);
        const registeredHelpers = createRegisteredWorkerRuntimeHelpers({
            executeHelpers: args.executeHelpers,
            context: {
                ...context,
                credential: credentialBinding.credential
            }
        });
        const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
            executeHelpers: args.executeHelpers,
            context: {
                ...context,
                credential: credentialBinding.credential
            },
            modelId: args.modelId
        });

        registerWorkerRuntimeHelpers(helperId, registeredHelpers);

        try {
            try {
                const controlNodes = await buildRuntimeControlNodeGroups({
                    context: {
                        ...context,
                        credential: credentialBinding.credential
                    },
                    helperId,
                    runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                    executeHelpers: args.executeHelpers,
                    typescriptModuleLoader: args.typescriptModuleLoader,
                    loadCompiledModule: loadBrowserCompiledModule,
                    executePeerInputs: async ({ nodeId, args: executeInputsArgs }) =>
                        executeControlPeerInputs({
                            context,
                            nodeId,
                            args: executeInputsArgs,
                            executePeer: async ({ nodeId: upstreamNodeId }) => {
                                if (context.invokeConnectedNode) {
                                    const executed = await context.invokeConnectedNode({
                                        nodeId: upstreamNodeId
                                    });
                                    syncControlPeerNode(context.workflow, executed.node);
                                    return { node: executed.node };
                                }
                                const executed = await executeControlPeer({
                                    context,
                                    nodeId: upstreamNodeId,
                                    runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                                    executeHelpers: args.executeHelpers,
                                    typescriptModuleLoader: args.typescriptModuleLoader,
                                    loadCompiledModule: loadBrowserCompiledModule
                                });
                                return { node: executed.node };
                            }
                        }),
                    executePeer: async ({ nodeId, input, patch }) => {
                        if (context.invokeConnectedNode) {
                            const executed = await context.invokeConnectedNode({
                                nodeId,
                                input,
                                overrides: buildControlPeerOverrides(patch)
                            });
                            syncControlPeerNode(context.workflow, executed.node, Boolean(patch));
                            return executed;
                        }
                        return executeControlPeer({
                            context,
                            nodeId,
                            input,
                            patch,
                            runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                            executeHelpers: args.executeHelpers,
                            typescriptModuleLoader: args.typescriptModuleLoader,
                            loadCompiledModule: loadBrowserCompiledModule
                        });
                    }
                });
                const module = await loadWorkerModule({
                    modelId: args.modelId,
                    workflow: context.workflow,
                    helperId,
                    runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                    typescriptModuleLoader: args.typescriptModuleLoader,
                    resolvedSourceFiles,
                    loadCompiledModule: loadBrowserCompiledModule
                });
                const previewValidator = await loadPreviewValidator({
                    modelId: args.modelId,
                    workflow: context.workflow,
                    helperId,
                    runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                    typescriptModuleLoader: args.typescriptModuleLoader,
                    resolvedSourceFiles,
                    loadCompiledModule: loadBrowserCompiledModule
                });

                const result = await executeLoadedWorkerModuleLifecycle({
                    context: {
                        ...context,
                        credential: credentialBinding.credential
                    },
                    runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                    module,
                    previewValidator,
                    controlNodes
                });
                await recordNodeCredentialExecutionResult({
                    credentialId: credentialBinding.credentialId,
                    host: credentialBinding.host,
                    result
                });
                return result;
            } catch (error) {
                const result = toErrorResult(error instanceof Error ? error.message : 'Worker module execution failed.');
                await recordNodeCredentialExecutionResult({
                    credentialId: credentialBinding.credentialId,
                    host: credentialBinding.host,
                    result
                });
                return result;
            }
        } finally {
            unregisterWorkerRuntimeHelpers(helperId);
        }
    };
};
