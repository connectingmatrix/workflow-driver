import { describe, expect, it } from 'vitest';
import { WorkflowNodeKindEnum, WorkflowNodeStatusEnum, type WorkflowConnectionModel, type WorkflowDefinition, type WorkflowNodeModel } from '../types';
import { layoutWorkflowGraph } from '../workflow-ai-creation';

const node = (id: string, modelId: string): WorkflowNodeModel => ({
  id,
  gigaId: id,
  modelId,
  type: 'workflowStep',
  name: id,
  description: '',
  kind: modelId === 'respond-end' ? WorkflowNodeKindEnum.Output : WorkflowNodeKindEnum.Process,
  status: WorkflowNodeStatusEnum.Stopped,
  position: { x: 0, y: 0 },
  runtime: {},
  ports: { in: {}, out: {} },
});

const link = (from: string, to: string, sourceHandle = 'out:output', targetHandle = 'in:input'): WorkflowConnectionModel => ({
  id: `${from}_${to}_${sourceHandle}_${targetHandle}`,
  name: `${from} -> ${to}`,
  from,
  to,
  sourceHandle,
  targetHandle,
});

const workflow = (nodes: WorkflowNodeModel[], connections: WorkflowConnectionModel[]): WorkflowDefinition => ({
  metadata: { id: 'wf_layout', name: 'Workflow Layout' },
  nodes,
  connections,
});

describe('layoutWorkflowGraph', () => {
  it('keeps linear flows on one vertical spine', () => {
    const arranged = layoutWorkflowGraph(workflow([node('start', 'start'), node('code', 'code'), node('end', 'respond-end')], [link('start', 'code'), link('code', 'end')]));
    const start = arranged.nodes.find((entry) => entry.id === 'start')?.position;
    const code = arranged.nodes.find((entry) => entry.id === 'code')?.position;
    const end = arranged.nodes.find((entry) => entry.id === 'end')?.position;
    expect(start?.x).toBe(code?.x);
    expect(code?.x).toBe(end?.x);
    expect((start?.y || 0) < (code?.y || 0)).toBe(true);
    expect((code?.y || 0) < (end?.y || 0)).toBe(true);
  });

  it('fans out branches and recenters merge nodes', () => {
    const arranged = layoutWorkflowGraph(workflow([node('start', 'start'), node('branch', 'if-else'), node('left', 'code'), node('right', 'code'), node('merge', 'merge'), node('end', 'respond-end')], [link('start', 'branch'), link('branch', 'left', 'out:true'), link('branch', 'right', 'out:false'), link('left', 'merge'), link('right', 'merge', 'out:output', 'in:input2'), link('merge', 'end')]));
    const left = arranged.nodes.find((entry) => entry.id === 'left')?.position;
    const right = arranged.nodes.find((entry) => entry.id === 'right')?.position;
    const merge = arranged.nodes.find((entry) => entry.id === 'merge')?.position;
    expect(left?.y).toBe(right?.y);
    expect(left?.x).not.toBe(right?.x);
    expect((merge?.x || 0) > Math.min(left?.x || 0, right?.x || 0)).toBe(true);
    expect((merge?.x || 0) < Math.max(left?.x || 0, right?.x || 0)).toBe(true);
  });

  it('clusters command-only nodes beside their owner bank', () => {
    const arranged = layoutWorkflowGraph(workflow([node('start', 'start'), node('governor', 'ai-governor'), node('router', 'action-router'), node('llm', 'openai'), node('channel', 'run-channel-action'), node('subject', 'run-subject-action')], [link('start', 'governor'), link('governor', 'router'), link('llm', 'governor', 'cmd:command', 'cmd:llm'), link('channel', 'governor', 'cmd:command', 'cmd:tools'), link('subject', 'governor', 'cmd:command', 'cmd:tools'), link('channel', 'router', 'cmd:command', 'cmd:actions'), link('subject', 'router', 'cmd:command', 'cmd:actions')]));
    const router = arranged.nodes.find((entry) => entry.id === 'router')?.position;
    const channel = arranged.nodes.find((entry) => entry.id === 'channel')?.position;
    const subject = arranged.nodes.find((entry) => entry.id === 'subject')?.position;
    const llm = arranged.nodes.find((entry) => entry.id === 'llm')?.position;
    expect((channel?.x || 0) > (router?.x || 0)).toBe(true);
    expect((subject?.x || 0) > (router?.x || 0)).toBe(true);
    expect(channel?.x).toBe(subject?.x);
    expect(channel?.y).not.toBe(subject?.y);
    expect((llm?.x || 0) >= 0).toBe(true);
  });

  it('does not overlap arranged node frames', () => {
    const arranged = layoutWorkflowGraph(workflow([node('start', 'start'), node('branch', 'if-else'), node('left', 'code'), node('right', 'code'), node('merge', 'merge'), node('end', 'respond-end'), node('llm', 'openai'), node('tool', 'run-chat-action')], [link('start', 'branch'), link('branch', 'left', 'out:true'), link('branch', 'right', 'out:false'), link('left', 'merge'), link('right', 'merge', 'out:output', 'in:input2'), link('merge', 'end'), link('llm', 'branch', 'cmd:command', 'cmd:tools'), link('tool', 'branch', 'cmd:command', 'cmd:tools')]));
    arranged.nodes.forEach((left, index) => {
      arranged.nodes.slice(index + 1).forEach((right) => {
        const overlapX = Math.abs(left.position.x - right.position.x) < 236;
        const overlapY = Math.abs(left.position.y - right.position.y) < 248;
        expect(overlapX && overlapY, `${left.id} overlaps ${right.id}`).toBe(false);
      });
    });
  });
});
