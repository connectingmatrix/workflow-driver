import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { Monaco, OnMount } from '@monaco-editor/react';
import { InputTextarea } from 'primereact/inputtextarea';
import { Skeleton } from 'primereact/skeleton';
import type * as MonacoEditor from 'monaco-editor';
import { WorkflowVariableSuggestion, getVariableTokenStates, buildVariableToken, filterVariableSuggestions } from '@workflow/ui/workflow/utils/workflow-variables.utils';

interface CodeEditorProps {
    value: string;
    onChange: (nextCode: string) => void;
    language?: 'javascript' | 'json' | 'markdown';
    readOnly?: boolean;
    fillAvailableHeight?: boolean;
    minHeight?: number | string;
    allowVariables?: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowVariableSuggestion[];
    autoFocus?: boolean;
    dataCy?: string;
}

declare global {
    interface Window {
        __workflowCodeEditors?: Record<string, { setValue: (nextValue: string) => void; getValue: () => string }>;
    }
}

const MONACO_MIN_HEIGHT_PX = 190;

let monacoEditorComponentCache: React.ComponentType<Record<string, unknown>> | null = null;
let monacoEditorComponentPromise: Promise<React.ComponentType<Record<string, unknown>>> | null = null;

const loadMonacoEditorComponent = async (): Promise<React.ComponentType<Record<string, unknown>>> => {
    if (monacoEditorComponentCache) {
        return monacoEditorComponentCache;
    }

    if (!monacoEditorComponentPromise) {
        monacoEditorComponentPromise = import('@monaco-editor/react')
            .then((module) => {
                const editorComponent = module.default as React.ComponentType<Record<string, unknown>> | undefined;
                if (!editorComponent) {
                    throw new Error('Monaco editor module does not expose a default component.');
                }
                monacoEditorComponentCache = editorComponent;
                return editorComponent;
            })
            .catch((error) => {
                monacoEditorComponentPromise = null;
                throw error;
            });
    }

    return monacoEditorComponentPromise;
};

const insertTokenAtCursor = (editor: MonacoEditor.editor.IStandaloneCodeEditor, monaco: Monaco | null, token: string): void => {
    const position = editor.getPosition();
    const model = editor.getModel();
    if (!position || !model || !monaco) {
        return;
    }

    const range = new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column);
    editor.executeEdits('workflow-json-token-drop', [{ range, text: token }]);
    editor.focus();
};

const getDropToken = (event: React.DragEvent<HTMLDivElement>): string => {
    const path = event.dataTransfer.getData('application/x-workflow-variable-path').trim();
    if (path) {
        return buildVariableToken(path);
    }
    return event.dataTransfer.getData('text/plain').trim();
};

const resolveTokenQueryContext = (model: MonacoEditor.editor.ITextModel, position: MonacoEditor.Position): { query: string; rangeStartOffset: number; rangeEndOffset: number } | null => {
    const currentOffset = model.getOffsetAt(position);
    const source = model.getValue().slice(0, currentOffset);
    const openIndex = source.lastIndexOf('{{');
    if (openIndex < 0) return null;
    const closeIndex = source.lastIndexOf('}}');
    if (closeIndex > openIndex) return null;
    const query = source.slice(openIndex + 2);
    if (/[\r\n{}]/.test(query)) return null;
    return {
        query,
        rangeStartOffset: openIndex,
        rangeEndOffset: currentOffset
    };
};

const isElementVisible = (element: HTMLElement | null): boolean => {
    if (!element || typeof window === 'undefined') {
        return false;
    }

    const computedStyle = window.getComputedStyle(element);
    if (computedStyle.display === 'none' || computedStyle.visibility === 'hidden') {
        return false;
    }

    if (typeof navigator !== 'undefined' && /jsdom/i.test(navigator.userAgent || '')) {
        return true;
    }

    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
};

const toMinHeightPx = (value: number | string): number => {
    if (typeof value === 'number' && Number.isFinite(value)) {
        return Math.max(MONACO_MIN_HEIGHT_PX, Math.round(value));
    }
    if (typeof value === 'string') {
        const trimmed = value.trim();
        const pxMatch = /^(\d+(?:\.\d+)?)px$/i.exec(trimmed);
        if (pxMatch) {
            return Math.max(MONACO_MIN_HEIGHT_PX, Math.round(Number(pxMatch[1])));
        }
        const parsed = Number(trimmed);
        if (Number.isFinite(parsed)) {
            return Math.max(MONACO_MIN_HEIGHT_PX, Math.round(parsed));
        }
    }
    return MONACO_MIN_HEIGHT_PX;
};

const parseCssPx = (rawValue: string): number => {
    const parsed = Number.parseFloat(rawValue);
    return Number.isFinite(parsed) ? parsed : 0;
};

const getAvailableHeightPx = (element: HTMLElement | null): number => {
    if (!element) {
        return 0;
    }

    const elementRect = element.getBoundingClientRect();
    const elementStyle = window.getComputedStyle(element);
    const marginTop = parseCssPx(elementStyle.marginTop);
    const marginBottom = parseCssPx(elementStyle.marginBottom);

    let current: HTMLElement | null = element.parentElement;
    let depth = 0;
    while (current && depth < 12) {
        const parentRect = current.getBoundingClientRect();
        const parentHeight = Math.round(parentRect.height);
        if (parentHeight > 0) {
            const topOffset = Math.max(0, elementRect.top - parentRect.top);
            const availableHeight = Math.round(parentRect.height - topOffset - marginTop - marginBottom);
            if (availableHeight > 0) {
                return availableHeight;
            }
            return parentHeight;
        }
        current = current.parentElement;
        depth += 1;
    }

    const ownHeight = Math.round(elementRect.height);
    return ownHeight > 0 ? ownHeight : 0;
};

const collectWatchTargets = (element: HTMLElement | null): HTMLElement[] => {
    const targets: HTMLElement[] = [];
    let current: HTMLElement | null = element;
    let depth = 0;
    while (current && depth < 8) {
        targets.push(current);
        current = current.parentElement;
        depth += 1;
    }
    return targets;
};

const CodeEditor: React.FC<CodeEditorProps> = ({
    value,
    onChange,
    language = 'javascript',
    readOnly = false,
    fillAvailableHeight = true,
    minHeight = MONACO_MIN_HEIGHT_PX,
    allowVariables = true,
    variableContext = {},
    variableSuggestions = [],
    autoFocus = false,
    dataCy
}) => {
    const minHeightPx = useMemo(() => toMinHeightPx(minHeight), [minHeight]);
    const [EditorComponent, setEditorComponent] = useState<React.ComponentType<Record<string, unknown>> | null>(() => monacoEditorComponentCache);
    const [editorHeightPx, setEditorHeightPx] = useState<number>(minHeightPx);
    const [editorEngaged, setEditorEngaged] = useState<boolean>(autoFocus);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const editorRef = useRef<MonacoEditor.editor.IStandaloneCodeEditor | null>(null);
    const monacoRef = useRef<Monaco | null>(null);
    const completionRef = useRef<MonacoEditor.IDisposable | null>(null);
    const blurSubscriptionRef = useRef<MonacoEditor.IDisposable | null>(null);
    const decorationRef = useRef<string[]>([]);
    const modelUriRef = useRef<string>('');
    const allowVariablesRef = useRef<boolean>(allowVariables);
    const variableSuggestionsRef = useRef<WorkflowVariableSuggestion[]>(variableSuggestions);
    const [showFallback, setShowFallback] = useState<boolean>(false);
    const [editorLoadError, setEditorLoadError] = useState<string>('');
    const [editorReadyVersion, setEditorReadyVersion] = useState<number>(0);
    const layoutFrameRef = useRef<number | null>(null);

    useEffect(() => {
        setEditorHeightPx((current) => (current < minHeightPx ? minHeightPx : current));
    }, [minHeightPx]);

    useEffect(() => {
        if (autoFocus) {
            setEditorEngaged(true);
        }
    }, [autoFocus]);

    const syncEditorHeight = useCallback(() => {
        if (!fillAvailableHeight) {
            setEditorHeightPx((current) => (current === minHeightPx ? current : minHeightPx));
            return;
        }
        const container = containerRef.current;
        const availableHeight = getAvailableHeightPx(container);
        const nextHeight = Math.max(minHeightPx, availableHeight || minHeightPx);
        setEditorHeightPx((current) => (Math.abs(current - nextHeight) <= 1 ? current : nextHeight));
    }, [fillAvailableHeight, minHeightPx]);

    const syncEditorInteraction = useCallback(() => {
        const editor = editorRef.current;
        if (!editor) {
            return;
        }

        editor.updateOptions({
            fixedOverflowWidgets: true,
            scrollbar: {
                handleMouseWheel: editorEngaged,
                alwaysConsumeMouseWheel: editorEngaged
            }
        });
    }, [editorEngaged]);

    const scheduleLayout = useCallback(() => {
        const editor = editorRef.current;
        const container = containerRef.current;
        if (!editor || !container || !isElementVisible(container)) {
            return;
        }
        syncEditorHeight();

        if (layoutFrameRef.current !== null) {
            window.cancelAnimationFrame(layoutFrameRef.current);
        }

        layoutFrameRef.current = window.requestAnimationFrame(() => {
            layoutFrameRef.current = null;
            const nextEditor = editorRef.current;
            const nextContainer = containerRef.current;
            if (!nextEditor || !nextContainer || !isElementVisible(nextContainer)) {
                return;
            }
            syncEditorHeight();
            nextEditor.layout();
            if (autoFocus) {
                nextEditor.focus();
            }
        });
    }, [autoFocus, syncEditorHeight]);

    useEffect(() => {
        let cancelled = false;

        loadMonacoEditorComponent()
            .then((editorComponent) => {
                if (cancelled) {
                    return;
                }
                setEditorComponent(() => editorComponent);
                setShowFallback(false);
                setEditorLoadError('');
            })
            .catch((error) => {
                if (cancelled) {
                    return;
                }
                const message = error instanceof Error ? error.message : 'Failed to load Monaco editor module.';
                setEditorLoadError(message);
                setShowFallback(true);
                console.error('[WorkflowInspector:CodeEditor] Failed to load Monaco editor module.', error);
            });

        return () => {
            cancelled = true;
        };
    }, []);

    useEffect(() => {
        allowVariablesRef.current = allowVariables;
    }, [allowVariables]);

    useEffect(() => {
        variableSuggestionsRef.current = variableSuggestions;
    }, [variableSuggestions]);

    const onMount: OnMount = (editor, monaco) => {
        editorRef.current = editor;
        monacoRef.current = monaco;
        modelUriRef.current = editor.getModel()?.uri.toString() ?? '';
        blurSubscriptionRef.current?.dispose();
        blurSubscriptionRef.current = editor.onDidBlurEditorText(() => {
            setEditorEngaged(false);
        });
        syncEditorInteraction();
        setShowFallback(false);
        setEditorReadyVersion((current) => current + 1);
        scheduleLayout();
    };

    useEffect(() => {
        syncEditorInteraction();
    }, [syncEditorInteraction]);

    useEffect(() => {
        const container = containerRef.current;
        if (!container || typeof window === 'undefined') {
            return;
        }

        const triggerLayout = (): void => {
            syncEditorHeight();
            scheduleLayout();
        };

        const watchTargets = collectWatchTargets(container);
        const resizeObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(triggerLayout) : null;
        if (resizeObserver) {
            watchTargets.forEach((target) => {
                resizeObserver.observe(target);
            });
        }

        const mutationObserver =
            typeof MutationObserver !== 'undefined'
                ? new MutationObserver(() => {
                      triggerLayout();
                  })
                : null;
        watchTargets.forEach((target) => {
            mutationObserver?.observe(target, { attributes: true, attributeFilter: ['style', 'class'] });
        });

        const intersectionObserver =
            typeof IntersectionObserver !== 'undefined'
                ? new IntersectionObserver(
                      (entries) => {
                          if (entries.some((entry) => entry.isIntersecting)) {
                              triggerLayout();
                          }
                      },
                      { threshold: 0 }
                  )
                : null;
        intersectionObserver?.observe(container);

        window.addEventListener('resize', triggerLayout);
        document.addEventListener('visibilitychange', triggerLayout);
        container.addEventListener('transitionend', triggerLayout, true);

        return () => {
            resizeObserver?.disconnect();
            mutationObserver?.disconnect();
            intersectionObserver?.disconnect();
            window.removeEventListener('resize', triggerLayout);
            document.removeEventListener('visibilitychange', triggerLayout);
            container.removeEventListener('transitionend', triggerLayout, true);
        };
    }, [scheduleLayout, syncEditorHeight]);

    useEffect(() => {
        syncEditorHeight();
        scheduleLayout();
    }, [editorReadyVersion, scheduleLayout, syncEditorHeight]);

    useEffect(() => {
        return () => {
            blurSubscriptionRef.current?.dispose();
            blurSubscriptionRef.current = null;
            if (layoutFrameRef.current !== null) {
                window.cancelAnimationFrame(layoutFrameRef.current);
            }
        };
    }, []);

    useEffect(() => {
        if (typeof document === 'undefined' || !editorEngaged) {
            return;
        }

        const handlePointerDown = (event: MouseEvent): void => {
            const container = containerRef.current;
            if (!container) {
                return;
            }
            if (container.contains(event.target as Node)) {
                return;
            }
            setEditorEngaged(false);
        };

        document.addEventListener('mousedown', handlePointerDown, true);
        return () => {
            document.removeEventListener('mousedown', handlePointerDown, true);
        };
    }, [editorEngaged]);

    const editorHeightCss = `${Math.max(minHeightPx, editorHeightPx)}px`;

    useEffect(() => {
        const editor = editorRef.current;
        const monaco = monacoRef.current;
        if (!editor || !monaco) {
            return;
        }

        completionRef.current?.dispose();
        completionRef.current = monaco.languages.registerCompletionItemProvider(language, {
            triggerCharacters: ['{', '.'],
            provideCompletionItems: (model: MonacoEditor.editor.ITextModel, position: MonacoEditor.Position) => {
                if (!allowVariablesRef.current) {
                    return { suggestions: [] };
                }
                if (modelUriRef.current && model.uri.toString() !== modelUriRef.current) {
                    return { suggestions: [] };
                }
                const tokenContext = resolveTokenQueryContext(model, position);
                if (!tokenContext) {
                    return { suggestions: [] };
                }
                const filtered = filterVariableSuggestions(variableSuggestionsRef.current, tokenContext.query);
                const startPosition = model.getPositionAt(tokenContext.rangeStartOffset);
                const endPosition = model.getPositionAt(tokenContext.rangeEndOffset);
                if (!startPosition || !endPosition) {
                    return { suggestions: [] };
                }
                return {
                    suggestions: filtered.map((item) => ({
                        label: item.label,
                        kind: monaco.languages.CompletionItemKind.Variable,
                        insertText: item.token,
                        detail: item.path,
                        documentation: item.preview ? `Current value: ${item.preview}` : undefined,
                        range: new monaco.Range(startPosition.lineNumber, startPosition.column, endPosition.lineNumber, endPosition.column)
                    }))
                };
            }
        });

        return () => {
            completionRef.current?.dispose();
            completionRef.current = null;
        };
    }, [language, editorReadyVersion]);

    useEffect(() => {
        const editor = editorRef.current;
        const monaco = monacoRef.current;
        if (!editor || !monaco) return;
        const model = editor.getModel();
        if (!model) return;
        if (!allowVariables) {
            decorationRef.current = editor.deltaDecorations(decorationRef.current, []);
            return;
        }
        const tokenStates = getVariableTokenStates(value, variableContext);
        decorationRef.current = editor.deltaDecorations(
            decorationRef.current,
            tokenStates.map((token) => {
                const start = model.getPositionAt(token.start);
                const end = model.getPositionAt(token.end);
                return {
                    range: new monaco.Range(start.lineNumber, start.column, end.lineNumber, end.column),
                    options: {
                        inlineClassName: token.status === 'resolved' ? 'wf-variable-token--resolved' : 'wf-variable-token--unresolved'
                    }
                };
            })
        );
    }, [allowVariables, value, variableContext]);

    useEffect(() => {
        return () => {
            completionRef.current?.dispose();
            completionRef.current = null;
            const editor = editorRef.current;
            if (editor) {
                editor.deltaDecorations(decorationRef.current, []);
            }
            decorationRef.current = [];
        };
    }, []);

    useEffect(() => {
        if (typeof window === 'undefined' || !dataCy) {
            return;
        }

        window.__workflowCodeEditors = window.__workflowCodeEditors ?? {};
        window.__workflowCodeEditors[dataCy] = {
            setValue: (nextValue: string) => {
                editorRef.current?.setValue(nextValue);
                onChange(nextValue);
                scheduleLayout();
            },
            getValue: () => editorRef.current?.getValue() ?? value
        };

        return () => {
            if (window.__workflowCodeEditors) {
                delete window.__workflowCodeEditors[dataCy];
            }
        };
    }, [dataCy, onChange, scheduleLayout, value]);

    return (
        <div
            ref={containerRef}
            className="wf-monaco-editor"
            style={{
                minHeight: `${minHeightPx}px`,
                height: editorHeightCss
            }}
            data-cy={dataCy}
            onMouseDownCapture={() => {
                if (!editorEngaged) {
                    setEditorEngaged(true);
                }
            }}
            onBlurCapture={(event) => {
                const nextTarget = event.relatedTarget;
                if (nextTarget && event.currentTarget.contains(nextTarget as Node)) {
                    return;
                }
                setEditorEngaged(false);
            }}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
                event.preventDefault();
                const token = getDropToken(event);
                if (!token) {
                    return;
                }

                if (editorRef.current) {
                    insertTokenAtCursor(editorRef.current, monacoRef.current, token);
                    return;
                }

                onChange(`${value}${value ? '\n' : ''}${token}`);
            }}
        >
            {showFallback ? (
                <InputTextarea
                    value={value}
                    onChange={(event) => onChange(event.target.value)}
                    rows={14}
                    className="w-full wf-monaco-editor__fallback"
                    readOnly={readOnly}
                    title={editorLoadError ? `Monaco disabled: ${editorLoadError}` : undefined}
                />
            ) : !EditorComponent ? (
                <div className="wf-monaco-editor__loading" aria-live="polite">
                    <Skeleton height="1.2rem" className="wf-monaco-editor__loading-line" />
                    <Skeleton height="1.2rem" className="wf-monaco-editor__loading-line" />
                    <Skeleton height="1.2rem" className="wf-monaco-editor__loading-line" />
                    <Skeleton height="1.2rem" className="wf-monaco-editor__loading-line" />
                </div>
            ) : (
                <EditorComponent
                    height={editorHeightCss}
                    language={language}
                    value={value}
                    onMount={onMount}
                    onChange={(nextCode) => onChange(nextCode ?? '')}
                    theme="vs-dark"
                    loading={<div className="wf-monaco-editor__loading">Loading editor...</div>}
                    options={{
                        fontSize: 13,
                        minimap: { enabled: false },
                        scrollBeyondLastLine: true,
                        padding: {
                            top: 12,
                            bottom: 20
                        },
                        automaticLayout: true,
                        readOnly,
                        tabSize: 2,
                        wordWrap: 'on',
                        bracketPairColorization: { enabled: true },
                        fixedOverflowWidgets: true,
                        suggestOnTriggerCharacters: true,
                        quickSuggestions: {
                            other: true,
                            comments: false,
                            strings: true
                        },
                        suggest: {
                            preview: false,
                            showInlineDetails: true
                        },
                        wordBasedSuggestions: 'off',
                        scrollbar: {
                            handleMouseWheel: editorEngaged,
                            alwaysConsumeMouseWheel: editorEngaged
                        }
                    }}
                />
            )}
        </div>
    );
};

export default CodeEditor;
