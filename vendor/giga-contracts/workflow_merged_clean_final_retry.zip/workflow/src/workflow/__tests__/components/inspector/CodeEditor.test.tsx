// @vitest-environment jsdom
import React from 'react';
import { fireEvent, render, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';

const monacoState: { options: Record<string, unknown> | null; height: unknown } = {
    options: null,
    height: null
};

const completionProviderState: {
    provider: { provideCompletionItems: (model: any, position: any) => { suggestions: unknown[] } } | null;
} = {
    provider: null
};

const monacoMountState: {
    updateOptions: ReturnType<typeof vi.fn> | null;
    options: Record<string, unknown> | null;
    focus: ReturnType<typeof vi.fn> | null;
    blur: (() => void) | null;
} = {
    updateOptions: null,
    options: null,
    focus: null,
    blur: null
};

vi.mock('@monaco-editor/react', async () => {
    const ReactModule = await vi.importActual<typeof import('react')>('react');

    const mockEditor = {
        getPosition: () => ({ lineNumber: 1, column: 1 }),
        getModel: () => ({
            uri: {
                toString: () => 'inmemory://model/workflow-editor'
            },
            getValue: () => '',
            getOffsetAt: () => 0,
            getPositionAt: () => ({ lineNumber: 1, column: 1 })
        }),
        executeEdits: vi.fn(),
        focus: vi.fn(),
        layout: vi.fn(),
        deltaDecorations: vi.fn(() => []),
        onDidBlurEditorText: vi.fn((listener: () => void) => {
            monacoMountState.blur = listener;
            return { dispose: vi.fn() };
        }),
        updateOptions: vi.fn((nextOptions: Record<string, unknown>) => {
            monacoMountState.options = nextOptions;
        })
    };

    const mockMonaco = {
        Range: class {
            constructor(public startLineNumber: number, public startColumn: number, public endLineNumber: number, public endColumn: number) {}
        },
        languages: {
            CompletionItemKind: {
                Variable: 6
            },
            registerCompletionItemProvider: vi.fn((_language: string, provider: { provideCompletionItems: (model: any, position: any) => { suggestions: unknown[] } }) => {
                completionProviderState.provider = provider;
                return { dispose: vi.fn() };
            })
        }
    };

    return {
        __esModule: true,
        default: ({ options, height, onMount }: { options?: Record<string, unknown>; height?: unknown; onMount?: (editor: unknown, monaco: unknown) => void }) => {
            monacoState.options = options ?? null;
            monacoState.height = height ?? null;

            ReactModule.useEffect(() => {
                monacoMountState.updateOptions = mockEditor.updateOptions;
                monacoMountState.focus = mockEditor.focus;
                onMount?.(mockEditor, mockMonaco);
            }, []);

            return <div data-testid="mock-monaco" />;
        }
    };
});

describe('CodeEditor', () => {
    beforeEach(() => {
        monacoState.options = null;
        monacoState.height = null;
        monacoMountState.options = null;
        monacoMountState.updateOptions = null;
        monacoMountState.focus = null;
        monacoMountState.blur = null;
        completionProviderState.provider = null;
    });

    it('enables native Monaco overflow widget settings for cursor-aligned suggestions', async () => {
        render(
            <CodeEditor
                value=""
                onChange={() => undefined}
                allowVariables
                variableContext={{}}
                variableSuggestions={[
                    {
                        path: 'node_1.title',
                        token: '{{node_1.title}}',
                        label: 'node_1.title',
                        preview: 'Hello'
                    }
                ]}
            />
        );

        await waitFor(() => {
            expect(monacoState.options).toMatchObject({
                fixedOverflowWidgets: true,
                suggestOnTriggerCharacters: true,
                wordBasedSuggestions: 'off',
                scrollbar: {
                    handleMouseWheel: false,
                    alwaysConsumeMouseWheel: false
                }
            });
            expect(monacoMountState.updateOptions).toHaveBeenCalled();
            expect(monacoMountState.options).toMatchObject({
                fixedOverflowWidgets: true,
                scrollbar: {
                    handleMouseWheel: false,
                    alwaysConsumeMouseWheel: false
                }
            });
            expect(monacoMountState.focus).not.toHaveBeenCalled();
        });
    });

    it('focuses Monaco on mount only when autoFocus is enabled', async () => {
        render(<CodeEditor value="" onChange={() => undefined} autoFocus />);

        await waitFor(() => {
            expect(monacoMountState.focus).toHaveBeenCalledTimes(1);
            expect(monacoState.options).toMatchObject({
                scrollbar: {
                    handleMouseWheel: true,
                    alwaysConsumeMouseWheel: true
                }
            });
        });
    });

    it('keeps wheel scrolling disengaged until the editor is clicked', async () => {
        const view = render(<CodeEditor value="" onChange={() => undefined} />);

        await waitFor(() => {
            expect(monacoMountState.options).toMatchObject({
                scrollbar: {
                    handleMouseWheel: false,
                    alwaysConsumeMouseWheel: false
                }
            });
        });

        const shell = view.container.querySelector('.wf-monaco-editor');
        expect(shell).toBeTruthy();
        fireEvent.mouseDown(shell!);

        await waitFor(() => {
            expect(monacoMountState.options).toMatchObject({
                scrollbar: {
                    handleMouseWheel: true,
                    alwaysConsumeMouseWheel: true
                }
            });
        });

        monacoMountState.blur?.();

        await waitFor(() => {
            expect(monacoMountState.options).toMatchObject({
                scrollbar: {
                    handleMouseWheel: false,
                    alwaysConsumeMouseWheel: false
                }
            });
        });
    });

    it('scopes variable completion provider to the mounted editor model only', async () => {
        render(
            <CodeEditor
                value="{{"
                onChange={() => undefined}
                allowVariables
                variableContext={{}}
                variableSuggestions={[
                    {
                        path: 'node_1.title',
                        token: '{{node_1.title}}',
                        label: 'node_1.title',
                        preview: 'Hello'
                    }
                ]}
            />
        );

        await waitFor(() => {
            expect(completionProviderState.provider).toBeTruthy();
        });
        const mismatchedModelResult = completionProviderState.provider?.provideCompletionItems(
            {
                uri: {
                    toString: () => 'inmemory://model/other-editor'
                },
                getOffsetAt: () => 2,
                getPositionAt: () => ({ lineNumber: 1, column: 1 }),
                getValue: () => '{{'
            },
            { lineNumber: 1, column: 3 }
        );
        expect(mismatchedModelResult?.suggestions).toHaveLength(0);
    });

    it('provides Monaco height as pixel values and updates when minHeight changes', async () => {
        const { rerender } = render(<CodeEditor value="" onChange={() => undefined} minHeight={320} />);

        await waitFor(() => {
            expect(monacoState.height).toBe('320px');
        });

        rerender(<CodeEditor value="" onChange={() => undefined} minHeight="180px" />);

        await waitFor(() => {
            expect(monacoState.height).toBe('190px');
        });
    });

    it('keeps a fixed editor height when fillAvailableHeight is disabled', async () => {
        const originalGetBoundingClientRect = HTMLElement.prototype.getBoundingClientRect;
        try {
            HTMLElement.prototype.getBoundingClientRect = () =>
                ({
                    width: 640,
                    height: 640,
                    top: 0,
                    left: 0,
                    right: 640,
                    bottom: 640,
                    x: 0,
                    y: 0,
                    toJSON: () => ({})
                }) as DOMRect;

            render(<CodeEditor value="" onChange={() => undefined} minHeight={260} fillAvailableHeight={false} />);

            await waitFor(() => {
                expect(monacoState.height).toBe('260px');
            });
        } finally {
            HTMLElement.prototype.getBoundingClientRect = originalGetBoundingClientRect;
        }
    });
});
