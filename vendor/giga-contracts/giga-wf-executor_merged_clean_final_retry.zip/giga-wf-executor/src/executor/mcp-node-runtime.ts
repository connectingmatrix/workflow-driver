import type { WorkflowMcpRuntimeManager } from './mcp-runtime.types';
import type { WorkflowResolvedCredential } from '../types';
import { parseJsonValue, parseStringValue, toRecordValue } from './mcp-runtime.utils';

export interface WorkflowMcpNodeRuntimeConfig {
    credentialId: string;
    capabilityQuery: string;
    outputContract: Record<string, unknown>;
    forwardNonMcpWork: boolean;
    loopNonMcpWork: boolean;
    maxLoopPasses: number;
}

interface WorkflowMcpCredentialServer {
    serverKey: string;
    serverUrl: string;
    transport: 'streamable-http';
    headers: Record<string, unknown>;
}

const parseBooleanValue = (value: unknown, fallback: boolean): boolean => {
    if (typeof value === 'boolean') return value;
    const normalized = parseStringValue(value).toLowerCase();
    if (!normalized) return fallback;
    return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
};

export const normalizeWorkflowMcpRuntime = (runtime: unknown): WorkflowMcpNodeRuntimeConfig => {
    const record = toRecordValue(runtime);
    const maxLoopPasses = Number(record.maxLoopPasses ?? 3);
    return {
        credentialId: parseStringValue(record.credentialId),
        capabilityQuery: parseStringValue(record.capabilityQuery),
        outputContract: toRecordValue(parseJsonValue(record.outputContract)),
        forwardNonMcpWork: parseBooleanValue(record.forwardNonMcpWork, true),
        loopNonMcpWork: parseBooleanValue(record.loopNonMcpWork, true),
        maxLoopPasses: Math.max(1, Math.min(6, Math.round(Number.isFinite(maxLoopPasses) ? maxLoopPasses : 3)))
    };
};

const resolveWorkflowMcpCredentialServer = (credential: WorkflowResolvedCredential | null | undefined): WorkflowMcpCredentialServer => {
    const values = toRecordValue(credential?.values);
    const servers = toRecordValue(values.mcpServers);
    const entries = Object.entries(servers);
    if (!entries.length) {
        throw new Error('Selected MCP credential does not define an MCP server.');
    }

    const [serverKey, serverValue] = entries[0];
    const config = toRecordValue(serverValue);
    const transport = parseStringValue(config.type);
    const serverUrl = parseStringValue(config.url);
    if (!parseStringValue(serverKey)) {
        throw new Error('Selected MCP credential is missing the server key.');
    }
    if (transport !== 'streamable-http') {
        throw new Error('Selected MCP credential must use "streamable-http".');
    }
    if (!serverUrl) {
        throw new Error('Selected MCP credential is missing the server URL.');
    }

    return {
        serverKey,
        serverUrl,
        transport: 'streamable-http',
        headers: toRecordValue(config.headers)
    };
};

const resolveToolArguments = (payload: Record<string, unknown>, envelope: Record<string, unknown>): Record<string, unknown> => {
    const direct = toRecordValue(payload.toolArguments);
    if (Object.keys(direct).length > 0) return direct;
    return toRecordValue(envelope.toolArguments);
};

const readToolCallCandidate = (value: unknown, source: string): { source: string; toolName: string; toolArguments: Record<string, unknown> } | null => {
    const payload = toRecordValue(value);
    const envelope = toRecordValue(payload.payload);
    const toolName = parseStringValue(payload.toolName || envelope.toolName);
    if (!toolName) return null;
    return {
        source,
        toolName,
        toolArguments: resolveToolArguments(payload, envelope)
    };
};

const readToolCallCandidates = (input: unknown): Array<{ source: string; toolName: string; toolArguments: Record<string, unknown> }> => {
    const payload = toRecordValue(input);
    const candidates: Array<{ source: string; toolName: string; toolArguments: Record<string, unknown> }> = [];
    const skipKeys = new Set(['payload', 'toolName', 'toolArguments', 'current', 'input']);
    const appendCandidate = (value: unknown, source: string): void => {
        const candidate = readToolCallCandidate(value, source);
        if (candidate) candidates.push(candidate);
    };

    appendCandidate(payload, 'root');
    appendCandidate(payload.current, 'current');
    appendCandidate(payload.input, 'input');
    Object.entries(toRecordValue(payload.input)).forEach(([key, value]) => appendCandidate(value, `input.${key}`));
    Object.entries(toRecordValue(payload.current)).forEach(([key, value]) => appendCandidate(value, `current.${key}`));
    Object.entries(payload).forEach(([key, value]) => {
        if (skipKeys.has(key)) return;
        appendCandidate(value, key);
    });
    return candidates;
};

export const resolveWorkflowMcpToolCall = (input: unknown): {
    payload: Record<string, unknown>;
    toolName: string;
    toolArguments: Record<string, unknown>;
    error: string;
} => {
    const payload = toRecordValue(input);
    const candidates = readToolCallCandidates(payload);
    if (candidates.length > 1) {
        return {
            payload,
            toolName: '',
            toolArguments: {},
            error: `Received multiple MCP tool call candidates from ${candidates.map((candidate) => candidate.source).join(', ')}. Keep exactly one upstream MCP tool payload.`
        };
    }
    if (!candidates.length) {
        return {
            payload,
            toolName: '',
            toolArguments: {},
            error: ''
        };
    }
    const candidate = candidates[0];
    return {
        payload,
        toolName: candidate?.toolName || '',
        toolArguments: candidate?.toolArguments || {},
        error: ''
    };
};

export const validateWorkflowMcpRuntime = (runtime: unknown): { ok: boolean; errors: string[]; normalizedRuntime: Record<string, unknown> } => {
    const record = toRecordValue(runtime);
    const normalized = normalizeWorkflowMcpRuntime(runtime);
    const errors: string[] = [];
    if (!normalized.credentialId) errors.push('MCP credential is required.');
    if (parseStringValue(record.maxLoopPasses) && (Number(record.maxLoopPasses) < 1 || Number(record.maxLoopPasses) > 6 || !Number.isFinite(Number(record.maxLoopPasses)))) {
        errors.push('Max Loop Passes must be between 1 and 6.');
    }
    return { ok: errors.length === 0, errors, normalizedRuntime: normalized as unknown as Record<string, unknown> };
};

export const resolveWorkflowMcpServer = (manager: WorkflowMcpRuntimeManager, runtime: WorkflowMcpNodeRuntimeConfig, credential: WorkflowResolvedCredential | null | undefined) => {
    const serverConfig = resolveWorkflowMcpCredentialServer(credential);
    const server = manager.resolveNodeServer({
        credentialId: runtime.credentialId,
        serverKey: serverConfig.serverKey,
        serverUrl: serverConfig.serverUrl,
        transport: serverConfig.transport,
        headers: serverConfig.headers
    });
    if (!server) throw new Error('MCP server configuration could not be resolved.');
    return server;
};
