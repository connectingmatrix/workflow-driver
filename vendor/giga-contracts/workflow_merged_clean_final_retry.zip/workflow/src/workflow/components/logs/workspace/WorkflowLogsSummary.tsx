import React from 'react';

interface WorkflowLogsSummaryProps {
    completed: boolean;
    durationLabel: string;
    warningLabel: string;
    outputContract: string;
}

const SummaryRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
    <div className="wf-workspace-logs__summary-row">
        <span className="wf-workspace-logs__summary-label">{label}</span>
        <span className="wf-workspace-logs__summary-value">{value}</span>
    </div>
);

export const WorkflowLogsSummary: React.FC<WorkflowLogsSummaryProps> = ({ completed, durationLabel, warningLabel, outputContract }) => (
    <aside className="wf-workspace-logs__summary">
        <div className="wf-workspace-logs__summary-card">
            <h3>Execution summary</h3>
            <p>Key run metadata aligned with the inspector output.</p>
            <SummaryRow label="Status" value={<span className={`wf-workspace-logs__status-pill${completed ? ' wf-workspace-logs__status-pill--completed' : ''}`}>{completed ? 'Completed' : 'Running'}</span>} />
            <SummaryRow label="Duration" value={durationLabel} />
            <SummaryRow label="Warnings" value={warningLabel} />
            <SummaryRow label="Output contract" value={outputContract} />
            <SummaryRow label="Tip" value="Match this JSONL surface with the node inspector output viewer." />
        </div>
    </aside>
);
