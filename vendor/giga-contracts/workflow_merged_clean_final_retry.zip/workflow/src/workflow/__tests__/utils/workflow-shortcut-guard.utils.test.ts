/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it } from 'vitest';
import { isWorkflowClipboardShortcutBlocked } from '@workflow/ui/workflow/utils/workflow-shortcut-guard.utils';

const clearSelection = () => {
    const selection = window.getSelection();
    if (selection) {
        selection.removeAllRanges();
    }
};

describe('isWorkflowClipboardShortcutBlocked', () => {
    beforeEach(() => {
        document.body.innerHTML = '';
        clearSelection();
    });

    it('blocks shortcuts from editable inspector elements', () => {
        const inspector = document.createElement('div');
        inspector.className = 'wf-inspector-dialog';
        const input = document.createElement('input');

        inspector.appendChild(input);
        document.body.appendChild(inspector);
        input.focus();

        expect(isWorkflowClipboardShortcutBlocked(input)).toBe(true);
    });

    it('blocks shortcuts when text is selected inside the inspector', () => {
        const inspector = document.createElement('div');
        inspector.className = 'wf-inspector-dialog';
        const text = document.createElement('div');

        text.textContent = 'Inspector copy text';
        inspector.appendChild(text);
        document.body.appendChild(inspector);

        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(text);
        selection?.addRange(range);

        expect(isWorkflowClipboardShortcutBlocked(text)).toBe(true);
    });

    it('does not block shortcuts for normal canvas elements', () => {
        const canvas = document.createElement('button');
        canvas.textContent = 'Canvas';
        document.body.appendChild(canvas);

        expect(isWorkflowClipboardShortcutBlocked(canvas)).toBe(false);
    });
});
