import fs from 'node:fs';
import path from 'node:path';

const workflowRepoRoot = '/Users/abeer/dev/giga/workflow';
const auditReportPath = path.join(workflowRepoRoot, 'src/workflow/icons/workflow-service-icon.audit.generated.json');
const report = JSON.parse(fs.readFileSync(auditReportPath, 'utf8'));

const classifiedTotal = report.manualAssetCount + report.componentBackedCount + (report.iconifyAssetCount ?? 0) + report.fallbackBackedCount;
const hasCoverageGap = classifiedTotal !== report.totalCatalogIcons;

console.log(JSON.stringify({
    totalCatalogIcons: report.totalCatalogIcons,
    manualAssetCount: report.manualAssetCount,
    componentBackedCount: report.componentBackedCount,
    iconifyAssetCount: report.iconifyAssetCount ?? 0,
    fallbackBackedCount: report.fallbackBackedCount,
    classifiedTotal,
    hasCoverageGap
}, null, 2));

if (hasCoverageGap) {
    console.error('Workflow service icon audit failed: catalog icons are not fully classified.');
    process.exit(1);
}
