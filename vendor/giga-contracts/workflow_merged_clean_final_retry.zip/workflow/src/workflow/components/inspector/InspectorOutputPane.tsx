import React, { useEffect, useMemo, useState } from 'react';
import { TabPanel, TabView } from 'primereact/tabview';
import JsonViewer from '@workflow/ui/workflow/components/viewers/JsonViewer';
import MarkdownViewer from '@workflow/ui/workflow/components/viewers/MarkdownViewer';
import TableViewer from '@workflow/ui/workflow/components/viewers/TableViewer';
import { WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';
import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';

interface InspectorOutputPaneProps {
    viewers: WorkflowInspectorViewer[];
    renderedMarkdown: string;
}

const formatRawViewerValue = (value: unknown): string => {
    if (typeof value === 'string') {
        return value;
    }
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const InspectorOutputPane: React.FC<InspectorOutputPaneProps> = ({ viewers, renderedMarkdown }) => {
    const allViewers = useMemo<WorkflowInspectorViewer[]>(() => {
        if (!renderedMarkdown.trim()) {
            return viewers;
        }
        return [
            ...viewers,
            {
                id: '__rendered_markdown__',
                label: 'Rendered Markdown',
                type: WorkflowViewerTypeEnum.Markdown,
                value: renderedMarkdown
            }
        ];
    }, [renderedMarkdown, viewers]);
    const [activeViewerId, setActiveViewerId] = useState<string>(allViewers[0]?.id ?? '');
    const activeViewerIndex = useMemo(() => {
        const index = allViewers.findIndex((viewer) => viewer.id === activeViewerId);
        return index >= 0 ? index : 0;
    }, [activeViewerId, allViewers]);

    useEffect(() => {
        if (!allViewers.length) {
            setActiveViewerId('');
            return;
        }
        if (!allViewers.some((viewer) => viewer.id === activeViewerId)) {
            setActiveViewerId(allViewers[0].id);
        }
    }, [activeViewerId, allViewers]);

    const activeViewer = useMemo(() => allViewers.find((viewer) => viewer.id === activeViewerId) ?? allViewers[0] ?? null, [activeViewerId, allViewers]);
    const renderViewerTabs = (): React.ReactNode => (
        <div className="wf-inspector__section wf-inspector__section--stretch">
            {allViewers.length > 0 && (
                <TabView
                    activeIndex={activeViewerIndex}
                    onTabChange={(event) => {
                        const next = allViewers[event.index];
                        if (next) {
                            setActiveViewerId(next.id);
                        }
                    }}
                    className="wf-inspector__tabview"
                >
                    {allViewers.map((viewer) => (
                        <TabPanel key={viewer.id} header={viewer.label}>
                            <div className="wf-inspector__output-panel-content">
                                {viewer.type === WorkflowViewerTypeEnum.Json && (
                                    <div className="wf-inspector__json-output">
                                        <JsonViewer value={viewer.value} rootPath="output" />
                                    </div>
                                )}
                                {viewer.type === WorkflowViewerTypeEnum.Markdown && <MarkdownViewer content={String(viewer.value ?? '')} />}
                                {viewer.type === WorkflowViewerTypeEnum.Raw && <pre className="wf-inspector__raw">{formatRawViewerValue(viewer.value)}</pre>}
                                {viewer.type === WorkflowViewerTypeEnum.Table && <TableViewer value={viewer.value} />}
                            </div>
                        </TabPanel>
                    ))}
                </TabView>
            )}
            {!activeViewer && <div className="wf-inspector__hint">No viewer information.</div>}
        </div>
    );

    return (
        <section className="wf-inspector-pane wf-inspector-pane--output">
            <header className="wf-inspector-pane__header wf-inspector-pane__header--split">
                <div>
                    <div className="wf-inspector-pane__title">Output</div>
                    <div className="wf-inspector-pane__subtitle">Node output for the selected viewer.</div>
                </div>
            </header>

            <div className="wf-inspector-pane__body">{renderViewerTabs()}</div>
        </section>
    );
};

export default InspectorOutputPane;
