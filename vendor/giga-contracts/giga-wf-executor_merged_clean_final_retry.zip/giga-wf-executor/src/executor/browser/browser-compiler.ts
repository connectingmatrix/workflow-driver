import { WorkerRuntimeEnvironmentEnum } from '../../types';
import {
    createBrowserNodeBuiltinStubSource,
    createVirtualExecuteModuleSource,
    createVirtualExecutorModuleSource
} from '../core/compiler/worker-virtual-modules';
import {
    compileWorkerSource,
    importCompiledModule,
    rewriteWorkerSourceSpecifiers,
    toDataUrl
} from '../core/compiler/typescript-compiler';
import { WorkerCompiledModuleLoader } from '../core/compiler/worker-module-loader';

const WORKER_NODE_BUILTIN_STUB_SPECIFIER = '@workflow/node-builtin-stub';
const NODE_BUILTIN_MODULES = new Set<string>([
    'assert',
    'buffer',
    'child_process',
    'cluster',
    'console',
    'constants',
    'crypto',
    'dgram',
    'diagnostics_channel',
    'dns',
    'domain',
    'events',
    'fs',
    'http',
    'http2',
    'https',
    'inspector',
    'module',
    'net',
    'os',
    'path',
    'perf_hooks',
    'process',
    'punycode',
    'querystring',
    'readline',
    'repl',
    'stream',
    'string_decoder',
    'timers',
    'tls',
    'tty',
    'url',
    'util',
    'v8',
    'vm',
    'wasi',
    'worker_threads',
    'zlib'
]);

const normalizeNodeBuiltinSpecifier = (specifier: string): string =>
    specifier.startsWith('node:') ? specifier.slice(5) : specifier;

const isNodeBuiltinSpecifier = (specifier: string): boolean =>
    NODE_BUILTIN_MODULES.has(normalizeNodeBuiltinSpecifier(specifier));

const parseNamedBindings = (namedSection: string): Array<{ imported: string; local: string }> => {
    return namedSection
        .split(',')
        .map((part) => part.trim())
        .filter((part) => part.length > 0)
        .map((part) => part.replace(/^type\s+/, '').trim())
        .filter((part) => part.length > 0)
        .map((part) => {
            const [left, right] = part.split(/\s+as\s+/);
            const imported = (left ?? '').trim();
            const local = (right ?? left ?? '').trim();
            return { imported, local };
        })
        .filter((entry) => entry.imported.length > 0 && entry.local.length > 0);
};

const rewriteNodeBuiltinImportsForBrowser = (source: string): string => {
    let importCounter = 0;
    let rewritten = source;

    rewritten = rewritten.replace(/(^|\n)([ \t]*)import\s+([\s\S]*?)\s+from\s+(['"])([^'"]+)\4\s*;?/gm, (match, prefix, indent, clauseRaw, _quote, rawSpecifier) => {
        const specifier = String(rawSpecifier ?? '').trim();
        if (!isNodeBuiltinSpecifier(specifier)) return match;

        const clause = String(clauseRaw ?? '').trim();
        const namedOnlyMatch = clause.match(/^\{([\s\S]*)\}$/);
        const namespaceOnlyMatch = clause.match(/^\*\s+as\s+([A-Za-z_$][\w$]*)$/);
        const defaultAndRestMatch = clause.match(/^([A-Za-z_$][\w$]*)\s*,\s*([\s\S]+)$/);
        const defaultOnlyMatch = clause.match(/^([A-Za-z_$][\w$]*)$/);

        let defaultBinding: string | null = null;
        let namespaceBinding: string | null = null;
        let namedBindings: Array<{ imported: string; local: string }> = [];

        if (namedOnlyMatch) {
            namedBindings = parseNamedBindings(namedOnlyMatch[1] ?? '');
        } else if (namespaceOnlyMatch) {
            namespaceBinding = namespaceOnlyMatch[1] ?? null;
        } else if (defaultAndRestMatch) {
            defaultBinding = defaultAndRestMatch[1] ?? null;
            const rest = (defaultAndRestMatch[2] ?? '').trim();
            const restNamedMatch = rest.match(/^\{([\s\S]*)\}$/);
            const restNamespaceMatch = rest.match(/^\*\s+as\s+([A-Za-z_$][\w$]*)$/);
            if (restNamedMatch) {
                namedBindings = parseNamedBindings(restNamedMatch[1] ?? '');
            } else if (restNamespaceMatch) {
                namespaceBinding = restNamespaceMatch[1] ?? null;
            }
        } else if (defaultOnlyMatch) {
            defaultBinding = defaultOnlyMatch[1] ?? null;
        } else {
            return `${prefix}${indent}/* Node builtin import "${specifier}" is ignored in browser runtime. */`;
        }

        const tempBinding = `__wfBuiltin_${normalizeNodeBuiltinSpecifier(specifier).replace(/[^a-zA-Z0-9_$]/g, '_')}_${importCounter}`;
        importCounter += 1;
        const importBinding = defaultBinding ?? namespaceBinding ?? tempBinding;
        const lines: string[] = [`${indent}import ${importBinding} from '${WORKER_NODE_BUILTIN_STUB_SPECIFIER}';`];

        if (namespaceBinding && namespaceBinding !== importBinding) {
            lines.push(`${indent}const ${namespaceBinding} = ${importBinding};`);
        }

        namedBindings.forEach(({ imported, local }) => {
            lines.push(`${indent}const ${local} = ${importBinding}.${imported};`);
        });

        return `${prefix}${lines.join('\n')}`;
    });

    rewritten = rewritten.replace(/(^|\n)([ \t]*)import\s+(['"])([^'"]+)\3\s*;?/gm, (match, prefix, indent, _quote, rawSpecifier) => {
        const specifier = String(rawSpecifier ?? '').trim();
        if (!isNodeBuiltinSpecifier(specifier)) return match;
        return `${prefix}${indent}/* Node builtin side-effect import "${specifier}" is ignored in browser runtime. */`;
    });

    rewritten = rewritten.replace(/import\(\s*(['"])([^'"]+)\1\s*\)/g, (match, _quote, rawSpecifier) => {
        const specifier = String(rawSpecifier ?? '').trim();
        if (!isNodeBuiltinSpecifier(specifier)) return match;
        return `import('${WORKER_NODE_BUILTIN_STUB_SPECIFIER}').then((module) => module.default ?? module)`;
    });

    return rewritten;
};

export const loadBrowserCompiledModule: WorkerCompiledModuleLoader = async (params) => {
    const sourceForCompile = rewriteNodeBuiltinImportsForBrowser(params.source);
    const compiledSource = await compileWorkerSource({
        modelId: params.modelId,
        source: sourceForCompile,
        sourceSignature: params.sourceSignature,
        cacheKey: `${params.moduleLabel}:${WorkerRuntimeEnvironmentEnum.Browser}:${params.modelId}:${params.sourceSignature}`,
        moduleLoader: params.typescriptModuleLoader
    });
    const executeModuleSpecifier = toDataUrl(createVirtualExecuteModuleSource(params.helperId));
    const executorModuleSpecifier = toDataUrl(createVirtualExecutorModuleSource());
    const builtinStubSpecifier = toDataUrl(createBrowserNodeBuiltinStubSource());
    const rewrittenSource = rewriteWorkerSourceSpecifiers(
        compiledSource,
        executeModuleSpecifier,
        executorModuleSpecifier,
        builtinStubSpecifier
    );

    return importCompiledModule({
        source: rewrittenSource,
        modelId: params.modelId,
        moduleLabel: params.moduleLabel
    });
};
