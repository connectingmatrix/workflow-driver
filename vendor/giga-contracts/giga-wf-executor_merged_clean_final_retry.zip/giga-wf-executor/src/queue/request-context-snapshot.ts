import type { WorkflowQueueRequestContextMode, WorkflowQueueRequestContextSnapshot } from './types';

const textValue = (value: unknown): string => String(value || '').trim();
const cloneValue = (value: unknown) => {
  if (value == null) return value;
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
};

const normalizeHeaders = (headers: Record<string, unknown> = {}): Record<string, string> =>
  Object.entries(headers).reduce<Record<string, string>>((result, [key, value]) => {
    if (Array.isArray(value) && value[0]) result[key] = String(value[0]);
    if (!Array.isArray(value) && value != null) result[key] = String(value);
    return result;
  }, {});

export const createWorkflowQueueRequestContextSnapshot = (params: {
  mode: WorkflowQueueRequestContextMode;
  request: Record<string, any>;
  userId: string;
  authorization?: string | null;
}): WorkflowQueueRequestContextSnapshot => {
  const headers = normalizeHeaders(params.request.headers || {});
  const accessToken = textValue(params.request.supabase?.__access_token);
  const authorization = textValue(params.authorization) || textValue(headers.authorization) || (accessToken ? `Bearer ${accessToken}` : '');
  if (authorization && !headers.authorization) headers.authorization = authorization;
  return {
    mode: params.mode,
    userId: params.userId,
    authorization: headers.authorization || null,
    headers,
    method: textValue(params.request.method) || null,
    protocol: textValue(params.request.protocol) || null,
    host: textValue(params.request.headers?.['x-forwarded-host']) || textValue(params.request.headers?.host) || null,
    origin: textValue(params.request.headers?.origin) || null,
    path: textValue(params.request.path) || null,
    originalUrl: textValue(params.request.originalUrl) || null,
    query: cloneValue(params.request.query || null),
    body: cloneValue(params.request.body || null),
    ip: textValue(params.request.ip) || null,
  };
};
