import { describe, expect, it } from 'vitest';
import { hydrateWorkflowDefinition } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('workflow hydration', () => {
    it('keeps current field contracts when saved node model fields are stale', () => {
        const workflow = createEmptyWorkflow('wf_stale_schema');
        const outputFormat = workflow.nodeModels['output-format'];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'output-format': {
                ...outputFormat,
                fields: {
                    ...outputFormat.fields,
                    aiPrompt: {
                        type: 'markdown',
                        label: 'Saved AI Prompt',
                        editable: true,
                        allowVariables: true
                    }
                }
            }
        };

        const hydrated = hydrateWorkflowDefinition(workflow);

        expect(hydrated.nodeModels['output-format'].fields.aiPrompt.label).toBe('Saved AI Prompt');
        expect(hydrated.nodeModels['output-format'].fields.aiPrompt.resolveVariablesWhen).toEqual({ field: 'useAiFormatting', value: true });
    });
});
