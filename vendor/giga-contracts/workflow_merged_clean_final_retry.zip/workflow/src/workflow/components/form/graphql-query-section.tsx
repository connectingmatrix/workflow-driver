import React, { useMemo } from 'react';

interface GraphqlQuerySectionProps {
    queryText: unknown;
    variables: unknown;
}

const parseVariables = (variables: unknown): unknown => {
    if (typeof variables !== 'string') return variables;
    const raw = variables.trim();
    if (!raw) return {};
    try {
        return JSON.parse(raw);
    } catch {
        return { invalidJson: raw };
    }
};

const GraphqlQuerySection: React.FC<GraphqlQuerySectionProps> = ({ queryText, variables }) => {
    const parsedVariables = useMemo(() => parseVariables(variables), [variables]);

    return (
        <div className="wf-inspector__graphql-section">
            <div className="wf-inspector__graphql-heading">GraphQL Query Preview</div>
            <pre className="wf-inspector__graphql-query">{String(queryText ?? '').trim() || '# Select a query from dropdown.'}</pre>
            <div className="wf-inspector__graphql-heading">Variables</div>
            <pre className="wf-inspector__graphql-variables">{JSON.stringify(parsedVariables ?? {}, null, 2)}</pre>
        </div>
    );
};

export default GraphqlQuerySection;
export type { GraphqlQuerySectionProps };
