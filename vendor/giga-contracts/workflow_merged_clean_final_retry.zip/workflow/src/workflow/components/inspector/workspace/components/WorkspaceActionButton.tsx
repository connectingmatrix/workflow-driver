import type { ButtonHTMLAttributes } from 'react';
import type { WorkspaceAction } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';

interface WorkspaceActionButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> {
    action: WorkspaceAction;
    onClick?: (actionId: string) => void;
}

export const WorkspaceActionButton = ({ action, onClick, className = '', ...rest }: WorkspaceActionButtonProps) => {
    if (action.visible === false) {
        return null;
    }

    const toneClass = action.tone ? ` cnw-action-button--${action.tone}` : '';
    const busyClass = action.busy ? ' cnw-action-button--busy' : '';
    const iconName = action.busy ? 'refresh' : action.icon;

    return (
        <button
            type="button"
            className={`cnw-action-button${toneClass}${busyClass}${className ? ` ${className}` : ''}`}
            disabled={action.disabled}
            aria-busy={action.busy || undefined}
            aria-label={action.label}
            data-cy={`workflow-inspector-action-${action.id}`}
            onClick={() => onClick?.(action.id)}
            {...rest}
        >
            {iconName ? <WorkspaceGlyph name={iconName} className="cnw-action-button__icon" /> : null}
            {!action.iconOnly ? <span className="cnw-action-button__label">{action.label}</span> : null}
        </button>
    );
};
