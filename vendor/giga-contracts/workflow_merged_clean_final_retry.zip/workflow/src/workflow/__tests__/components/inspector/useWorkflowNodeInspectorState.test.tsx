// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { useWorkflowNodeInspectorState } from '@workflow/ui/workflow/components/inspector/useWorkflowNodeInspectorState';
import { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import { WorkflowNodeFieldTypeEnum, WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';

interface ProbeProps {
    config: WorkflowInspectorConfig;
}

const buildConfig = (overrides: Partial<WorkflowInspectorConfig> = {}): WorkflowInspectorConfig => ({
    nodeId: 'node_1',
    modelId: 'code',
    nodeTypeLabel: 'Code',
    instruction: { code: true, markdown: true },
    name: 'Node 1',
    title: 'Node 1',
    input: {},
    properties: { name: 'Node 1', description: 'Initial description' },
    fields: {
        name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
        description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true }
    },
    viewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: {} }],
    code: 'return input;',
    markdown: 'Initial markdown',
    ...overrides
});

const StateProbe: React.FC<ProbeProps> = ({ config }) => {
    const state = useWorkflowNodeInspectorState({
        config,
        onExecuteStep: vi.fn(async () => ({ output: { ok: true }, logs: [], error: null }))
    });

    return (
        <div>
            <button onClick={() => state.setProperty('name', 'Draft Name')}>Edit Name</button>
            <button onClick={() => state.onCodeChange('return "draft";')}>Edit Code</button>
            <pre data-testid="state-name">{String(state.propertiesEditorState.name ?? '')}</pre>
            <pre data-testid="state-code">{state.code}</pre>
        </div>
    );
};

const ExecutionProbe: React.FC<ProbeProps> = ({ config }) => {
    const state = useWorkflowNodeInspectorState({
        config,
        onExecuteStep: vi.fn(async () => ({ output: { status: 'ok' }, logs: ['done'], error: null }))
    });

    return (
        <div>
            <button onClick={() => void state.runCurrentCode()}>Run</button>
            <pre data-testid="execution-output">{JSON.stringify(state.executionResult?.output ?? null)}</pre>
        </div>
    );
};

const SaveProbe: React.FC<{ config: WorkflowInspectorConfig; onSave: (nextConfig: WorkflowInspectorConfig) => void }> = ({ config, onSave }) => {
    const state = useWorkflowNodeInspectorState({ config, onSave });

    return (
        <div>
            <button onClick={() => state.setProperty('description', 'Updated description')}>Edit Description</button>
            <button onClick={state.saveChanges}>Save</button>
            <pre data-testid="save-state">{state.hasUnsavedChanges ? 'dirty' : 'clean'}</pre>
        </div>
    );
};

const PromptSaveProbe: React.FC<{ config: WorkflowInspectorConfig; onSave: (nextConfig: WorkflowInspectorConfig) => void }> = ({ config, onSave }) => {
    const state = useWorkflowNodeInspectorState({ config, onSave });

    return (
        <div>
            <button onClick={() => state.setProperty('aiPrompt', 'Line 1\nLine 2\nLine 3\nUse strict markdown output.')}>Edit AI Prompt</button>
            <button onClick={state.saveChanges}>Save</button>
            <pre data-testid="state-prompt">{String(state.propertiesEditorState.aiPrompt ?? '')}</pre>
        </div>
    );
};

describe('useWorkflowNodeInspectorState', () => {
    it('preserves unsaved drafts when same node config updates after step execution', () => {
        const initialConfig = buildConfig();
        const { rerender } = render(<StateProbe config={initialConfig} />);

        fireEvent.click(screen.getByRole('button', { name: 'Edit Name' }));
        fireEvent.click(screen.getByRole('button', { name: 'Edit Code' }));

        expect(screen.getByTestId('state-name')).toHaveTextContent('Draft Name');
        expect(screen.getByTestId('state-code')).toHaveTextContent('return "draft";');

        const refreshedConfig = buildConfig({
            properties: { name: 'Server Name', description: 'Server description' },
            code: 'return "server";',
            markdown: 'Server markdown'
        });

        rerender(<StateProbe config={refreshedConfig} />);

        expect(screen.getByTestId('state-name')).toHaveTextContent('Draft Name');
        expect(screen.getByTestId('state-code')).toHaveTextContent('return "draft";');
    });

    it('auto-selects the only connected llm option for output format and clears disconnected values', () => {
        const outputFormatConfig = buildConfig({
            nodeId: 'node_output',
            modelId: 'output-format',
            nodeTypeLabel: 'Output Format',
            instruction: { code: false, markdown: false },
            code: '',
            markdown: '',
            properties: {
                name: 'Output Format',
                modelId: ''
            },
            fields: {
                name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                modelId: {
                    type: WorkflowNodeFieldTypeEnum.Select,
                    editable: true,
                    options: [{ label: 'OpenAI', value: 'node_llm_1' }]
                }
            }
        });

        const AutoSelectProbe: React.FC<{ config: WorkflowInspectorConfig }> = ({ config }) => {
            const state = useWorkflowNodeInspectorState({ config });
            return <pre data-testid="state-model-id">{String(state.propertiesEditorState.modelId ?? '')}</pre>;
        };

        const { rerender } = render(<AutoSelectProbe config={outputFormatConfig} />);
        expect(screen.getByTestId('state-model-id')).toHaveTextContent('node_llm_1');

        rerender(
            <AutoSelectProbe
                config={{
                    ...outputFormatConfig,
                    properties: {
                        ...outputFormatConfig.properties,
                        modelId: 'node_llm_1'
                    },
                    fields: {
                        ...outputFormatConfig.fields,
                        modelId: {
                            type: WorkflowNodeFieldTypeEnum.Select,
                            editable: true,
                            options: []
                        }
                    }
                }}
            />
        );

        expect(screen.getByTestId('state-model-id')).toHaveTextContent('');
    });

    it('preserves the latest execution result when the same node config refreshes', async () => {
        const initialConfig = buildConfig();
        const { rerender } = render(<ExecutionProbe config={initialConfig} />);

        fireEvent.click(screen.getByRole('button', { name: 'Run' }));
        await screen.findByText('{"status":"ok"}');

        rerender(
            <ExecutionProbe
                config={buildConfig({
                    properties: { name: 'Node 1', description: 'Server description' },
                    viewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: { server: true } }]
                })}
            />
        );

        expect(screen.getByTestId('execution-output')).toHaveTextContent('{"status":"ok"}');
    });

    it('clears the unsaved state immediately after saving', async () => {
        const onSave = vi.fn();
        render(<SaveProbe config={buildConfig()} onSave={onSave} />);

        expect(screen.getByTestId('save-state')).toHaveTextContent('clean');

        fireEvent.click(screen.getByRole('button', { name: 'Edit Description' }));
        expect(screen.getByTestId('save-state')).toHaveTextContent('dirty');

        fireEvent.click(screen.getByRole('button', { name: 'Save' }));

        expect(onSave).toHaveBeenCalledTimes(1);
        await waitFor(() => expect(screen.getByTestId('save-state')).toHaveTextContent('clean'));
    });

    it('saves and reloads output format ai prompts without resetting to defaults', () => {
        const onSave = vi.fn();
        const outputFormatConfig = buildConfig({
            nodeId: 'node_output',
            modelId: 'output-format',
            nodeTypeLabel: 'Output Format',
            instruction: { code: false, markdown: false },
            code: '',
            markdown: '',
            properties: {
                name: 'Output Format',
                useAiFormatting: true,
                aiPrompt: 'Original prompt'
            },
            fields: {
                name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                useAiFormatting: { type: WorkflowNodeFieldTypeEnum.Boolean, editable: true },
                aiPrompt: { type: WorkflowNodeFieldTypeEnum.Markdown, editable: true, defaultValue: 'Default prompt' }
            }
        });
        const { rerender } = render(<PromptSaveProbe config={outputFormatConfig} onSave={onSave} />);

        fireEvent.click(screen.getByRole('button', { name: 'Edit AI Prompt' }));
        fireEvent.click(within(screen.getByTestId('state-prompt').parentElement as HTMLElement).getByRole('button', { name: 'Save' }));
        const savedConfig = onSave.mock.calls[0][0] as WorkflowInspectorConfig;

        rerender(<PromptSaveProbe config={{ ...outputFormatConfig, properties: savedConfig.properties }} onSave={onSave} />);

        expect(screen.getByTestId('state-prompt')).toHaveTextContent('Line 1');
        expect(screen.getByTestId('state-prompt')).toHaveTextContent('Use strict markdown output.');
        expect(screen.getByTestId('state-prompt')).not.toHaveTextContent('Default prompt');
    });

    it('keeps executing while the same node config refreshes before the step resolves', async () => {
        let resolveStep: ((value: { output: unknown; logs: string[]; error: string | null }) => void) | null = null;
        const ExecutionStateProbe: React.FC<{ config: WorkflowInspectorConfig }> = ({ config }) => {
            const state = useWorkflowNodeInspectorState({
                config,
                onExecuteStep: () =>
                    new Promise((resolve) => {
                        resolveStep = resolve;
                    })
            });

            return (
                <div>
                    <button onClick={() => void state.runCurrentCode()}>Run Deferred</button>
                    <pre data-testid="execution-state">{state.isExecuting ? 'running' : 'idle'}</pre>
                </div>
            );
        };
        const initialConfig = buildConfig();
        const { rerender } = render(<ExecutionStateProbe config={initialConfig} />);

        fireEvent.click(screen.getByRole('button', { name: 'Run Deferred' }));
        await waitFor(() => expect(screen.getByTestId('execution-state')).toHaveTextContent('running'));

        rerender(
            <ExecutionStateProbe
                config={buildConfig({
                    properties: { name: 'Node 1', description: 'Server refresh' },
                    viewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: { refreshed: true } }]
                })}
            />
        );

        expect(screen.getByTestId('execution-state')).toHaveTextContent('running');

        resolveStep?.({ output: { ok: true }, logs: ['done'], error: null });

        await waitFor(() => expect(screen.getByTestId('execution-state')).toHaveTextContent('idle'));
    });

    it('drops hidden legacy properties that are no longer part of the schema', () => {
        const LegacyProbe: React.FC<ProbeProps> = ({ config }) => {
            const state = useWorkflowNodeInspectorState({ config });
            return <pre data-testid="state-properties">{JSON.stringify(state.propertiesEditorState)}</pre>;
        };

        render(
            <LegacyProbe
                config={buildConfig({
                    modelId: 'mcp-runtime',
                    properties: {
                        name: 'MCP Execute',
                        description: 'Runs MCP tools',
                        serverUrl: 'https://example.com/mcp',
                        transport: 'streamable-http',
                        capabilityQuery: 'tools'
                    },
                    fields: {
                        name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
                        description: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true },
                        capabilityQuery: { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true }
                    },
                    hiddenFieldKeys: ['serverUrl', 'transport']
                })}
            />
        );

        expect(screen.getByTestId('state-properties')).toHaveTextContent('"capabilityQuery":"tools"');
        expect(screen.getByTestId('state-properties')).not.toHaveTextContent('serverUrl');
        expect(screen.getByTestId('state-properties')).not.toHaveTextContent('transport');
    });
});
