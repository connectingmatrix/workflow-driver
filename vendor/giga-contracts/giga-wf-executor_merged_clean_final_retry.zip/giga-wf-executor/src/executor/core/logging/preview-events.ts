import {
    ExecuteNodeStepOptions,
    WorkflowPreviewLogEvent,
    WorkflowPreviewLogSource,
    WorkflowPreviewStateEvent
} from '../../../types';

const nowIso = (): string => new Date().toISOString();

const toPreviewRuntime = (
    value: ExecuteNodeStepOptions['overrides'] | undefined
): WorkflowPreviewStateEvent['requestedRuntime'] =>
    value?.previewRuntime === 'browser' ||
    value?.previewRuntime === 'node' ||
    value?.previewRuntime === 'auto'
        ? value.previewRuntime
        : undefined;

export const emitPreviewState = (params: {
    options: Pick<ExecuteNodeStepOptions, 'onPreviewState' | 'overrides'>;
    runId: string;
    nodeId: string;
    state: WorkflowPreviewStateEvent['state'];
    runtime?: WorkflowPreviewStateEvent['runtime'];
    startedAt?: string;
    durationMs?: number;
    message?: string;
    validation?: WorkflowPreviewStateEvent['validation'];
}): void => {
    params.options.onPreviewState?.({
        runId: params.runId,
        nodeId: params.nodeId,
        state: params.state,
        requestedRuntime: toPreviewRuntime(params.options.overrides),
        runtime: params.runtime,
        startedAt: params.startedAt,
        durationMs: params.durationMs,
        message: params.message,
        validation: params.validation
    });
};

export const emitPreviewLogLine = (params: {
    options: Pick<ExecuteNodeStepOptions, 'onPreviewLogLine'>;
    runId: string;
    nodeId: string;
    source: WorkflowPreviewLogSource;
    line: string;
    runtime?: WorkflowPreviewLogEvent['runtime'];
    stream?: string;
}): void => {
    if (!params.line) return;
    params.options.onPreviewLogLine?.({
        runId: params.runId,
        nodeId: params.nodeId,
        source: params.source,
        line: params.line,
        timestamp: nowIso(),
        runtime: params.runtime,
        stream: params.stream
    });
};

export const emitPreviewLogs = (params: {
    options: Pick<ExecuteNodeStepOptions, 'onPreviewLogLine'>;
    runId: string;
    nodeId: string;
    source: WorkflowPreviewLogSource;
    lines?: string[];
    runtime?: WorkflowPreviewLogEvent['runtime'];
    stream?: string;
}): void => {
    (params.lines ?? []).forEach((line) =>
        emitPreviewLogLine({
            options: params.options,
            runId: params.runId,
            nodeId: params.nodeId,
            source: params.source,
            line,
            runtime: params.runtime,
            stream: params.stream
        })
    );
};
