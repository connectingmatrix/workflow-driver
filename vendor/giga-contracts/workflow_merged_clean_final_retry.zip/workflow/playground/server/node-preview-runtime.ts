import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { loadTypeScriptModule } from '../../src/workflow/executor/typescript-loader';
import type { ExecuteWorkflowPreviewParams, WorkflowNodePreviewRequest, WorkflowNodePreviewResponse } from '../shared/preview-runtime.types';

interface ExecutorModule {
    createWorkerNodeHandler: typeof import('../../../giga-wf-executor/src/index').createWorkerNodeHandler;
    createWorkflowExecutor: typeof import('../../../giga-wf-executor/src/index').createWorkflowExecutor;
    WorkflowExecutorModeEnum: typeof import('../../../giga-wf-executor/src/index').WorkflowExecutorModeEnum;
    WorkflowNodeStatusEnum: typeof import('../../../giga-wf-executor/src/index').WorkflowNodeStatusEnum;
}

let nodePreviewExecutorPromise: Promise<ReturnType<ExecutorModule['createWorkflowExecutor']>> | null = null;

const loadExecutorModule = async (): Promise<ExecutorModule> => {
    const executorEntryPath = path.resolve(process.cwd(), '../giga-wf-executor/dist/index.js');
    try {
        return (await import(/* @vite-ignore */ pathToFileURL(executorEntryPath).href)) as ExecutorModule;
    } catch (error) {
        return (await import('../../../giga-wf-executor/src/index')) as ExecutorModule;
    }
};

const getNodePreviewExecutor = async () => {
    if (!nodePreviewExecutorPromise) {
        nodePreviewExecutorPromise = loadExecutorModule().then((executorModule) =>
            executorModule.createWorkflowExecutor({
                mode: executorModule.WorkflowExecutorModeEnum.Local,
                adapters: {
                    getNodeHandler: (modelId) =>
                        executorModule.createWorkerNodeHandler({
                            modelId: modelId ?? 'unknown-node',
                            runtimeEnvironment: 'node',
                            typescriptModuleLoader: loadTypeScriptModule,
                            executeHelpers: {
                                executeBackend: async () => ({
                                    output: { stub: true },
                                    status: executorModule.WorkflowNodeStatusEnum.Passed,
                                    logs: ['playground executeBackend is stubbed']
                                }),
                                resolveNodeSourceFiles: async ({ context }) => {
                                    const preview = (context.hostContext ?? {}) as { __workflowPreview?: { sourceFiles?: Record<string, string> } };
                                    return preview.__workflowPreview?.sourceFiles ?? null;
                                },
                                updateNode: () => undefined
                            }
                        })
                }
            })
        );
    }

    return nodePreviewExecutorPromise;
};

export const executeNodeWorkflowPreview = async (params: ExecuteWorkflowPreviewParams) => {
    const nodePreviewExecutor = await getNodePreviewExecutor();
    return nodePreviewExecutor.executeNodeStep({
        workflow: params.workflow,
        nodeId: params.nodeId,
        settings: params.settings,
        signal: params.signal,
        hostContext: {
            __workflowPreview: {
                sourceFiles: params.overrides?.sourceFiles ?? {}
            }
        },
        overrides: params.overrides,
        onPreviewLogLine: (event) => params.emitLog({ ...event, runId: params.runId }),
        onPreviewState: (event) => params.emitState({ ...event, runId: params.runId })
    });
};

export const executeNodeWorkflowPreviewRequest = async (request: WorkflowNodePreviewRequest): Promise<WorkflowNodePreviewResponse> => {
    const logs: WorkflowNodePreviewResponse['logs'] = [];
    const states: WorkflowNodePreviewResponse['states'] = [];

    try {
        const result = await executeNodeWorkflowPreview({
            ...request,
            emitLog: (event) => {
                logs.push(event);
            },
            emitState: (event) => {
                states.push(event);
            }
        });

        return {
            ok: true,
            logs,
            states,
            result
        };
    } catch (error) {
        return {
            ok: false,
            logs,
            states,
            error: error instanceof Error ? error.message : String(error)
        };
    }
};
