import React from 'react';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { OrderList } from 'primereact/orderlist';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import { UserNodeFieldDraft } from './user-node-schema-draft.utils';

const FIELD_TYPES = Object.values(WorkflowNodeFieldTypeEnum).map((value) => ({ label: value, value }));

interface UserNodeFieldDesignerProps {
    fields: UserNodeFieldDraft[];
    onChange: (fields: UserNodeFieldDraft[]) => void;
    onAdd: () => void;
}

const UserNodeFieldDesigner: React.FC<UserNodeFieldDesignerProps> = ({ fields, onChange, onAdd }) => {
    const updateField = (fieldId: string, patch: Partial<UserNodeFieldDraft>) => {
        onChange(fields.map((field) => (field.id === fieldId ? { ...field, ...patch } : field)).map((field, index) => ({ ...field, order: index + 1 })));
    };

    return (
        <div className="wf-user-node-designer__section">
            <div className="wf-user-node-designer__section-header">
                <div>
                    <h4>Inspector Fields</h4>
                    <p>Drag to reorder the inspector fields that will be saved in the node schema.</p>
                </div>
                <Button label="Add Field" icon="pi pi-plus" size="small" onClick={onAdd} />
            </div>
            <OrderList
                value={fields}
                onChange={(event) => onChange((event.value as UserNodeFieldDraft[]).map((field, index) => ({ ...field, order: index + 1 })))}
                itemTemplate={(field: UserNodeFieldDraft) => (
                    <div className="wf-user-node-designer__card-grid">
                        <InputText value={field.key} onChange={(event) => updateField(field.id, { key: event.target.value })} placeholder="Field key" />
                        <InputText value={field.label} onChange={(event) => updateField(field.id, { label: event.target.value })} placeholder="Field label" />
                        <Dropdown value={field.type} options={FIELD_TYPES} onChange={(event) => updateField(field.id, { type: String(event.value) })} />
                        <InputText value={field.placeholder} onChange={(event) => updateField(field.id, { placeholder: event.target.value })} placeholder="Placeholder" />
                        <label className="wf-user-node-designer__checkbox-row"><Checkbox checked={field.editable} onChange={(event) => updateField(field.id, { editable: Boolean(event.checked) })} /> Editable</label>
                        <label className="wf-user-node-designer__checkbox-row"><Checkbox checked={field.allowVariables} onChange={(event) => updateField(field.id, { allowVariables: Boolean(event.checked) })} /> Variables</label>
                        <label className="wf-user-node-designer__checkbox-row"><Checkbox checked={field.hidden} onChange={(event) => updateField(field.id, { hidden: Boolean(event.checked) })} /> Hidden</label>
                    </div>
                )}
                dataKey="id"
                dragdrop
                className="wf-user-node-designer__order-list"
            />
        </div>
    );
};

export default UserNodeFieldDesigner;
