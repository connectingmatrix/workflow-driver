import { WorkflowExecutionResult } from '@workflow/ui/workflow/components/inspector/types';
import { WorkflowNodeFieldMap } from '@workflow/ui/workflow/types';
import { evaluateJavascriptInIframe } from '@workflow/ui/workflow/browser-runtime/js-runtime-iframe';
import { parseEditorPropertyValues } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';
import { containsVariableToken, resolveWorkflowVariablePath } from '@workflow/ui/workflow/utils/workflow-variables.utils';
import { parseEditableStringValue } from '@workflow/ui/workflow/utils/value-utils';

const parseValue = (raw: unknown): unknown => {
    const normalized = String(raw ?? '').trim();
    if (!normalized) {
        return '';
    }
    if (containsVariableToken(normalized)) {
        return normalized;
    }

    try {
        return JSON.parse(normalized);
    } catch {
        // fall through to scalar coercion
    }
    if (normalized === 'true') return true;
    if (normalized === 'false') return false;
    if (normalized === 'null') return null;
    const asNumber = Number(normalized);
    return Number.isNaN(asNumber) ? raw : asNumber;
};

export const parsePropertiesInput = (propertiesEditorState: Record<string, unknown>, fields: WorkflowNodeFieldMap = {}): Record<string, unknown> => {
    if (Object.keys(fields).length > 0) {
        return parseEditorPropertyValues(fields, propertiesEditorState);
    }
    return Object.entries(propertiesEditorState).reduce<Record<string, unknown>>((acc, [key, value]) => {
        acc[key] = parseValue(value);
        return acc;
    }, {});
};

export interface WorkflowExecutionContext {
    input: Record<string, unknown>;
    properties: Record<string, unknown>;
    workflow?: Record<string, unknown>;
}

const resolvePath = (path: string, context: WorkflowExecutionContext): unknown => {
    return resolveWorkflowVariablePath(path, context as unknown as Record<string, unknown>);
};

export const executeNodeCode = async (code: string, input: Record<string, unknown>, properties: Record<string, unknown>, workflow: Record<string, unknown> = {}, onLog?: (line: string) => void): Promise<WorkflowExecutionResult> => {
    const executableCode = code.trim() ? code : 'return input;';
    const evaluated = await evaluateJavascriptInIframe(executableCode, { input, properties, workflow });
    evaluated.logs.forEach((line) => onLog?.(line));
    return {
        output: evaluated.error ? null : evaluated.result,
        logs: evaluated.logs,
        error: evaluated.error ?? null
    };
};

export const executeConsoleSnippet = async (snippet: string, context: WorkflowExecutionContext): Promise<WorkflowExecutionResult> => {
    const trimmed = snippet.trim();
    if (!trimmed) {
        return { output: null, logs: [], error: 'No JavaScript input provided.' };
    }

    const maybeExpression = /^[a-zA-Z_$\[\(]/.test(trimmed) && !trimmed.includes('\n') && !trimmed.includes(';') && !trimmed.startsWith('return');
    const executable = maybeExpression ? `return (${trimmed});` : trimmed;
    return executeNodeCode(executable, context.input, context.properties, context.workflow ?? {});
};

export const renderInstructionMarkdown = (markdown: string, context: WorkflowExecutionContext): string => {
    if (!markdown.trim()) {
        return '';
    }

    return markdown.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_match, rawPath: string) => {
        const resolved = resolvePath(rawPath, context);
        return parseEditableStringValue(resolved);
    });
};
