import type { WorkspaceInspectorFlags, WorkspaceInspectorTheme } from '@workflow/ui/workflow/components/inspector/workspace/types';

export const DEFAULT_WORKSPACE_INSPECTOR_FLAGS: WorkspaceInspectorFlags = {
    showHeader: true,
    showAcceptedFormats: false,
    showInputFeatures: true,
    showParametersHero: true,
    showBestPracticeHints: true,
    showOutputSummary: true,
    showRecentActivity: true,
    showFooterAction: true
};

export const DEFAULT_WORKSPACE_INSPECTOR_THEME: WorkspaceInspectorTheme = {
    accent: '#4f6bff',
    accentSoft: 'rgba(79, 107, 255, 0.12)',
    accentStrong: '#3f5ef7',
    surface: '#ffffff',
    surfaceAlt: '#f6f8ff',
    border: 'rgba(126, 142, 178, 0.18)',
    text: '#1f2a44',
    muted: '#7d869f',
    success: '#2a9b62',
    warning: '#d68a22',
    danger: '#d2504b',
    shadow: '0 24px 80px rgba(41, 52, 86, 0.12)',
    shellBackground: 'linear-gradient(180deg, #eef2fb 0%, #e7edf9 100%)'
};

export const WORKSPACE_ACTION_IDS = {
    Preview: 'preview',
    RunNode: 'run-node',
    RefreshNode: 'refresh-node',
    CloseNode: 'close-node',
    InspectNode: 'inspect-node',
    SaveChanges: 'save-changes',
    CopyOutput: 'copy-output',
    AddInput: 'add-input'
} as const;
