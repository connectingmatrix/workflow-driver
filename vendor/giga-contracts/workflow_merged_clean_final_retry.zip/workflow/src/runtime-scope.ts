export type GigaRuntimeScopeType =
  | "CHAT_DEFAULT"
  | "AI_AGENT"
  | "WORKFLOW"
  | "SWARM"
  | "AI_AGENT_PROJECT"
  | "NODE"
  | "AGENT_INGESTION";

export interface GigaRuntimeScopeInput {
  processId?: string | null;
  parentScopeId?: string | null;
  scopeType?: GigaRuntimeScopeType | string | null;
  userId?: string | null;
  pid?: number | null;
  cpuPercent?: number | null;
  ramMb?: number | null;
  iteration?: number | null;
}

export interface GigaRuntimeScope extends GigaRuntimeScopeInput {
  processId: string;
  parentScopeId: string | null;
  scopeType: GigaRuntimeScopeType | string;
  userId: string | null;
}

const clean = (value: unknown): string =>
  typeof value === "string" ? value.trim() : "";
const numberOrNull = (value: unknown): number | null => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

export const createGigaRuntimeScope = (
  input: GigaRuntimeScopeInput & { fallbackProcessId: string },
): GigaRuntimeScope => {
  const scope: GigaRuntimeScope = {
    processId: clean(input.processId) || input.fallbackProcessId,
    parentScopeId: clean(input.parentScopeId) || null,
    scopeType: clean(input.scopeType) || "WORKFLOW",
    userId: clean(input.userId) || null,
  };
  const pid = numberOrNull(input.pid);
  const cpuPercent = numberOrNull(input.cpuPercent);
  const ramMb = numberOrNull(input.ramMb);
  const iteration = numberOrNull(input.iteration);
  if (pid !== null) scope.pid = pid;
  if (cpuPercent !== null) scope.cpuPercent = cpuPercent;
  if (ramMb !== null) scope.ramMb = ramMb;
  if (iteration !== null) scope.iteration = iteration;
  return scope;
};

export const attachGigaRuntimeScopeMetadata = <
  TMetadata extends Record<string, unknown> | null | undefined,
>(
  metadata: TMetadata,
  runtimeScope: GigaRuntimeScopeInput,
) => ({
  ...(metadata && typeof metadata === "object" ? metadata : {}),
  runtimeScope,
});
