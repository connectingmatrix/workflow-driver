/** @vitest-environment jsdom */
import { act, renderHook } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { useUserNodeDesignerController } from '@workflow/ui/workflow/components/user-node-designer/useUserNodeDesignerController';
import type { WorkflowUiDriver } from '@workflow/ui/workflow/driver';

const mocks = vi.hoisted(() => ({
    executeNodeStep: vi.fn()
}));

vi.mock('@workflow/ui/workflow/executor/runtime', () => ({
    workflowExecutor: {
        executeNodeStep: mocks.executeNodeStep
    }
}));

vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn()
}));

const createDriverStub = (): WorkflowUiDriver => {
    let requestId = 0;
    return {
        createRequestId: () => {
            requestId += 1;
            return `req_${requestId}`;
        },
        getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
        createRealtimeClient: () => ({
            connect: vi.fn(),
            disconnect: vi.fn(),
            startPreview: vi.fn(async () => undefined),
            cancelPreview: vi.fn(),
            addPreviewLogHandler: vi.fn(() => () => undefined),
            addPreviewStateHandler: vi.fn(() => () => undefined),
            addPreviewResultHandler: vi.fn(() => () => undefined),
            addPreviewErrorHandler: vi.fn(() => () => undefined),
            addPreviewStopHandler: vi.fn(() => () => undefined)
        }),
        buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
        fetchCredentials: vi.fn(async () => []),
        fetchCredentialById: vi.fn(async () => null),
        openCredentialManager: vi.fn(),
        fetchExecutableWorkflows: vi.fn(async () => []),
        executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: { metadata: { id: 'wf_1', name: 'Preview' }, nodes: [], connections: [] }, logs: [] })),
        requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
        listWorkflowUserNodes: vi.fn(async () => []),
        createWorkflowUserNode: vi.fn(async (input) => ({
            id: 'user_node_1',
            userId: 'user_1',
            name: input.name,
            slug: input.slug ?? 'user-node-1',
            description: input.description ?? null,
            groupName: input.groupName ?? 'User Nodes',
            nodeSchema: input.nodeSchema ?? {},
            sourceFiles: input.sourceFiles,
            isActive: true,
            createdAt: '2026-03-28T00:00:00.000Z',
            updatedAt: '2026-03-28T00:00:00.000Z',
            modelId: 'user-node:user_node_1'
        })),
        updateWorkflowUserNode: vi.fn(async ({ id, input }) => ({
            id,
            userId: 'user_1',
            name: input.name ?? 'Updated Node',
            slug: input.slug ?? 'updated-node',
            description: input.description ?? null,
            groupName: input.groupName ?? 'User Nodes',
            nodeSchema: input.nodeSchema ?? {},
            sourceFiles: input.sourceFiles ?? { 'worker.ts': '', 'validate.ts': '' },
            isActive: true,
            createdAt: '2026-03-28T00:00:00.000Z',
            updatedAt: '2026-03-28T00:00:00.000Z',
            modelId: `user-node:${id}`
        })),
        deleteWorkflowUserNode: vi.fn(async () => true)
    };
};

describe('useUserNodeDesignerController preview input guards', () => {
    it('blocks run on invalid sample JSON and stores diagnostics', async () => {
        mocks.executeNodeStep.mockReset();
        const driver = createDriverStub();
        const { result } = renderHook(() =>
            useUserNodeDesignerController({
                driver,
                visible: false
            })
        );

        act(() => {
            result.current.actions.setSampleInputJson('{"broken":');
        });
        await act(async () => {
            await result.current.actions.runPreview();
        });

        expect(mocks.executeNodeStep).not.toHaveBeenCalled();
        expect(result.current.preview.state.diagnostics.some((entry) => entry.includes('Sample input JSON is invalid'))).toBe(true);
    });

    it('uses upstream input context when upstream mode is selected', async () => {
        mocks.executeNodeStep.mockReset();
        mocks.executeNodeStep.mockResolvedValue({
            workflow: { metadata: { id: 'wf_1', name: 'Preview' }, nodes: [], connections: [] },
            node: { id: 'node_preview_1', status: 'passed', runtime: {}, ports: { in: {}, out: {} } },
            result: { output: { ok: true }, status: 'passed', logs: [] },
            events: []
        });
        const upstreamInput = { current: { output: { value: 42 } } };
        const driver = createDriverStub();
        const { result } = renderHook(() =>
            useUserNodeDesignerController({
                driver,
                visible: false,
                upstreamInputContext: upstreamInput
            })
        );

        act(() => {
            result.current.actions.setInputMode('upstream');
        });
        await act(async () => {
            await result.current.actions.runPreview();
        });

        expect(mocks.executeNodeStep).toHaveBeenCalledTimes(1);
        expect(mocks.executeNodeStep.mock.calls[0]?.[0]?.overrides?.previewInput).toEqual(upstreamInput);
    });

    it('auto-switches preview to node runtime when worker.ts imports Node builtins', async () => {
        mocks.executeNodeStep.mockReset();
        const startPreview = vi.fn(async () => undefined);
        const driver = createDriverStub();
        const realtimeClient = {
            connect: vi.fn(),
            disconnect: vi.fn(),
            startPreview,
            cancelPreview: vi.fn(),
            addPreviewLogHandler: vi.fn(() => () => undefined),
            addPreviewStateHandler: vi.fn(() => () => undefined),
            addPreviewResultHandler: vi.fn(() => () => undefined),
            addPreviewErrorHandler: vi.fn(() => () => undefined),
            addPreviewStopHandler: vi.fn(() => () => undefined)
        };
        vi.spyOn(driver, 'createRealtimeClient').mockReturnValue(realtimeClient as any);

        const { result } = renderHook(() =>
            useUserNodeDesignerController({
                driver,
                visible: false
            })
        );

        act(() => {
            result.current.actions.setWorkerTs("import fs from 'fs';\\nexport const validate = async () => ({ ok: true, errors: [], warnings: [] });\\nexport const init = async () => true;\\nexport const onUpdate = async () => ({ ok: true });\\nexport const execute = async () => ({ output: { ok: fs.readdirSync('.') }, status: 'passed', logs: [] });");
        });
        await act(async () => {
            await result.current.actions.runPreview();
        });

        expect(mocks.executeNodeStep).not.toHaveBeenCalled();
        expect(startPreview).toHaveBeenCalledTimes(1);
        expect(startPreview.mock.calls[0]?.[0]?.overrides?.previewRuntime).toBe('node');
        expect(result.current.state.browserRuntimeAllowed).toBe(false);
        expect(result.current.state.runtimeFallbackReason).toContain('Auto switched to Node runtime');
    });

    it('serializes schema draft changes into save payloads', async () => {
        const driver = createDriverStub();
        const createWorkflowUserNode = vi.spyOn(driver, 'createWorkflowUserNode');
        const { result } = renderHook(() =>
            useUserNodeDesignerController({
                driver,
                visible: false
            })
        );

        act(() => {
            result.current.actions.setSchemaDraft({
                ...result.current.state.schemaDraft,
                iconMode: 'svg',
                iconClass: 'pi pi-bolt',
                iconColor: '#0f766e',
                iconSvg: '<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="4"/></svg>',
                useCredentials: 'openai',
                ports: [
                    {
                        id: 'command_llm',
                        kind: 'command',
                        key: 'llm',
                        label: 'LLM',
                        side: 'bottom',
                        order: 1,
                        allowMultipleArrows: true,
                        portType: 'bi-directional',
                        acceptedSourceGroups: 'AI Models',
                        acceptedSourceModelIds: 'openai',
                        showQuickAdd: false
                    }
                ]
            });
        });

        await act(async () => {
            await result.current.actions.saveNode();
        });

        expect(createWorkflowUserNode).toHaveBeenCalledWith(
            expect.objectContaining({
                nodeSchema: expect.objectContaining({
                    iconClass: 'pi pi-bolt',
                    iconColor: '#0f766e',
                    iconMode: 'svg',
                    iconSvg: expect.stringContaining('<svg'),
                    useCredentials: 'openai',
                    commands: expect.objectContaining({
                        llm: expect.objectContaining({
                            portType: 'bi-directional',
                            acceptedSourceGroups: ['AI Models'],
                            acceptedSourceModelIds: ['openai']
                        })
                    })
                })
            })
        );
    });
});
