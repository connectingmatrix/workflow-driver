declare module '*?raw' {
    const content: string;
    export default content;
}

declare module '*.txt?raw' {
    const content: string;
    export default content;
}

declare module '*.md?raw' {
    const content: string;
    export default content;
}

declare global {
    interface ImportMeta {
        glob<T = unknown>(
            pattern: string,
            options?: {
                as?: string;
                eager?: boolean;
                import?: string;
                query?: string | Record<string, string | number | boolean>;
            }
        ): Record<string, T>;
    }
}

export {};
