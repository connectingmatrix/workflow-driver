import type { Connection } from '@xyflow/react';
import { WorkflowDefinition, WorkflowNodeSchema } from '@workflow/ui/workflow/types';
import { canAttachConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';

const hasValue = (value: unknown): boolean => {
    if (value === null || typeof value === 'undefined') return false;
    if (typeof value === 'string') return value.trim().length > 0;
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === 'object') return Object.keys(value as Record<string, unknown>).length > 0;
    return true;
};

export const buildWorkflowGraphHealth = (workflow: WorkflowDefinition): string[] => {
    const warnings: string[] = [];
    workflow.nodes.forEach((node) => {
        const schema = (workflow.nodeModels || {})[node.modelId] as WorkflowNodeSchema | undefined;
        Object.entries((schema && schema.fields) || {}).forEach(([fieldKey, field]) => {
            if (field.required && !hasValue((node.runtime || {})[fieldKey])) {
                warnings.push(`${node.name} is missing required field "${fieldKey}".`);
            }
        });
        const value = String((node.runtime || {}).value || '');
        if (/lets see what it/i.test(value)) warnings.push(`${node.name} still contains demo output text.`);
    });
    workflow.connections.forEach((edge) => {
        const workflowWithoutCurrent = { ...workflow, connections: workflow.connections.filter((item) => item.id !== edge.id) };
        const ok = canAttachConnection(workflowWithoutCurrent, {
            source: edge.from,
            target: edge.to,
            sourceHandle: edge.sourceHandle,
            targetHandle: edge.targetHandle
        } as Connection);
        if (!ok) {
            const sourceNode = workflow.nodes.find((node) => node.id === edge.from);
            const targetNode = workflow.nodes.find((node) => node.id === edge.to);
            const sourceLabel = sourceNode?.name || edge.from;
            const targetLabel = targetNode?.name || edge.to;
            warnings.push(`Invalid connection "${sourceLabel}" -> "${targetLabel}" (${edge.sourceHandle || 'out:output'} -> ${edge.targetHandle || 'in:input'}).`);
        }
    });
    return warnings;
};
