import { beforeEach, describe, expect, it, vi } from 'vitest';
import { getNodeModule } from '@workflow/nodes/node-utils';
import { WorkflowAuthModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

const { evaluateJavascriptInIframeMock } = vi.hoisted(() => ({
    evaluateJavascriptInIframeMock: vi.fn()
}));

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', () => ({
    evaluateJavascriptInIframe: evaluateJavascriptInIframeMock
}));

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: WorkflowAuthModeEnum.None,
    manualHeaders: {}
};

describe('flow-control node behavior', () => {
    beforeEach(() => {
        evaluateJavascriptInIframeMock.mockReset();
    });

    it('loop-over-items activates loop when resolved collection is non-empty', async () => {
        const workflow = createEmptyWorkflow('wf_loop_non_empty');
        const node = createWorkflowNode(workflow, 'loop-over-items', 'Loop', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            sourceValue: { input: { items: ['a', 'b', 'c'] } },
            loopItems: 'input.items'
        };

        const result = await getNodeModule('loop-over-items').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.source).toBe('input.items');
        expect(output.itemCount).toBe(3);
        expect(output.selectedBranch).toBe('loop');
        expect(output.__activeOutputs).toEqual(['loop']);
    });

    it('loop-over-items activates done when resolved collection is empty', async () => {
        const workflow = createEmptyWorkflow('wf_loop_empty');
        const node = createWorkflowNode(workflow, 'loop-over-items', 'Loop', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            sourceValue: { input: { items: [] } },
            loopItems: 'input.items'
        };

        const result = await getNodeModule('loop-over-items').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.source).toBe('input.items');
        expect(output.itemCount).toBe(0);
        expect(output.selectedBranch).toBe('done');
        expect(output.__activeOutputs).toEqual(['done']);
    });

    it('replace-me replaces nested string values globally and keeps keys unchanged', async () => {
        const workflow = createEmptyWorkflow('wf_replace_nested');
        const node = createWorkflowNode(workflow, 'replace-me', 'Replace', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            sourceValue: {
                title: 'foo foo',
                nested: {
                    fooKey: 'foo',
                    items: [{ note: 'foo-note' }]
                }
            },
            findValue: 'foo',
            replaceWith: 'bar'
        };

        const result = await getNodeModule('replace-me').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.title).toBe('bar bar');
        expect((output.nested as Record<string, any>).fooKey).toBe('bar');
        expect((output.nested as Record<string, any>).items[0].note).toBe('bar-note');
        expect(Object.keys(output.nested as Record<string, unknown>)).toContain('fooKey');
        expect(output.__activeOutputs).toEqual(['output']);
    });

    it('replace-me performs no-op when findValue is empty', async () => {
        const workflow = createEmptyWorkflow('wf_replace_noop');
        const node = createWorkflowNode(workflow, 'replace-me', 'Replace', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            sourceValue: { title: 'foo' },
            findValue: '',
            replaceWith: 'bar'
        };

        const result = await getNodeModule('replace-me').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.title).toBe('foo');
        expect(output.__activeOutputs).toEqual(['output']);
    });

    it('if-else selects true when the configured condition passes', async () => {
        const workflow = createEmptyWorkflow('wf_if_else_valid_branch');
        const node = createWorkflowNode(workflow, 'if-else', 'If Else', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            value: { flag: true },
            leftPath: 'flag',
            operator: 'truthy'
        };

        const result = await getNodeModule('if-else').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.selectedBranch).toBe('true');
        expect(output.__activeOutputs).toEqual(['true']);
    });

    it('if-else selects false when the configured condition fails', async () => {
        const workflow = createEmptyWorkflow('wf_if_else_no_branch');
        const node = createWorkflowNode(workflow, 'if-else', 'If Else', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            value: { flag: false },
            leftPath: 'flag',
            operator: 'truthy'
        };

        const result = await getNodeModule('if-else').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        const output = result.output as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.selectedBranch).toBe('false');
        expect(output.__activeOutputs).toEqual(['false']);
    });

    it('if-else fails when value is missing', async () => {
        const workflow = createEmptyWorkflow('wf_if_else_both_branches');
        const node = createWorkflowNode(workflow, 'if-else', 'If Else', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            value: '',
            leftPath: 'flag',
            operator: 'truthy'
        };

        const result = await getNodeModule('if-else').execute({
            node,
            workflow,
            settings,
            input: {} as any
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>)?.error ?? '')).toContain('Value is required');
    });
});
