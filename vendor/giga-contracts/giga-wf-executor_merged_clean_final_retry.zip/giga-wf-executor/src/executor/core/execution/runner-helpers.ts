import { ExecuteNodeStepOptions, ExecuteWorkflowOptions, WorkflowDefinition, WorkflowNodeModel, WorkflowNodeStatusEnum, WorkflowRunLogEvent } from '../../../types';
import { WorkflowEventSink } from '../graph/log';
import { getCommandPeerNodeIds, getNodeSchema, getNormalizedCommandPorts, isCommandConnection, parseInputPortName, parseOutputPortName } from '../graph/command-ports';

export const toRunnerRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
export const toPortsOut = (node: WorkflowNodeModel): Record<string, unknown> => (node.ports?.out && typeof node.ports.out === 'object' ? node.ports.out : {});
export const toPortsIn = (node: WorkflowNodeModel): Record<string, Record<string, unknown>> => (node.ports?.in && typeof node.ports.in === 'object' ? node.ports.in : {});
export const isNodeEnabled = (node: WorkflowNodeModel): boolean => (typeof node.runtime?.enabled === 'boolean' ? node.runtime.enabled : true);

export const toRuntimeError = (node: WorkflowNodeModel): string | null => {
    const runtime = node.runtime;
    if (!runtime || typeof runtime !== 'object' || Array.isArray(runtime)) return null;
    const candidate = (runtime as Record<string, unknown>).error;
    return typeof candidate === 'string' && candidate.trim().length > 0 ? candidate.trim() : null;
};

export const normalizeNodeStatus = (node: WorkflowNodeModel, status: string): WorkflowNodeModel => {
    if (node.status === status && node.runtime?.status === status) return node;
    return { ...node, status: status as WorkflowNodeStatusEnum, runtime: { ...(node.runtime ?? {}), status } };
};

const getCommandOutputPortIds = (workflow: WorkflowDefinition, node: WorkflowNodeModel): string[] => Object.keys(getNormalizedCommandPorts(getNodeSchema(workflow, node.id)));

export const publishBiControlState = (workflow: WorkflowDefinition, node: WorkflowNodeModel): WorkflowNodeModel => {
    const commandPortIds = getCommandOutputPortIds(workflow, node);
    if (commandPortIds.length === 0) return node;
    const nextPortsOut = toRunnerRecord(node.ports?.out);
    const controlState = { nodeId: node.id, nodeName: node.name, modelId: node.modelId, status: node.status, runtime: toRunnerRecord(node.runtime), output: nextPortsOut.output ?? null };
    commandPortIds.forEach((portId) => {
        const existingPortValue = toRunnerRecord(nextPortsOut[portId]);
        nextPortsOut[portId] = { ...existingPortValue, STATE: controlState };
    });
    return { ...node, ports: { in: toPortsIn(node), out: nextPortsOut } };
};

export const getBiPeerNodeIds = (workflow: WorkflowDefinition, nodeId: string): string[] => getCommandPeerNodeIds(workflow, nodeId);

export const createEventCollector = (
    options: Pick<ExecuteWorkflowOptions | ExecuteNodeStepOptions, 'onEvent'>
): { events: WorkflowRunLogEvent[]; sink: WorkflowEventSink } => {
    const events: WorkflowRunLogEvent[] = [];
    const sink: WorkflowEventSink = (event) => {
        const withTimestamp: WorkflowRunLogEvent = { ...event, timestamp: new Date().toISOString() };
        events.push(withTimestamp);
        options.onEvent?.(withTimestamp);
    };
    return { events, sink };
};
