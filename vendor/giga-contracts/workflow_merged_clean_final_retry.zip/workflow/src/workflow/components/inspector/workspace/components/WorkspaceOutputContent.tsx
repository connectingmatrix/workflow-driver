import React from 'react';
import MarkdownViewer from '@workflow/ui/workflow/components/viewers/MarkdownViewer';
import TableViewer from '@workflow/ui/workflow/components/viewers/TableViewer';
import JsonViewer from '@workflow/ui/workflow/components/viewers/JsonViewer';
import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';
import { buildWorkspaceOutputEditorValue } from '@workflow/ui/workflow/components/inspector/workspace/utils/workspace-output.utils';
import type { WorkspaceOutputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface WorkspaceOutputContentProps {
    model: WorkspaceOutputPanelModel;
}

export const WorkspaceOutputContent: React.FC<WorkspaceOutputContentProps> = ({ model }) => {
    const activeViewer = model.activeViewer;
    if (!activeViewer) {
        return <div className="cnw-output-empty">No output available yet.</div>;
    }

    if (activeViewer.type === WorkflowViewerTypeEnum.Markdown) {
        return (
            <div className="cnw-output-viewer-shell cnw-output-viewer-shell--light">
                <MarkdownViewer content={String(activeViewer.value ?? '')} />
            </div>
        );
    }

    if (activeViewer.type === WorkflowViewerTypeEnum.Table) {
        return (
            <div className="cnw-output-viewer-shell cnw-output-viewer-shell--light">
                <TableViewer value={activeViewer.value} />
            </div>
        );
    }

    if (activeViewer.type === WorkflowViewerTypeEnum.Json || activeViewer.type === WorkflowViewerTypeEnum.Raw) {
        const content = buildWorkspaceOutputEditorValue(activeViewer);
        return (
            <div className="cnw-editor-card">
                <div className="cnw-editor-card__toolbar">
                    <div className="cnw-editor-card__traffic-lights">
                        <span className="cnw-editor-card__traffic-light is-red" />
                        <span className="cnw-editor-card__traffic-light is-amber" />
                        <span className="cnw-editor-card__traffic-light is-green" />
                    </div>
                    <div className="cnw-editor-card__copy-chip">{activeViewer.label.toUpperCase()}</div>
                </div>
                <div className="cnw-editor-card__body">
                    <pre className="cnw-editor-card__content" aria-label={`${activeViewer.label} output`}>
                        <code>{content}</code>
                    </pre>
                </div>
            </div>
        );
    }

    return (
        <div className="cnw-output-viewer-shell cnw-output-viewer-shell--light">
            <JsonViewer value={activeViewer.value} rootPath="output" />
        </div>
    );
};
