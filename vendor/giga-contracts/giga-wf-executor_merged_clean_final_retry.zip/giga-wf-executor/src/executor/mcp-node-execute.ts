import type { WorkflowMcpRuntimeManager } from './mcp-runtime.types';
import type { WorkflowResolvedCredential } from '../types';
import { normalizeWorkflowMcpRuntime, resolveWorkflowMcpServer, resolveWorkflowMcpToolCall } from './mcp-node-runtime';

const buildRoutingState = (runtime: ReturnType<typeof normalizeWorkflowMcpRuntime>, payload: Record<string, unknown>): Record<string, unknown> => {
    const loopPass = Math.max(0, Math.round(Number(payload.__loopPass ?? 0) || 0));
    const shouldLoop = runtime.loopNonMcpWork && loopPass < runtime.maxLoopPasses;
    const forwardedPayload = runtime.forwardNonMcpWork
        ? {
              ...payload,
              __loopPass: loopPass + 1,
              __loopBudgetRemaining: Math.max(runtime.maxLoopPasses - (loopPass + 1), 0)
          }
        : {};
    return {
        shouldLoop,
        forwardedPayload,
        nonMcpRouting: {
            hasToolCall: false,
            loopEnabled: runtime.loopNonMcpWork,
            forwarded: runtime.forwardNonMcpWork,
            maxLoopPasses: runtime.maxLoopPasses,
            currentLoopPass: loopPass,
            hasLoopBudget: loopPass < runtime.maxLoopPasses
        }
    };
};

export const executeWorkflowMcpCapabilitiesNode = async (params: {
    runtime: unknown;
    input?: unknown;
    manager: WorkflowMcpRuntimeManager;
    credential?: WorkflowResolvedCredential | null;
}) => {
    const runtime = normalizeWorkflowMcpRuntime(params.runtime);
    const listed = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential ?? null) });
    return {
        output: {
            capabilityQuery: runtime.capabilityQuery,
            tools: listed.tools,
            capabilities: listed.capabilities,
            serverInfo: listed.serverInfo,
            protocolVersion: listed.protocolVersion,
            __activeOutputs: ['output']
        },
        status: 'passed' as const,
        logs: ['MCP capabilities resolved.']
    };
};

export const executeWorkflowMcpRuntimeNode = async (params: {
    runtime: unknown;
    input?: unknown;
    manager: WorkflowMcpRuntimeManager;
    credential?: WorkflowResolvedCredential | null;
}) => {
    const runtime = normalizeWorkflowMcpRuntime(params.runtime);
    const resolved = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential ?? null) });
    const toolCall = resolveWorkflowMcpToolCall(params.input);
    if (toolCall.error) {
        return {
            output: {
                error: toolCall.error,
                __activeOutputs: ['output']
            },
            status: 'failed' as const,
            logs: [toolCall.error]
        };
    }
    if (!toolCall.toolName) {
        const routingState = buildRoutingState(runtime, toolCall.payload);
        return {
            output: {
                capabilityQuery: runtime.capabilityQuery,
                outputContract: runtime.outputContract,
                toolCall: null,
                toolResult: null,
                tools: resolved.tools,
                serverInfo: resolved.serverInfo,
                protocolVersion: resolved.protocolVersion,
                forwardedPayload: routingState.forwardedPayload,
                nonMcpRouting: routingState.nonMcpRouting,
                __activeOutputs: [routingState.shouldLoop ? 'loop' : 'output']
            },
            status: 'passed' as const,
            logs: [routingState.shouldLoop ? 'Loop route selected because no MCP tool call was provided.' : 'No MCP tool call was provided.']
        };
    }
    const called = await params.manager.callTool({
        server: resolved.server,
        toolName: toolCall.toolName,
        toolArguments: toolCall.toolArguments
    });
    return {
        output: {
            capabilityQuery: runtime.capabilityQuery,
            outputContract: runtime.outputContract,
            toolCall: called.toolCall,
            toolResult: called.toolResult,
            tools: called.tools,
            serverInfo: called.serverInfo,
            protocolVersion: called.protocolVersion,
            __activeOutputs: ['output']
        },
        status: 'passed' as const,
        logs: [`MCP tool "${called.toolCall.name}" executed.`]
    };
};
