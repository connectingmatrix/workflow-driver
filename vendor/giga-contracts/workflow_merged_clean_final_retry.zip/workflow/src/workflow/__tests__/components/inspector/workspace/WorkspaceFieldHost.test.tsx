// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { WorkspaceFieldHost } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceFieldHost';
import { WorkspaceFileListField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceFileListField';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import type { WorkspaceFieldModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

const buildField = (overrides: Partial<WorkspaceFieldModel> = {}): WorkspaceFieldModel => ({
    id: 'time',
    key: 'time',
    value: 30,
    definition: {
        type: WorkflowNodeFieldTypeEnum.Number,
        editable: true,
        dependsOn: {
            field: 'unit',
            entityField: true,
            fallback: { min: 0, max: 300, step: 1 },
            map: {
                milliseconds: { min: 0, max: 300000, step: 1 },
                seconds: { min: 0, max: 300, step: 1 },
                minutes: { min: 0, max: 5, step: 1 }
            }
        }
    },
    ...overrides
});

afterEach(() => {
    cleanup();
});

describe('WorkspaceFieldHost', () => {
    it('renders dependent fields together for wait-style controls', () => {
        render(
            <WorkspaceFieldHost
                field={buildField()}
                propertiesEditorState={{ time: 30, unit: 'seconds' }}
                onChange={vi.fn()}
                dependingField={{
                    fieldKey: 'unit',
                    definition: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        label: 'Unit',
                        editable: true,
                        options: [{ label: 'Seconds', value: 'seconds' }]
                    },
                    value: 'seconds'
                }}
            />
        );

        expect(screen.getByText('Unit')).toBeInTheDocument();
        expect(screen.getByRole('spinbutton')).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Select an option' })).toBeInTheDocument();
        expect(screen.getAllByText('Seconds').length).toBeGreaterThan(0);
    });

    it('disables field editing in read-only mode', () => {
        render(
            <WorkspaceFieldHost
                field={buildField({
                    id: 'name',
                    key: 'name',
                    value: 'Replay',
                    definition: {
                        type: WorkflowNodeFieldTypeEnum.String,
                        editable: true
                    }
                })}
                readOnly
                propertiesEditorState={{ name: 'Replay' }}
                onChange={vi.fn()}
            />
        );

        expect(screen.getByRole('textbox')).toBeDisabled();
    });

    it('moves the variable toggle into the field label row for select fields', () => {
        render(
            <WorkspaceFieldHost
                field={buildField({
                    id: 'mode',
                    key: 'mode',
                    value: 'one',
                    definition: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        editable: true,
                        options: [{ label: 'One', value: 'one' }]
                    }
                })}
                propertiesEditorState={{ mode: 'one' }}
                onChange={vi.fn()}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Enable variable mode' }));

        expect(screen.getByRole('textbox')).toBeInTheDocument();
        expect(screen.queryByRole('button', { name: 'Select an option' })).not.toBeInTheDocument();
    });

    it('shows the variable toggle for execution companion fields', () => {
        render(
            <WorkspaceFieldHost
                field={buildField({
                    id: 'failureMitigation',
                    key: 'failureMitigation',
                    value: 'retry-node',
                    definition: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        editable: true,
                        options: [
                            { label: 'Retry node', value: 'retry-node' },
                            { label: 'Stop workflow', value: 'stop-workflow' }
                        ]
                    }
                })}
                propertiesEditorState={{ failureMitigation: 'retry-node' }}
                onChange={vi.fn()}
                companionField={{
                    fieldKey: 'retryCount',
                    definition: {
                        type: WorkflowNodeFieldTypeEnum.Select,
                        editable: true,
                        options: [
                            { label: '1', value: '1' },
                            { label: '2', value: '2' },
                            { label: '3', value: '3' }
                        ]
                    },
                    value: '2',
                    visible: true
                }}
            />
        );

        expect(screen.getByRole('button', { name: 'Enable retryCount variable mode' })).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Enable retryCount variable mode' }));
        expect(screen.getAllByRole('textbox').length).toBeGreaterThan(0);
    });
});

describe('WorkspaceFileListField', () => {
    it('parses uploaded files and forwards the file envelopes', async () => {
        const onChange = vi.fn();
        const file = new File(['hello world'], 'sample.csv', { type: 'text/csv' });

        const { container } = render(<WorkspaceFileListField fieldKey="files" value={[]} editable accept=".csv" onChange={onChange} />);
        const input = container.querySelector('input[type="file"]');
        if (!input) {
            throw new Error('Expected file input to be rendered.');
        }

        fireEvent.change(input, { target: { files: [file] } });

        await waitFor(() => {
            expect(onChange).toHaveBeenCalledTimes(1);
        });

        expect(onChange.mock.calls[0]?.[0]).toBe('files');
        expect(onChange.mock.calls[0]?.[1]).toEqual([
            expect.objectContaining({
                name: 'sample.csv',
                mimeType: 'text/csv'
            })
        ]);
    });
});
