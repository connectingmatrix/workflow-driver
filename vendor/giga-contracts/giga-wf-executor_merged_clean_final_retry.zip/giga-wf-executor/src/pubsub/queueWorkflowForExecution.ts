import { CompressionTypes, type Producer } from "kafkajs";
import { readWorkflowQueueRedpandaConfig } from "../queue";
import { toWorkflowQueueRequestMessage } from "../queue/workflowQueueMessage";
import { createWorkflowExecutionPubsubClient } from "./createWorkflowExecutionPubsubClient";
import type {
  WorkflowQueueRedpandaConfig,
  WorkflowQueueRequestProducer,
} from "../queue/types";

export const queueWorkflowForExecution = (
  config?: WorkflowQueueRedpandaConfig,
): WorkflowQueueRequestProducer => {
  const resolvedConfig = config || readWorkflowQueueRedpandaConfig(process.env);
  const producer: Producer =
    createWorkflowExecutionPubsubClient(resolvedConfig).producer();
  return {
    connect: async () => producer.connect(),
    disconnect: async () => producer.disconnect(),
    publish: async (executionRequest) => {
      await producer.send({
        compression: CompressionTypes.GZIP,
        topic: resolvedConfig.requestTopic,
        messages: [toWorkflowQueueRequestMessage(executionRequest)],
      });
    },
  };
};
