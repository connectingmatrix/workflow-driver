import React from 'react';
import { Dialog } from 'primereact/dialog';
import type { JsonlLogsDialogProps, WorkflowLogsFilter } from '@workflow/ui/workflow/components/logs/logs-dialog.types';
import { WorkflowLogsHeader } from '@workflow/ui/workflow/components/logs/workspace/WorkflowLogsHeader';
import { WorkflowLogsFilters } from '@workflow/ui/workflow/components/logs/workspace/WorkflowLogsFilters';
import { WorkflowLogsViewer } from '@workflow/ui/workflow/components/logs/workspace/WorkflowLogsViewer';
import { WorkflowLogsSummary } from '@workflow/ui/workflow/components/logs/workspace/WorkflowLogsSummary';
import {
    buildWorkflowLogsRecords,
    copyWorkflowLogs,
    downloadWorkflowLogs,
    filterWorkflowLogsRecords,
    formatWorkflowLogsBytes,
    getWorkflowLogsCounts,
    getWorkflowLogsDurationSeconds,
    getWorkflowLogsOutputContract,
    getWorkflowLogsRunId
} from '@workflow/ui/workflow/components/logs/workspace/workflow-logs.utils';
import '@workflow/ui/workflow/components/logs/workspace/wf-workspace-logs.scss';

const WorkflowLogsDialog: React.FC<JsonlLogsDialogProps> = ({ visible, onHide, jsonl, header = 'Workflow logs', fileNamePrefix = 'workflow-logs', events }) => {
    const [search, setSearch] = React.useState('');
    const [filter, setFilter] = React.useState<WorkflowLogsFilter>('all');
    const [prettyPrint, setPrettyPrint] = React.useState(false);

    const records = React.useMemo(() => buildWorkflowLogsRecords(jsonl, events, prettyPrint), [events, jsonl, prettyPrint]);
    const filteredRecords = React.useMemo(() => filterWorkflowLogsRecords(records, filter, search), [records, filter, search]);
    const counts = React.useMemo(() => getWorkflowLogsCounts(records), [records]);
    const byteLabel = React.useMemo(() => formatWorkflowLogsBytes(new Blob([jsonl]).size), [jsonl]);
    const runId = React.useMemo(() => getWorkflowLogsRunId(records), [records]);
    const durationLabel = React.useMemo(() => getWorkflowLogsDurationSeconds(records), [records]);
    const outputContract = React.useMemo(() => getWorkflowLogsOutputContract(records), [records]);

    React.useEffect(() => {
        if (!visible) {
            setSearch('');
            setFilter('all');
            setPrettyPrint(false);
        }
    }, [visible]);

    return (
        <Dialog visible={visible} onHide={onHide} showHeader={false} className="wf-workspace-logs-dialog" contentClassName="wf-workspace-logs-dialog__content" modal dismissableMask style={{ width: 'min(96vw, 1880px)', height: 'min(92vh, 980px)' }}>
            <div className="wf-workspace-logs">
                <WorkflowLogsHeader title={header} subtitle="Structured JSONL output for the latest workflow execution." runId={runId} eventCount={counts.total} byteLabel={byteLabel} warningCount={counts.warn} onDownload={() => downloadWorkflowLogs(jsonl, fileNamePrefix)} onCopy={() => void copyWorkflowLogs(jsonl)} onClose={onHide} />
                <div className="wf-workspace-logs__body">
                    <div className="wf-workspace-logs__main">
                        <WorkflowLogsFilters search={search} filter={filter} prettyPrint={prettyPrint} onSearchChange={setSearch} onFilterChange={setFilter} onPrettyPrintChange={setPrettyPrint} />
                        <WorkflowLogsViewer records={filteredRecords} />
                    </div>
                    <WorkflowLogsSummary completed={counts.error === 0} durationLabel={durationLabel} warningLabel={counts.warn > 0 ? `${counts.warn} warning${counts.warn === 1 ? '' : 's'}` : 'None'} outputContract={outputContract} />
                </div>
                <footer className="wf-workspace-logs__footer">Latest stream captured from the active workflow run. Filters and search update the viewer instantly.</footer>
            </div>
        </Dialog>
    );
};

export default WorkflowLogsDialog;
