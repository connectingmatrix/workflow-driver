// @vitest-environment jsdom
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import JsonViewer from '@workflow/ui/workflow/components/viewers/JsonViewer';

afterEach(() => {
    cleanup();
});

describe('JsonViewer', () => {
    it('drags variable token payloads instead of raw values', () => {
        render(<JsonViewer value={{ node_1: { title: 'Hello' } }} draggableKeys />);

        const keyElement = screen.getByText('title');
        const dataTransfer = {
            setData: vi.fn(),
            effectAllowed: ''
        } as unknown as DataTransfer;

        fireEvent.dragStart(keyElement, { dataTransfer });

        expect(dataTransfer.setData).toHaveBeenCalledWith('application/x-workflow-variable-path', 'node_1.title');
        expect(dataTransfer.setData).toHaveBeenCalledWith('text/plain', '{{node_1.title}}');
    });

    it('shows current value preview on hover title for draggable keys', () => {
        render(<JsonViewer value={{ node_1: { title: 'Hello' } }} draggableKeys />);
        const keyElement = screen.getByText('title');
        expect(keyElement.getAttribute('title')).toBe('Current value: Hello');
    });

    it('renders circular objects without recursing forever', () => {
        const value: Record<string, unknown> = { label: 'Root' };
        value.self = value;

        render(<JsonViewer value={{ node_1: value }} />);

        expect(screen.getByText('[Circular]')).toBeTruthy();
    });
});
