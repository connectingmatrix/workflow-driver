import { describe, expect, it } from 'vitest';
import { compileWorkflowCypher } from '../workflow-ai-creation';

describe('compileWorkflowCypher runtime bindings', () => {
  it('rewrites Cypher aliases in runtime variable bindings and keeps built-ins', () => {
    const compiled = compileWorkflowCypher({
      executable: true,
      cypher: [
        '(start:start {"name":"Start","runtime":{}})',
        '(code:code {"name":"Build Output","runtime":{"code":"return { text: \\"hello\\" };"}})',
        '(end:respond-end {"name":"Respond End","runtime":{"response":"{{code.text}} {{workflow.input.chatId}}"}})',
        '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(code)',
        '(code)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)'
      ].join('\n')
    });

    const end = compiled.workflow.nodes.find((node) => node.modelId === 'respond-end');
    expect(compiled.validation.ok).toBe(true);
    expect(end?.runtime.response).toBe('{{code-2.text}} {{workflow.input.chatId}}');
  });
});
