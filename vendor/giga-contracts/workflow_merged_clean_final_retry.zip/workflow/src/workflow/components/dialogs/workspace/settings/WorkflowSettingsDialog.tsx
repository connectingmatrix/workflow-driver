import React from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { WorkflowAuthModeEnum } from '@workflow/ui/workflow/types';
import type { SettingsDialogProps } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';
import { buildAuthOptions, buildEdgeStyleOptions, buildLayoutEngineOptions, buildTimeoutOptions, createHeaderRowId, createWorkflowSettingsFormState, deriveHttpBaseUrl, toManualHeadersRecord } from '@workflow/ui/workflow/components/dialogs/settings-dialog.utils';
import { WorkflowSettingsHeader } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsHeader';
import { WorkflowSettingsStatusBar } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsStatusBar';
import { WorkflowSettingsBasicsCard } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsBasicsCard';
import { WorkflowSettingsCanvasCard } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsCanvasCard';
import { WorkflowSettingsConnectivityCard } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsConnectivityCard';
import { WorkflowSettingsExecutionCard } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsExecutionCard';
import { WorkflowSettingsNotesCard } from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsNotesCard';
import '@workflow/ui/workflow/components/dialogs/workspace/settings/wf-workspace-settings.scss';

const authOptions = buildAuthOptions();
const edgeStyleOptions = buildEdgeStyleOptions();
const layoutEngineOptions = buildLayoutEngineOptions();
const timeoutOptions = buildTimeoutOptions();

const WorkflowSettingsDialog: React.FC<SettingsDialogProps> = ({ visible, readOnly = false, settings, canvasSettings, workflowName, workflowDescription, workflowId, onHide, onSave, onResetLayout }) => {
    const [formState, setFormState] = React.useState(() => createWorkflowSettingsFormState(settings, canvasSettings, workflowName, workflowDescription));

    React.useEffect(() => {
        setFormState(createWorkflowSettingsFormState(settings, canvasSettings, workflowName, workflowDescription));
    }, [canvasSettings, settings, workflowName, workflowDescription]);

    const updateState = (patch: Partial<typeof formState>) => setFormState((previous) => ({ ...previous, ...patch }));

    return (
        <Dialog visible={visible} onHide={onHide} showHeader={false} className="wf-workspace-settings-dialog" contentClassName="wf-workspace-settings-dialog__content" modal dismissableMask style={{ width: 'min(96vw, 1540px)', height: 'min(92vh, 1120px)' }}>
            <div className="wf-workspace-settings">
                <WorkflowSettingsHeader workflowId={workflowId} onClose={onHide} />
                <WorkflowSettingsStatusBar graphqlUrl={formState.graphqlUrl} authModeLabel={String(formState.authMode).replace(/-/g, ' ')} />
                <div className="wf-workspace-settings__grid">
                    <div className="wf-workspace-settings__grid-column wf-workspace-settings__grid-column--wide">
                        <WorkflowSettingsBasicsCard
                            readOnly={readOnly}
                            workflowName={formState.workflowNameInput}
                            workflowDescription={formState.workflowDescriptionInput}
                            onWorkflowNameChange={(value) => updateState({ workflowNameInput: value })}
                            onWorkflowDescriptionChange={(value) => updateState({ workflowDescriptionInput: value })}
                        />
                        <WorkflowSettingsConnectivityCard
                            readOnly={readOnly}
                            graphqlUrl={formState.graphqlUrl}
                            httpBaseUrl={formState.httpBaseUrl}
                            onGraphqlUrlChange={(value) => {
                                const nextDerivedBase = deriveHttpBaseUrl(value);
                                updateState({
                                    graphqlUrl: value,
                                    httpBaseUrl: formState.httpBaseUrl.trim() && formState.httpBaseUrl.trim() !== deriveHttpBaseUrl(formState.graphqlUrl) ? formState.httpBaseUrl : nextDerivedBase
                                });
                            }}
                            onHttpBaseUrlChange={(value) => updateState({ httpBaseUrl: value })}
                        />
                    </div>
                    <div className="wf-workspace-settings__grid-column">
                        <WorkflowSettingsExecutionCard
                            readOnly={readOnly}
                            authMode={String(formState.authMode)}
                            authModeIsManual={formState.authMode === WorkflowAuthModeEnum.Manual}
                            maxExecutionSeconds={Number(formState.maxExecutionSeconds)}
                            authOptions={authOptions}
                            timeoutOptions={timeoutOptions}
                            manualHeaderRows={formState.manualHeaderRows}
                            onAuthModeChange={(value) => updateState({ authMode: value })}
                            onMaxExecutionSecondsChange={(value) => updateState({ maxExecutionSeconds: value })}
                            onManualHeaderChange={(rowId, key, value) =>
                                updateState({
                                    manualHeaderRows: formState.manualHeaderRows.map((row) => (row.id === rowId ? { ...row, [key]: value } : row))
                                })
                            }
                            onAddManualHeader={() => updateState({ manualHeaderRows: [...formState.manualHeaderRows, { id: createHeaderRowId(), header: '', value: '' }] })}
                            onRemoveManualHeader={(rowId) =>
                                updateState({
                                    manualHeaderRows:
                                        formState.manualHeaderRows.length === 1
                                            ? [{ id: createHeaderRowId(), header: '', value: '' }]
                                            : formState.manualHeaderRows.filter((row) => row.id !== rowId)
                                })
                            }
                        />
                        <WorkflowSettingsCanvasCard
                            readOnly={readOnly}
                            layoutEngine={formState.layoutEngine}
                            edgeStyle={formState.edgeStyle}
                            layoutEngineOptions={layoutEngineOptions}
                            edgeStyleOptions={edgeStyleOptions}
                            onLayoutEngineChange={(value) => updateState({ layoutEngine: value })}
                            onEdgeStyleChange={(value) => updateState({ edgeStyle: value })}
                            onResetLayout={() =>
                                onResetLayout?.({
                                    layoutEngine: formState.layoutEngine,
                                    edgeStyle: formState.edgeStyle
                                })
                            }
                        />
                        <WorkflowSettingsNotesCard />
                    </div>
                </div>
                <footer className="wf-workspace-settings__footer">
                    <span>{readOnly ? 'Execution settings are read-only.' : 'Changes apply instantly to the workflow canvas and node inspector.'}</span>
                    {readOnly ? null : (
                        <div className="wf-workspace-settings__footer-actions">
                            <Button label="Discard" outlined onClick={onHide} />
                            <Button
                                data-cy="workflow-settings-save"
                                className="wf-workspace-settings__save-button"
                                label="Save changes"
                                onClick={() => {
                                    onSave({
                                        workflowName: formState.workflowNameInput,
                                        workflowDescription: formState.workflowDescriptionInput,
                                        canvasSettings: {
                                            layoutEngine: formState.layoutEngine,
                                            edgeStyle: formState.edgeStyle
                                        },
                                        settings: {
                                            graphqlUrl: formState.graphqlUrl,
                                            httpBaseUrl: formState.httpBaseUrl.trim() || deriveHttpBaseUrl(formState.graphqlUrl) || undefined,
                                            authMode: formState.authMode,
                                            manualHeaders: formState.authMode === WorkflowAuthModeEnum.Manual ? toManualHeadersRecord(formState.manualHeaderRows) : {},
                                            maxExecutionSeconds: Number(formState.maxExecutionSeconds)
                                        }
                                    });
                                    onHide();
                                }}
                            />
                        </div>
                    )}
                </footer>
            </div>
        </Dialog>
    );
};

export default WorkflowSettingsDialog;
