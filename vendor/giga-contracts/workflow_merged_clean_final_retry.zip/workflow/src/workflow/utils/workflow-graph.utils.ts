import { Connection, Edge, MarkerType } from '@xyflow/react';
import { getAllNodeSchemas, getNodeModuleById, resolveNodeSchema } from '@workflow/nodes/node-utils';
import { WorkflowCanvasEdgeStyle, WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { getNormalizedCommandPorts, parseHandlePortName, resolveCommandPortIdFromHandle } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';

interface EdgeActionHandlers {
    onDeleteEdge?: (edgeId: string) => void;
    onInsertNodeOnEdge?: (payload: { edgeId: string; anchor: HTMLElement }) => void;
}

const BASE_EDGE_STROKE_WIDTH = 2.5;
const EDGE_HIGHLIGHT_DELTA = 0.4;
const toComparable = (value: string): string => value.trim().toLowerCase();

const includesComparable = (source: string[], candidate: string | undefined): boolean => {
    if (!candidate) return false;
    const normalizedCandidate = toComparable(candidate);
    return source.some((entry) => toComparable(entry) === normalizedCandidate);
};

const getForwardedItemCount = (output: unknown): number => {
    if (Array.isArray(output)) return output.length;
    if (!output || typeof output !== 'object') return output == null ? 0 : 1;
    const payload = output as Record<string, unknown>;
    if (Object.keys(payload).length === 0) return 0;
    if (Array.isArray(payload.items)) return payload.items.length;
    if (Array.isArray(payload.data)) return payload.data.length;
    if (Array.isArray(payload.rows)) return payload.rows.length;
    return typeof payload.count === 'number' ? payload.count : 1;
};

const resolveEdgeStrokeColor = (status: string, isActive: boolean, isCompleted: boolean): string => {
    if (isActive) return '#2563eb';
    if (isCompleted || status === WorkflowNodeStatusEnum.Passed) return '#16a34a';
    if (status === WorkflowNodeStatusEnum.Failed) return '#dc2626';
    if (status === WorkflowNodeStatusEnum.Warning) return '#d97706';
    return '#94a3b8';
};

export const canAttachConnection = (workflow: WorkflowDefinition | null, connection: Connection): boolean => {
    if (!workflow || !connection.source || !connection.target) return false;
    if (connection.source === connection.target) return false;
    const source = workflow.nodes.find((node) => node.id === connection.source);
    const target = workflow.nodes.find((node) => node.id === connection.target);
    if (!source || !target) return false;
    const schemas = workflow.nodeModels ?? getAllNodeSchemas();
    const sourceModel = resolveNodeSchema(source.modelId, schemas);
    const targetModel = resolveNodeSchema(target.modelId, schemas);
    const sourceCommandPortId = resolveCommandPortIdFromHandle(sourceModel, connection.sourceHandle, 'outputs', parseHandlePortName(connection.sourceHandle, 'output'));
    const targetCommandPortId = resolveCommandPortIdFromHandle(targetModel, connection.targetHandle, 'inputs', parseHandlePortName(connection.targetHandle, 'input'));
    const sourcePorts = sourceCommandPortId ? getNormalizedCommandPorts(sourceModel) : sourceModel.outputs;
    const targetPorts = targetCommandPortId ? getNormalizedCommandPorts(targetModel) : targetModel.inputs;
    const sourcePort = sourceCommandPortId ?? parseHandlePortName(connection.sourceHandle, Object.keys(sourcePorts)[0] ?? 'output');
    const targetPort = targetCommandPortId ?? parseHandlePortName(connection.targetHandle, Object.keys(targetPorts)[0] ?? 'input');
    const sourceRules = sourcePorts[sourcePort];
    const targetRules = targetPorts[targetPort];
    if (!sourceRules || !targetRules) return false;
    const sourceIsCommand = Boolean(sourceCommandPortId);
    const targetIsCommand = Boolean(targetCommandPortId);
    if (sourceIsCommand !== targetIsCommand) {
        return false;
    }
    const acceptedSourceModelIds = targetRules.acceptedSourceModelIds ?? [];
    if (acceptedSourceModelIds.length > 0 && !includesComparable(acceptedSourceModelIds, source.modelId)) {
        return false;
    }
    const acceptedSourceGroups = targetRules.acceptedSourceGroups ?? [];
    if (acceptedSourceGroups.length > 0) {
        const sourceModule = getNodeModuleById(source.modelId);
        const sourceGroups = [sourceModel.group, sourceModule?.library.group].filter((entry): entry is string => typeof entry === 'string' && entry.trim().length > 0);
        const hasMatchedGroup = sourceGroups.some((group) => includesComparable(acceptedSourceGroups, group));
        if (!hasMatchedGroup) {
            return false;
        }
    }
    const sourceHandleId = sourceIsCommand ? `cmd:${sourcePort}` : `out:${sourcePort}`;
    const targetHandleId = targetIsCommand ? `cmd:${targetPort}` : `in:${targetPort}`;
    const sourceUsed = workflow.connections.filter((item) => item.from === source.id && item.sourceHandle === sourceHandleId).length;
    const targetUsed = workflow.connections.filter((item) => item.to === target.id && item.targetHandle === targetHandleId).length;
    if (!sourceRules.allowMultipleArrows && sourceUsed > 0) return false;
    if (!targetRules.allowMultipleArrows && targetUsed > 0) return false;
    return true;
};

export const createWorkflowConnection = (connection: Connection): WorkflowConnectionModel => ({
    id: `connection_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: `${connection.source} -> ${connection.target}`,
    from: connection.source ?? '',
    to: connection.target ?? '',
    sourceHandle: connection.sourceHandle ?? undefined,
    targetHandle: connection.targetHandle ?? undefined
});

export const buildCanvasEdges = (workflowState: WorkflowDefinition | null, orderedNodeIds: string[], activeIndex: number, isPlaying: boolean, handlers: EdgeActionHandlers = {}, edgeStyle: WorkflowCanvasEdgeStyle = 'legacy'): Edge[] => {
    if (!workflowState) return [];
    const nodesById = new Map(workflowState.nodes.map((node) => [node.id, node]));
    const sourceCounts = new Map<string, number>();
    const targetCounts = new Map<string, number>();
    const sourceIndexes = new Map<string, number>();
    const targetIndexes = new Map<string, number>();

    for (const connection of workflowState.connections) {
        const sourceKey = `${connection.from}|${connection.sourceHandle ?? ''}`;
        const targetKey = `${connection.to}|${connection.targetHandle ?? ''}`;
        sourceCounts.set(sourceKey, (sourceCounts.get(sourceKey) ?? 0) + 1);
        targetCounts.set(targetKey, (targetCounts.get(targetKey) ?? 0) + 1);
    }

    return workflowState.connections.map((connection) => {
        const sourceNode = nodesById.get(connection.from);
        const targetIndex = orderedNodeIds.indexOf(connection.to);
        const isActive = isPlaying && targetIndex === activeIndex;
        const isCompleted = targetIndex > 0 && targetIndex < activeIndex;
        const sourceStatus = sourceNode?.status ?? WorkflowNodeStatusEnum.Running;
        const isFailed = sourceStatus === WorkflowNodeStatusEnum.Failed;
        const count = sourceNode ? getForwardedItemCount(sourceNode.ports?.out?.output ?? sourceNode.output) : 0;
        const strokeWidth = BASE_EDGE_STROKE_WIDTH + (isActive || isFailed ? EDGE_HIGHLIGHT_DELTA : 0);
        const sourceKey = `${connection.from}|${connection.sourceHandle ?? ''}`;
        const targetKey = `${connection.to}|${connection.targetHandle ?? ''}`;
        const sourceIndex = sourceIndexes.get(sourceKey) ?? 0;
        const targetIndexInLane = targetIndexes.get(targetKey) ?? 0;
        const sourceCount = sourceCounts.get(sourceKey) ?? 1;
        const targetCount = targetCounts.get(targetKey) ?? 1;

        sourceIndexes.set(sourceKey, sourceIndex + 1);
        targetIndexes.set(targetKey, targetIndexInLane + 1);

        return {
            id: connection.id,
            source: connection.from,
            target: connection.to,
            sourceHandle: connection.sourceHandle,
            targetHandle: connection.targetHandle,
            label: String(count),
            type: 'workflowEdge',
            markerEnd: { type: MarkerType.ArrowClosed },
            animated: isActive || sourceStatus === WorkflowNodeStatusEnum.Running,
            className: `wf-edge ${isCompleted ? 'wf-edge--completed' : ''} ${isActive ? 'wf-edge--active' : ''} ${sourceStatus === WorkflowNodeStatusEnum.Failed ? 'wf-edge--failed' : ''} ${
                sourceStatus === WorkflowNodeStatusEnum.Warning ? 'wf-edge--warning' : ''
            } wf-edge--count`.trim(),
            style: { strokeWidth, stroke: resolveEdgeStrokeColor(sourceStatus, isActive, isCompleted) },
            data: {
                edgeStyle,
                sourceLaneOffset: sourceCount > 1 ? (sourceIndex - (sourceCount - 1) / 2) * 18 : 0,
                targetLaneOffset: targetCount > 1 ? (targetIndexInLane - (targetCount - 1) / 2) * 18 : 0,
                onDelete: handlers.onDeleteEdge,
                onInsert: handlers.onInsertNodeOnEdge
            }
        };
    });
};
