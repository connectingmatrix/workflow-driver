import type { WorkflowDefinition } from '../types';

function dataEdges(workflow: WorkflowDefinition) {
  return (workflow.connections || []).filter((edge) => !String(edge.sourceHandle || '').startsWith('cmd:') && !String(edge.targetHandle || '').startsWith('cmd:'));
}

function commandPeerIds(workflow: WorkflowDefinition, reachable: Set<string>) {
  const commandEdges = (workflow.connections || []).filter((edge) => String(edge.sourceHandle || '').startsWith('cmd:') && String(edge.targetHandle || '').startsWith('cmd:'));
  const peers = new Set<string>();
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of commandEdges) {
      if (!reachable.has(edge.to) && !peers.has(edge.to)) continue;
      if (peers.has(edge.from)) continue;
      peers.add(edge.from);
      changed = true;
    }
  }
  return peers;
}

function reachableNodeIds(workflow: WorkflowDefinition, startId: string) {
  const nextByNode = dataEdges(workflow).reduce<Record<string, string[]>>((acc, edge) => {
    acc[edge.from] = [...(acc[edge.from] || []), edge.to];
    return acc;
  }, {});
  const seen = new Set<string>([startId]);
  const queue = [startId];
  while (queue.length) {
    const id = queue.shift() as string;
    for (const next of nextByNode[id] || []) {
      if (seen.has(next)) continue;
      seen.add(next);
      queue.push(next);
    }
  }
  return seen;
}

export function validateExecutableGraph(workflow: WorkflowDefinition, executable: boolean) {
  const errors: string[] = [];
  const startNodes = workflow.nodes.filter((node) => node.modelId === 'start');
  const endNodes = workflow.nodes.filter((node) => node.modelId === 'respond-end');
  if (!workflow.nodes.length) errors.push('Workflow must include at least one node.');
  if (executable && startNodes.length !== 1) errors.push('Executable chat workflows must include exactly one start node.');
  if (executable && !endNodes.length) errors.push('Executable chat workflows must include at least one respond-end node.');
  if (!executable || startNodes.length !== 1 || !endNodes.length) return errors;
  const reachable = reachableNodeIds(workflow, startNodes[0].id);
  const commandPeers = commandPeerIds(workflow, reachable);
  if (!endNodes.some((node) => reachable.has(node.id))) errors.push('At least one respond-end node must be reachable from start.');
  workflow.nodes
    .filter((node) => node.modelId !== 'start')
    .filter((node) => !reachable.has(node.id) && !commandPeers.has(node.id))
    .forEach((node) => errors.push(`${node.name || node.id} is not reachable from start through data edges.`));
  return errors;
}
