import { selectedWorkflowNodeSources, workflowNodeSources } from './files';

function portSummary(ports: any) {
  return Object.entries(ports || {}).map(([key, value]: [string, any]) => ({
    key,
    label: value?.label || key,
    portType: value?.portType || 'data',
    multiple: value?.allowMultipleArrows === true,
    acceptedSourceGroups: value?.acceptedSourceGroups || [],
    acceptedSourceModelIds: value?.acceptedSourceModelIds || [],
  }));
}

function docSummary(schema: any) {
  return schema?.documentation || {};
}

function fieldSummary(schema: any) {
  return Object.entries(schema?.fields || {}).map(([key, value]: [string, any]) => ({
    key,
    type: value?.type || 'unknown',
    required: value?.required === true,
    defaultValue: value?.defaultValue ?? null,
    allowVariables: value?.allowVariables === true,
  }));
}

export function workflowNodeCatalog() {
  return workflowNodeSources().map((source) => {
    const docs: any = docSummary(source.schema);
    return {
      id: source.id,
      name: docs.nodeTypeLabel || (source.schema?.name as any)?.label || source.id,
      group: source.schema?.group || 'Other',
      summary: docs.summary || '',
      usage: docs.usage || '',
      inputs: portSummary(source.schema?.inputs),
      outputs: portSummary(source.schema?.outputs),
      fields: fieldSummary(source.schema),
      has_worker: Boolean(source.worker),
      has_docs: Boolean(source.readme),
    };
  });
}

export function workflowNodeDetails(modelIds: string[]) {
  return selectedWorkflowNodeSources(modelIds).map((source) => ({
    id: source.id,
    schema: source.schema,
    schema_json: source.schemaText,
    readme: source.readme,
    worker_ts: source.worker,
    rules: [
      'Cypher node syntax: (alias:modelId {"name":"Name","runtime":{...}})',
      'Cypher edge syntax: (from)-[:CONNECT {"source":"out:output","target":"in:input"}]->(to)',
      'Executable chat workflows must include one start node and at least one respond-end node.',
      'Do not put nodes, connections, ports, output, nodeModels, NODE_EXECUTORS, or signatures in runtime.',
    ],
  }));
}
