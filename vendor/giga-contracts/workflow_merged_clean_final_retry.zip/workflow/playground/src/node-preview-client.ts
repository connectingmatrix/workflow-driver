import type { WorkflowNodePreviewRequest, WorkflowNodePreviewResponse } from '../shared/preview-runtime.types';
import { WORKFLOW_NODE_PREVIEW_ENDPOINT } from '../shared/preview-runtime.constants';

export const requestNodeWorkflowPreview = async (request: WorkflowNodePreviewRequest, signal?: AbortSignal): Promise<WorkflowNodePreviewResponse> => {
    const response = await fetch(WORKFLOW_NODE_PREVIEW_ENDPOINT, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(request),
        signal
    });

    const payload = (await response.json()) as WorkflowNodePreviewResponse;
    return payload;
};
