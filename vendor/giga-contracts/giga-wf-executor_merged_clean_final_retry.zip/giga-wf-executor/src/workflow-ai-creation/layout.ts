import type { WorkflowDefinition } from '../types';
import { placeCommandNodes } from './layout-command';
import { readLayoutGraph } from './layout-graph';
import { placeMainNodes } from './layout-main';

export function layoutWorkflowGraph(workflow: WorkflowDefinition): WorkflowDefinition {
  if (!(workflow.nodes || []).length) return workflow;
  const graph = readLayoutGraph(workflow);
  const main = placeMainNodes(graph);
  const command = placeCommandNodes(graph, main);

  return {
    ...workflow,
    nodes: workflow.nodes.map((node) => ({
      ...node,
      position: main.positions[node.id] || command[node.id] || node.position,
    })),
  };
}
