import React from 'react';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';

interface WorkspaceJsonFieldProps {
    value: string;
    editable: boolean;
    allowVariables: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: string) => void;
}

export const WorkspaceJsonField: React.FC<WorkspaceJsonFieldProps> = ({ value, editable, allowVariables, variableContext, variableSuggestions, onChange }) => {
    return (
        <div className="cnw-json-editor-shell">
            <CodeEditor value={value} onChange={onChange} language="json" readOnly={!editable} allowVariables={allowVariables} variableContext={variableContext} variableSuggestions={variableSuggestions} minHeight={320} />
        </div>
    );
};
