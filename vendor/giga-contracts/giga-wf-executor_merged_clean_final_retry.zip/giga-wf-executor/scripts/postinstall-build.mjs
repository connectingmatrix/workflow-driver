import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(scriptDir, '..');
const sourceEntry = path.join(repoRoot, 'src', 'index.ts');
const distEntry = path.join(repoRoot, 'dist', 'index.js');
const require = createRequire(import.meta.url);

if (!existsSync(sourceEntry) || existsSync(distEntry)) {
    process.exit(0);
}

const runNodeScript = (scriptPath, args) =>
    spawnSync(process.execPath, [scriptPath, ...args], {
        cwd: repoRoot,
        stdio: 'inherit'
    });

const tsupCliPath = require.resolve('tsup/dist/cli-default.js', { paths: [repoRoot] });
const tsupResult = runNodeScript(tsupCliPath, [
    'src/index.ts',
    'src/types/index.ts',
    'src/node-core/index.ts',
    '--format',
    'cjs,esm',
    '--outDir',
    'dist',
    '--clean'
]);

if (typeof tsupResult.status === 'number' && tsupResult.status !== 0) {
    process.exit(tsupResult.status);
}

if (typeof tsupResult.status !== 'number') {
    process.exit(1);
}

const tscCliPath = require.resolve('typescript/bin/tsc', { paths: [repoRoot] });
const tscResult = runNodeScript(tscCliPath, ['-p', 'tsconfig.build.json']);

if (typeof tscResult.status === 'number') {
    process.exit(tscResult.status);
}

process.exit(1);
