import { describe, expect, it } from 'vitest';
import fixturePayload from './fixtures/workflows/0f711eb4-7f83-40db-9928-49ade24c0b42-with-data.json';
import { createWorkflowExecutor } from '../executor/create-workflow-executor';
import { createWorkerNodeHandler } from '../executor/worker-runtime';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowExecutorModeEnum, WorkflowNodeStatusEnum } from '../types';

type WorkflowExportPayload = {
    metadata?: WorkflowDefinition['metadata'];
    nodes?: WorkflowDefinition['nodes'] | Record<string, WorkflowDefinition['nodes'][number]>;
    connections?: WorkflowConnectionModel[] | Record<string, WorkflowConnectionModel & { fromId?: string; toId?: string }>;
    nodeModels?: WorkflowDefinition['nodeModels'];
    NODE_EXECUTORS?: WorkflowDefinition['NODE_EXECUTORS'];
    NODE_EXECUTOR_SIGNATURES?: WorkflowDefinition['NODE_EXECUTOR_SIGNATURES'];
};

const toWorkflowDefinition = (payload: WorkflowExportPayload): WorkflowDefinition => {
    const nodes = Array.isArray(payload.nodes) ? payload.nodes : Object.values(payload.nodes ?? {});
    const rawConnections = Array.isArray(payload.connections) ? payload.connections : Object.values(payload.connections ?? {});
    const connections: WorkflowConnectionModel[] = rawConnections
        .map((connection) => ({
            ...connection,
            from: String((connection as { fromId?: string }).fromId ?? connection.from ?? ''),
            to: String((connection as { toId?: string }).toId ?? connection.to ?? '')
        }))
        .filter((connection) => connection.from.length > 0 && connection.to.length > 0);

    return {
        metadata: {
            id: String(payload.metadata?.id ?? 'workflow_fixture_runtime'),
            name: String(payload.metadata?.name ?? 'Workflow Fixture Runtime'),
            ...(payload.metadata ?? {})
        },
        nodeModels: payload.nodeModels ?? {},
        NODE_EXECUTORS: payload.NODE_EXECUTORS ?? {},
        NODE_EXECUTOR_SIGNATURES: payload.NODE_EXECUTOR_SIGNATURES ?? {},
        nodes,
        connections
    };
};

const createFixtureExecutor = (runtimeEnvironment: 'browser' | 'node') =>
    createWorkflowExecutor({
        mode: WorkflowExecutorModeEnum.Local,
        adapters: {
            getNodeHandler: (modelId) =>
                createWorkerNodeHandler({
                    modelId: String(modelId ?? ''),
                    runtimeEnvironment
                })
        }
    });

const executeFixture = async (runtimeEnvironment: 'browser' | 'node') => {
    const executor = createFixtureExecutor(runtimeEnvironment);
    const workflow = toWorkflowDefinition(fixturePayload as WorkflowExportPayload);
    const result = await executor.executeWorkflow(workflow, {
        settings: {
            graphqlUrl: 'http://localhost/graphql',
            authMode: 'none'
        }
    });
    return result;
};

describe('workflow fixture runtime execution (0f711eb4)', () => {
    it('executes the fixture workflow in browser runtime', async () => {
        const result = await executeFixture('browser');
        const startNode = result.workflow.nodes.find((node) => node.id === 'start-1');
        const codeNode = result.workflow.nodes.find((node) => node.id === 'code-node-3');
        const endNode = result.workflow.nodes.find((node) => node.id === 'respond-end-4');

        expect(startNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(codeNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(endNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(true);
    }, 20000);

    it('executes the fixture workflow in server/node runtime', async () => {
        const result = await executeFixture('node');
        const startNode = result.workflow.nodes.find((node) => node.id === 'start-1');
        const codeNode = result.workflow.nodes.find((node) => node.id === 'code-node-3');
        const endNode = result.workflow.nodes.find((node) => node.id === 'respond-end-4');

        expect(startNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(codeNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(endNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(true);
    }, 20000);
});
