import type { WorkflowDefinition } from '../types';

export interface WorkflowShapeSummary {
  connection_count: number;
  connections: Array<Record<string, unknown>>;
  node_count: number;
  nodes: Array<Record<string, unknown>>;
}

export const readWorkflowEditorUrl = (workflowId?: string | null) => (workflowId ? `/workflows/${workflowId}/edit` : null);

export const readWorkflowExcerpt = (value: unknown, limit = 1200) => {
  const text = typeof value === 'string' ? value : JSON.stringify(value ?? null);
  return text.length > limit ? `${text.slice(0, limit)}...` : text;
};

export const readWorkflowShape = (workflow: WorkflowDefinition | null | undefined): WorkflowShapeSummary => {
  const nodes = workflow?.nodes || [];
  const connections = workflow?.connections || [];
  return {
    node_count: nodes.length,
    connection_count: connections.length,
    nodes: nodes.map((node) => ({ id: node.id || null, model_id: node.modelId || null, name: node.name || null })),
    connections: connections.map((connection) => ({
      id: connection.id || null,
      source: connection.from || null,
      target: connection.to || null,
      source_handle: connection.sourceHandle || null,
      target_handle: connection.targetHandle || null,
    })),
  };
};
