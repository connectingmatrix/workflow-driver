import type { WorkflowQueueRequestConsumer } from './types';

const DEFAULT_CONSUMER_READY_TIMEOUT_MS = 35_000;

type WorkflowQueueInstrumentedConsumer = WorkflowQueueRequestConsumer & {
  events?: { GROUP_JOIN?: unknown };
  off?: (eventName: unknown, listener: (...args: any[]) => void) => void;
  on?: (eventName: unknown, listener: (...args: any[]) => void) => void;
  removeListener?: (eventName: unknown, listener: (...args: any[]) => void) => void;
};

const getConsumerEventApi = (consumer: WorkflowQueueRequestConsumer) => consumer as WorkflowQueueInstrumentedConsumer;

export const waitForWorkflowQueueConsumerReady = async (params: {
  consumer: WorkflowQueueRequestConsumer;
  start: () => Promise<void>;
  timeoutMs?: number;
}): Promise<void> => {
  const api = getConsumerEventApi(params.consumer);
  const groupJoinEvent = api.events?.GROUP_JOIN;
  const addListener = typeof api.on === 'function' ? api.on.bind(params.consumer) : null;
  const removeListener = typeof api.off === 'function' ? api.off.bind(params.consumer) : typeof api.removeListener === 'function' ? api.removeListener.bind(params.consumer) : null;

  if (!groupJoinEvent || !addListener) {
    await params.start();
    return;
  }

  const timeoutMs = Number.isFinite(Number(params.timeoutMs)) ? Math.max(1, Number(params.timeoutMs)) : DEFAULT_CONSUMER_READY_TIMEOUT_MS;
  let timeoutId: NodeJS.Timeout | null = null;
  const readyPromise = new Promise<void>((resolve, reject) => {
    const onGroupJoin = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = null;
      removeListener?.(groupJoinEvent, onGroupJoin);
      resolve();
    };

    addListener(groupJoinEvent, onGroupJoin);
    timeoutId = setTimeout(() => {
      removeListener?.(groupJoinEvent, onGroupJoin);
      reject(new Error(`Timed out after ${timeoutMs}ms waiting for workflow queue consumer readiness.`));
    }, timeoutMs);
  });

  try {
    await params.start();
    await readyPromise;
  } catch (error) {
    if (timeoutId) clearTimeout(timeoutId);
    throw error;
  }
};
