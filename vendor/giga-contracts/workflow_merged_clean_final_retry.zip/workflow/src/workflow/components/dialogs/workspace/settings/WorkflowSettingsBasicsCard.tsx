import React from 'react';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import WorkflowSettingsSectionCard from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsSectionCard';

interface WorkflowSettingsBasicsCardProps {
    readOnly?: boolean;
    workflowName: string;
    workflowDescription: string;
    onWorkflowNameChange: (value: string) => void;
    onWorkflowDescriptionChange: (value: string) => void;
}

export const WorkflowSettingsBasicsCard: React.FC<WorkflowSettingsBasicsCardProps> = ({ readOnly = false, workflowName, workflowDescription, onWorkflowNameChange, onWorkflowDescriptionChange }) => (
    <WorkflowSettingsSectionCard icon="pi pi-th-large" title="Basics" description="Friendly name and description shown across the designer.">
        <label className="wf-workspace-settings__field-label">Name</label>
        <InputText value={workflowName} onChange={(event) => onWorkflowNameChange(event.target.value)} readOnly={readOnly} className="wf-workspace-settings__input" />
        <label className="wf-workspace-settings__field-label">Description</label>
        <InputTextarea value={workflowDescription} onChange={(event) => onWorkflowDescriptionChange(event.target.value)} readOnly={readOnly} rows={4} className="wf-workspace-settings__textarea" />
        <span className="wf-workspace-settings__field-note">Visible in workflow listings and execution history.</span>
    </WorkflowSettingsSectionCard>
);
