// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import NodeInspector from '@workflow/ui/workflow/components/inspector/NodeInspector';
import { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowCredentialOption, WorkflowExecutableOption } from '@workflow/ui/workflow/types';
import { WorkflowNodeFieldTypeEnum, WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';

const fetchCredentialsMock = vi.fn();
const fetchExecutableWorkflowsMock = vi.fn();
const openCredentialManagerMock = vi.fn();

const inspectorState = {
    canClose: vi.fn(() => true),
    hasUnsavedChanges: false,
    saveChanges: vi.fn(),
    isExecuting: false,
    propertiesEditorState: {
        name: 'Node 1',
        transport: 'streamable-http'
    } as Record<string, unknown>,
    setProperty: vi.fn(),
    setProperties: vi.fn(),
    runCurrentCode: vi.fn(),
    code: '',
    markdown: '',
    onCodeChange: vi.fn(),
    onMarkdownChange: vi.fn(),
    executionResult: null
};

vi.mock('primereact/dialog', () => ({
    Dialog: ({ visible, children }: { visible: boolean; children: React.ReactNode }) => (visible ? <div data-testid="inspector-dialog">{children}</div> : null)
}));

vi.mock('primereact/button', () => ({
    Button: ({ label, onClick, className, disabled, children, ...props }: { label?: string; onClick?: () => void; className?: string; disabled?: boolean; children?: React.ReactNode; [key: string]: unknown }) => (
        <button type="button" onClick={onClick} className={className} disabled={disabled} aria-label={typeof props['aria-label'] === 'string' ? props['aria-label'] : undefined}>
            {label ?? children ?? 'button'}
        </button>
    )
}));

vi.mock('@workflow/ui/workflow/components/inspector/useWorkflowNodeInspectorState', () => ({
    useWorkflowNodeInspectorState: () => inspectorState
}));

vi.mock('@workflow/ui/workflow/components/inspector/InspectorInputPane', () => ({
    default: () => <div data-testid="inspector-input-pane">input-pane</div>
}));

vi.mock('@workflow/ui/workflow/components/inspector/InspectorOutputPane', () => ({
    default: () => <div data-testid="inspector-output-pane">output-pane</div>
}));

vi.mock('@workflow/ui/workflow/components/inspector/InspectorPropertiesPane', () => ({
    default: ({ modelId }: { modelId?: string }) => <div data-testid="inspector-properties-pane">generic-properties-{modelId}</div>
}));

const buildConfig = (overrides: Partial<WorkflowInspectorConfig> = {}): WorkflowInspectorConfig => ({
    nodeId: 'node_1',
    modelId: 'mcp-runtime',
    nodeTypeLabel: 'MCP Runtime',
    executorKey: 'mcp-runtime',
    useCredentials: null,
    useWorkflows: null,
    instruction: { code: false, markdown: false },
    name: 'Node 1',
    title: 'Node 1',
    input: { input: { foo: 'bar' } },
    properties: {
        name: 'Node 1',
        transport: 'streamable-http'
    },
    fields: {
        name: { type: WorkflowNodeFieldTypeEnum.String, editable: true },
        transport: { type: WorkflowNodeFieldTypeEnum.String, editable: true }
    },
    viewers: [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: {} }],
    ...overrides
});

describe('NodeInspector', () => {
    const scrollIntoViewSpy = vi.fn();

    beforeEach(() => {
        inspectorState.canClose.mockClear();
        inspectorState.saveChanges.mockClear();
        inspectorState.setProperty.mockClear();
        inspectorState.hasUnsavedChanges = false;
        inspectorState.propertiesEditorState = {
            name: 'Node 1',
            transport: 'streamable-http'
        };
        scrollIntoViewSpy.mockClear();
        fetchCredentialsMock.mockReset();
        fetchExecutableWorkflowsMock.mockReset();
        openCredentialManagerMock.mockReset();
        Object.defineProperty(HTMLElement.prototype, 'scrollIntoView', {
            configurable: true,
            value: scrollIntoViewSpy
        });
    });

    afterEach(() => {
        cleanup();
    });

    it('renders the workspace inspector shell for editable nodes', () => {
        render(<NodeInspector visible config={buildConfig()} onHide={vi.fn()} />);

        expect(screen.getByTestId('inspector-dialog')).toBeInTheDocument();
        expect(screen.getByRole('heading', { name: 'Parameters', level: 3 })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Run Node' })).toBeInTheDocument();
        expect(screen.getByRole('heading', { name: 'Input', level: 3 })).toBeInTheDocument();
        expect(screen.getByRole('heading', { name: 'Output', level: 3 })).toBeInTheDocument();
    });

    it('saves through the shared inspector state', () => {
        inspectorState.hasUnsavedChanges = true;
        render(<NodeInspector visible config={buildConfig()} onHide={vi.fn()} />);

        expect(document.querySelectorAll('[data-cy="workflow-inspector-action-save-changes"]')).toHaveLength(1);
        expect(document.querySelector('.cnw-shell__footer')).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Save changes' }));
        expect(inspectorState.saveChanges).toHaveBeenCalled();
    });

    it('keeps header refresh actions in-place without scrolling the dialog', () => {
        render(<NodeInspector visible config={buildConfig()} onHide={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Refresh' }));
        fireEvent.click(screen.getByRole('button', { name: 'Output' }));

        expect(scrollIntoViewSpy).not.toHaveBeenCalled();
    });

    it('renders bounded workspace pane scroll containers', () => {
        render(<NodeInspector visible config={buildConfig()} onHide={vi.fn()} />);

        expect(document.querySelector('.cnw-input-panel__scroll')).toBeInTheDocument();
        expect(document.querySelector('.cnw-parameters-panel__scroll')).toBeInTheDocument();
        expect(document.querySelector('.cnw-output-panel__scroll')).toBeInTheDocument();
    });

    it('renders the credential selector for provider nodes and saves credentialId through shared state', async () => {
        inspectorState.propertiesEditorState = {
            name: 'OpenAI Node',
            credentialId: 'cred_org_2'
        };
        const options: WorkflowCredentialOption[] = [
            {
                id: 'cred_user_1',
                credentialId: 'cred_user_1',
                credentialName: 'Personal OpenAI',
                serviceId: 'openai',
                serviceName: 'OpenAI',
                serviceIcon: 'simple-icons:openai',
                scope: 'PERSONAL',
                scopeTag: 'User'
            },
            {
                id: 'cred_org_2',
                credentialId: 'cred_org_2',
                credentialName: 'Org OpenAI',
                serviceId: 'openai',
                serviceName: 'OpenAI',
                serviceIcon: 'simple-icons:openai',
                scope: 'ORGANIZATION',
                scopeTag: 'Org'
            }
        ];
        fetchCredentialsMock.mockResolvedValue(options);

        render(<NodeInspector visible config={buildConfig({ modelId: 'openai', nodeTypeLabel: 'OpenAI', useCredentials: 'openai' })} onHide={vi.fn()} fetchCredentials={fetchCredentialsMock} />);

        await waitFor(() => {
            expect(fetchCredentialsMock).toHaveBeenCalledWith('openai');
        });
        expect(screen.getByText('Credential')).toBeInTheDocument();
        expect(screen.getByText('Org OpenAI')).toBeInTheDocument();

        fireEvent.click(screen.getByRole('button', { name: /org openai/i }));
        fireEvent.click(screen.getByRole('button', { name: /personal openai/i }));

        expect(inspectorState.setProperty).toHaveBeenCalledWith('credentialId', 'cred_user_1');
    });

    it('does not render the credential selector for nodes without useCredentials', async () => {
        render(<NodeInspector visible config={buildConfig({ modelId: 'code', nodeTypeLabel: 'Code' })} onHide={vi.fn()} fetchCredentials={fetchCredentialsMock} />);

        await waitFor(() => {
            expect(screen.queryByText('Credential')).not.toBeInTheDocument();
        });
        expect(fetchCredentialsMock).not.toHaveBeenCalled();
    });

    it('shows an empty credential state when no credentials are returned for the service', async () => {
        fetchCredentialsMock.mockResolvedValue([]);

        render(
            <NodeInspector
                visible
                config={buildConfig({ modelId: 'openai', nodeTypeLabel: 'OpenAI', useCredentials: 'openai' })}
                onHide={vi.fn()}
                fetchCredentials={fetchCredentialsMock}
                openCredentialManager={openCredentialManagerMock}
            />
        );

        expect(await screen.findByText('No credentials available.')).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Add Credentials' }));
        expect(openCredentialManagerMock).toHaveBeenCalled();
    });

    it('shows an error credential state when credential loading fails', async () => {
        fetchCredentialsMock.mockRejectedValue(new Error('backend unavailable'));

        render(<NodeInspector visible config={buildConfig({ modelId: 'openai', nodeTypeLabel: 'OpenAI', useCredentials: 'openai' })} onHide={vi.fn()} fetchCredentials={fetchCredentialsMock} />);

        expect(await screen.findByText('Credentials could not be loaded.')).toBeInTheDocument();
        expect(screen.getByText('backend unavailable')).toBeInTheDocument();
    });

    it('reloads credential options from the selector header', async () => {
        fetchCredentialsMock.mockResolvedValue([
            {
                id: 'cred-1',
                credentialId: 'cred-1',
                credentialName: 'Primary MCP',
                serviceId: 'mcp',
                serviceName: 'MCP',
                serviceIcon: null,
                scope: 'PERSONAL',
                scopeTag: 'User'
            }
        ]);

        render(<NodeInspector visible config={buildConfig({ modelId: 'mcp-runtime', nodeTypeLabel: 'MCP Execute', useCredentials: 'mcp' })} onHide={vi.fn()} fetchCredentials={fetchCredentialsMock} />);

        await waitFor(() => {
            expect(fetchCredentialsMock).toHaveBeenCalledTimes(1);
        });

        fireEvent.click(screen.getByRole('button', { name: 'Refresh credentials' }));

        await waitFor(() => {
            expect(fetchCredentialsMock).toHaveBeenCalledTimes(2);
        });
    });

    it('renders the workflow selector and persists workflow metadata through shared state', async () => {
        inspectorState.propertiesEditorState = {
            name: 'Execute Workflow',
            workflowId: 'wf-org',
            workflowName: 'Org Workflow',
            workflowScope: 'organization'
        };
        const options: WorkflowExecutableOption[] = [
            { workflowId: 'wf-user', workflowName: 'User Workflow', scope: 'user', scopeTag: 'User', status: 'published' },
            { workflowId: 'wf-org', workflowName: 'Org Workflow', scope: 'organization', scopeTag: 'Org', status: 'published' }
        ];
        fetchExecutableWorkflowsMock.mockResolvedValue(options);

        render(
            <NodeInspector
                visible
                config={buildConfig({ modelId: 'execute-workflow', nodeTypeLabel: 'Execute Workflow', useWorkflows: ['user', 'organization'] })}
                onHide={vi.fn()}
                fetchExecutableWorkflows={fetchExecutableWorkflowsMock}
            />
        );

        await waitFor(() => {
            expect(fetchExecutableWorkflowsMock).toHaveBeenCalled();
        });
        expect(screen.getByRole('heading', { name: 'Workflow' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: /org workflow/i })).toBeInTheDocument();

        fireEvent.click(screen.getByRole('button', { name: /org workflow/i }));
        fireEvent.click(screen.getByRole('button', { name: /user workflow/i }));

        expect(inspectorState.setProperty).toHaveBeenNthCalledWith(1, 'workflowId', 'wf-user');
        expect(inspectorState.setProperty).toHaveBeenNthCalledWith(2, 'workflowName', 'User Workflow');
        expect(inspectorState.setProperty).toHaveBeenNthCalledWith(3, 'workflowScope', 'user');
    });
});
