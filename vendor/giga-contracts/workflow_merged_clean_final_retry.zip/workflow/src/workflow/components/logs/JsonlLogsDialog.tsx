import React from 'react';
import type { JsonlLogsDialogProps } from '@workflow/ui/workflow/components/logs/logs-dialog.types';
import WorkflowLogsDialog from '@workflow/ui/workflow/components/logs/workspace/WorkflowLogsDialog';

const JsonlLogsDialog: React.FC<JsonlLogsDialogProps> = (props) => <WorkflowLogsDialog {...props} />;

export type { JsonlLogsDialogProps };
export default JsonlLogsDialog;
