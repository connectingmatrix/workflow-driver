import { WorkflowCypherGraph, WorkflowCypherNodeSpec, WorkflowCypherEdgeSpec } from './types';

const NODE_LINE = /^\(([A-Za-z][\w-]*):([A-Za-z][\w-]*)(?:\s+(\{.*\}))?\)$/;
const EDGE_LINE = /^\(([A-Za-z][\w-]*)\)\s*-\[:CONNECT(?:\s+(\{.*\}))?\]->\s*\(([A-Za-z][\w-]*)\)$/;

function cypherJson(value: string): Record<string, unknown> {
  const parsed = JSON.parse(value.trim() || '{}');
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Cypher properties must be a JSON object.');
  return parsed as Record<string, unknown>;
}

function propertyText(record: Record<string, unknown>, key: string) {
  return String(record[key] || '').trim();
}

function cypherLines(source: string) {
  return String(source || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('//') && !line.startsWith('#'));
}

function nodeFromLine(line: string): WorkflowCypherNodeSpec | null {
  const match = line.match(NODE_LINE);
  if (!match) return null;
  const properties = match[3] ? cypherJson(match[3]) : {};
  const runtime = properties.runtime && typeof properties.runtime === 'object' && !Array.isArray(properties.runtime) ? properties.runtime : {};
  return {
    alias: String(match[1]),
    modelId: String(match[2]),
    name: propertyText(properties, 'name') || undefined,
    runtime: runtime as Record<string, unknown>,
  };
}

function edgeFromLine(line: string): WorkflowCypherEdgeSpec | null {
  const match = line.match(EDGE_LINE);
  if (!match) return null;
  const properties = match[2] ? cypherJson(match[2]) : {};
  return {
    from: String(match[1]),
    to: String(match[3]),
    source: propertyText(properties, 'source') || 'out:output',
    target: propertyText(properties, 'target') || 'in:input',
  };
}

export function parseWorkflowCypher(source: string): WorkflowCypherGraph {
  const graph: WorkflowCypherGraph = { nodes: [], edges: [] };
  for (const line of cypherLines(source)) {
    const node = nodeFromLine(line);
    if (node) {
      graph.nodes.push(node);
      continue;
    }
    const edge = edgeFromLine(line);
    if (edge) {
      graph.edges.push(edge);
      continue;
    }
    throw new Error(`Unsupported workflow cypher line: ${line}`);
  }
  if (!graph.nodes.length) throw new Error('Workflow cypher must include at least one node.');
  return graph;
}
