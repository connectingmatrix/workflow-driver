import { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { normalizeNodeName } from '@workflow/ui/workflow/utils/workflow-node-name.utils';
import { stringifyCypherJson } from './cypher-json';

const aliasForNode = (name: string, id: string): string =>
    normalizeNodeName(name, id)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '') || id;

const runtimeForExport = (runtime: Record<string, unknown> | undefined): Record<string, unknown> => {
    const source = runtime || {};
    return Object.entries(source).reduce<Record<string, unknown>>((acc, [key, value]) => {
        if (key === 'status' || key === 'timestamp' || key === 'source' || key.startsWith('__')) return acc;
        if (typeof value === 'undefined' || value === null || value === '') return acc;
        acc[key] = value;
        return acc;
    }, {});
};

export const workflowAsCypher = (workflow: WorkflowDefinition): string => {
    const aliases = workflow.nodes.reduce<Record<string, string>>((acc, node) => {
        acc[node.id] = aliasForNode(node.name, node.id);
        return acc;
    }, {});
    const nodeLines = workflow.nodes.map((node) => {
        const properties = stringifyCypherJson({
            name: node.name,
            runtime: runtimeForExport(node.runtime)
        });
        return `(${aliases[node.id]}:${node.modelId} ${properties})`;
    });
    const edgeLines = workflow.connections.map((edge) => {
        const properties = stringifyCypherJson({
            source: edge.sourceHandle || 'out:output',
            target: edge.targetHandle || 'in:input'
        });
        return `(${aliases[edge.from] || edge.from})-[:CONNECT ${properties}]->(${aliases[edge.to] || edge.to})`;
    });
    return [...nodeLines, ...edgeLines].join('\n');
};
