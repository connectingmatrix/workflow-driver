# Workflow Command Ports

## Canonical Schema

Command ports are authored in `nodeSchema.commands`.

```ts
commands?: Record<string, WorkflowNodePortProperty>
```

Each key is a single logical command port. New authored nodes should not duplicate the same command port under both `inputs` and `outputs`.

Example:

```json
{
  "commands": {
    "llm": {
      "label": "LLM",
      "side": "bottom",
      "order": 1,
      "portType": "bi-directional",
      "acceptedSourceGroups": ["AI Models"]
    },
    "tools": {
      "label": "Tools",
      "side": "bottom",
      "order": 2,
      "portType": "bi-directional",
      "acceptedSourceGroups": ["Actions", "Tools"]
    }
  }
}
```

## Compatibility

- New authored schemas write `commands`.
- Legacy nodes that still mirror command ports in `inputs` and `outputs` with `portType: "bi-directional"` are normalized at runtime.
- Existing saved workflows do not need a bulk migration for this cutover.

## Handle Contract

- Canonical command handle id: `cmd:<portName>`
- Canonical examples:
  - `cmd:llm`
  - `cmd:tools`
  - `cmd:workflow`
  - `cmd:command`

Legacy `in:<port>` and `out:<port>` command handles remain readable, but new connections and AI actions should emit `cmd:*`.

## Worker Runtime Contract

The executor exposes connected command peers on:

```ts
payload.NODE.CONTROL_NODES[commandPortName][peerKey]
```

- `commandPortName` is the command port id from schema, such as `llm`, `tools`, or `workflow`.
- `peerKey` is the connected node name.
- Duplicate names are disambiguated with `__<nodeIdPrefix>`.

### Control Node Facade

Each peer exposes async methods:

```ts
type WorkflowControlNodePatch = {
  properties?: Record<string, unknown>;
  runtime?: Record<string, unknown>;
  code?: string;
  markdown?: string;
  sourceFiles?: Record<string, string>;
};

controlNode.get(): Promise<{
  nodeId: string;
  name: string;
  modelId: string;
  status: string;
  properties: Record<string, unknown>;
  runtime: Record<string, unknown>;
  input: Record<string, Record<string, unknown>>;
  output: unknown;
}>;

controlNode.getSchema(): Promise<WorkflowNodeSchema>;

controlNode.set(patch: WorkflowControlNodePatch): Promise<ControlNodeSnapshot>;

controlNode.validate(args?: {
  patch?: WorkflowControlNodePatch;
  input?: Record<string, Record<string, unknown>>;
}): Promise<WorkerValidateResult>;

controlNode.executeInputs(args?: {
  patch?: WorkflowControlNodePatch;
}): Promise<ControlNodeSnapshot>;

controlNode.execute(args?: {
  patch?: WorkflowControlNodePatch;
  input?: Record<string, Record<string, unknown>>;
}): Promise<{
  node: ControlNodeSnapshot;
  result: WorkflowNodeHandlerResult;
}>;
```

### Execution Semantics

- `get()` and `getSchema()` are read-only and do not execute any graph nodes.
- `set()` mutates the target node in the current in-memory workflow/session only.
- `validate()` validates the target node against the current or overridden input and does not execute upstream/downstream nodes.
- `executeInputs()` materializes the target node's standard data predecessors only.
  - It recursively executes upstream non-command dependencies when their outputs are missing in the current run state.
  - It updates the target node's `ports.in` and returns the refreshed snapshot.
  - It does not execute the target node itself.
  - It does not execute downstream nodes.
- `execute()` executes only the target node.
  - If you need fresh predecessor data first, call `executeInputs()` before `execute()`.

## Persistence Semantics

- `set(...)` mutates the in-memory execution node immediately.
- The same patch is applied back onto the working workflow definition returned from the executor.
- `set(...)` does not persist to backend storage. Saving the workflow remains an explicit UI action.

## Forwarding Semantics

Command-port orchestration is additive.

- Standard `output` ports remain active and visible.
- Nodes can use command ports to inspect, patch, validate, or execute peers.
- After `execute(...)`, the controlling node can still forward processed data through its normal output ports.

This is required for nodes such as AI Governor and AI Agent, where command orchestration selects and runs peers while the node still emits a normal aggregated `output`.

## AI Agent Workflow Port

`ai-agent` adds a dedicated `workflow` command port:

```json
{
  "commands": {
    "workflow": {
      "label": "Workflow",
      "portType": "bi-directional",
      "acceptedSourceModelIds": ["workflow", "execute-workflow"]
    }
  }
}
```

- Connect `workflow` and `execute-workflow` nodes to `cmd:workflow`.
- Keep reusable backend tools on `cmd:tools`.
- Keep planner or reply models on `cmd:llm`.
