import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import type { WorkflowRealtimeClient, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import { WorkflowPreviewRuntime, WorkflowRuntimeSettings, WorkflowSourceFiles, WorkflowUserNodeDefinition } from '@workflow/ui/workflow/types';
import { buildUserNodePreviewWorkflow, toUserNodeSchema } from '@workflow/ui/workflow/components/user-node-designer/user-node-designer.utils';
import { analyzeUserNodePreviewRuntimeSupport, resolveUserNodePreviewRuntime } from '@workflow/ui/workflow/components/user-node-designer/user-node-preview-runtime.utils';
import { useUserNodePreviewStore } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';
import {
    UserNodeSchemaDraft,
    createEmptyUserNodeSchemaDraft,
    deserializeUserNodeSchemaDraft,
    serializeUserNodeSchemaDraft
} from '@workflow/ui/workflow/components/user-node-designer/designer/user-node-schema-draft.utils';

const DEFAULT_WORKER_SOURCE = `export const validate = async () => ({ ok: true, errors: [], warnings: [] });\nexport const init = async () => true;\nexport const onUpdate = async () => ({ ok: true });\nexport const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['user-node executed'] });\n`;
const DEFAULT_VALIDATE_SOURCE = `export const validate = async () => ({ ok: true, errors: [], warnings: [] });\n`;

const DEFAULT_SETTINGS: WorkflowRuntimeSettings = {
    graphqlUrl: '',
    authMode: 'none',
    manualHeaders: {},
    maxExecutionSeconds: 300
};

const isMissingGraphqlAuthTokenError = (error: unknown): boolean => {
    if (!(error instanceof Error)) return false;
    return /missing authentication token/i.test(error.message);
};

const parseSampleInputJson = (value: string): { ok: true; value: Record<string, unknown> } | { ok: false; error: string } => {
    if (!value.trim()) return { ok: true, value: {} };
    try {
        const parsed = JSON.parse(value);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return { ok: false, error: 'Sample input must be a JSON object.' };
        }
        return { ok: true, value: parsed as Record<string, unknown> };
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Invalid JSON.';
        return { ok: false, error: `Sample input JSON is invalid: ${message}` };
    }
};

const safeJsonParse = (value: string): Record<string, unknown> => {
    if (!value.trim()) return {};
    const parsed = JSON.parse(value);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    return parsed as Record<string, unknown>;
};

export const useUserNodeDesignerController = (params: {
    driver: WorkflowUiDriver;
    onNodesChanged?: (nodes: WorkflowUserNodeDefinition[]) => void;
    upstreamInputContext?: Record<string, unknown> | null;
    visible: boolean;
}) => {
    const { driver, onNodesChanged, upstreamInputContext, visible } = params;
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [nodes, setNodes] = useState<WorkflowUserNodeDefinition[]>([]);
    const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
    const [name, setName] = useState<string>('New User Node');
    const [description, setDescription] = useState<string>('');
    const [groupName, setGroupName] = useState<string>('User Nodes');
    const [schemaDraft, setSchemaDraft] = useState<UserNodeSchemaDraft>(createEmptyUserNodeSchemaDraft());
    const [schemaJson, setSchemaJsonState] = useState<string>(JSON.stringify(serializeUserNodeSchemaDraft(createEmptyUserNodeSchemaDraft()), null, 2));
    const [sampleInputJson, setSampleInputJson] = useState<string>('{}');
    const [workerTs, setWorkerTs] = useState<string>(DEFAULT_WORKER_SOURCE);
    const [validateTs, setValidateTs] = useState<string>(DEFAULT_VALIDATE_SOURCE);
    const [activeFile, setActiveFile] = useState<'worker.ts' | 'validate.ts'>('worker.ts');
    const [runtimeMode, setRuntimeMode] = useState<WorkflowPreviewRuntime>('auto');
    const [inputMode, setInputMode] = useState<'sample' | 'last' | 'upstream'>('sample');
    const lastInputRef = useRef<Record<string, unknown> | null>(null);
    const browserAbortRef = useRef<AbortController | null>(null);
    const previewSubscriptionsRef = useRef<Array<() => void>>([]);
    const socketClientRef = useRef<WorkflowRealtimeClient | null>(null);
    const onNodesChangedRef = useRef<typeof onNodesChanged>(onNodesChanged);
    const selectedNodeIdRef = useRef<string | null>(selectedNodeId);
    const nodesRef = useRef<WorkflowUserNodeDefinition[]>(nodes);
    const hasLoadedForVisibleSessionRef = useRef<boolean>(false);
    const previewStore = useUserNodePreviewStore();

    const selectedNode = useMemo(() => nodes.find((node) => node.id === selectedNodeId) ?? null, [nodes, selectedNodeId]);
    const slug = useMemo(
        () =>
            name
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, ''),
        [name]
    );
    const previewRuntimeSupport = useMemo(() => analyzeUserNodePreviewRuntimeSupport({ activeFile, workerSource: workerTs }), [activeFile, workerTs]);
    const browserRuntimeAllowed = previewRuntimeSupport.browserRuntimeAllowed;
    const { effectiveRuntime, runtimeFallbackReason } = useMemo(() => resolveUserNodePreviewRuntime(runtimeMode, previewRuntimeSupport), [previewRuntimeSupport, runtimeMode]);

    const resetPreviewSubscriptions = useCallback(() => {
        previewSubscriptionsRef.current.forEach((unsubscribe) => unsubscribe());
        previewSubscriptionsRef.current = [];
    }, []);

    useEffect(() => {
        onNodesChangedRef.current = onNodesChanged;
    }, [onNodesChanged]);

    useEffect(() => {
        selectedNodeIdRef.current = selectedNodeId;
    }, [selectedNodeId]);

    useEffect(() => {
        nodesRef.current = nodes;
    }, [nodes]);

    const setSchemaDraftAndJson = useCallback((nextDraft: UserNodeSchemaDraft) => {
        const serialized = serializeUserNodeSchemaDraft(nextDraft);
        setSchemaDraft(nextDraft);
        setSchemaJsonState(JSON.stringify(serialized, null, 2));
    }, []);

    const setSchemaJson = useCallback((value: string) => {
        setSchemaJsonState(value);
        try {
            setSchemaDraft(deserializeUserNodeSchemaDraft(safeJsonParse(value)));
        } catch {
            // Keep the last valid draft state while raw JSON is invalid.
        }
    }, []);

    const hydrateFromDefinition = useCallback((definition: WorkflowUserNodeDefinition | null) => {
        if (!definition) {
            const emptyDraft = createEmptyUserNodeSchemaDraft();
            setSelectedNodeId(null);
            setName('New User Node');
            setDescription('');
            setGroupName('User Nodes');
            setSchemaDraftAndJson(emptyDraft);
            setWorkerTs(DEFAULT_WORKER_SOURCE);
            setValidateTs(DEFAULT_VALIDATE_SOURCE);
            return;
        }
        const nextDraft = deserializeUserNodeSchemaDraft(definition.nodeSchema ?? {});
        setSelectedNodeId(definition.id);
        setName(definition.name);
        setDescription(definition.description ?? '');
        setGroupName(definition.groupName ?? 'User Nodes');
        setSchemaDraftAndJson(nextDraft);
        setWorkerTs(definition.sourceFiles['worker.ts'] ?? DEFAULT_WORKER_SOURCE);
        setValidateTs(definition.sourceFiles['validate.ts'] ?? DEFAULT_VALIDATE_SOURCE);
    }, [setSchemaDraftAndJson]);

    const reloadNodes = useCallback(async (options?: { showLoading?: boolean }) => {
        const shouldShowLoading = options?.showLoading ?? nodesRef.current.length === 0;
        if (shouldShowLoading) {
            setIsLoading(true);
        }
        try {
            const nextNodes = await driver.listWorkflowUserNodes(false);
            setNodes(nextNodes);
            onNodesChangedRef.current?.(nextNodes);
            if (nextNodes.length && !selectedNodeIdRef.current) {
                hydrateFromDefinition(nextNodes[0]);
            }
        } catch (error) {
            if (!isMissingGraphqlAuthTokenError(error)) {
                console.error('[UserNodeDesigner] Could not load user nodes.', error);
            }
        } finally {
            if (shouldShowLoading) {
                setIsLoading(false);
            }
        }
    }, [driver, hydrateFromDefinition]);

    useEffect(() => {
        if (!visible) {
            hasLoadedForVisibleSessionRef.current = false;
            return;
        }
        if (hasLoadedForVisibleSessionRef.current) {
            return;
        }
        hasLoadedForVisibleSessionRef.current = true;
        void reloadNodes({ showLoading: true });
    }, [reloadNodes, visible]);

    useEffect(
        () => () => {
            browserAbortRef.current?.abort();
            resetPreviewSubscriptions();
            socketClientRef.current = null;
        },
        [resetPreviewSubscriptions]
    );

    const saveNode = useCallback(async () => {
        const sourceFiles: WorkflowSourceFiles = { 'worker.ts': workerTs, 'validate.ts': validateTs };
        const nodeSchema = serializeUserNodeSchemaDraft(schemaDraft);
        const input = { name, description, groupName, slug, nodeSchema, sourceFiles };
        const saved = selectedNodeId ? await driver.updateWorkflowUserNode({ id: selectedNodeId, input }) : await driver.createWorkflowUserNode(input);
        const nextNodes = selectedNodeId ? nodes.map((node) => (node.id === saved.id ? saved : node)) : [saved, ...nodes];
        setNodes(nextNodes);
        setSelectedNodeId(saved.id);
        onNodesChangedRef.current?.(nextNodes);
    }, [description, driver, groupName, name, nodes, schemaDraft, selectedNodeId, slug, validateTs, workerTs]);

    const deleteNode = useCallback(async () => {
        if (!selectedNodeId) return;
        const deleted = await driver.deleteWorkflowUserNode(selectedNodeId);
        if (!deleted) return;
        const nextNodes = nodes.filter((node) => node.id !== selectedNodeId);
        setNodes(nextNodes);
        onNodesChangedRef.current?.(nextNodes);
        hydrateFromDefinition(nextNodes[0] ?? null);
    }, [driver, hydrateFromDefinition, nodes, selectedNodeId]);

    const stopRun = useCallback(() => {
        const runId = previewStore.state.runId;
        browserAbortRef.current?.abort();
        browserAbortRef.current = null;
        if (runId && socketClientRef.current) {
            socketClientRef.current.cancelPreview(runId);
        }
        previewStore.actions.stopRun('cancelled');
    }, [previewStore.actions, previewStore.state.runId]);

    const runPreview = useCallback(
        async (requestedRuntimeOverride?: WorkflowPreviewRuntime) => {
        if (!workerTs.trim()) {
            const message = 'worker.ts is required before running preview.';
            previewStore.actions.setDiagnostics({ errors: [message], message });
            return;
        }
        const requestedRuntime = requestedRuntimeOverride ?? runtimeMode;
        const runtimeSelection = resolveUserNodePreviewRuntime(requestedRuntime, previewRuntimeSupport);
        if (runtimeSelection.runtimeFallbackReason) {
            previewStore.actions.appendLog({
                runId: previewStore.state.runId ?? driver.createRequestId(),
                nodeId: selectedNode?.id ?? 'node_preview_1',
                source: 'runtime',
                line: runtimeSelection.runtimeFallbackReason,
                timestamp: new Date().toISOString(),
                runtime: runtimeSelection.effectiveRuntime
            });
        }
        let resolvedPreviewInput: Record<string, unknown> = {};
        if (inputMode === 'last') {
            resolvedPreviewInput = lastInputRef.current ?? {};
        } else if (inputMode === 'upstream') {
            if (!upstreamInputContext || typeof upstreamInputContext !== 'object') {
                const message = 'Workflow upstream input is unavailable. Select a node in the workflow graph or use sample input.';
                previewStore.actions.setDiagnostics({ errors: [message], message });
                previewStore.actions.appendLog({
                    runId: previewStore.state.runId ?? driver.createRequestId(),
                    nodeId: selectedNode?.id ?? 'node_preview_1',
                    source: 'runtime',
                    line: message,
                    timestamp: new Date().toISOString(),
                    runtime: runtimeSelection.effectiveRuntime
                });
                return;
            }
            resolvedPreviewInput = upstreamInputContext;
        } else {
            const parsedSampleInput = parseSampleInputJson(sampleInputJson);
            if ('error' in parsedSampleInput) {
                const parseError = parsedSampleInput.error;
                previewStore.actions.setDiagnostics({ errors: [parseError], message: parseError });
                previewStore.actions.appendLog({
                    runId: previewStore.state.runId ?? driver.createRequestId(),
                    nodeId: selectedNode?.id ?? 'node_preview_1',
                    source: 'runtime',
                    line: parseError,
                    timestamp: new Date().toISOString(),
                    runtime: runtimeSelection.effectiveRuntime
                });
                return;
            }
            resolvedPreviewInput = parsedSampleInput.value;
        }
        lastInputRef.current = resolvedPreviewInput;
        const previewNode: WorkflowUserNodeDefinition = selectedNode ?? {
            id: driver.createRequestId(),
            userId: 'current-user',
            name: name.trim() || 'Untitled Node',
            slug: slug || 'untitled-node',
            description: description || null,
            groupName: groupName || 'User Nodes',
            nodeSchema: serializeUserNodeSchemaDraft(schemaDraft),
            sourceFiles: { 'worker.ts': workerTs, 'validate.ts': validateTs },
            isActive: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            modelId: `user-node:${selectedNodeId ?? driver.createRequestId()}`
        };
        const runtime = runtimeSelection.effectiveRuntime;
        const runId = driver.createRequestId();
        previewStore.actions.startRun({
            runId,
            inputUsed: resolvedPreviewInput,
            requestedRuntime,
            effectiveRuntime: runtime,
            sourceMode: selectedNode && selectedNode.sourceFiles['worker.ts'] === workerTs && (selectedNode.sourceFiles['validate.ts'] ?? DEFAULT_VALIDATE_SOURCE) === validateTs ? 'saved' : 'unsaved',
            nodeModelId: previewNode.modelId,
            nodeDefinitionId: selectedNode?.id ?? null
        });
        const workflow = buildUserNodePreviewWorkflow({
            userNode: previewNode,
            runtime: {},
            schema: toUserNodeSchema(previewNode),
            settings: DEFAULT_SETTINGS
        });
        const overrides = {
            sourceFiles: { 'worker.ts': workerTs, 'validate.ts': validateTs },
            previewRuntime: runtime,
            previewInput: resolvedPreviewInput,
            previewMode: 'designer' as const
        };

        if (runtime === 'browser') {
            const abortController = new AbortController();
            browserAbortRef.current = abortController;
            try {
                const result = await workflowExecutor.executeNodeStep({
                    workflow,
                    nodeId: 'node_preview_1',
                    settings: DEFAULT_SETTINGS,
                    signal: abortController.signal,
                    overrides,
                    onPreviewLogLine: previewStore.actions.appendLog,
                    onPreviewState: previewStore.actions.applyStateEvent
                });
                previewStore.actions.setResult(result.result.output, result.result.status);
                previewStore.actions.stopRun('completed');
            } catch (error) {
                previewStore.actions.setRuntimeError(error instanceof Error ? error.message : 'Browser preview failed.');
                previewStore.actions.stopRun('failed');
            } finally {
                browserAbortRef.current = null;
            }
            return;
        }

        resetPreviewSubscriptions();
        if (!socketClientRef.current) {
            socketClientRef.current = driver.createRealtimeClient();
        }
        const socketClient = socketClientRef.current;
        previewSubscriptionsRef.current = [
            socketClient.addPreviewLogHandler((event) => event.runId === runId && previewStore.actions.appendLog(event)),
            socketClient.addPreviewStateHandler((event) => event.runId === runId && previewStore.actions.applyStateEvent(event)),
            socketClient.addPreviewResultHandler((payload) => {
                if (payload.run_id !== runId) return;
                previewStore.actions.setResult(payload.result?.output ?? null, payload.result?.status);
            }),
            socketClient.addPreviewErrorHandler((payload) => payload.run_id === runId && previewStore.actions.setRuntimeError(payload.error || 'Backend preview failed.')),
            socketClient.addPreviewStopHandler((payload) => {
                if (payload.run_id !== runId) return;
                previewStore.actions.stopRun(payload.reason === 'cancelled' ? 'cancelled' : payload.reason === 'failed' ? 'failed' : 'completed');
            })
        ];
        try {
            await socketClient.startPreview({
                workflow,
                nodeId: 'node_preview_1',
                settings: DEFAULT_SETTINGS,
                runId,
                overrides
            });
        } catch (error) {
            previewStore.actions.setRuntimeError(error instanceof Error ? error.message : 'Could not start backend preview.');
            previewStore.actions.stopRun('failed');
            resetPreviewSubscriptions();
        }
    },
        [
            browserRuntimeAllowed,
            description,
            driver,
            groupName,
            schemaDraft,
            inputMode,
            name,
            previewStore.actions,
            previewStore.state.runId,
            previewRuntimeSupport,
            resetPreviewSubscriptions,
            runtimeMode,
            sampleInputJson,
            schemaJson,
            selectedNode,
            selectedNodeId,
            slug,
            upstreamInputContext,
            validateTs,
            workerTs
        ]
    );

    const runPreviewOnServer = useCallback(async () => {
        setRuntimeMode('node');
        await runPreview('node');
    }, [runPreview]);

    return {
        state: {
            isLoading,
            nodes,
            selectedNode,
            selectedNodeId,
            name,
            description,
            groupName,
            schemaDraft,
            schemaJson,
            sampleInputJson,
            workerTs,
            validateTs,
            activeFile,
            runtimeMode,
            inputMode,
            slug,
            effectiveRuntime,
            browserRuntimeAllowed,
            runtimeFallbackReason,
            upstreamInputAvailable: Boolean(upstreamInputContext)
        },
        preview: previewStore,
        actions: {
            deleteNode,
            hydrateFromDefinition,
            reloadNodes,
            runPreview,
            runPreviewOnServer,
            saveNode,
            setActiveFile,
            setDescription,
            setGroupName,
            setInputMode,
            setName,
            setSampleInputJson,
            setSchemaDraft: setSchemaDraftAndJson,
            setRuntimeMode,
            setSchemaJson,
            setValidateTs,
            setWorkerTs,
            stopRun
        }
    };
};
