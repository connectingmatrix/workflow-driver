import { parseRecordValue } from '@workflow/ui/workflow/utils/value-utils';
import { WorkflowDefinition, WorkflowNodeStatus, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

const cloneRecordValue = (value: unknown): Record<string, unknown> => {
    const source = parseRecordValue(value);
    return JSON.parse(JSON.stringify(source)) as Record<string, unknown>;
};

export const patchNodeRuntimeState = (currentNode: WorkflowDefinition['nodes'][number], nextNode: WorkflowDefinition['nodes'][number]): WorkflowDefinition['nodes'][number] => {
    const nextPortsOut = nextNode.ports?.out && typeof nextNode.ports.out === 'object' ? (nextNode.ports.out as Record<string, unknown>) : null;
    const outputFromPorts = nextPortsOut && Object.prototype.hasOwnProperty.call(nextPortsOut, 'output') ? nextPortsOut.output : undefined;

    return {
        ...currentNode,
        runtime: nextNode.runtime,
        ports: nextNode.ports,
        input: nextNode.input ?? currentNode.input,
        output: nextNode.output ?? outputFromPorts ?? currentNode.output,
        status: nextNode.status,
        properties: nextNode.properties ?? nextNode.runtime,
        inspector: nextNode.inspector
            ? {
                  ...(currentNode.inspector ?? {}),
                  ...nextNode.inspector,
                  properties: nextNode.inspector.properties ?? nextNode.runtime
              }
            : currentNode.inspector
    };
};

export const isWorkflowNodeModel = (value: unknown): value is WorkflowDefinition['nodes'][number] => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const candidate = value as Partial<WorkflowDefinition['nodes'][number]>;
    return typeof candidate.id === 'string' && typeof candidate.modelId === 'string';
};

export const toErrorMessage = (value: unknown, fallback: string): string => {
    if (typeof value === 'string' && value.trim().length > 0) return value.trim();
    return fallback;
};

export const buildFailureResultFromStatus = (status: WorkflowNodeStatus | undefined, output: unknown, logs: string[], fallbackMessage: string): { error: string | null; logs: string[] } => {
    if (status !== WorkflowNodeStatusEnum.Failed) {
        return { error: null, logs };
    }

    const outputRecord = parseRecordValue(output);
    const errorMessage = toErrorMessage(outputRecord.error ?? outputRecord.message, fallbackMessage);
    const normalizedLogs = logs.length > 0 ? logs : [errorMessage];

    return {
        error: errorMessage,
        logs: normalizedLogs
    };
};

export const clearNodeExecutionArtifacts = (node: WorkflowDefinition['nodes'][number], statusOverride?: WorkflowNodeStatusEnum): WorkflowDefinition['nodes'][number] => {
    const nextRuntime = cloneRecordValue(node.runtime);
    delete nextRuntime.lastError;
    delete nextRuntime.error;
    delete nextRuntime.stack;

    const nextPortsOut = cloneRecordValue(node.ports?.out);
    nextPortsOut.output = null;
    if (Array.isArray(nextPortsOut.__activeOutputs)) {
        nextPortsOut.__activeOutputs = [];
    }

    return {
        ...node,
        status: statusOverride ?? node.status,
        runtime: nextRuntime,
        properties: nextRuntime,
        inspector: node.inspector
            ? {
                  ...node.inspector,
                  properties: nextRuntime
              }
            : node.inspector,
        output: null,
        ports: {
            ...(node.ports ?? { in: {}, out: {} }),
            out: nextPortsOut
        }
    };
};
