#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
index = Path('src/index.ts')
if index.exists():
    s = index.read_text()
    line = "export * from './executor/agent-runtime';"
    if line not in s:
        index.write_text(s.rstrip() + "\n" + line + "\n")
PY
