import { describe, expect, it } from 'vitest';
import { formatPropertyLabel } from '@workflow/ui/workflow/components/inspector/InspectorPropertyField';

describe('formatPropertyLabel', () => {
    it('formats camelCase keys into capitalized labels', () => {
        expect(formatPropertyLabel('leftPath')).toBe('Left Path');
        expect(formatPropertyLabel('nodeLibraryId')).toBe('Node Library Id');
    });

    it('formats snake_case and kebab-case keys into capitalized labels', () => {
        expect(formatPropertyLabel('compare_value')).toBe('Compare Value');
        expect(formatPropertyLabel('request-method')).toBe('Request Method');
    });
});
