/** @vitest-environment jsdom */
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import { WorkflowDefinition } from '@workflow/ui/workflow/types';

vi.mock('@workflow/ui/workflow/components/toolbar/Toolbar', () => ({ default: () => <div data-testid="workflow-toolbar" /> }));
vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({ default: () => null }));
vi.mock('@/common/components/logs/JsonlLogsDialog', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({ default: () => null }));
vi.mock('primereact/contextmenu', () => ({ ContextMenu: React.forwardRef((_: unknown, ref) => (React.useImperativeHandle(ref, () => ({ show: () => undefined, hide: () => undefined })), null)) }));
vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({
    default: (props: { nodes: Array<{ id: string; position: { x: number; y: number } }>; onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number } }) => void; onNodeClick?: (event: MouseEvent, node: { id: string; position: { x: number; y: number } }) => void }) => (
        React.useEffect(() => props.onInit({ screenToFlowPosition: ({ x, y }) => ({ x, y }) }), [props.onInit]),
        <button type="button" onClick={() => props.nodes[1] && props.onNodeClick?.(new MouseEvent('click', { bubbles: true }), props.nodes[1])}>
            Open Node
        </button>
    )
}));
vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({
    default: (props: { visible: boolean; readOnly?: boolean; config?: { nodeId?: string } | null }) =>
        props.visible ? (
            <div data-testid="workflow-node-inspector">
                <span data-testid="workflow-node-inspector-node-id">{props.config?.nodeId ?? ''}</span>
                <span data-testid="workflow-node-inspector-readonly">{String(Boolean(props.readOnly))}</span>
            </div>
        ) : null
}));
vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (importOriginal) => ({ ...(await importOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>()), prewarmJavascriptRuntimeFrame: vi.fn(async () => undefined) }));
vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({ listWorkflowUserNodes: vi.fn(async () => []) }));

const driver: WorkflowUiDriver = {
    createRequestId: () => 'req_1',
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({ connect: vi.fn(), disconnect: vi.fn(), startPreview: vi.fn(async () => undefined), cancelPreview: vi.fn(), addPreviewLogHandler: vi.fn(() => () => undefined), addPreviewStateHandler: vi.fn(() => () => undefined), addPreviewResultHandler: vi.fn(() => () => undefined), addPreviewErrorHandler: vi.fn(() => () => undefined), addPreviewStopHandler: vi.fn(() => () => undefined) }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: createEmptyWorkflow('wf_1'), logs: [] })),
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};
const nodeCatalog: WorkflowNodeCatalog = { modules: [], getAllNodeSchemas: () => ({}), getNodeLibraryItems: () => [], getNodeModuleById: () => null, resolveNodeSchema: () => ({ documentation: {} }) as never, isLocalCapableNodeModel: () => true };
const createWorkflowFixture = (): WorkflowDefinition => {
    const workflow = createEmptyWorkflow('wf_execution_view');
    const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
    const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
    const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
    workflow.nodes = [startNode, codeNode, endNode];
    workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];
    return workflow;
};

afterEach(() => cleanup());

describe('DesignerDialog execution view', () => {
    it('opens the inspector on single click and keeps it read-only', () => {
        render(<DesignerDialog visible mode="execution" workflow={createWorkflowFixture()} driver={driver} nodeCatalog={nodeCatalog} onHide={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Open Node' }));

        expect(screen.getByTestId('workflow-node-inspector-node-id').textContent).toBe('node_2');
        expect(screen.getByTestId('workflow-node-inspector-readonly').textContent).toBe('true');
    });
});
