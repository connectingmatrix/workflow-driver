import React from 'react';

interface WorkflowSettingsHeaderProps {
    workflowId?: string | null;
    onClose: () => void;
}

export const WorkflowSettingsHeader: React.FC<WorkflowSettingsHeaderProps> = ({ workflowId, onClose }) => (
    <header className="wf-workspace-settings__header">
        <div className="wf-workspace-settings__header-title">
            <div className="wf-workspace-settings__header-icon"><i className="pi pi-cog" aria-hidden /></div>
            <div>
                <h2>Workflow settings</h2>
                <p>Configure runtime, connectivity, and session defaults for this workflow.</p>
            </div>
        </div>
        <div className="wf-workspace-settings__header-actions">
            {workflowId ? <div className="wf-workspace-settings__workflow-id">Workflow ID · {workflowId}</div> : null}
            <button type="button" className="wf-workspace-settings__close" onClick={onClose} aria-label="Close workflow settings">
                <i className="pi pi-times" aria-hidden />
            </button>
        </div>
    </header>
);
