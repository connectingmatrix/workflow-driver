/** @vitest-environment jsdom */
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import BaseNode, { BaseNodeData } from '@workflow/ui/workflow/nodes/BaseNode';
import { WorkflowNodeKindEnum, WorkflowNodePortSideEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

vi.mock('@xyflow/react', () => ({
    Handle: ({ id, type, className, style }: { id?: string; type?: string; className?: string; style?: Record<string, unknown> }) => (
        <div
            data-testid={`node-handle-${type}-${id}`}
            data-style-top={typeof style?.top === 'string' ? style.top : ''}
            data-style-bottom={typeof style?.bottom === 'string' ? style.bottom : ''}
            data-style-left={typeof style?.left === 'string' ? style.left : ''}
            className={className}
        />
    ),
    Position: {
        Left: 'left',
        Right: 'right',
        Top: 'top',
        Bottom: 'bottom'
    }
}));

const createBaseNodeData = (overrides: Partial<BaseNodeData> = {}): BaseNodeData => ({
    nodeId: 'node_1',
    title: 'Code',
    nodeTypeLabel: 'Code',
    kind: WorkflowNodeKindEnum.Process,
    status: WorkflowNodeStatusEnum.Stopped,
    isActive: false,
    isCompleted: false,
    isLoading: false,
    progressIndicatorMode: null,
    nameEditable: true,
    render: {
        iconClass: 'pi pi-code',
        nodeWidth: 236,
        nodeHeight: 248,
        iconSize: 48
    },
    inputs: [],
    outputs: [],
    commands: [],
    isEnabled: true,
    outputConnectionCounts: {},
    ...overrides
});

afterEach(() => {
    cleanup();
});

describe('BaseNode progress indicators', () => {
    it('renders local spinner indicator when local execution is active', () => {
        const data = createBaseNodeData({ progressIndicatorMode: 'local' });
        const view = render(<BaseNode {...({ id: 'node_1', data, selected: false } as any)} />);
        expect(view.container.querySelector('.base-node__loading-spinner')).not.toBeNull();
        expect(view.container.querySelector('.base-node__server-running')).toBeNull();
    });

    it('renders blinking lightning indicator when server execution is active', () => {
        const data = createBaseNodeData({ progressIndicatorMode: 'server' });
        const view = render(<BaseNode {...({ id: 'node_1', data, selected: false } as any)} />);
        expect(view.container.querySelector('.base-node__server-running')).not.toBeNull();
        expect(screen.getByLabelText('Server node running')).toBeTruthy();
        expect(view.container.querySelector('.base-node__loading-spinner')).toBeNull();
    });

    it('keeps standard input and output handles visible while command ports are present', () => {
        const data = createBaseNodeData({
            inputs: [{ id: 'input', name: 'Input', rules: { side: WorkflowNodePortSideEnum.Left, order: 1 } }],
            outputs: [{ id: 'output', name: 'Output', rules: { side: WorkflowNodePortSideEnum.Right, order: 1 } }],
            commands: [{ id: 'llm', name: 'LLM', rules: { side: WorkflowNodePortSideEnum.Bottom, order: 1, portType: 'bi-directional' } }]
        });

        const view = render(<BaseNode {...({ id: 'node_1', data, selected: false } as any)} />);

        expect(screen.getByTestId('node-handle-target-in:input')).toBeTruthy();
        expect(screen.getByTestId('node-handle-source-out:output')).toBeTruthy();
        expect(screen.getByTestId('node-handle-target-cmd:llm')).toBeTruthy();
        expect(screen.getByTestId('node-handle-source-cmd:llm')).toBeTruthy();
        expect(view.container.querySelectorAll('.base-node__command-anchor')).toHaveLength(1);
    });

    it('renders bottom-side ports below the node name with dedicated bottom markup', () => {
        const data = createBaseNodeData({
            inputs: [{ id: 'input', name: 'Input', rules: { side: WorkflowNodePortSideEnum.Bottom, order: 1 } }],
            outputs: [{ id: 'output', name: 'Output', rules: { side: WorkflowNodePortSideEnum.Bottom, order: 2 } }],
            commands: [{ id: 'llm', name: 'LLM', rules: { side: WorkflowNodePortSideEnum.Bottom, order: 3, portType: 'bi-directional' } }]
        });

        const view = render(<BaseNode {...({ id: 'node_1', data, selected: false } as any)} />);

        expect(view.container.querySelectorAll('.base-node__bottom-branch')).toHaveLength(3);
        expect(view.container.querySelector('.base-node__command-anchor--bottom')).not.toBeNull();
        expect(screen.getByTestId('node-handle-target-in:input')).toBeTruthy();
        expect(screen.getByTestId('node-handle-source-out:output')).toBeTruthy();
        expect(screen.getByTestId('node-handle-target-cmd:llm')).toBeTruthy();
        expect(screen.getByTestId('node-handle-target-cmd:llm').getAttribute('data-style-top')).toBe('100%');
        expect(screen.getByTestId('node-handle-source-cmd:llm').getAttribute('data-style-top')).toBe('100%');
    });

    it('shows the output quick-add button by default for disconnected outputs', () => {
        const onQuickAddFromPort = vi.fn();
        const data = createBaseNodeData({
            outputs: [{ id: 'output', name: 'Output', rules: { side: WorkflowNodePortSideEnum.Right, order: 1 } }],
            onQuickAddFromPort
        });

        render(<BaseNode {...({ id: 'node_1', data, selected: true } as any)} />);

        const quickAddButtons = screen.getAllByTitle('Add node from Output');
        fireEvent.click(quickAddButtons[0] as HTMLElement);

        expect(onQuickAddFromPort).toHaveBeenCalledWith(expect.objectContaining({ nodeId: 'node_1', outputPortId: 'output' }));
    });
});
