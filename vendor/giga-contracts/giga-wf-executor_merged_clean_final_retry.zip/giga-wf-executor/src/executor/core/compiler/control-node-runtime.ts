import {
    WorkflowCommandToolSpec,
    WorkerPayload,
    WorkerRuntimeEnvironment,
    WorkflowControlNodeExecuteInputsArgs,
    WorkerValidateResult,
    WorkflowControlNodeExecuteArgs,
    WorkflowControlNodeSnapshot,
    WorkflowControlNodeValidateArgs,
    WorkflowNodeHandlerContext,
    WorkflowNodeHandlerResult,
    WorkflowNodeModel
} from '../../../types';
import { applyControlNodePatch, buildControlNodeFacadeMap } from './control-node-facade';
import {
    buildWorkerPayload,
    loadPreviewValidator,
    loadWorkerModule,
    normalizeValidationResult,
    resolveNodeSourceFilesFromHelper,
    WorkerCompiledModuleLoader
} from './worker-module-loader';
import { TypeScriptModuleLoader } from './typescript-compiler';

const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as T)
        : ({} as T);

const resolvePeerNode = (context: WorkflowNodeHandlerContext, nodeId: string): WorkflowNodeModel => {
    const node = context.workflow.nodes.find((entry) => entry.id === nodeId);
    if (!node) throw new Error(`Control node "${nodeId}" was not found.`);
    return node;
};

const buildPeerContext = (
    context: WorkflowNodeHandlerContext,
    nodeId: string,
    args?: WorkflowControlNodeValidateArgs | WorkflowControlNodeExecuteArgs
): WorkflowNodeHandlerContext => {
    const baseNode = resolvePeerNode(context, nodeId);
    const patchedNode = args?.patch ? applyControlNodePatch(baseNode, args.patch) : baseNode;
    return {
        ...context,
        node: patchedNode,
        input: args?.input ?? toRecord(patchedNode.ports?.in)
    };
};

export interface RuntimeControlNodeGroupArgs {
    context: WorkflowNodeHandlerContext;
    helperId: string;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    executePeerInputs: (args: { nodeId: string; args?: WorkflowControlNodeExecuteInputsArgs }) => Promise<WorkflowControlNodeSnapshot>;
    executePeer: (args: { nodeId: string; input?: Record<string, Record<string, unknown>>; patch?: WorkflowControlNodeExecuteArgs['patch'] }) => Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }>;
    executeHelpers?: Parameters<typeof resolveNodeSourceFilesFromHelper>[0]['executeHelpers'];
    typescriptModuleLoader?: TypeScriptModuleLoader;
    loadCompiledModule: WorkerCompiledModuleLoader;
}

export const buildRuntimeControlNodeGroups = async (args: RuntimeControlNodeGroupArgs): Promise<WorkerPayload['NODE']['CONTROL_NODES']> => {
    return buildControlNodeFacadeMap({
        context: args.context,
        validatePeer: async ({ nodeId, args: validationArgs }) => {
            const peerContext = buildPeerContext(args.context, nodeId, validationArgs);
            const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
                executeHelpers: args.executeHelpers,
                context: peerContext,
                modelId: peerContext.node.modelId
            });
            const module = await loadWorkerModule({
                modelId: peerContext.node.modelId,
                workflow: peerContext.workflow,
                helperId: args.helperId,
                runtimeEnvironment: args.runtimeEnvironment,
                typescriptModuleLoader: args.typescriptModuleLoader,
                resolvedSourceFiles,
                loadCompiledModule: args.loadCompiledModule
            });
            const previewValidator = await loadPreviewValidator({
                modelId: peerContext.node.modelId,
                workflow: peerContext.workflow,
                helperId: args.helperId,
                runtimeEnvironment: args.runtimeEnvironment,
                typescriptModuleLoader: args.typescriptModuleLoader,
                resolvedSourceFiles,
                loadCompiledModule: args.loadCompiledModule
            });

            let result: WorkerValidateResult = { ok: true, errors: [], warnings: [] };
            if (previewValidator) {
                result = normalizeValidationResult(await previewValidator(buildWorkerPayload(peerContext, {}, null, args.runtimeEnvironment)));
                if (!result.ok) return result;
            }
            return normalizeValidationResult(await module.validate(buildWorkerPayload(peerContext, {}, null, args.runtimeEnvironment)));
        },
        executePeerInputs: async ({ nodeId, args: executeInputsArgs }) => {
            const nextNode = await args.executePeerInputs({
                nodeId,
                args: executeInputsArgs
            });
            return nextNode;
        },
        executePeer: async ({ nodeId, args: executeArgs }) =>
            args.executePeer({
                nodeId,
                input: executeArgs?.input,
                patch: executeArgs?.patch
            }),
        commandToolSpecPeer: async ({ nodeId }): Promise<WorkflowCommandToolSpec | null> => {
            const peerContext = buildPeerContext(args.context, nodeId);
            const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
                executeHelpers: args.executeHelpers,
                context: peerContext,
                modelId: peerContext.node.modelId
            });
            const module = await loadWorkerModule({
                modelId: peerContext.node.modelId,
                workflow: peerContext.workflow,
                helperId: args.helperId,
                runtimeEnvironment: args.runtimeEnvironment,
                typescriptModuleLoader: args.typescriptModuleLoader,
                resolvedSourceFiles,
                loadCompiledModule: args.loadCompiledModule
            });
            if (typeof module.commandToolSpec !== 'function') return null;
            return (await module.commandToolSpec(buildWorkerPayload(peerContext, {}, null, args.runtimeEnvironment))) ?? null;
        }
    });
};
