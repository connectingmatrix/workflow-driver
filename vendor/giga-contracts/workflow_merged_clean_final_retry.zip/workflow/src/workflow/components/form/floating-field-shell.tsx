import React from 'react';
import { classNames } from 'primereact/utils';

interface FloatingFieldShellProps {
    id: string;
    label: string;
    active: boolean;
    multiline?: boolean;
    disabled?: boolean;
    invalid?: boolean;
    className?: string;
    children: React.ReactNode;
}

const FloatingFieldShell: React.FC<FloatingFieldShellProps> = ({ id, label, active, multiline = false, disabled = false, invalid = false, className, children }) => (
    <div
        className={classNames(
            'wf-float-field',
            {
                'wf-float-field--active': active,
                'wf-float-field--multiline': multiline,
                'wf-float-field--disabled': disabled,
                'wf-float-field--invalid': invalid
            },
            className
        )}
    >
        <label htmlFor={id} className="wf-float-field__label">
            {label}
        </label>
        <div className="wf-float-field__control">{children}</div>
    </div>
);

export default FloatingFieldShell;
export type { FloatingFieldShellProps };
