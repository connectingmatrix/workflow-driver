import { formatPropertyLabel } from '@workflow/ui/workflow/components/inspector/InspectorPropertyField';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';
import type { WorkspaceFieldModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

export const parseWorkspaceFieldString = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null || typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

export const parseWorkspaceFieldNumber = (value: unknown): number | null => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    const parsed = Number(String(value ?? '').trim());
    return Number.isFinite(parsed) ? parsed : null;
};

export const resolveWorkspaceFieldLabel = (field: WorkspaceFieldModel): string => field.definition.label ?? formatPropertyLabel(field.key);

export const shouldWorkspaceFieldSpanFullWidth = (field: WorkspaceFieldModel): boolean => {
    if (field.presentation === 'execution-select' || field.presentation === 'execution-toggle') {
        return false;
    }
    if (field.key === 'name' || field.key === 'description' || field.key === 'compareValue' || field.key === 'leftPath' || field.key === 'operator') return true;
    return ['textarea', 'markdown', 'json', 'headers', 'object-array'].includes(String(field.definition.type ?? ''));
};

export const isWorkspaceFieldEditable = (definition: WorkflowNodeFieldDefinition): boolean => definition.editable !== false && !definition.auto;
