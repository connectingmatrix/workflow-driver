import React from 'react';
import { Handle } from '@xyflow/react';
import { WorkflowNodePortProperty, WorkflowNodePortSideEnum } from '@workflow/ui/workflow/types';
import { buildCommandHandleStyle, buildPortHandleStyle, isBottomPortSide, resolvePortPosition } from '@workflow/ui/workflow/nodes/base-node-port-layout.utils';

interface BaseNodeCommandPortProps {
    port: { id: string; label: string; rules: WorkflowNodePortProperty };
    side: WorkflowNodePortSideEnum;
    index: number;
    total: number;
}

const BaseNodeCommandPortComponent: React.FC<BaseNodeCommandPortProps> = ({ port, side, index, total }) => {
    const style = buildPortHandleStyle(side, index, total);
    const handleStyle = buildCommandHandleStyle(side, index, total);
    const labelClass = isBottomPortSide(side) ? 'base-node__bottom-branch base-node__bottom-branch--command' : `base-node__output-branch base-node__output-branch--${side}`;

    return (
        <>
            <Handle id={`cmd:${port.id}`} type="target" position={resolvePortPosition(side)} className={`base-node__handle base-node__handle--input base-node__handle--bi base-node__handle--command-hitbox base-node__handle--${side}`} style={handleStyle} />
            <Handle id={`cmd:${port.id}`} type="source" position={resolvePortPosition(side)} className={`base-node__handle base-node__handle--output base-node__handle--bi base-node__handle--command-hitbox base-node__handle--${side}`} style={handleStyle} />
            <div className={`base-node__command-anchor base-node__command-anchor--${side}`} style={style} aria-hidden="true">
                <span className="base-node__command-anchor-dot" />
            </div>
            <div className={labelClass} style={style}>
                <span className={isBottomPortSide(side) ? 'base-node__bottom-branch-line' : 'base-node__output-branch-line'} />
                <span className={isBottomPortSide(side) ? 'base-node__bottom-branch-label' : 'base-node__output-branch-label'}>{port.label}</span>
            </div>
        </>
    );
};

const BaseNodeCommandPort = React.memo(BaseNodeCommandPortComponent);

export default BaseNodeCommandPort;
