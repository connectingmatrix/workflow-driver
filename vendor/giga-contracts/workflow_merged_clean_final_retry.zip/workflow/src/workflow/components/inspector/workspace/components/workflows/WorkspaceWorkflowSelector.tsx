import React from 'react';
import type { WorkflowExecutableOption } from '@workflow/ui/workflow/types';
import type { WorkspaceWorkflowSelectorModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceAsyncSelectorStateView } from '@workflow/ui/workflow/components/inspector/workspace/components/credentials/WorkspaceCredentialState';
import { WorkspaceWorkflowOptionRow } from '@workflow/ui/workflow/components/inspector/workspace/components/workflows/WorkspaceWorkflowOptionRow';

interface WorkspaceWorkflowSelectorProps {
    model: WorkspaceWorkflowSelectorModel;
    readOnly?: boolean;
    onChange: (workflow: WorkflowExecutableOption | null) => void;
}

const STATE_LABELS = {
    loading: 'Loading workflows…',
    ready: '',
    empty: 'No workflows available.',
    error: 'Workflows could not be loaded.'
} as const;

export const WorkspaceWorkflowSelector: React.FC<WorkspaceWorkflowSelectorProps> = ({ model, readOnly = false, onChange }) => {
    const [isOpen, setIsOpen] = React.useState<boolean>(false);
    const containerRef = React.useRef<HTMLDivElement | null>(null);
    const selectedOption = React.useMemo(() => model.options.find((option) => option.workflowId === model.selectedWorkflowId) ?? null, [model.options, model.selectedWorkflowId]);

    React.useEffect(() => {
        const handlePointerDown = (event: MouseEvent) => {
            if (!containerRef.current || containerRef.current.contains(event.target as Node)) return;
            setIsOpen(false);
        };
        document.addEventListener('mousedown', handlePointerDown);
        return () => document.removeEventListener('mousedown', handlePointerDown);
    }, []);

    React.useEffect(() => {
        if (model.state !== 'ready') setIsOpen(false);
    }, [model.state]);

    return (
        <div className="cnw-credential-selector" ref={containerRef}>
            <div className="cnw-credential-selector__header">
                <div>
                    <h4 className="cnw-subsection__title">{model.title}</h4>
                    {model.description ? <p className="cnw-section-block__description">{model.description}</p> : null}
                </div>
                {selectedOption ? <button type="button" className="cnw-credential-selector__clear" onClick={() => onChange(null)} disabled={readOnly}>Clear</button> : null}
            </div>
            <WorkspaceAsyncSelectorStateView labels={STATE_LABELS} message={model.message} state={model.state} />
            {model.state === 'ready' ? (
                <>
                    <button type="button" className={`cnw-credential-selector__trigger${isOpen ? ' cnw-credential-selector__trigger--open' : ''}`} onClick={() => setIsOpen((previous) => !previous)} disabled={readOnly}>
                        <span className="cnw-credential-selector__trigger-main">
                            <span className="cnw-credential-selector__trigger-copy">
                                <strong>{selectedOption?.workflowName ?? 'Select a workflow'}</strong>
                                <span>{selectedOption ? `${selectedOption.scopeTag} · ${selectedOption.status || 'published'}` : 'Published workflow reference'}</span>
                            </span>
                        </span>
                        <span className="cnw-credential-selector__trigger-caret">▾</span>
                    </button>
                    {isOpen ? (
                        <div className="cnw-credential-selector__menu">
                            {model.options.map((option) => (
                                <WorkspaceWorkflowOptionRow
                                    key={option.workflowId}
                                    option={option}
                                    selected={option.workflowId === model.selectedWorkflowId}
                                    onSelect={(workflowId) => {
                                        onChange(model.options.find((option) => option.workflowId === workflowId) ?? null);
                                        setIsOpen(false);
                                    }}
                                />
                            ))}
                        </div>
                    ) : null}
                </>
            ) : null}
        </div>
    );
};
