import React from 'react';
import type { WorkspaceAsyncSelectorState } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface WorkspaceAsyncSelectorStateProps {
    state: WorkspaceAsyncSelectorState;
    message?: string;
    labels: Record<WorkspaceAsyncSelectorState, string>;
}

const CREDENTIAL_STATE_LABELS: Record<WorkspaceAsyncSelectorState, string> = {
    loading: 'Loading credentials…',
    ready: '',
    empty: 'No credentials available.',
    error: 'Credentials could not be loaded.'
};

export const WorkspaceAsyncSelectorStateView: React.FC<WorkspaceAsyncSelectorStateProps> = ({ state, message, labels }) => {
    if (state === 'ready') {
        return null;
    }

    return (
        <div className={`cnw-credential-state cnw-credential-state--${state}`}>
            <strong>{labels[state]}</strong>
            {message ? <span>{message}</span> : null}
        </div>
    );
};

interface WorkspaceCredentialStateProps {
    state: WorkspaceAsyncSelectorState;
    message?: string;
}

export const WorkspaceCredentialState: React.FC<WorkspaceCredentialStateProps> = ({ state, message }) => (
    <WorkspaceAsyncSelectorStateView labels={CREDENTIAL_STATE_LABELS} message={message} state={state} />
);
