import React from 'react';
import InspectorObjectArrayField from '@workflow/ui/workflow/components/inspector/fields/InspectorObjectArrayField';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';

interface WorkspaceObjectArrayFieldProps {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (fieldKey: string, value: unknown) => void;
}

export const WorkspaceObjectArrayField: React.FC<WorkspaceObjectArrayFieldProps> = ({ fieldKey, definition, value, variableContext, variableSuggestions, onChange }) => {
    return <InspectorObjectArrayField fieldKey={fieldKey} definition={definition} value={value} onChange={onChange} variableContext={variableContext} variableSuggestions={variableSuggestions} />;
};
