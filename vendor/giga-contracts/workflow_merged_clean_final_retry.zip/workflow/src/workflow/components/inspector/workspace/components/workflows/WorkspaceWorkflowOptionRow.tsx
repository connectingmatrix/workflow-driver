import React from 'react';
import type { WorkflowExecutableOption } from '@workflow/ui/workflow/types';

interface WorkspaceWorkflowOptionRowProps {
    option: WorkflowExecutableOption;
    selected: boolean;
    onSelect: (workflowId: string) => void;
}

export const WorkspaceWorkflowOptionRow: React.FC<WorkspaceWorkflowOptionRowProps> = ({ option, selected, onSelect }) => (
    <button type="button" className={`cnw-credential-option${selected ? ' cnw-credential-option--selected' : ''}`} onClick={() => onSelect(option.workflowId)}>
        <span className="cnw-credential-option__content">
            <span className="cnw-credential-option__title">{option.workflowName}</span>
            <span className="cnw-credential-option__meta">
                <span>{option.scopeTag}</span>
                <span>{option.status || 'published'}</span>
            </span>
        </span>
        <span className={`cnw-credential-option__scope cnw-credential-option__scope--${option.scope}`}>{option.scopeTag}</span>
    </button>
);
