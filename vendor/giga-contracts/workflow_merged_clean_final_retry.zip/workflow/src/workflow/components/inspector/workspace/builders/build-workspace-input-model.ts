import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowInspectorModuleDefinition } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import type { WorkspaceInputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WORKSPACE_ACTION_IDS } from '@workflow/ui/workflow/components/inspector/workspace/constants';
import { buildWorkspaceInputRows } from '@workflow/ui/workflow/components/inspector/workspace/builders/workspace-input.utils';

interface BuildWorkspaceInputModelArgs {
    config: WorkflowInspectorConfig;
    moduleDefinition: WorkflowInspectorModuleDefinition | null;
    activeTab: string;
}

export const buildWorkspaceInputPanelModel = ({ config, moduleDefinition, activeTab }: BuildWorkspaceInputModelArgs): WorkspaceInputPanelModel => {
    const tableRows = buildWorkspaceInputRows(config.input ?? {});
    const tabs = [
        { id: 'table', label: 'Table' },
        { id: 'json', label: 'JSON' },
        { id: 'document', label: 'Document' }
    ];

    if (config.controlNodes && Object.keys(config.controlNodes).length > 0) {
        tabs.push({ id: 'control-nodes', label: 'Control Nodes' });
    }

    const requestedTab = tabs.some((tab) => tab.id === activeTab) ? activeTab : tabs[0]?.id ?? 'table';
    return {
        title: 'Input',
        description: 'Tabular inputs and node documentation',
        icon: moduleDefinition?.workspace?.input?.icon ?? 'database',
        tabs,
        activeTab: requestedTab,
        emptyState: {
            icon: moduleDefinition?.workspace?.input?.emptyState?.icon ?? 'document',
            title: moduleDefinition?.workspace?.input?.emptyState?.title ?? 'No input values yet',
            description:
                moduleDefinition?.workspace?.input?.emptyState?.description ??
                'Connect a dataset or document to preview incoming values for this node.',
            action: {
                id: WORKSPACE_ACTION_IDS.AddInput,
                label: 'Add input',
                tone: 'secondary'
            }
        },
        acceptedFormats: moduleDefinition?.workspace?.input?.acceptedFormats,
        featureItems: moduleDefinition?.workspace?.input?.featureItems,
        tableRows,
        jsonValue: config.input ?? {},
        documentation: config.documentation,
        nodeTypeLabel: config.nodeTypeLabel,
        controlNodes: config.controlNodes ?? null
    };
};
