import React from 'react';
import type { WorkspaceAsyncSelectorState } from '@workflow/ui/workflow/components/inspector/workspace/types';

export interface WorkspaceAsyncSelectorOptionsState<TOption> {
    status: WorkspaceAsyncSelectorState;
    options: TOption[];
    message?: string;
    reload: () => void;
}

interface UseWorkspaceAsyncSelectorOptionsArgs<TOption> {
    visible: boolean;
    enabled: boolean;
    emptyMessage: string;
    missingFetcherMessage: string;
    emptyFetcherResultMessage: string;
    loadOptions?: () => Promise<TOption[]>;
    normalizeOptions?: (options: TOption[]) => TOption[];
}

export const useWorkspaceAsyncSelectorOptions = <TOption,>({
    visible,
    enabled,
    emptyMessage,
    missingFetcherMessage,
    emptyFetcherResultMessage,
    loadOptions,
    normalizeOptions
}: UseWorkspaceAsyncSelectorOptionsArgs<TOption>): WorkspaceAsyncSelectorOptionsState<TOption> => {
    const [state, setState] = React.useState<Omit<WorkspaceAsyncSelectorOptionsState<TOption>, 'reload'>>({ status: 'empty', options: [], message: emptyMessage });
    const [reloadVersion, setReloadVersion] = React.useState(0);
    const reload = React.useCallback(() => {
        setReloadVersion((value) => value + 1);
    }, []);

    React.useEffect(() => {
        if (!visible) return;
        if (!enabled) return setState({ status: 'empty', options: [], message: emptyMessage });
        if (!loadOptions) return setState({ status: 'error', options: [], message: missingFetcherMessage });
        let cancelled = false;
        setState((previous) => ({ status: 'loading', options: previous.options, message: undefined }));
        void loadOptions()
            .then((options) => {
                if (cancelled) return;
                const nextOptions = normalizeOptions ? normalizeOptions(options) : options;
                if (!nextOptions.length) return setState({ status: 'empty', options: [], message: emptyFetcherResultMessage });
                setState({ status: 'ready', options: nextOptions, message: undefined });
            })
            .catch((error) => {
                if (!cancelled) setState({ status: 'error', options: [], message: error instanceof Error ? error.message : missingFetcherMessage });
            });
        return () => {
            cancelled = true;
        };
    }, [emptyFetcherResultMessage, emptyMessage, enabled, loadOptions, missingFetcherMessage, normalizeOptions, reloadVersion, visible]);

    return {
        ...state,
        reload
    };
};
