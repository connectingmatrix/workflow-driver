import fs from 'node:fs/promises';
import path from 'node:path';

export type ArchiveTreeEntry = { path: string; name: string; type: 'file' | 'dir'; bytes?: number | null };

const walk = async (dir: string, base = dir): Promise<ArchiveTreeEntry[]> => {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const rows: ArchiveTreeEntry[] = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    const rel = path.relative(base, full);
    if (entry.isDirectory()) rows.push({ path: rel, name: entry.name, type: 'dir' }, ...(await walk(full, base)));
    else if (entry.isFile()) rows.push({ path: rel, name: entry.name, type: 'file', bytes: (await fs.stat(full)).size });
  }
  return rows;
};

export const buildExtractedFileTree = async (directory: string) => ({ root: directory, entries: await walk(directory) });
