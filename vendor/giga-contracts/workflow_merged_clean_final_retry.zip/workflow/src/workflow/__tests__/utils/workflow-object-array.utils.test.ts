import { describe, expect, it } from 'vitest';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import { buildEditorPropertiesState, parseEditorPropertyValues } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';

const FIELDS = {
    headers: {
        type: WorkflowNodeFieldTypeEnum.ObjectArray,
        valueMode: 'record',
        keyField: 'key',
        valueField: 'value',
        subFields: {
            key: { label: 'Key', required: true, styleCol: 5 },
            value: { label: 'Value', required: true, styleCol: 6 }
        }
    },
    stdioArgs: {
        type: WorkflowNodeFieldTypeEnum.ObjectArray,
        valueMode: 'string-array',
        valueField: 'value',
        subFields: {
            value: { label: 'Value', required: true, styleCol: 11 }
        }
    }
};

describe('workflow object-array field parsing', () => {
    it('builds editor rows from canonical runtime values', () => {
        const state = buildEditorPropertiesState(FIELDS, {
            headers: { Authorization: 'Bearer token' },
            stdioArgs: ['--debug', '--trace']
        });

        expect(state.headers).toEqual([{ key: 'Authorization', value: 'Bearer token' }]);
        expect(state.stdioArgs).toEqual([{ value: '--debug' }, { value: '--trace' }]);
    });

    it('seeds editor rows from object-array defaults', () => {
        const state = buildEditorPropertiesState(
            {
                chartInputs: {
                    type: WorkflowNodeFieldTypeEnum.ObjectArray,
                    valueMode: 'record',
                    keyField: 'key',
                    valueField: 'value',
                    defaultValue: [{ key: 'series', value: 3 }],
                    subFields: {
                        key: { label: 'Input', required: true, defaultValue: 'series', styleCol: 5 },
                        value: { label: 'Value', required: true, defaultValue: 3, styleCol: 6 }
                    }
                }
            },
            { chartInputs: [{ key: 'series', value: 3 }] }
        );

        expect(state.chartInputs).toEqual([{ key: 'series', value: 3 }]);
    });

    it('serializes shared object-array rows back to runtime values', () => {
        const parsed = parseEditorPropertyValues(FIELDS, {
            headers: [{ key: 'Authorization', value: 'Bearer token' }],
            stdioArgs: [{ value: '--debug' }, { value: '' }, { value: '--trace' }]
        });

        expect(parsed.headers).toEqual({ Authorization: 'Bearer token' });
        expect(parsed.stdioArgs).toEqual(['--debug', '--trace']);
    });
});
