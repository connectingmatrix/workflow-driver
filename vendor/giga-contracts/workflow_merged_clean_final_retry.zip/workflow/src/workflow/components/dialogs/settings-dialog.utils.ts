import { WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS, WorkflowAuthModeEnum, type WorkflowCanvasSettings, type WorkflowRuntimeSettings } from '@workflow/ui/workflow/types';
import type { ManualHeaderRow, WorkflowSettingsFormState } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';
import { resolveWorkflowCanvasSettings } from '@workflow/ui/workflow/utils/workflow-canvas-settings.utils';

export const createHeaderRowId = (): string => {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
        return crypto.randomUUID();
    }
    return `wf-header-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
};

export const deriveHttpBaseUrl = (graphqlUrl: string): string => {
    const trimmed = graphqlUrl.trim();
    if (!trimmed) {
        return '';
    }
    return trimmed.replace(/\/graphql\/?$/i, '');
};

export const toManualHeaderRows = (headers: Record<string, string> | undefined): ManualHeaderRow[] => {
    const entries = Object.entries(headers ?? {});
    if (entries.length === 0) {
        return [{ id: createHeaderRowId(), header: '', value: '' }];
    }
    return entries.map(([header, value]) => ({ id: createHeaderRowId(), header, value }));
};

export const toManualHeadersRecord = (rows: ManualHeaderRow[]): Record<string, string> =>
    rows.reduce<Record<string, string>>((acc, row) => {
        const header = row.header.trim();
        const value = row.value.trim();
        if (!header || !value) {
            return acc;
        }
        acc[header] = value;
        return acc;
    }, {});

export const buildAuthOptions = () => [
    { label: 'Auto from current session', value: WorkflowAuthModeEnum.AutoFromCurrentSession },
    { label: 'Manual', value: WorkflowAuthModeEnum.Manual },
    { label: 'None', value: WorkflowAuthModeEnum.None }
];

export const buildTimeoutOptions = () => WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS.map((value) => ({ label: `${value} seconds`, value }));

export const buildLayoutEngineOptions = () => [{ label: 'Legacy', value: 'legacy' }, { label: 'ELK', value: 'elk' }];

export const buildEdgeStyleOptions = () => [
    { label: 'Legacy', value: 'legacy' },
    { label: 'Bezier', value: 'bezier' },
    { label: 'Straight', value: 'straight' },
    { label: 'Step', value: 'step' },
    { label: 'Smooth Step', value: 'smoothstep' }
];

export const createWorkflowSettingsFormState = (settings: WorkflowRuntimeSettings, canvasSettings: WorkflowCanvasSettings, workflowName: string, workflowDescription?: string | null): WorkflowSettingsFormState => {
    const resolvedCanvasSettings = resolveWorkflowCanvasSettings({ metadata: { id: 'settings_canvas', name: workflowName, ui: { canvas: canvasSettings } }, nodes: [], connections: [] });
    return {
        workflowNameInput: workflowName || '',
        workflowDescriptionInput: workflowDescription || '',
        graphqlUrl: settings.graphqlUrl ?? '',
        httpBaseUrl: settings.httpBaseUrl ?? deriveHttpBaseUrl(settings.graphqlUrl ?? ''),
        authMode: settings.authMode ?? WorkflowAuthModeEnum.AutoFromCurrentSession,
        manualHeaderRows: toManualHeaderRows(settings.manualHeaders),
        maxExecutionSeconds: settings.maxExecutionSeconds ?? 300,
        layoutEngine: resolvedCanvasSettings.layoutEngine,
        edgeStyle: resolvedCanvasSettings.edgeStyle
    };
};
