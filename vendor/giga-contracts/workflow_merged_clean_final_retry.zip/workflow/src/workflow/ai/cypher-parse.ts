import { WorkflowCypherEdgeSpec, WorkflowCypherGraph, WorkflowCypherNodeSpec } from './cypher-types';
import { parseCypherJson } from './cypher-json';

const NODE_LINE = /^\(([A-Za-z][\w-]*):([A-Za-z][\w-]*)(?:\s+(\{.*\}))?\)$/;
const EDGE_LINE = /^\(([A-Za-z][\w-]*)\)\s*-\[:CONNECT(?:\s+(\{.*\}))?\]->\s*\(([A-Za-z][\w-]*)\)$/;

const normalizeLines = (source: string): string[] =>
    source
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith('//') && !line.startsWith('#'));

const readString = (record: Record<string, unknown>, key: string): string => {
    const value = record[key];
    return typeof value === 'string' ? value.trim() : '';
};

const parseNode = (line: string): WorkflowCypherNodeSpec | null => {
    const match = line.match(NODE_LINE);
    if (!match) return null;
    const properties = match[3] ? parseCypherJson(match[3]) : {};
    const runtime = properties.runtime && typeof properties.runtime === 'object' && !Array.isArray(properties.runtime) ? (properties.runtime as Record<string, unknown>) : {};
    return {
        alias: String(match[1]),
        modelId: String(match[2]),
        name: readString(properties, 'name') || undefined,
        runtime
    };
};

const parseEdge = (line: string): WorkflowCypherEdgeSpec | null => {
    const match = line.match(EDGE_LINE);
    if (!match) return null;
    const properties = match[2] ? parseCypherJson(match[2]) : {};
    return {
        from: String(match[1]),
        to: String(match[3]),
        source: readString(properties, 'source') || 'out:output',
        target: readString(properties, 'target') || 'in:input'
    };
};

export const parseWorkflowCypher = (source: string): WorkflowCypherGraph => {
    const nodes: WorkflowCypherNodeSpec[] = [];
    const edges: WorkflowCypherEdgeSpec[] = [];
    for (const line of normalizeLines(source)) {
        const node = parseNode(line);
        if (node) {
            nodes.push(node);
            continue;
        }
        const edge = parseEdge(line);
        if (edge) {
            edges.push(edge);
            continue;
        }
        throw new Error(`Unsupported workflow cypher line: ${line}`);
    }
    if (nodes.length === 0) throw new Error('Workflow cypher must include at least one node.');
    return { nodes, edges };
};
