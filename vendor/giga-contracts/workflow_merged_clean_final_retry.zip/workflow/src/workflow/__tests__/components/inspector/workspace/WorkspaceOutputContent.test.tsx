// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, render } from '@testing-library/react';
import { afterEach, describe, expect, it } from 'vitest';
import { WorkspaceOutputContent } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceOutputContent';
import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';
import type { WorkspaceOutputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

const buildModel = (value: unknown, type: WorkflowViewerTypeEnum.Raw | WorkflowViewerTypeEnum.Json): WorkspaceOutputPanelModel => ({
    title: 'Output',
    description: 'Output',
    tabs: [{ id: type, label: type.toUpperCase() }],
    activeTab: type,
    activeViewer: {
        id: type,
        label: type.toUpperCase(),
        type,
        value
    },
    renderedMarkdown: ''
});

describe('WorkspaceOutputContent', () => {
    afterEach(() => {
        cleanup();
    });

    it('renders raw string output as plain text', () => {
        const { getByLabelText } = render(<WorkspaceOutputContent model={buildModel('plain text result', WorkflowViewerTypeEnum.Raw)} />);
        expect(getByLabelText('RAW output')).toHaveTextContent('plain text result');
    });

    it('stringifies non-string raw output instead of rendering key value viewers', () => {
        const { getByLabelText } = render(<WorkspaceOutputContent model={buildModel({ ok: true, count: 2 }, WorkflowViewerTypeEnum.Raw)} />);
        expect(getByLabelText('RAW output')).toHaveTextContent('"ok": true');
        expect(getByLabelText('RAW output')).toHaveTextContent('"count": 2');
    });
});
