import {
  WorkflowLogLevelEnum,
  WorkflowNodeKindEnum,
  type WorkflowDefinition,
  type WorkflowNodeKind,
  type WorkflowRunLogEvent,
} from "../types";

const recordValue = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
const textValue = (value: unknown): string => String(value || "").trim();
const normalizeNodeKind = (kind: string): WorkflowNodeKind => {
  if (kind === WorkflowNodeKindEnum.Output) return WorkflowNodeKindEnum.Output;
  if (kind === WorkflowNodeKindEnum.Error) return WorkflowNodeKindEnum.Error;
  return WorkflowNodeKindEnum.Process;
};

const normalizeLogLevel = (
  level: WorkflowRunLogEvent["level"] | undefined,
): WorkflowRunLogEvent["level"] => {
  if (level === WorkflowLogLevelEnum.Error) return WorkflowLogLevelEnum.Error;
  if (level === WorkflowLogLevelEnum.Warn) return WorkflowLogLevelEnum.Warn;
  return WorkflowLogLevelEnum.Info;
};

export const normalizeWorkflowQueueDefinition = (
  workflow: WorkflowDefinition,
): WorkflowDefinition => {
  const normalized = {
    ...workflow,
    metadata: { ...recordValue(workflow.metadata) },
    nodes: Array.isArray(workflow.nodes)
      ? workflow.nodes.map((node) => ({
          ...node,
          description: undefined,
          inspector: undefined,
          kind: normalizeNodeKind(String(node.kind || "")),
          render: undefined,
        }))
      : [],
  } as unknown as WorkflowDefinition;

  delete normalized.metadata.worker_hashes;
  delete normalized.NODE_EXECUTORS;
  delete normalized.NODE_EXECUTOR_SIGNATURES;
  return normalized;
};

const compactWorkflowRecord = (value: unknown) => {
  const record = recordValue(value);
  const nested = recordValue(record.workflow);
  const source = Object.keys(nested).length ? nested : record;
  return {
    id: textValue(source.id || source.workflowId || record.workflow_id) || null,
    workflow_id:
      textValue(source.workflow_id || source.workflowId || source.id) || null,
    name:
      textValue(source.name || source.workflowName || record.workflow_name) ||
      null,
    workflow_name:
      textValue(source.workflow_name || source.workflowName || source.name) ||
      null,
    editor_url:
      textValue(source.editor_url || source.editorUrl || record.editor_url) ||
      null,
  };
};

const compactPlan = (value: unknown) => {
  const record = recordValue(value);
  return {
    intent: textValue(record.intent) || "",
    actions: Array.isArray(record.actions)
      ? record.actions.map((entry, index) => {
          const action = recordValue(entry);
          return {
            id: textValue(action.id) || `a${index + 1}`,
            name: textValue(action.name) || null,
            reason: textValue(action.reason) || null,
            depends_on: Array.isArray(action.depends_on)
              ? action.depends_on
              : [],
          };
        })
      : [],
  };
};

const compactActionResult = (value: unknown, index: number) => {
  const record = recordValue(value);
  const data = recordValue(record.data);
  return {
    id: textValue(record.id) || `r${index + 1}`,
    name: textValue(record.name) || null,
    status: textValue(record.status) || null,
    reason: textValue(record.reason) || null,
    summary: textValue(record.summary) || null,
    error: textValue(record.error) || null,
    duration_ms: Number.isFinite(Number(record.duration_ms))
      ? Number(record.duration_ms)
      : null,
    data: {
      ...Object.fromEntries(
        Object.entries(data).filter(
          ([, entry]) =>
            entry == null ||
            typeof entry === "string" ||
            typeof entry === "number" ||
            typeof entry === "boolean",
        ),
      ),
      output: Object.prototype.hasOwnProperty.call(data, "output")
        ? data.output
        : null,
      workflow: Object.keys(recordValue(data.workflow)).length
        ? compactWorkflowRecord(data.workflow)
        : null,
    },
  };
};

export const normalizeWorkflowQueueResponsePayload = (
  value: unknown,
): unknown => {
  const record = recordValue(value);
  if (!Object.keys(record).length) return value;
  const validation = recordValue(record.workflow_validation);
  if (Array.isArray(record.nodes) || Array.isArray(record.connections))
    return compactWorkflowRecord(record);
  return {
    ...record,
    plan: compactPlan(record.plan),
    pending_actions: Array.isArray(record.pending_actions)
      ? record.pending_actions.map((entry, index) =>
          compactActionResult(entry, index),
        )
      : record.pending_actions,
    action_results: Array.isArray(record.action_results)
      ? record.action_results.map((entry, index) =>
          compactActionResult(entry, index),
        )
      : record.action_results,
    pipeline_passes: Array.isArray(record.pipeline_passes)
      ? record.pipeline_passes.map((entry) => {
          const pass = recordValue(entry);
          return {
            kind: textValue(pass.kind) || null,
            response_format: textValue(pass.response_format) || null,
            plan: compactPlan(pass.plan),
            action_results: Array.isArray(pass.action_results)
              ? pass.action_results.map((action, index) =>
                  compactActionResult(action, index),
                )
              : [],
          };
        })
      : record.pipeline_passes,
    workflow_validation: Object.keys(validation).length
      ? {
          ok: validation.ok === true,
          errors: Array.isArray(validation.errors) ? validation.errors : [],
          warnings: Array.isArray(validation.warnings)
            ? validation.warnings
            : [],
        }
      : record.workflow_validation,
    agent: normalizeWorkflowQueueResponsePayload(record.agent),
    interaction: normalizeWorkflowQueueResponsePayload(record.interaction),
    terminal_payload: normalizeWorkflowQueueResponsePayload(
      record.terminal_payload,
    ),
  };
};

export const normalizeWorkflowQueueLogEvent = (
  event: WorkflowRunLogEvent,
): WorkflowRunLogEvent => ({ ...event, level: normalizeLogLevel(event.level) });
export const normalizeWorkflowQueueLogs = (
  logs: WorkflowRunLogEvent[],
): WorkflowRunLogEvent[] =>
  Array.isArray(logs) ? logs.map(normalizeWorkflowQueueLogEvent) : [];
