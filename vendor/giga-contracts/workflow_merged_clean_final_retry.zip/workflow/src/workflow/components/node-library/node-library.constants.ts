export const DRAG_MIME_TYPE = 'application/giga-workflow-node';
