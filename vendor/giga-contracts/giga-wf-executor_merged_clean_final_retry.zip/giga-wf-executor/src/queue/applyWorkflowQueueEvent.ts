import { withWorkflowQueueExecutionStarted } from './workflowQueueTiming';
import type { WorkflowQueueEvent } from './types';

type WorkflowQueueEventApplierDependencies = {
  appendLog: (params: { store: any; executionId: string; log: any }) => Promise<void>;
  emitLogEvent: (params: { broadcastId: string; broadcastChannelName: string; workflowId: string; event: any }) => void;
  finalizeRecord: (params: { store: any; broadcastId: string; broadcastChannelName: string; executionId: string; workflowReference: any; status: 'completed' | 'failed'; errorMessage?: string | null; logs?: any[]; workflowSnapshot?: any; responsePayload?: unknown }) => Promise<void>;
  loadResponsePayload: (params: { store: any; executionId: string }) => Promise<unknown>;
  resolveCompletion: (event: any) => void;
  transitionRecord: (params: { store: any; broadcastId: string; broadcastChannelName: string; executionId: string; workflowReference: any; status: string; extraFields?: Record<string, unknown>; expectedStatuses?: string[] }) => Promise<void>;
};

export const createWorkflowQueueEventApplier =
  (dependencies: WorkflowQueueEventApplierDependencies) =>
  async (store: any, event: WorkflowQueueEvent): Promise<void> => {
    if (event.type === 'started') {
      await dependencies.transitionRecord({ store, broadcastId: event.broadcastId, broadcastChannelName: event.broadcastChannelName, executionId: event.executionId, workflowReference: event.workflowReference as any, status: 'running', expectedStatuses: ['queued', 'running'], extraFields: { response_payload: withWorkflowQueueExecutionStarted(await dependencies.loadResponsePayload({ store, executionId: event.executionId }), event.timestamp) } });
      return;
    }
    if (event.type === 'log') {
      await dependencies.appendLog({ store, executionId: event.executionId, log: event.log as any });
      dependencies.emitLogEvent({ broadcastId: event.broadcastId, broadcastChannelName: event.broadcastChannelName, workflowId: event.workflowId, event: event.log as any });
      return;
    }
    if (event.type === 'completed') {
      await dependencies.finalizeRecord({ store, broadcastId: event.broadcastId, broadcastChannelName: event.broadcastChannelName, executionId: event.executionId, workflowReference: event.workflowReference as any, status: 'completed', workflowSnapshot: event.result.workflow as any, logs: event.result.logs as any, responsePayload: event.result.responsePayload ?? null });
      dependencies.resolveCompletion(event);
      return;
    }
    await dependencies.finalizeRecord({ store, broadcastId: event.broadcastId, broadcastChannelName: event.broadcastChannelName, executionId: event.executionId, workflowReference: event.workflowReference as any, status: 'failed', errorMessage: event.errorMessage, logs: event.logs as any, workflowSnapshot: event.workflow as any, responsePayload: event.responsePayload ?? null });
    dependencies.resolveCompletion(event);
  };
