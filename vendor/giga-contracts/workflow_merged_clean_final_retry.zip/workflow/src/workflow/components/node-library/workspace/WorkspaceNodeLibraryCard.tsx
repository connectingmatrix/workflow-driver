import React from 'react';
import { DRAG_MIME_TYPE } from '@workflow/ui/workflow/components/node-library/node-library.constants';
import { resolveFallbackIconStyle, resolveWorkspaceNodeLibraryGroupLabel } from '@workflow/ui/workflow/components/node-library/workspace/workspace-node-library.utils';
import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

interface WorkspaceNodeLibraryCardProps {
    item: WorkflowNodeLibraryItem;
    onInsert?: (item: WorkflowNodeLibraryItem) => void;
}

export const WorkspaceNodeLibraryCard: React.FC<WorkspaceNodeLibraryCardProps> = ({ item, onInsert }) => {
    const renderedIcon = item.renderIcon ? item.renderIcon(24) : null;
    const reactIcon = React.isValidElement(renderedIcon) ? renderedIcon : null;
    const fallbackIconStyle = resolveFallbackIconStyle(item.modelId || item.id);
    const groupLabel = resolveWorkspaceNodeLibraryGroupLabel(item);

    return (
        <button
            type="button"
            draggable
            className="wf-workspace-node-library__card"
            onClick={() => onInsert?.(item)}
            onDragStart={(event) => {
                event.dataTransfer.setData(DRAG_MIME_TYPE, item.id);
                event.dataTransfer.effectAllowed = 'move';
            }}
        >
            <div className="wf-workspace-node-library__card-icon-shell">
                <span
                    className="wf-workspace-node-library__card-icon"
                    style={{
                        color: item.iconColor ?? fallbackIconStyle.iconColor,
                        background: item.iconBackground ?? fallbackIconStyle.iconBackground
                    }}
                >
                    {typeof renderedIcon === 'string' ? <span dangerouslySetInnerHTML={{ __html: renderedIcon }} /> : reactIcon}
                    {!renderedIcon ? <i className={item.iconClass ?? 'pi pi-box'} aria-hidden /> : null}
                </span>
            </div>
            <div className="wf-workspace-node-library__card-content">
                <div className="wf-workspace-node-library__card-header">
                    <strong>{item.label}</strong>
                    <span className="wf-workspace-node-library__card-pill">{groupLabel}</span>
                </div>
                <p>{item.description}</p>
            </div>
        </button>
    );
};
