import { describe, expect, it } from 'vitest';
import { createQueuedWorkflowRequestExecutor } from '../queue/executeQueuedWorkflowRequest';
import type { WorkflowQueueEvent, WorkflowQueueRequest } from '../queue/types';

const request = (): WorkflowQueueRequest => ({
  executionId: 'execution-1',
  runId: 'run-1',
  queueKey: 'user-1',
  userId: 'user-1',
  broadcastId: 'user-1',
  broadcastChannelName: 'workflow-socket',
  triggerType: 'chat',
  workflowReference: { workflowId: 'workflow-1', scope: 'user', ownerUserId: 'user-1' },
  workflowVersionId: null,
  workflow: { metadata: { id: 'workflow-1', name: 'Workflow' }, nodes: [], connections: [] },
  settings: {
    authMode: 'auto-from-current-session',
    graphqlUrl: 'http://localhost:3001/api/v2/graphql',
  },
  requestContext: {
    headers: {},
    mode: 'user',
    userId: 'user-1',
  },
  metadata: null,
});

describe('createQueuedWorkflowRequestExecutor', () => {
  it('keeps execution completed when async log publishing fails', async () => {
    const events: WorkflowQueueEvent[] = [];
    const executor = createQueuedWorkflowRequestExecutor({
      createHostContext: () => ({}),
      executeWorkflowImpl: async (workflow, params) => {
        params.logger.push({ event: 'node.delta', level: 'info', message: 'node updated', nodeId: 'node-1', runId: 'run-1', workflowId: 'workflow-1' });
        return { workflow, stopped: false, runId: 'run-1' };
      },
      extractTerminalPayload: () => ({ text: 'ok' }),
      restoreRequestContext: () => ({}),
    });

    await executor(request(), {
      publishEvent: async (event) => {
        if (event.type === 'log') throw { reason: 'redpanda publish failed' };
        events.push(event);
      },
      signal: new AbortController().signal,
    });

    expect(events.map((event) => event.type)).toEqual(['started', 'completed']);
  });

  it('keeps execution completed when completed logs override stale failed node state', async () => {
    const events: WorkflowQueueEvent[] = [];
    const executor = createQueuedWorkflowRequestExecutor({
      createHostContext: () => ({}),
      executeWorkflowImpl: async (workflow, params) => {
        params.logger.push({ event: 'workflow.completed', level: 'info', runId: 'run-1', workflowId: 'workflow-1' });
        return {
          workflow: {
            ...workflow,
            nodes: [{ id: 'stale-node', name: 'Stale Node', modelId: 'test', status: 'failed', ports: {} }],
          },
          stopped: false,
          runId: 'run-1',
        };
      },
      extractTerminalPayload: () => ({ text: 'ok' }),
      restoreRequestContext: () => ({}),
    });

    await executor(request(), {
      publishEvent: async (event) => {
        events.push(event);
      },
      signal: new AbortController().signal,
    });

    expect(events.map((event) => event.type)).toEqual(['started', 'log', 'completed']);
  });

  it('uses explicit terminal text fields instead of searching nested fallback objects', async () => {
    const events: WorkflowQueueEvent[] = [];
    const executor = createQueuedWorkflowRequestExecutor({
      createHostContext: () => ({}),
      executeWorkflowImpl: async (workflow) => ({ workflow, stopped: false, runId: 'run-1' }),
      extractTerminalPayload: () => ({
        text: 'Chat Actions: post link is unsupported.',
        input1: { agent: { text: 'Hidden nested fallback text.' } },
        plan: { intent: 'not the response' },
      }),
      restoreRequestContext: () => ({}),
    });

    await executor(request(), {
      publishEvent: async (event) => {
        events.push(event);
      },
      signal: new AbortController().signal,
    });

    const completed = events.find((event) => event.type === 'completed') as Extract<WorkflowQueueEvent, { type: 'completed' }>;
    expect(completed.result.responsePayload).toMatchObject({ text: 'Chat Actions: post link is unsupported.' });
  });

  it('does not serialize object terminal payloads as chat text', async () => {
    const events: WorkflowQueueEvent[] = [];
    const executor = createQueuedWorkflowRequestExecutor({
      createHostContext: () => ({}),
      executeWorkflowImpl: async (workflow) => ({ workflow, stopped: false, runId: 'run-1' }),
      extractTerminalPayload: () => ({ input1: { agent: { text: 'Hidden nested fallback text.' } } }),
      restoreRequestContext: () => ({}),
    });

    await executor(request(), {
      publishEvent: async (event) => {
        events.push(event);
      },
      signal: new AbortController().signal,
    });

    const completed = events.find((event) => event.type === 'completed') as Extract<WorkflowQueueEvent, { type: 'completed' }>;
    expect(completed.result.responsePayload).toMatchObject({ text: '' });
  });
});
