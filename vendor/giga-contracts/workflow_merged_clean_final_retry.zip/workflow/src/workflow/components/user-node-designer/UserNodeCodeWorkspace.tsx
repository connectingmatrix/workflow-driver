import React, { useCallback, useState } from 'react';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { TabPanel, TabView } from 'primereact/tabview';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';
import UserNodeCodeToolbar from '@workflow/ui/workflow/components/user-node-designer/UserNodeCodeToolbar';
import UserNodePreviewPanel from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewPanel';
import { UserNodePreviewState } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';
import { WorkflowPreviewRuntime } from '@workflow/ui/workflow/types';

interface UserNodeCodeWorkspaceProps {
    activeFile: 'worker.ts' | 'validate.ts';
    browserRuntimeAllowed: boolean;
    inputMode: 'sample' | 'last' | 'upstream';
    isRunning: boolean;
    onClearLogs: () => void;
    onInputModeChange: (value: 'sample' | 'last' | 'upstream') => void;
    onRun: () => void;
    onRunOnServer: () => void;
    onRevert: () => void;
    onSave: () => void;
    onStop: () => void;
    onSwitchFile: (value: 'worker.ts' | 'validate.ts') => void;
    onValidateChange: (value: string) => void;
    onWorkerChange: (value: string) => void;
    previewState: UserNodePreviewState;
    runtimeMode: WorkflowPreviewRuntime;
    runtimeFallbackReason: string | null;
    runtimeResolved: 'browser' | 'node';
    sampleInputJson: string;
    setRuntimeMode: (value: WorkflowPreviewRuntime) => void;
    setSampleInputJson: (value: string) => void;
    upstreamInputAvailable: boolean;
    validateTs: string;
    workerTs: string;
}

const SPLITTER_STORAGE_KEY = 'workflow.userNodeDesigner.splitterSizes';
const DEFAULT_SPLITTER_SIZES: [number, number] = [56, 44];

const normalizeSplitterSizes = (sizes: number[] | null | undefined): [number, number] | null => {
    if (!Array.isArray(sizes) || sizes.length < 2) return null;
    const left = Number(sizes[0]);
    const right = Number(sizes[1]);
    if (!Number.isFinite(left) || !Number.isFinite(right) || left < 10 || right < 10) return null;
    const total = left + right;
    if (total <= 0) return null;
    const normalizedLeft = Math.round((left / total) * 100);
    const normalizedRight = 100 - normalizedLeft;
    if (normalizedLeft < 10 || normalizedRight < 10) return null;
    return [normalizedLeft, normalizedRight];
};

const resolveInitialSplitterSizes = (): [number, number] => {
    if (typeof window === 'undefined') {
        return DEFAULT_SPLITTER_SIZES;
    }

    try {
        const raw = window.localStorage.getItem(SPLITTER_STORAGE_KEY);
        if (!raw) return DEFAULT_SPLITTER_SIZES;
        const parsed = JSON.parse(raw) as unknown;
        if (!Array.isArray(parsed)) return DEFAULT_SPLITTER_SIZES;
        return normalizeSplitterSizes(parsed.map((value) => Number(value))) ?? DEFAULT_SPLITTER_SIZES;
    } catch {
        return DEFAULT_SPLITTER_SIZES;
    }
};

const UserNodeCodeWorkspace: React.FC<UserNodeCodeWorkspaceProps> = (props) => {
    const [splitterSizes, setSplitterSizes] = useState<[number, number]>(resolveInitialSplitterSizes);

    const applySplitterSizes = useCallback((event: { sizes: number[] }, persist: boolean) => {
        const nextSizes = normalizeSplitterSizes(event.sizes);
        if (!nextSizes) return;
        setSplitterSizes(nextSizes);
        if (!persist || typeof window === 'undefined') return;
        try {
            window.localStorage.setItem(SPLITTER_STORAGE_KEY, JSON.stringify(nextSizes));
        } catch {
            // Ignore storage failures and keep runtime state only.
        }
    }, []);

    const handleResize = useCallback((event: { sizes: number[] }) => {
        applySplitterSizes(event, false);
    }, [applySplitterSizes]);

    const handleResizeEnd = useCallback((event: { sizes: number[] }) => {
        applySplitterSizes(event, true);
    }, [applySplitterSizes]);

    const splitterLiveResizeProps = { onResize: handleResize } as unknown as Record<string, unknown>;

    return (
        <div className="wf-user-node-workspace" data-cy="user-node-code-workspace">
            <UserNodeCodeToolbar
                canRun={Boolean(props.workerTs.trim())}
                inputMode={props.inputMode}
                isRunning={props.isRunning}
                onClearLogs={props.onClearLogs}
                onInputModeChange={props.onInputModeChange}
                onRevert={props.onRevert}
                onRun={props.onRun}
                onRunOnServer={props.onRunOnServer}
                onSave={props.onSave}
                onStop={props.onStop}
                runtimeMode={props.runtimeMode}
                runtimeResolved={props.runtimeResolved}
                runtimeFallbackReason={props.runtimeFallbackReason}
                browserRuntimeAllowed={props.browserRuntimeAllowed}
                setRuntimeMode={props.setRuntimeMode}
                upstreamInputAvailable={props.upstreamInputAvailable}
            />
            {(props.runtimeResolved === 'browser' || props.runtimeFallbackReason) && (
                <div className="wf-user-node-workspace__notices">
                    {props.runtimeResolved === 'browser' ? <div className="text-xs text-500">Browser preview runs the browser-compatible worker path only.</div> : null}
                    {props.runtimeFallbackReason ? <div className="text-xs text-orange-500">{props.runtimeFallbackReason}</div> : null}
                </div>
            )}
            <div className="wf-user-node-workspace__splitter-wrap">
                <Splitter className="wf-user-node-workspace__splitter" style={{ height: '100%' }} gutterSize={8} {...splitterLiveResizeProps} onResizeEnd={handleResizeEnd}>
                    <SplitterPanel size={splitterSizes[0]} minSize={25} className="wf-user-node-workspace__editor-panel">
                        <section className="wf-user-node-workspace__panel-frame" data-cy="user-node-workspace-source-panel">
                            <header className="wf-user-node-workspace__panel-header">
                                <span className="wf-user-node-workspace__panel-title">Source Workspace</span>
                            </header>
                            <div className="wf-user-node-workspace__panel-body">
                                <TabView className="wf-user-node-workspace__file-tabs" activeIndex={props.activeFile === 'worker.ts' ? 0 : 1} onTabChange={(event) => props.onSwitchFile(event.index === 0 ? 'worker.ts' : 'validate.ts')}>
                                    <TabPanel header="worker.ts">
                                        <div className="wf-user-node-workspace__editor-surface" data-cy="user-node-worker-editor">
                                            <CodeEditor value={props.workerTs} onChange={props.onWorkerChange} language="javascript" minHeight={320} dataCy="user-node-worker-monaco" />
                                        </div>
                                    </TabPanel>
                                    <TabPanel header="validate.ts">
                                        <div className="wf-user-node-workspace__editor-surface" data-cy="user-node-validate-editor">
                                            <CodeEditor value={props.validateTs} onChange={props.onValidateChange} language="javascript" minHeight={320} dataCy="user-node-validate-monaco" />
                                        </div>
                                    </TabPanel>
                                </TabView>
                                <div className="wf-user-node-workspace__sample">
                                    <label className="text-sm block mb-1">
                                        Sample Input JSON
                                        {props.inputMode === 'upstream' && !props.upstreamInputAvailable ? ' (upstream unavailable)' : ''}
                                    </label>
                                    <div className="wf-user-node-workspace__sample-editor" data-cy="user-node-sample-input">
                                        <CodeEditor value={props.sampleInputJson} onChange={props.setSampleInputJson} language="json" minHeight={180} allowVariables={false} dataCy="user-node-sample-input-monaco" />
                                    </div>
                                </div>
                            </div>
                        </section>
                    </SplitterPanel>
                    <SplitterPanel size={splitterSizes[1]} minSize={25} className="wf-user-node-workspace__preview-panel">
                        <section className="wf-user-node-workspace__panel-frame" data-cy="user-node-workspace-preview-panel">
                            <header className="wf-user-node-workspace__panel-header">
                                <span className="wf-user-node-workspace__panel-title">Execution Preview</span>
                            </header>
                            <div className="wf-user-node-workspace__panel-body">
                                <UserNodePreviewPanel state={props.previewState} onClearLogs={props.onClearLogs} />
                            </div>
                        </section>
                    </SplitterPanel>
                </Splitter>
            </div>
        </div>
    );
};

export default UserNodeCodeWorkspace;
