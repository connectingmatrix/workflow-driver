import { describe, expect, it } from 'vitest';
import { analyzeUserNodePreviewRuntimeSupport, resolveUserNodePreviewRuntime } from '@workflow/ui/workflow/components/user-node-designer/user-node-preview-runtime.utils';

describe('user node preview runtime utils', () => {
    it('blocks browser preview when worker.ts imports Node builtins', () => {
        const support = analyzeUserNodePreviewRuntimeSupport({
            activeFile: 'worker.ts',
            workerSource: "import fs from 'fs';\nexport const execute = async () => ({ output: fs.readdirSync('.') });"
        });

        expect(support.browserRuntimeAllowed).toBe(false);
        expect(support.nodeImports).toEqual(['fs']);
        expect(resolveUserNodePreviewRuntime('auto', support)).toEqual({
            effectiveRuntime: 'node',
            runtimeFallbackReason: 'Auto switched to Node runtime because worker.ts imports Node module: fs.'
        });
    });
});
