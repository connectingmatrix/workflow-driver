import React, { useState } from 'react';
import { BaseEdge, EdgeLabelRenderer, EdgeProps } from '@xyflow/react';
import { Button } from 'primereact/button';
import type { WorkflowCanvasEdgeStyle } from '@workflow/ui/workflow/types';
import { buildWorkflowEdgePath } from '@workflow/ui/workflow/components/canvas/workflow-edge-path.utils';

interface EdgeData {
    edgeStyle?: WorkflowCanvasEdgeStyle;
    sourceLaneOffset?: number;
    targetLaneOffset?: number;
    onDelete?: (edgeId: string) => void;
    onInsert?: (payload: { edgeId: string; anchor: HTMLElement }) => void;
}

const Edge: React.FC<EdgeProps> = ({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, markerEnd, style, selected, label, data }) => {
    const [isHovered, setIsHovered] = useState<boolean>(false);
    const edgeData = (data || {}) as EdgeData;
    const edgePath = buildWorkflowEdgePath(edgeData.edgeStyle || 'legacy', {
        sourceX,
        sourceY,
        targetX,
        targetY,
        sourcePosition,
        targetPosition,
        sourceLaneOffset: edgeData.sourceLaneOffset,
        targetLaneOffset: edgeData.targetLaneOffset
    });
    const showControls = selected || isHovered;

    return (
        <>
            <BaseEdge id={id} path={edgePath.path} markerEnd={markerEnd} style={style} />
            <path d={edgePath.path} fill="none" stroke="transparent" strokeWidth={20} className="wf-edge__hit-area" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)} />
            <EdgeLabelRenderer>
                <div className="wf-edge__controls" style={{ transform: `translate(-50%, -50%) translate(${edgePath.controlsX}px, ${edgePath.controlsY}px)` }} onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
                    {label ? <span className="wf-edge__label">{String(label)}</span> : null}
                    {showControls && edgeData.onInsert ? (
                        <Button
                            icon="pi pi-plus"
                            className="wf-edge__action-btn wf-edge__insert-btn"
                            onClick={(event) => {
                                event.preventDefault();
                                event.stopPropagation();
                                edgeData.onInsert?.({
                                    edgeId: id,
                                    anchor: event.currentTarget
                                });
                            }}
                            aria-label="Insert node"
                            tooltip="Insert Node"
                            tooltipOptions={{ position: 'top' }}
                        />
                    ) : null}
                    {showControls && edgeData.onDelete ? (
                        <Button
                            icon="pi pi-trash"
                            className="wf-edge__action-btn wf-edge__delete-btn"
                            onClick={(event) => {
                                event.preventDefault();
                                event.stopPropagation();
                                edgeData.onDelete?.(id);
                            }}
                            aria-label="Remove connection"
                            tooltip="Remove Connection"
                            tooltipOptions={{ position: 'top' }}
                        />
                    ) : null}
                </div>
            </EdgeLabelRenderer>
        </>
    );
};

export default Edge;
