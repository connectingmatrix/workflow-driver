import { WORKFLOW_LAYOUT_COMMAND_GAP, WORKFLOW_LAYOUT_LANE_GAP, WORKFLOW_LAYOUT_NODE_HEIGHT, WORKFLOW_LAYOUT_NODE_WIDTH, WORKFLOW_LAYOUT_START_Y } from '@workflow/ui/workflow/layout/layout-constants';
import type { WorkflowLayoutGraph } from '@workflow/ui/workflow/layout/layout-graph';

interface WorkflowMainLayout {
    stages: Record<string, number>;
    positions: Record<string, { x: number; y: number }>;
}

const overlaps = (left: { x: number; y: number }, right: { x: number; y: number }): boolean =>
    Math.abs(left.x - right.x) < WORKFLOW_LAYOUT_NODE_WIDTH && Math.abs(left.y - right.y) < WORKFLOW_LAYOUT_NODE_HEIGHT;

const resolveAnchorId = (graph: WorkflowLayoutGraph, stages: Record<string, number>, nodeId: string): string => {
    const targets = graph.commandLinks.filter((link) => link.from === nodeId).map((link) => link.to);
    return targets.sort((left, right) => (stages[right] || 0) - (stages[left] || 0) || (graph.orderById[left] || 0) - (graph.orderById[right] || 0))[0] || '';
};

export const placeCommandNodes = (graph: WorkflowLayoutGraph, main: WorkflowMainLayout): Record<string, { x: number; y: number }> => {
    const groups = graph.commandNodeIds.reduce<Record<string, string[]>>((record, nodeId) => {
        const anchorId = resolveAnchorId(graph, main.stages, nodeId) || '__floating__';
        record[anchorId] = [...(record[anchorId] || []), nodeId];
        return record;
    }, {});
    const occupied = [...Object.values(main.positions)];
    const positions: Record<string, { x: number; y: number }> = {};

    Object.keys(groups).sort((left, right) => (main.positions[left]?.y || WORKFLOW_LAYOUT_START_Y) - (main.positions[right]?.y || WORKFLOW_LAYOUT_START_Y)).forEach((anchorId) => {
        const nodeIds = (groups[anchorId] || []).sort((left, right) => (graph.orderById[left] || 0) - (graph.orderById[right] || 0));
        const anchor = main.positions[anchorId] || { x: Math.max(...Object.values(main.positions).map((point) => point.x), 0), y: WORKFLOW_LAYOUT_START_Y };
        const startY = anchor.y - ((nodeIds.length - 1) * WORKFLOW_LAYOUT_COMMAND_GAP) / 2;
        let x = anchor.x + WORKFLOW_LAYOUT_LANE_GAP;
        while (nodeIds.some((_, index) => occupied.some((point) => overlaps(point, { x, y: startY + index * WORKFLOW_LAYOUT_COMMAND_GAP })))) x += WORKFLOW_LAYOUT_LANE_GAP;
        nodeIds.forEach((nodeId, index) => {
            positions[nodeId] = { x, y: startY + index * WORKFLOW_LAYOUT_COMMAND_GAP };
            occupied.push(positions[nodeId]);
        });
    });

    return positions;
};
