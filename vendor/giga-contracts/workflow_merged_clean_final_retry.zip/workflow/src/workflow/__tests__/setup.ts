import '@testing-library/jest-dom/vitest';

process.env.WORKFLOW_NODE_SANDBOX_POOL_SIZE = '0';
process.env.WORKFLOW_SANDBOX_POOL_SIZE = '0';
