import { describe, expect, it, vi } from 'vitest';
import { createBrowserWorkerNodeHandler } from '../executor/browser/browser-runtime';
import { createNodeExecutorSignature, createWorkerNodeHandler } from '../executor/worker-runtime';
import { WorkflowDefinition, WorkflowNodeHandlerContext, WorkflowNodeModel, WorkflowNodeStatusEnum } from '../types';

const textEncoder = new TextEncoder();

const toBase64 = (source: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(source, 'utf8').toString('base64');
    }

    const bytes = textEncoder.encode(source);
    let binary = '';
    bytes.forEach((byte) => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
};

const GOVERNOR_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peers = payload.NODE.CONTROL_NODES.llm ?? {};
  const peer = peers.OpenAI;
  if (!peer) {
    return { output: { error: 'missing peer', peerKeys: Object.keys(peers) }, status: 'failed', logs: [] };
  }

  const schema = await peer.getSchema();
  await peer.set({ runtime: { customFlag: 'patched' } });
  const validation = await peer.validate();
  const executed = await peer.execute({
    input: {
      [payload.NODE.id]: {
        fromGovernor: true
      }
    }
  });
  const snapshot = await peer.get();

  return {
    output: {
      peerKeys: Object.keys(peers),
      commandKeys: Object.keys(schema.commands ?? {}),
      validationOk: validation.ok,
      peerStatus: executed.result.status,
      peerOutput: executed.result.output,
      snapshotOutput: snapshot.output,
      patchedFlag: snapshot.runtime.customFlag ?? snapshot.properties.customFlag ?? null
    },
    status: 'passed',
    logs: ['governor-executed']
  };
};
`;

const OPENAI_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [], normalizedRuntime: { normalized: true } });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({
  output: {
    ok: true,
    received: payload.self?.PORTS ?? {}
  },
  status: 'passed',
  logs: ['openai-executed']
});
`;

const BACKEND_DELEGATING_OPENAI_SOURCE = `
import { executeBackend } from '@workflow/execute';

export const validate = async () => ({ ok: true, errors: [], warnings: [], normalizedRuntime: { normalized: true } });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => await executeBackend(
  { key: 'executeOpenAINode' },
  { NODE: payload.NODE, payload }
);
`;

const PRODUCER_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: {
    producerValue: 'from-producer'
  },
  status: 'passed',
  logs: ['producer-executed']
});
`;

const GOVERNOR_SOURCE_WITHOUT_INPUT_EXECUTION = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = payload.NODE.CONTROL_NODES.llm?.OpenAI;
  const executed = await peer.execute();
  return {
    output: {
      peerOutput: executed.result.output
    },
    status: 'passed',
    logs: ['governor-executed']
  };
};
`;

const GOVERNOR_SOURCE_WITH_INPUT_EXECUTION = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = payload.NODE.CONTROL_NODES.llm?.OpenAI;
  const prepared = await peer.executeInputs();
  const executed = await peer.execute({
    input: {
      ...prepared.input,
      input: {
        ...(prepared.input?.input ?? {}),
        [payload.NODE.id]: {
          fromGovernor: true
        }
      }
    }
  });
  return {
    output: {
      preparedInput: prepared.input,
      peerOutput: executed.result.output
    },
    status: 'passed',
    logs: ['governor-executed']
  };
};
`;

const GOVERNOR_SOURCE_WITH_TRANSIENT_PATCH = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = payload.NODE.CONTROL_NODES.llm?.OpenAI;
  const executed = await peer.execute({
    patch: {
      runtime: { prompt: 'temporary prompt' },
      properties: { prompt: 'temporary prompt' }
    },
    input: {
      input: {
        [payload.NODE.id]: {
          fromGovernor: true
        }
      }
    }
  });
  const snapshot = await peer.get();
  return {
    output: {
      peerOutput: executed.result.output,
      snapshotPrompt: snapshot.runtime.prompt ?? null
    },
    status: 'passed',
    logs: ['governor-executed']
  };
};
`;

const OPENAI_SOURCE_ECHO_RUNTIME = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({
  output: {
    prompt: payload.NODE.PROPERTIES.prompt ?? null,
    received: payload.self?.PORTS ?? {}
  },
  status: 'passed',
  logs: ['openai-executed']
});
`;

const ROUTER_SOURCE_WITH_TOOL_SPEC = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const commandToolSpec = async () => ({
  toolName: 'Channel Actions',
  toolDescription: 'Read channels.',
  inputContract: { required: [{ key: 'action' }], optional: [{ key: 'actionInput' }] },
  outputContract: [{ key: 'action_result' }],
  metadata: { broadcastModelId: 'run-channel-action' },
  executionKind: 'tool'
});
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: [] });
`;

const createNode = (id: string, modelId: string, name: string): WorkflowNodeModel => ({
    id,
    gigaId: id,
    modelId,
    type: 'workflowStep',
    name,
    description: '',
    kind: 'process',
    status: WorkflowNodeStatusEnum.Stopped,
    position: { x: 0, y: 0 },
    runtime: {},
    ports: {
        in: {},
        out: {}
    }
});

const createCommandWorkflow = (options: { sourceHandle: string; targetHandle: string; legacySchemas?: boolean }): WorkflowDefinition => ({
    metadata: {
        id: 'wf_control_nodes',
        name: 'Control Nodes'
    },
    nodeModels: {
        governor: options.legacySchemas
            ? {
                  inputs: {
                      input: {},
                      llm: { portType: 'bi-directional', allowMultipleArrows: true }
                  },
                  outputs: {
                      output: {},
                      llm: { portType: 'bi-directional', allowMultipleArrows: true }
                  }
              }
            : {
                  inputs: {
                      input: {}
                  },
                  outputs: {
                      output: {}
                  },
                  commands: {
                      llm: { portType: 'bi-directional', allowMultipleArrows: true }
                  }
              },
        openai: options.legacySchemas
            ? {
                  inputs: {
                      input: {},
                      command: { portType: 'bi-directional', allowMultipleArrows: true }
                  },
                  outputs: {
                      output: {},
                      command: { portType: 'bi-directional', allowMultipleArrows: true }
                  }
              }
            : {
                  inputs: {
                      input: {}
                  },
                  outputs: {
                      output: {}
                  },
                  commands: {
                      command: { portType: 'bi-directional', allowMultipleArrows: true }
                  }
              }
    },
    nodes: [createNode('node_1', 'governor', 'Governor'), createNode('node_2', 'openai', 'OpenAI')],
    connections: [
        {
            id: 'c_1',
            name: 'OpenAI -> Governor',
            from: 'node_2',
            to: 'node_1',
            sourceHandle: options.sourceHandle,
            targetHandle: options.targetHandle
        }
    ],
    NODE_EXECUTORS: {
        governor: toBase64(GOVERNOR_SOURCE),
        openai: toBase64(OPENAI_SOURCE)
    },
    NODE_EXECUTOR_SIGNATURES: {
        governor: createNodeExecutorSignature('governor', GOVERNOR_SOURCE),
        openai: createNodeExecutorSignature('openai', OPENAI_SOURCE)
    }
});

const createCommandWorkflowWithProducer = (governorSource: string): WorkflowDefinition => ({
    metadata: {
        id: 'wf_control_nodes_upstream',
        name: 'Control Nodes Upstream'
    },
    nodeModels: {
        governor: {
            inputs: {
                input: {}
            },
            outputs: {
                output: {}
            },
            commands: {
                llm: { portType: 'bi-directional', allowMultipleArrows: true }
            }
        },
        openai: {
            inputs: {
                input: {}
            },
            outputs: {
                output: {}
            },
            commands: {
                command: { portType: 'bi-directional', allowMultipleArrows: true }
            }
        },
        producer: {
            outputs: {
                output: {}
            }
        }
    },
    nodes: [
        createNode('node_1', 'governor', 'Governor'),
        createNode('node_2', 'openai', 'OpenAI'),
        createNode('node_3', 'producer', 'Producer')
    ],
    connections: [
        {
            id: 'c_1',
            name: 'OpenAI -> Governor',
            from: 'node_2',
            to: 'node_1',
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        },
        {
            id: 'c_2',
            name: 'Producer -> OpenAI',
            from: 'node_3',
            to: 'node_2',
            sourceHandle: 'out:output',
            targetHandle: 'in:input'
        }
    ],
    NODE_EXECUTORS: {
        governor: toBase64(governorSource),
        openai: toBase64(OPENAI_SOURCE),
        producer: toBase64(PRODUCER_SOURCE)
    },
    NODE_EXECUTOR_SIGNATURES: {
        governor: createNodeExecutorSignature('governor', governorSource),
        openai: createNodeExecutorSignature('openai', OPENAI_SOURCE),
        producer: createNodeExecutorSignature('producer', PRODUCER_SOURCE)
    }
});

const createContext = (workflow: WorkflowDefinition): WorkflowNodeHandlerContext => ({
    node: workflow.nodes[0],
    workflow,
    settings: {
        graphqlUrl: 'http://localhost/graphql',
        authMode: 'none'
    },
    input: {}
});

describe('control-node runtime', () => {
    it('executes command peers through CONTROL_NODES for canonical cmd handles', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node'
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerKeys).toEqual(['OpenAI']);
        expect(output.commandKeys).toEqual(['command']);
        expect(output.validationOk).toBe(true);
        expect(output.peerStatus).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerOutput.ok).toBe(true);
        expect(output.snapshotOutput.ok).toBe(true);
        expect(output.patchedFlag).toBe('patched');
    }, 20000);

    it('normalizes legacy bi-directional in/out handles into CONTROL_NODES', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'out:command',
            targetHandle: 'in:llm',
            legacySchemas: true
        });
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node'
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerKeys).toEqual(['OpenAI']);
        expect(output.commandKeys).toEqual(['command']);
        expect(output.peerStatus).toBe(WorkflowNodeStatusEnum.Passed);
    }, 20000);

    it('routes browser control peer execution through connected-node executor when available', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        const handler = createBrowserWorkerNodeHandler({ modelId: 'governor' });
        const invokeConnectedNode = vi.fn(async ({ nodeId, input }) => {
            const node = workflow.nodes.find((entry) => entry.id === nodeId);
            if (!node) throw new Error('missing remote node');
            const output = { ok: true, remote: true, received: { in: input ?? {} } };
            return {
                node: {
                    ...node,
                    status: WorkflowNodeStatusEnum.Passed,
                    ports: {
                        in: input ?? {},
                        out: { output }
                    }
                },
                result: {
                    output,
                    status: WorkflowNodeStatusEnum.Passed,
                    logs: ['remote-peer-executed']
                }
            };
        });

        const result = await handler({ ...createContext(workflow), invokeConnectedNode });
        const output = result.output as Record<string, any>;

        expect(invokeConnectedNode).toHaveBeenCalledTimes(1);
        expect(output.peerOutput.remote).toBe(true);
        expect(output.snapshotOutput.remote).toBe(true);
        expect(output.patchedFlag).toBe('patched');
    }, 20000);

    it('removes live control-node functions before backend delegation', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        workflow.NODE_EXECUTORS = { ...workflow.NODE_EXECUTORS, openai: toBase64(BACKEND_DELEGATING_OPENAI_SOURCE) };
        workflow.NODE_EXECUTOR_SIGNATURES = { ...workflow.NODE_EXECUTOR_SIGNATURES, openai: createNodeExecutorSignature('openai', BACKEND_DELEGATING_OPENAI_SOURCE) };
        let backendPayload: Record<string, any> | null = null;
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node',
            executeHelpers: {
                executeBackend: async ({ payload }) => {
                    structuredClone(payload);
                    backendPayload = payload as Record<string, any>;
                    return {
                        output: {
                            ok: true,
                            backend: true
                        },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['backend-openai-executed']
                    };
                }
            }
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;
        expect(backendPayload).toBeTruthy();
        const backendEnvelope = backendPayload as unknown as Record<string, any>;
        const delegatedPayload = backendEnvelope.payload as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerOutput.backend).toBe(true);
        expect(delegatedPayload.NODE.CONTROL_NODES.command.Governor).toEqual({});
    }, 20000);

    it('does not auto-execute standard predecessors when only execute() is used', async () => {
        const workflow = createCommandWorkflowWithProducer(GOVERNOR_SOURCE_WITHOUT_INPUT_EXECUTION);
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node'
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;
        const peerOutput = output.peerOutput as Record<string, any>;
        const received = peerOutput.received as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(received.in ?? {}).toEqual({});
        expect(workflow.nodes.find((node) => node.id === 'node_3')?.status).toBe(WorkflowNodeStatusEnum.Stopped);
    }, 20000);

    it('materializes standard predecessors when executeInputs() is used first', async () => {
        const workflow = createCommandWorkflowWithProducer(GOVERNOR_SOURCE_WITH_INPUT_EXECUTION);
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node'
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;
        const preparedInput = output.preparedInput as Record<string, any>;
        const peerOutput = output.peerOutput as Record<string, any>;
        const received = peerOutput.received as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(preparedInput.input.node_3.producerValue).toBe('from-producer');
        expect(received.in.input.node_3.producerValue).toBe('from-producer');
        expect(received.in.input.node_1.fromGovernor).toBe(true);
        expect(workflow.nodes.find((node) => node.id === 'node_3')?.status).toBe(WorkflowNodeStatusEnum.Passed);
    }, 20000);

    it('keeps execute patches transient in node runtime control peers', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        workflow.NODE_EXECUTORS = {
            ...workflow.NODE_EXECUTORS,
            governor: toBase64(GOVERNOR_SOURCE_WITH_TRANSIENT_PATCH),
            openai: toBase64(OPENAI_SOURCE_ECHO_RUNTIME)
        };
        workflow.NODE_EXECUTOR_SIGNATURES = {
            ...workflow.NODE_EXECUTOR_SIGNATURES,
            governor: createNodeExecutorSignature('governor', GOVERNOR_SOURCE_WITH_TRANSIENT_PATCH),
            openai: createNodeExecutorSignature('openai', OPENAI_SOURCE_ECHO_RUNTIME)
        };
        const handler = createWorkerNodeHandler({
            modelId: 'governor',
            runtimeEnvironment: 'node'
        });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;
        const openAiNode = workflow.nodes.find((node) => node.id === 'node_2');

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerOutput.prompt).toBe('temporary prompt');
        expect(output.snapshotPrompt).toBe(null);
        expect(openAiNode?.runtime.prompt).toBeUndefined();
        expect(openAiNode?.properties?.prompt).toBeUndefined();
    }, 20000);

    it('keeps execute patches transient in browser remote control peers', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        workflow.NODE_EXECUTORS = {
            ...workflow.NODE_EXECUTORS,
            governor: toBase64(GOVERNOR_SOURCE_WITH_TRANSIENT_PATCH)
        };
        workflow.NODE_EXECUTOR_SIGNATURES = {
            ...workflow.NODE_EXECUTOR_SIGNATURES,
            governor: createNodeExecutorSignature('governor', GOVERNOR_SOURCE_WITH_TRANSIENT_PATCH)
        };
        const handler = createBrowserWorkerNodeHandler({ modelId: 'governor' });
        const invokeConnectedNode = vi.fn(async ({ nodeId, input, overrides }) => {
            const node = workflow.nodes.find((entry) => entry.id === nodeId);
            if (!node) throw new Error('missing remote node');
            const output = { prompt: overrides?.runtime?.prompt ?? null, received: { in: input ?? {} } };
            return {
                node: {
                    ...node,
                    runtime: { ...node.runtime, ...(overrides?.runtime ?? {}) },
                    status: WorkflowNodeStatusEnum.Passed,
                    ports: {
                        in: input ?? {},
                        out: { output }
                    }
                },
                result: {
                    output,
                    status: WorkflowNodeStatusEnum.Passed,
                    logs: ['remote-peer-executed']
                }
            };
        });

        const result = await handler({ ...createContext(workflow), invokeConnectedNode });
        const output = result.output as Record<string, any>;
        const openAiNode = workflow.nodes.find((node) => node.id === 'node_2');

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.peerOutput.prompt).toBe('temporary prompt');
        expect(output.snapshotPrompt).toBe(null);
        expect(openAiNode?.runtime.prompt).toBeUndefined();
    }, 20000);

    it('exposes command tool specs through CONTROL_NODES', async () => {
        const workflow = createCommandWorkflow({
            sourceHandle: 'cmd:command',
            targetHandle: 'cmd:llm'
        });
        workflow.nodeModels = {
            ...(workflow.nodeModels || {}),
            'action-router': {
                inputs: {
                    input: {}
                },
                outputs: {
                    output: {}
                },
                commands: {
                    command: { portType: 'bi-directional', allowMultipleArrows: true }
                }
            }
        };
        workflow.nodes[1] = {
            ...workflow.nodes[1],
            modelId: 'action-router',
            name: 'Channel Router',
            runtime: {
                ...(workflow.nodes[1].runtime || {}),
                toolName: 'Channel Actions',
                toolDescription: 'Read channels.',
                broadcastModelId: 'run-channel-action'
            }
        };
        workflow.NODE_EXECUTORS = {
            ...workflow.NODE_EXECUTORS,
            openai: toBase64(ROUTER_SOURCE_WITH_TOOL_SPEC),
            'action-router': toBase64(ROUTER_SOURCE_WITH_TOOL_SPEC)
        };
        workflow.NODE_EXECUTOR_SIGNATURES = {
            ...workflow.NODE_EXECUTOR_SIGNATURES,
            openai: createNodeExecutorSignature('action-router', ROUTER_SOURCE_WITH_TOOL_SPEC),
            'action-router': createNodeExecutorSignature('action-router', ROUTER_SOURCE_WITH_TOOL_SPEC)
        };
        const governorSource = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = Object.values(payload.NODE.CONTROL_NODES.llm || {})[0];
  const spec = await peer.commandToolSpec();
  return { output: spec, status: 'passed', logs: [] };
};`;
        workflow.NODE_EXECUTORS.governor = toBase64(governorSource);
        workflow.NODE_EXECUTOR_SIGNATURES.governor = createNodeExecutorSignature('governor', governorSource);
        const handler = createWorkerNodeHandler({ modelId: 'governor', runtimeEnvironment: 'node' });

        const result = await handler(createContext(workflow));
        const output = result.output as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.toolName).toBe('Channel Actions');
        expect(output.metadata.broadcastModelId).toBe('run-channel-action');
    }, 20000);
});
