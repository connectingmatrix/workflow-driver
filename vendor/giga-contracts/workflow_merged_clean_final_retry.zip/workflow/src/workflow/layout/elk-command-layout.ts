import { getAllNodeSchemas, resolveNodeSchema } from '@workflow/nodes/node-utils';
import type { WorkflowDefinition, WorkflowNodePortSide } from '@workflow/ui/workflow/types';
import { WORKFLOW_LAYOUT_COMMAND_GAP } from '@workflow/ui/workflow/layout/layout-constants';
import { readLayoutGraph } from '@workflow/ui/workflow/layout/layout-graph';
import { resolveElkNodeSize } from '@workflow/ui/workflow/layout/elk-node.utils';
import { getNormalizedCommandPorts, resolveCommandPortIdFromHandle } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';

const resolveAnchorSide = (workflow: WorkflowDefinition, nodeId: string, handleId: string | undefined, direction: 'inputs' | 'outputs'): WorkflowNodePortSide => {
    const node = workflow.nodes.find((entry) => entry.id === nodeId);
    if (!node) return 'right';
    const schema = resolveNodeSchema(node.modelId, workflow.nodeModels || getAllNodeSchemas());
    const portId = resolveCommandPortIdFromHandle(schema, handleId, direction);
    return getNormalizedCommandPorts(schema)[portId || '']?.side || 'right';
};

const resolveOffset = (index: number, total: number): number => (index - (total - 1) / 2) * WORKFLOW_LAYOUT_COMMAND_GAP;

export const placeElkCommandNodes = (workflow: WorkflowDefinition, positions: Record<string, { x: number; y: number }>): Record<string, { x: number; y: number }> => {
    const graph = readLayoutGraph(workflow);
    const next = { ...positions };
    const groups = graph.commandNodeIds.reduce<Record<string, Array<{ nodeId: string; anchorId: string; side: WorkflowNodePortSide }>>>((record, nodeId) => {
        const outbound = graph.commandLinks.find((link) => link.from === nodeId && graph.mainNodeIds.includes(link.to));
        const inbound = graph.commandLinks.find((link) => link.to === nodeId && graph.mainNodeIds.includes(link.from));
        const anchorLink = outbound || inbound;
        if (!anchorLink) return record;
        const anchorId = outbound ? outbound.to : inbound!.from;
        const side = outbound ? resolveAnchorSide(workflow, anchorId, outbound.targetHandle, 'inputs') : resolveAnchorSide(workflow, anchorId, inbound!.sourceHandle, 'outputs');
        record[`${anchorId}:${side}`] = [...(record[`${anchorId}:${side}`] || []), { nodeId, anchorId, side }];
        return record;
    }, {});

    Object.values(groups).forEach((items) => {
        items.forEach((item, index) => {
            const anchorNode = workflow.nodes.find((node) => node.id === item.anchorId);
            const commandNode = workflow.nodes.find((node) => node.id === item.nodeId);
            if (!anchorNode || !commandNode || !next[item.anchorId]) return;
            const anchorSize = resolveElkNodeSize(resolveNodeSchema(anchorNode.modelId, workflow.nodeModels || getAllNodeSchemas()));
            const commandSize = resolveElkNodeSize(resolveNodeSchema(commandNode.modelId, workflow.nodeModels || getAllNodeSchemas()));
            const offset = resolveOffset(index, items.length);
            next[item.nodeId] =
                item.side === 'bottom'
                    ? { x: next[item.anchorId].x + (anchorSize.width - commandSize.width) / 2 + offset, y: next[item.anchorId].y + anchorSize.height + 72 }
                    : item.side === 'top'
                      ? { x: next[item.anchorId].x + (anchorSize.width - commandSize.width) / 2 + offset, y: next[item.anchorId].y - commandSize.height - 72 }
                      : item.side === 'left'
                        ? { x: next[item.anchorId].x - commandSize.width - 120, y: next[item.anchorId].y + (anchorSize.height - commandSize.height) / 2 + offset }
                        : { x: next[item.anchorId].x + anchorSize.width + 120, y: next[item.anchorId].y + (anchorSize.height - commandSize.height) / 2 + offset };
        });
    });

    return next;
};
