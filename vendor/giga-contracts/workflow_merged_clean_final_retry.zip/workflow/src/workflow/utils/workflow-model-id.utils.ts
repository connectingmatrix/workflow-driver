const START_MODEL_ID = 'start';
const END_MODEL_ID = 'respond-end';

const START_MODEL_ALIASES = new Set(['start', 'start-node', 'startnode']);
const END_MODEL_ALIASES = new Set(['respond-end', 'respond-end-node', 'respondend', 'respondendnode', 'end', 'end-node']);

const toNormalizedToken = (value: unknown): string => {
    if (typeof value !== 'string') return '';
    const trimmed = value.trim();
    if (!trimmed) return '';
    const lowered = trimmed.toLowerCase();
    return lowered.replace(/[\s_]+/g, '-');
};

const toCompactedToken = (value: string): string => value.replace(/[-_]/g, '');

const asRecord = (value: unknown): Record<string, unknown> | null => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : null);

const asString = (value: unknown): string | null => (typeof value === 'string' ? value : null);

const collectModelCandidates = (value: unknown): string[] => {
    const direct = asString(value);
    if (direct !== null) {
        return [direct];
    }

    const record = asRecord(value);
    if (!record) {
        return [];
    }

    const runtime = asRecord(record.runtime);
    const properties = asRecord(record.properties);
    const inspector = asRecord(record.inspector);
    const inspectorProperties = asRecord(inspector?.properties);

    return [record.modelId, record.nodeLibraryId, record.gigaId, runtime?.nodeLibraryId, properties?.nodeLibraryId, inspectorProperties?.nodeLibraryId]
        .map((candidate) => asString(candidate))
        .filter((candidate): candidate is string => typeof candidate === 'string' && candidate.trim().length > 0);
};

export const normalizeWorkflowModelId = (value: unknown): string => {
    const candidates = collectModelCandidates(value);
    let fallback = '';
    for (const candidate of candidates) {
        const trimmed = candidate.trim();
        if (!trimmed) continue;
        if (!fallback) fallback = trimmed;
        const normalized = toNormalizedToken(trimmed);
        const compacted = toCompactedToken(normalized);
        if (START_MODEL_ALIASES.has(normalized) || START_MODEL_ALIASES.has(compacted)) {
            return START_MODEL_ID;
        }
        if (END_MODEL_ALIASES.has(normalized) || END_MODEL_ALIASES.has(compacted)) {
            return END_MODEL_ID;
        }
    }
    return fallback;
};

export const isStartWorkflowModel = (value: unknown): boolean => normalizeWorkflowModelId(value) === START_MODEL_ID;

export const isRespondEndWorkflowModel = (value: unknown): boolean => normalizeWorkflowModelId(value) === END_MODEL_ID;
