import React from 'react';
import type { NodeInspectorProps } from '@workflow/ui/workflow/components/inspector/node-inspector.types';
import WorkspaceNodeInspector from '@workflow/ui/workflow/components/inspector/workspace/WorkspaceNodeInspector';

const NodeInspector: React.FC<NodeInspectorProps> = (props) => <WorkspaceNodeInspector {...props} />;

export default NodeInspector;
