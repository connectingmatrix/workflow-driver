import React from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { WorkflowPreviewRuntime } from '@workflow/ui/workflow/types';

interface UserNodeCodeToolbarProps {
    browserRuntimeAllowed: boolean;
    canRun: boolean;
    inputMode: 'sample' | 'last' | 'upstream';
    isRunning: boolean;
    onClearLogs: () => void;
    onInputModeChange: (value: 'sample' | 'last' | 'upstream') => void;
    onRevert: () => void;
    onRun: () => void;
    onRunOnServer: () => void;
    onSave: () => void;
    onStop: () => void;
    runtimeMode: WorkflowPreviewRuntime;
    runtimeFallbackReason: string | null;
    runtimeResolved: 'browser' | 'node';
    setRuntimeMode: (value: WorkflowPreviewRuntime) => void;
    upstreamInputAvailable: boolean;
}

const RUNTIME_OPTIONS = [
    { label: 'Auto', value: 'auto' },
    { label: 'Browser', value: 'browser' },
    { label: 'Backend (Node)', value: 'node' }
] as const;

const INPUT_OPTIONS = [
    { label: 'Sample Input', value: 'sample' },
    { label: 'Last Run Input', value: 'last' },
    { label: 'Workflow Upstream', value: 'upstream' }
] as const;

export const buildRuntimeOptions = (browserRuntimeAllowed: boolean): Array<{ label: string; value: WorkflowPreviewRuntime; disabled?: boolean }> =>
    RUNTIME_OPTIONS.map((option) => ({ ...option, disabled: option.value === 'browser' && !browserRuntimeAllowed }));

export const buildInputOptions = (upstreamInputAvailable: boolean): Array<{ label: string; value: 'sample' | 'last' | 'upstream'; disabled?: boolean }> =>
    INPUT_OPTIONS.map((option) => ({ ...option, disabled: option.value === 'upstream' && !upstreamInputAvailable }));

const UserNodeCodeToolbar: React.FC<UserNodeCodeToolbarProps> = ({
    browserRuntimeAllowed,
    canRun,
    inputMode,
    isRunning,
    onClearLogs,
    onInputModeChange,
    onRevert,
    onRun,
    onRunOnServer,
    onSave,
    onStop,
    runtimeMode,
    runtimeFallbackReason,
    runtimeResolved,
    setRuntimeMode,
    upstreamInputAvailable
}) => (
    <div className="wf-user-node-toolbar">
        <div className="flex align-items-center gap-2">
            <Button
                icon="pi pi-play"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onRun}
                disabled={!canRun || isRunning}
                data-cy="user-node-run"
                aria-label="Run node"
                tooltip="Run Node"
                tooltipOptions={{ position: 'bottom' }}
            />
            <Button
                icon="pi pi-server"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onRunOnServer}
                disabled={!canRun || isRunning}
                data-cy="user-node-run-server"
                aria-label="Run node on server"
                tooltip="Run on Server"
                tooltipOptions={{ position: 'bottom' }}
            />
            <Button
                icon="pi pi-stop"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onStop}
                disabled={!isRunning}
                data-cy="user-node-stop"
                aria-label="Stop node run"
                tooltip="Stop"
                tooltipOptions={{ position: 'bottom' }}
            />
            <span className="text-sm text-500" data-cy="user-node-runtime-badge">
                Runtime: {runtimeResolved === 'browser' ? 'Browser' : 'Node'}
            </span>
            {runtimeFallbackReason ? <span className="text-xs text-orange-500">{runtimeFallbackReason}</span> : null}
        </div>
        <div className="flex align-items-center gap-2 flex-wrap justify-content-end">
            <Dropdown
                value={runtimeMode}
                options={buildRuntimeOptions(browserRuntimeAllowed) as unknown as Array<{ label: string; value: WorkflowPreviewRuntime; disabled?: boolean }>}
                optionDisabled="disabled"
                onChange={(event) => setRuntimeMode(event.value)}
                className="p-inputtext-sm"
                data-cy="user-node-runtime-mode"
            />
            <Dropdown
                value={inputMode}
                options={buildInputOptions(upstreamInputAvailable) as unknown as Array<{ label: string; value: 'sample' | 'last' | 'upstream'; disabled?: boolean }>}
                optionDisabled="disabled"
                onChange={(event) => onInputModeChange(event.value)}
                className="p-inputtext-sm"
                data-cy="user-node-input-mode"
            />
            <Button
                icon="pi pi-eraser"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onClearLogs}
                data-cy="user-node-clear-logs"
                aria-label="Clear logs"
                tooltip="Clear Logs"
                tooltipOptions={{ position: 'bottom' }}
            />
            <Button
                icon="pi pi-refresh"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onRevert}
                disabled={isRunning}
                data-cy="user-node-revert"
                aria-label="Revert code changes"
                tooltip="Revert"
                tooltipOptions={{ position: 'bottom' }}
            />
            <Button
                icon="pi pi-save"
                text
                rounded
                className="p-button-sm wf-user-node-icon-btn"
                onClick={onSave}
                disabled={isRunning}
                data-cy="user-node-save"
                aria-label="Save node"
                tooltip="Save"
                tooltipOptions={{ position: 'bottom' }}
            />
        </div>
    </div>
);

export default UserNodeCodeToolbar;
