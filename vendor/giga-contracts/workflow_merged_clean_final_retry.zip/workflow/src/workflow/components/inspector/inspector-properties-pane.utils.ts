import { WorkflowInspectorFieldLayoutPreset, WorkflowNodeFieldDefinition, WorkflowNodeFieldMap, WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';

const ALWAYS_HIDDEN_KEYS = new Set(['status', 'source', 'timestamp', 'nodelibraryid', 'code', 'markdown', 'credentialid']);
const PRIORITY_FIELDS = ['name', 'description'];
const DEFERRED_FIELDS = new Set(['forwardsessionlogs']);

const inferFieldTypeFromValue = (fieldKey: string, value: unknown): WorkflowNodeFieldDefinition['type'] => {
    if (fieldKey.toLowerCase() === 'description') return WorkflowNodeFieldTypeEnum.Textarea;
    if (typeof value === 'boolean') return WorkflowNodeFieldTypeEnum.Boolean;
    if (typeof value === 'number') return WorkflowNodeFieldTypeEnum.Number;
    if (value && typeof value === 'object') return WorkflowNodeFieldTypeEnum.Json;
    return WorkflowNodeFieldTypeEnum.String;
};

const shouldDisplayRetryField = (fieldKey: string, values: Record<string, unknown>): boolean => {
    if (fieldKey !== 'retryCount') return true;
    return String(values.failureMitigation ?? '').trim() === 'retry-node';
};

const matchesVisibleCondition = (definition: WorkflowNodeFieldDefinition, values: Record<string, unknown>): boolean => {
    const visibleWhen = definition.visibleWhen;
    if (!visibleWhen?.field) return true;
    const current = values[visibleWhen.field];
    const normalizedList = Array.isArray(current) ? current.map((entry) => String(entry ?? '').trim().toLowerCase()).filter(Boolean) : [];
    const normalizedValue = normalizedList[0] || String(current ?? '').trim().toLowerCase();
    if (visibleWhen.equals && normalizedValue !== visibleWhen.equals) return false;
    if (visibleWhen.notEquals && normalizedValue === visibleWhen.notEquals) return false;
    if (visibleWhen.includes?.length) {
        if (normalizedList.length) return visibleWhen.includes.some((entry) => normalizedList.includes(entry));
        return visibleWhen.includes.includes(normalizedValue);
    }
    return true;
};

export const buildVisibleInspectorFields = (args: {
    fields: WorkflowNodeFieldMap;
    values: Record<string, unknown>;
    hiddenFieldKeys: string[];
    propertyOrder?: string[];
    shouldDisplayField?: (fieldKey: string, values: Record<string, unknown>, fields: WorkflowNodeFieldMap) => boolean;
}): Array<[string, WorkflowNodeFieldDefinition]> => {
    const { fields, values, hiddenFieldKeys, propertyOrder = [], shouldDisplayField } = args;
    const mapped = new Map<string, WorkflowNodeFieldDefinition>(Object.entries(fields ?? {}));
    const hiddenFieldKeySet = new Set(hiddenFieldKeys.map((fieldKey) => fieldKey.toLowerCase()));
    const propertyOrderLookup = new Map(propertyOrder.map((fieldKey, index) => [fieldKey.toLowerCase(), index]));

    Object.keys(values).forEach((key) => {
        if (!mapped.has(key)) {
            mapped.set(key, { type: inferFieldTypeFromValue(key, values[key]), editable: true });
        }
    });

    return Array.from(mapped.entries())
        .filter(([key, definition]) => {
            const normalizedKey = key.toLowerCase();
            if (ALWAYS_HIDDEN_KEYS.has(normalizedKey) || definition.hidden || !shouldDisplayRetryField(key, values)) {
                return false;
            }
            if (hiddenFieldKeySet.has(normalizedKey)) {
                return false;
            }
            if (!matchesVisibleCondition(definition, values)) {
                return false;
            }
            if (shouldDisplayField && !shouldDisplayField(key, values, fields)) {
                return false;
            }
            return true;
        })
        .sort(([leftKey], [rightKey]) => {
            const leftNormalized = leftKey.toLowerCase();
            const rightNormalized = rightKey.toLowerCase();
            const leftOrder = propertyOrderLookup.get(leftNormalized);
            const rightOrder = propertyOrderLookup.get(rightNormalized);
            if (leftOrder !== undefined || rightOrder !== undefined) {
                if (leftOrder === undefined) return 1;
                if (rightOrder === undefined) return -1;
                if (leftOrder !== rightOrder) return leftOrder - rightOrder;
            }

            const leftDeferred = DEFERRED_FIELDS.has(leftNormalized);
            const rightDeferred = DEFERRED_FIELDS.has(rightNormalized);
            if (leftDeferred && !rightDeferred) return 1;
            if (rightDeferred && !leftDeferred) return -1;

            const leftPriority = PRIORITY_FIELDS.indexOf(leftNormalized);
            const rightPriority = PRIORITY_FIELDS.indexOf(rightNormalized);
            if (leftPriority === -1 && rightPriority === -1) return leftKey.localeCompare(rightKey);
            if (leftPriority === -1) return 1;
            if (rightPriority === -1) return -1;
            return leftPriority - rightPriority;
        });
};

export const stripHiddenUnknownInspectorValues = (fields: WorkflowNodeFieldMap, values: Record<string, unknown>, hiddenFieldKeys: string[]): Record<string, unknown> =>
    Object.entries(values).reduce<Record<string, unknown>>((acc, [key, value]) => {
        const normalizedKey = key.toLowerCase();
        if (ALWAYS_HIDDEN_KEYS.has(normalizedKey) || fields[key] || !hiddenFieldKeys.some((fieldKey) => fieldKey.toLowerCase() === normalizedKey)) {
            acc[key] = value;
        }
        return acc;
    }, {});

export const resolveInspectorLayoutPreset = (definition: WorkflowNodeFieldDefinition): WorkflowInspectorFieldLayoutPreset => definition.styles?.layoutPreset ?? 'inline';

export const resolveInspectorBooleanStateVisibility = (definition: WorkflowNodeFieldDefinition): boolean => definition.styles?.showBooleanState ?? true;
