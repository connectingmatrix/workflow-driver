declare module '@workflow/execute' {
    export interface WorkflowExecuteBackendDescriptor {
        service: string;
        function: string;
        description?: string;
    }

    export interface WorkflowInvokeConnectedNodeOverrides {
        runtime?: Record<string, unknown>;
        properties?: Record<string, unknown>;
        code?: string;
        markdown?: string;
    }

    export interface WorkflowInvokeConnectedNodeArgs {
        nodeId: string;
        input?: Record<string, Record<string, unknown>>;
        overrides?: WorkflowInvokeConnectedNodeOverrides;
    }

    /**
     * This will execute the backend service path, backend service function,
     * and description of what that service does.
     */
    export const executeBackend: (descriptor: WorkflowExecuteBackendDescriptor, payload?: unknown) => Promise<unknown>;
    export const invokeConnectedNode: (args: WorkflowInvokeConnectedNodeArgs) => Promise<unknown>;
    export const updateNode: (args: unknown) => Promise<void> | void;
}
