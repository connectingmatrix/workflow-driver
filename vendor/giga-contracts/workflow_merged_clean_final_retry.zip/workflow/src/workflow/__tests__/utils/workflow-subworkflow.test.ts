import { describe, expect, it } from 'vitest';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { createOrExtendSubworkflow, findExpandedSubworkflowIdAtPosition, moveSubworkflowNodes, SUBWORKFLOW_BOX_PREFIX, toggleSubworkflowCollapsed, ungroupSubworkflow } from '@workflow/ui/workflow/utils/workflow-subworkflow.utils';

describe('workflow subworkflow utils', () => {
    it('moves all member nodes when a subworkflow is dragged by delta', () => {
        const workflow = createEmptyWorkflow('wf_subworkflow_move');
        const nodeA = createWorkflowNode(workflow, 'metadata', 'Metadata A', 1);
        const nodeB = createWorkflowNode(workflow, 'code', 'Code B', 2);
        const nodeC = createWorkflowNode(workflow, 'respond-end', 'End C', 3);
        workflow.nodes = [nodeA, nodeB, nodeC];
        workflow.metadata.ui = {
            subworkflows: [{ id: 'sw_alpha', name: 'Alpha', nodeIds: [nodeA.id, nodeB.id], collapsed: false }]
        };

        const moved = moveSubworkflowNodes(workflow, 'sw_alpha', { x: 80, y: -25 });
        const movedA = moved.nodes.find((node) => node.id === nodeA.id);
        const movedB = moved.nodes.find((node) => node.id === nodeB.id);
        const movedC = moved.nodes.find((node) => node.id === nodeC.id);

        expect(movedA?.position).toEqual({ x: nodeA.position.x + 80, y: nodeA.position.y - 25 });
        expect(movedB?.position).toEqual({ x: nodeB.position.x + 80, y: nodeB.position.y - 25 });
        expect(movedC?.position).toEqual(nodeC.position);
    });

    it('resolves expanded subworkflow id for drop hit-testing', () => {
        const workflow = createEmptyWorkflow('wf_subworkflow_hit_test');
        const nodeA = createWorkflowNode(workflow, 'metadata', 'Metadata A', 1);
        const nodeB = createWorkflowNode(workflow, 'code', 'Code B', 2);
        const nodeC = createWorkflowNode(workflow, 'respond-end', 'End C', 3);
        workflow.nodes = [nodeA, nodeB, nodeC];
        workflow.metadata.ui = {
            subworkflows: [
                { id: 'sw_first', name: 'First', nodeIds: [nodeA.id, nodeB.id], collapsed: false },
                { id: 'sw_collapsed', name: 'Collapsed', nodeIds: [nodeC.id], collapsed: true }
            ]
        };

        expect(findExpandedSubworkflowIdAtPosition(workflow, { x: nodeA.position.x + 10, y: nodeA.position.y + 10 })).toBe('sw_first');
        expect(findExpandedSubworkflowIdAtPosition(workflow, { x: nodeC.position.x + 10, y: nodeC.position.y + 10 })).toBeNull();
        expect(findExpandedSubworkflowIdAtPosition(workflow, { x: Number.NaN, y: 20 })).toBeNull();
    });

    it('guards stale ids safely when creating/extending/toggling subworkflows', () => {
        const workflow = createEmptyWorkflow('wf_subworkflow_guards');
        const nodeA = createWorkflowNode(workflow, 'metadata', 'Metadata A', 1);
        const nodeB = createWorkflowNode(workflow, 'code', 'Code B', 2);
        workflow.nodes = [nodeA, nodeB];
        workflow.metadata.ui = {
            subworkflows: [{ id: 'sw_existing', name: 'Existing', nodeIds: [nodeA.id], collapsed: false }]
        };

        const staleExtend = createOrExtendSubworkflow(workflow, [nodeB.id], 'sw_missing');
        expect(staleExtend).toBe(workflow);

        const createWithStaleSelection = createOrExtendSubworkflow(workflow, ['missing_node', `${SUBWORKFLOW_BOX_PREFIX}sw_existing`, nodeB.id]);
        const created = createWithStaleSelection.metadata.ui?.subworkflows?.find((entry) => entry.id !== 'sw_existing');
        expect(created?.nodeIds).toEqual([nodeB.id]);

        const staleToggle = toggleSubworkflowCollapsed(workflow, 'sw_missing', true);
        expect(staleToggle).toBe(workflow);
    });

    it('ungroups subworkflow metadata only and keeps member nodes/connections intact', () => {
        const workflow = createEmptyWorkflow('wf_subworkflow_ungroup');
        const nodeA = createWorkflowNode(workflow, 'metadata', 'Metadata A', 1);
        const nodeB = createWorkflowNode(workflow, 'code', 'Code B', 2);
        workflow.nodes = [nodeA, nodeB];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'A -> B',
                from: nodeA.id,
                to: nodeB.id,
                sourceHandle: 'out:output',
                targetHandle: 'in:input'
            }
        ];
        workflow.metadata.ui = {
            subworkflows: [{ id: 'sw_group', name: 'Group', nodeIds: [nodeA.id, nodeB.id], collapsed: false }]
        };

        const next = ungroupSubworkflow(workflow, 'sw_group');
        expect(next.metadata.ui?.subworkflows ?? []).toHaveLength(0);
        expect(next.nodes).toHaveLength(2);
        expect(next.connections).toHaveLength(1);

        const staleUngroup = ungroupSubworkflow(workflow, 'sw_missing');
        expect(staleUngroup).toBe(workflow);
    });
});
