import { getAllNodeSchemas, resolveNodeSchema } from '@workflow/nodes/node-utils';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowExportMode, WorkflowExportPayload, WorkflowNodeModel, WorkflowNodePorts, WorkflowNodeSchema } from '@workflow/ui/workflow/types';
import { buildNodePorts, buildNodeRuntimeMap, parseKind, parsePosition, parseRecord, parseStatus, stripSessionLogs } from '@workflow/ui/workflow/utils/workflow-serialization-shape.utils';
import { claimUniqueNodeName, normalizeNodeName } from '@workflow/ui/workflow/utils/workflow-node-name.utils';
import { stringifyWorkflowJsonValue } from '@workflow/ui/workflow/utils/workflow-json-value.utils';

const makeNodeExportKey = (node: WorkflowNodeModel): string => normalizeNodeName(node.name, node.id);

export const workflowToExportPayload = (workflow: WorkflowDefinition, exportMode: WorkflowExportMode): WorkflowExportPayload => {
    const nameById = workflow.nodes.reduce<Record<string, string>>((acc, node) => {
        acc[node.id] = normalizeNodeName(node.name, node.id);
        return acc;
    }, {});
    const nodes = workflow.nodes.reduce<Record<string, WorkflowExportPayload['nodes'][string]>>((acc, node) => {
        acc[makeNodeExportKey(node)] = {
            id: node.id,
            gigaId: node.gigaId,
            modelId: node.modelId,
            type: node.type,
            name: node.name,
            description: node.description,
            status: node.status,
            kind: node.kind,
            position: node.position,
            runtime: exportMode === 'with-data' ? buildNodeRuntimeMap(node) : { status: node.status },
            ports: exportMode === 'with-data' ? buildNodePorts(node) : { in: {}, out: {} }
        };
        return acc;
    }, {});
    const connections = workflow.connections.reduce<Record<string, WorkflowExportPayload['connections'][string]>>((acc, connection) => {
        acc[connection.id] = {
            id: connection.id,
            name: connection.name,
            from: nameById[connection.from] ?? connection.from,
            to: nameById[connection.to] ?? connection.to,
            fromId: connection.from,
            toId: connection.to,
            sourceHandle: connection.sourceHandle,
            targetHandle: connection.targetHandle,
            text: connection.text
        };
        return acc;
    }, {});
    const sourceNodeModels = workflow.nodeModels ?? getAllNodeSchemas();
    const nodeModels =
        exportMode === 'with-data'
            ? Object.keys(sourceNodeModels).reduce<Record<string, WorkflowNodeSchema>>((acc, modelId) => {
                  acc[modelId] = resolveNodeSchema(modelId, sourceNodeModels);
                  return acc;
              }, {})
            : undefined;
    const nodeExecutors = exportMode === 'with-data' ? workflow.NODE_EXECUTORS : undefined;
    const nodeExecutorSignatures = exportMode === 'with-data' ? workflow.NODE_EXECUTOR_SIGNATURES : undefined;
    return {
        exportMode,
        metadata: stripSessionLogs(workflow.metadata),
        nodes,
        connections,
        ...(nodeModels ? { nodeModels } : {}),
        ...(nodeExecutors ? { NODE_EXECUTORS: nodeExecutors } : {}),
        ...(nodeExecutorSignatures ? { NODE_EXECUTOR_SIGNATURES: nodeExecutorSignatures } : {})
    };
};

const buildNodeFromPayload = (key: string, value: WorkflowExportPayload['nodes'][string], index: number, usedNames: Set<string>): WorkflowNodeModel => {
    const legacy = value as WorkflowExportPayload['nodes'][string] & {
        input?: unknown;
        output?: unknown;
        properties?: unknown;
        inspector?: WorkflowNodeModel['inspector'];
        runtime?: Record<string, unknown> & { input?: unknown; output?: unknown; properties?: unknown; inspector?: WorkflowNodeModel['inspector'] };
    };
    const runtimeRecord = parseRecord(legacy.runtime);
    const runtime = { ...parseRecord(legacy.properties), ...parseRecord(legacy.runtime?.properties), ...runtimeRecord, ...parseRecord(legacy.inspector?.properties), ...parseRecord(legacy.runtime?.inspector?.properties) };
    const code = legacy.inspector?.code ?? legacy.runtime?.inspector?.code ?? runtimeRecord.code;
    const markdown = legacy.inspector?.markdown ?? legacy.runtime?.inspector?.markdown ?? runtimeRecord.markdown;
    if (typeof code === 'string') runtime.code = code;
    if (typeof markdown === 'string') runtime.markdown = markdown;
    const ports: WorkflowNodePorts = {
        in: parseRecord(legacy.ports?.in ?? legacy.runtime?.input ?? legacy.input) as WorkflowNodePorts['in'],
        out: parseRecord(legacy.ports?.out ?? legacy.runtime?.output ?? legacy.output)
    };
    if (!Object.keys(ports.out).length) ports.out = { output: legacy.output ?? {} };
    const name = claimUniqueNodeName(value.name ?? key, usedNames, `Node ${index + 1}`);
    return {
        id: value.id ?? `node_${index + 1}`,
        gigaId: value.gigaId ?? value.modelId,
        modelId: value.modelId || 'code',
        type: value.type ?? 'workflowStep',
        name,
        description: String(value.description ?? runtime.description ?? ''),
        kind: parseKind(value.kind),
        status: parseStatus(value.status ?? runtime.status),
        position: parsePosition(value.position, index),
        runtime,
        ports,
        render: resolveNodeSchema(value.modelId || 'code', getAllNodeSchemas()).render,
        input: parseRecord(ports.in.input),
        output: Object.prototype.hasOwnProperty.call(ports.out, 'output') ? ports.out.output : ports.out,
        properties: runtime,
        inspector: { title: name, input: parseRecord(ports.in.input), properties: runtime, code: typeof runtime.code === 'string' ? runtime.code : '', markdown: typeof runtime.markdown === 'string' ? runtime.markdown : '', viewers: [] }
    };
};

export const exportPayloadToWorkflow = (payload: WorkflowExportPayload): WorkflowDefinition => {
    const usedNames = new Set<string>();
    const nodes = Object.entries(payload.nodes ?? {}).map(([key, value], index) => buildNodeFromPayload(key, value, index, usedNames));
    const localNodeModels = getAllNodeSchemas();
    const payloadNodeModels = payload.nodeModels ?? {};
    const modelIds = new Set<string>([...Object.keys(localNodeModels), ...Object.keys(payloadNodeModels), ...nodes.map((node) => node.modelId)]);
    const mergedNodeModels = Array.from(modelIds).reduce<Record<string, WorkflowNodeSchema>>((acc, modelId) => {
        acc[modelId] = resolveNodeSchema(modelId, { ...localNodeModels, ...payloadNodeModels });
        return acc;
    }, {});
    const idByName = nodes.reduce<Record<string, string>>((acc, node) => {
        acc[normalizeNodeName(node.name).toLowerCase()] = node.id;
        return acc;
    }, {});
    const ids = new Set(nodes.map((node) => node.id));
    const resolveRef = (name: string | undefined, id: string | undefined): string => {
        const normalized = normalizeNodeName(name ?? '', '').toLowerCase();
        if (normalized && idByName[normalized]) return idByName[normalized];
        if (normalized && ids.has(normalized)) return normalized;
        if (id && ids.has(id)) return id;
        return '';
    };
    const connections: WorkflowConnectionModel[] = Object.values(payload.connections ?? {})
        .map((connection) => ({
            id: connection.id ?? connection.name,
            name: connection.name ?? connection.id,
            from: resolveRef(connection.from, connection.fromId),
            to: resolveRef(connection.to, connection.toId),
            sourceHandle: connection.sourceHandle,
            targetHandle: connection.targetHandle,
            text: connection.text
        }))
        .filter((connection) => connection.from && connection.to);
    return {
        metadata: { ...payload.metadata, id: String(payload.metadata?.id ?? 'workflow_imported'), name: String(payload.metadata?.name ?? 'Imported Workflow') },
        nodeModels: mergedNodeModels,
        NODE_EXECUTORS: payload.NODE_EXECUTORS && typeof payload.NODE_EXECUTORS === 'object' ? payload.NODE_EXECUTORS : undefined,
        NODE_EXECUTOR_SIGNATURES: payload.NODE_EXECUTOR_SIGNATURES && typeof payload.NODE_EXECUTOR_SIGNATURES === 'object' ? payload.NODE_EXECUTOR_SIGNATURES : undefined,
        nodes,
        connections
    };
};

export const downloadWorkflowJson = (workflow: WorkflowDefinition, exportMode: WorkflowExportMode): void => {
    const payload = workflowToExportPayload(workflow, exportMode);
    const blob = new Blob([stringifyWorkflowJsonValue(payload, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${workflow.metadata.id ?? 'workflow'}-${exportMode}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
};
