import React from 'react';

interface WorkflowSettingsSectionCardProps {
    icon: string;
    title: string;
    description: string;
    children: React.ReactNode;
}

const WorkflowSettingsSectionCard: React.FC<WorkflowSettingsSectionCardProps> = ({ icon, title, description, children }) => (
    <section className="wf-workspace-settings__card">
        <header className="wf-workspace-settings__card-header">
            <div className="wf-workspace-settings__card-icon"><i className={icon} aria-hidden /></div>
            <div>
                <h3>{title}</h3>
                <p>{description}</p>
            </div>
        </header>
        <div className="wf-workspace-settings__card-body">{children}</div>
    </section>
);

export default WorkflowSettingsSectionCard;
