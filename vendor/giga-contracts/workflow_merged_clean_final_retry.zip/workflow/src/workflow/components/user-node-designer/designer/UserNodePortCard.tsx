import React from 'react';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { WorkflowNodePortSideEnum } from '@workflow/ui/workflow/types';
import { UserNodePortDraft, UserNodePortDraftKind, updatePortDraftKind } from './user-node-schema-draft.utils';

const PORT_SIDES = Object.values(WorkflowNodePortSideEnum).map((value) => ({ label: value, value }));
const PORT_TYPES: Array<{ label: string; value: UserNodePortDraftKind }> = [
    { label: 'Input', value: 'input' },
    { label: 'Output', value: 'output' },
    { label: 'Command', value: 'command' }
];

interface UserNodePortCardProps {
    port: UserNodePortDraft;
    onChange: (nextPort: UserNodePortDraft) => void;
    onRemove: () => void;
}

const UserNodePortCard: React.FC<UserNodePortCardProps> = ({ port, onChange, onRemove }) => {
    const isCommand = port.kind === 'command';
    const isInput = port.kind === 'input';
    const isOutput = port.kind === 'output';

    return (
        <div className="wf-user-node-designer__card-grid">
            <Dropdown value={port.kind} options={PORT_TYPES} onChange={(event) => onChange(updatePortDraftKind(port, String(event.value) as UserNodePortDraftKind))} />
            <InputText value={port.key} onChange={(event) => onChange({ ...port, key: event.target.value })} placeholder="Port name" />
            <InputText value={port.label} onChange={(event) => onChange({ ...port, label: event.target.value })} placeholder="Display label" />
            <Dropdown value={port.side} options={PORT_SIDES} onChange={(event) => onChange({ ...port, side: String(event.value) })} />
            {isCommand ? (
                <>
                    <InputText value={port.acceptedSourceGroups} onChange={(event) => onChange({ ...port, acceptedSourceGroups: event.target.value })} placeholder="Accepted groups" />
                    <InputText value={port.acceptedSourceModelIds} onChange={(event) => onChange({ ...port, acceptedSourceModelIds: event.target.value })} placeholder="Accepted model ids" />
                </>
            ) : (
                <>
                    <span />
                    <span />
                </>
            )}
            {isInput ? (
                <label className="wf-user-node-designer__checkbox-row">
                    <Checkbox checked={port.allowMultipleArrows} onChange={(event) => onChange({ ...port, allowMultipleArrows: Boolean(event.checked) })} />
                    Allow multiple
                </label>
            ) : isOutput ? (
                <label className="wf-user-node-designer__checkbox-row">
                    <Checkbox checked={port.showQuickAdd} onChange={(event) => onChange({ ...port, showQuickAdd: Boolean(event.checked) })} />
                    Show quick add
                </label>
            ) : (
                <span className="wf-user-node-designer__port-kind-note">Single visual command port</span>
            )}
            <Button type="button" icon="pi pi-trash" severity="secondary" text aria-label={`Remove ${port.key || 'port'}`} onClick={onRemove} />
        </div>
    );
};

export default UserNodePortCard;
