import type { WorkspaceInputTableRow } from '@workflow/ui/workflow/components/inspector/workspace/types';

const formatWorkspaceValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null || typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
};

export const buildWorkspaceInputRows = (inputData: Record<string, unknown>): WorkspaceInputTableRow[] =>
    Object.entries(inputData).map(([key, value]) => ({
        key,
        value: formatWorkspaceValue(value)
    }));
