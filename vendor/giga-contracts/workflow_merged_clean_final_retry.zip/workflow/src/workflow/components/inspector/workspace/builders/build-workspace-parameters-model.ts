import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowInspectorModuleDefinition } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import type { WorkspaceParametersPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WORKSPACE_ACTION_IDS } from '@workflow/ui/workflow/components/inspector/workspace/constants';
import { buildWorkspaceParameterSections } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-parameter-sections';

interface BuildWorkspaceParametersModelArgs {
    config: WorkflowInspectorConfig;
    moduleDefinition: WorkflowInspectorModuleDefinition | null;
    propertiesEditorState: Record<string, unknown>;
    activeTab: string;
    activeInstructionTab: string;
    hasUnsavedChanges: boolean;
    readOnly?: boolean;
}

export const buildWorkspaceParametersPanelModel = ({
    config,
    moduleDefinition,
    propertiesEditorState,
    activeTab,
    activeInstructionTab,
    hasUnsavedChanges,
    readOnly = false
}: BuildWorkspaceParametersModelArgs): WorkspaceParametersPanelModel => {
    const instructionTabs = [
        config.instruction.code ? { id: 'code', label: 'Code' } : null,
        config.instruction.markdown ? { id: 'markdown', label: 'Markdown' } : null
    ].filter((tab): tab is { id: string; label: string } => Boolean(tab));
    const tabs = [
        { id: 'properties', label: 'Properties' },
        ...(instructionTabs.length ? [{ id: 'instruction', label: 'Instruction' }] : [])
    ];
    const nextActiveTab = tabs.some((tab) => tab.id === activeTab) ? activeTab : tabs[0]?.id ?? 'properties';
    return {
        title: 'Parameters',
        description: 'Configure properties and run a single step',
        icon: moduleDefinition?.workspace?.parameters?.icon ?? 'inspect',
        tabs,
        activeTab: nextActiveTab,
        headerAction: undefined,
        heroCard: {
            title: moduleDefinition?.workspace?.parameters?.heroCard?.title ?? 'Node settings',
            description:
                moduleDefinition?.workspace?.parameters?.heroCard?.description ??
                `Define behavior, safety, and debugging preferences for this ${config.nodeTypeLabel.toLowerCase()} step.`,
            icon: moduleDefinition?.workspace?.parameters?.heroCard?.icon ?? 'play',
            chip: moduleDefinition?.workspace?.parameters?.heroCard?.chip
        },
        sections: buildWorkspaceParameterSections({
            config,
            fields: config.fields,
            propertiesEditorState,
            hiddenFieldKeys: config.hiddenFieldKeys ?? [],
            moduleDefinition
        }),
        hints: moduleDefinition?.workspace?.parameters?.hints,
        footerAction: readOnly
            ? undefined
            : {
                  id: WORKSPACE_ACTION_IDS.SaveChanges,
                  label: 'Save changes',
                  tone: 'primary',
                  disabled: !hasUnsavedChanges
              },
        instructionPanel: instructionTabs.length
            ? {
                  tabs: instructionTabs,
                  activeTab: instructionTabs.some((tab) => tab.id === activeInstructionTab) ? activeInstructionTab : instructionTabs[0].id
              }
            : undefined
    };
};
