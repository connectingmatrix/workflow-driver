import React from 'react';

interface WorkspaceFieldShellProps {
    label: string;
    badge?: string;
    helperText?: string;
    description?: string;
    presentation?: 'default' | 'execution-select' | 'execution-toggle';
    labelAction?: React.ReactNode;
    children: React.ReactNode;
}

export const WorkspaceFieldShell: React.FC<WorkspaceFieldShellProps> = ({ label, badge, helperText, description, presentation = 'default', labelAction, children }) => {
    return (
        <div className={`cnw-field${presentation !== 'default' ? ` cnw-field--${presentation}` : ''}`}>
            <div className="cnw-field__label-row">
                <div className="cnw-field__label-main">
                    <label className="cnw-field__label">{label}</label>
                    {badge ? <span className="cnw-field__badge">{badge}</span> : null}
                </div>
                {labelAction ? <div className="cnw-field__label-action">{labelAction}</div> : null}
            </div>
            {description ? <p className="cnw-field__description">{description}</p> : null}
            <div className="cnw-field__control">{children}</div>
            {helperText ? <small className="cnw-field__helper">{helperText}</small> : null}
        </div>
    );
};
