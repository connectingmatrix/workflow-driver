# Giga Workflow Package Guide

The workflow package provides shared runtime contracts, scope helpers, and output-contract helpers used by the UI, executor, and workflow nodes.

## Rules

- Workflows carry runtime scope to every node.
- AI Agent node outputs preserve chart, Excel, file, and Mermaid preview markers.
- Node execution emits parent scope for Process Monitor.

```mermaid
graph TD
  A[Workflow definition] --> B[Runtime scope]
  B --> C[Node input]
  C --> D[Node output]
  D --> E[Output contract previews]
```


- [Workflow interconnections](./interconnections.md) documents Chat Workflow mode, node execution, AI Agent nodes, and output previews.
