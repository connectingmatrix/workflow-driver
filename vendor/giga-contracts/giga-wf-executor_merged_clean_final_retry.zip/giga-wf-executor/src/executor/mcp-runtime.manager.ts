import type {
    WorkflowExecutorHostContext,
    WorkflowMcpCapabilityQueryInput,
    WorkflowMcpCapabilityQueryResult,
    WorkflowMcpRuntimeManager,
    WorkflowMcpServerRegistration
} from './mcp-runtime.types';
import { sendMcpRequest } from './mcp-runtime.http';
import { parseArrayValue, parseHeaders, parseJsonValue, parseStringArray, parseStringValue, parseTransport, toRecordValue } from './mcp-runtime.utils';

interface WorkflowMcpSessionState {
    sessionId?: string;
    protocolVersion: string;
    serverInfo: Record<string, unknown>;
    capabilities: Record<string, unknown>;
    tools: Record<string, unknown>[];
}

const normalizeServer = (server: WorkflowMcpServerRegistration): WorkflowMcpServerRegistration => {
    const key = parseStringValue(server.key);
    if (!key) {
        throw new Error('MCP server key is required.');
    }
    return {
        key,
        label: parseStringValue(server.label) || undefined,
        url: parseStringValue(server.url) || undefined,
        transport: parseTransport(server.transport) ?? 'streamable-http',
        headers: parseHeaders(server.headers),
        capabilities: toRecordValue(server.capabilities),
        metadata: toRecordValue(server.metadata)
    };
};

const throwIfUnsupportedTransport = (server: WorkflowMcpServerRegistration): void => {
    if (server.transport === 'stdio') {
        throw new Error('STDIO MCP execution is not supported in this pass.');
    }
};

export const createWorkflowMcpRuntimeManager = (initialServers: WorkflowMcpServerRegistration[] = []): WorkflowMcpRuntimeManager => {
    const servers = new Map<string, WorkflowMcpServerRegistration>();
    const sessions = new Map<string, WorkflowMcpSessionState>();
    let requestId = 0;
    initialServers.forEach((server) => servers.set(parseStringValue(server.key), normalizeServer(server)));
    const nextId = (): string => `mcp-${++requestId}`;
    const registerServer = (server: WorkflowMcpServerRegistration): WorkflowMcpServerRegistration => {
        const normalized = normalizeServer(server);
        servers.set(normalized.key, normalized);
        return normalized;
    };
    const getServer = (serverKey: string): WorkflowMcpServerRegistration | undefined => servers.get(parseStringValue(serverKey));
    const resolveServer = (input: { serverKey?: string; server?: WorkflowMcpServerRegistration }): WorkflowMcpServerRegistration => {
        if (input.server) return registerServer(input.server);
        const resolved = getServer(parseStringValue(input.serverKey));
        if (!resolved) throw new Error('MCP server configuration could not be resolved.');
        return resolved;
    };
    const initialize = async (input: { serverKey?: string; server?: WorkflowMcpServerRegistration }) => {
        const server = resolveServer(input);
        throwIfUnsupportedTransport(server);
        const existing = sessions.get(server.key);
        if (existing) return { server, ...existing };
        const initialized = await sendMcpRequest({
            server,
            body: {
                jsonrpc: '2.0',
                id: nextId(),
                method: 'initialize',
                params: {
                    protocolVersion: '2024-11-05',
                    capabilities: {},
                    clientInfo: { name: 'giga-workflow', version: '0.1.0' }
                }
            }
        });
        const sessionId = parseStringValue(initialized.headers.get('mcp-session-id'));
        await sendMcpRequest({ server, sessionId, body: { jsonrpc: '2.0', method: 'notifications/initialized', params: {} } });
        const session = {
            sessionId: sessionId || undefined,
            protocolVersion: parseStringValue(toRecordValue(initialized.payload.result).protocolVersion) || '2024-11-05',
            serverInfo: toRecordValue(toRecordValue(initialized.payload.result).serverInfo),
            capabilities: toRecordValue(toRecordValue(initialized.payload.result).capabilities),
            tools: []
        };
        sessions.set(server.key, session);
        return { server, ...session };
    };
    const listTools = async (input: { serverKey?: string; server?: WorkflowMcpServerRegistration }) => {
        const initialized = await initialize(input);
        const listed = await sendMcpRequest({
            server: initialized.server,
            sessionId: initialized.sessionId,
            body: { jsonrpc: '2.0', id: nextId(), method: 'tools/list', params: {} }
        });
        const tools = parseArrayValue(toRecordValue(listed.payload.result).tools).map((tool) => toRecordValue(tool));
        sessions.set(initialized.server.key, {
            sessionId: initialized.sessionId,
            protocolVersion: initialized.protocolVersion,
            serverInfo: initialized.serverInfo,
            capabilities: initialized.capabilities,
            tools
        });
        return { ...initialized, tools };
    };
    return {
        registerServer,
        removeServer: (serverKey) => servers.delete(parseStringValue(serverKey)),
        getServer,
        listServers: () => Array.from(servers.values()),
        queryCapabilities: (input: WorkflowMcpCapabilityQueryInput): WorkflowMcpCapabilityQueryResult => {
            const server = getServer(input.serverKey);
            const session = server ? sessions.get(server.key) : undefined;
            const capabilities: Record<string, unknown> = { ...(server ? toRecordValue(server.capabilities) : {}), ...(session ? { tools: session.tools } : {}) };
            if (input.includeServerMetadata !== false && server) {
                capabilities.server = { key: server.key, label: server.label, url: server.url, transport: server.transport };
            }
            if (parseStringValue(input.query)) {
                capabilities.query = parseStringValue(input.query);
            }
            return { server, query: parseStringValue(input.query), matchedCapabilities: capabilities, workload: input.workload, source: server && toRecordValue(server.metadata).ephemeral ? 'ephemeral' : 'registered' };
        },
        resolveNodeServer: (runtime) => {
            const serverKey = parseStringValue(runtime.serverKey);
            const serverUrl = parseStringValue(runtime.serverUrl);
            const transport = parseTransport(runtime.transport) ?? 'streamable-http';
            const stdioCommand = parseStringValue(runtime.stdioCommand);
            const metadata = {
                source: 'node-runtime',
                autoRegistered: true,
                ephemeral: !serverKey,
                httpEndpointPath: parseStringValue(runtime.httpEndpointPath) || '/mcp',
                bearerTokenEnvVar: parseStringValue(runtime.bearerTokenEnvVar),
                headersFromEnv: toRecordValue(parseJsonValue(runtime.headersFromEnv)),
                stdio: {
                    command: stdioCommand,
                    args: parseStringArray(runtime.stdioArgs),
                    cwd: parseStringValue(runtime.stdioWorkingDirectory),
                    env: toRecordValue(parseJsonValue(runtime.stdioEnv)),
                    envPassthrough: parseStringArray(runtime.envPassthrough)
                }
            };
            if (serverKey && getServer(serverKey)) return getServer(serverKey);
            if (serverKey && (serverUrl || transport === 'stdio')) return registerServer({ key: serverKey, url: serverUrl, transport, headers: parseHeaders(runtime.headers), capabilities: toRecordValue(parseJsonValue(runtime.capabilities)), metadata });
            if (!serverKey && serverUrl) return registerServer({ key: `ephemeral:${serverUrl}`, url: serverUrl, transport, headers: parseHeaders(runtime.headers), capabilities: toRecordValue(parseJsonValue(runtime.capabilities)), metadata });
            if (!serverKey && transport === 'stdio' && stdioCommand) return registerServer({ key: `stdio:${stdioCommand}`, transport, capabilities: toRecordValue(parseJsonValue(runtime.capabilities)), metadata });
            return undefined;
        },
        initialize,
        listTools,
        callTool: async (input) => {
            const initialized = await initialize(input);
            const session = sessions.get(initialized.server.key);
            const toolResult = await sendMcpRequest({
                server: initialized.server,
                sessionId: initialized.sessionId,
                body: { jsonrpc: '2.0', id: nextId(), method: 'tools/call', params: { name: parseStringValue(input.toolName), arguments: toRecordValue(input.toolArguments) } }
            });
            return {
                ...initialized,
                tools: session ? session.tools : [],
                toolCall: { name: parseStringValue(input.toolName), arguments: toRecordValue(input.toolArguments) },
                toolResult: toolResult.payload.result
            };
        },
        resetSession: (serverKey) => {
            sessions.delete(parseStringValue(serverKey));
        }
    };
};

export const createWorkflowExecutorHostContext = (initialServers: WorkflowMcpServerRegistration[] = []): WorkflowExecutorHostContext => ({
    mcp: createWorkflowMcpRuntimeManager(initialServers)
});

export const getWorkflowMcpRuntimeManager = (hostContext: unknown): WorkflowMcpRuntimeManager => {
    const record = toRecordValue(hostContext);
    const nested = toRecordValue(record.mcp);
    if (typeof nested.registerServer === 'function' && typeof nested.listTools === 'function' && typeof nested.callTool === 'function') {
        return nested as unknown as WorkflowMcpRuntimeManager;
    }
    return createWorkflowMcpRuntimeManager();
};
