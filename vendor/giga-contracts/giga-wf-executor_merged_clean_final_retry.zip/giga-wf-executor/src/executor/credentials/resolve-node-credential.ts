import type { WorkflowCredentialHostContext, WorkflowResolvedCredential, WorkflowNodeHandlerContext } from '../../types';
import { getWorkflowCredentialHostContext } from './credential-host';

const toRecord = (value: unknown): Record<string, unknown> =>
    value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

const resolveSelectedCredentialId = (context: WorkflowNodeHandlerContext): string => {
    const properties = toRecord(context.node.properties);
    const runtime = toRecord(context.node.runtime);
    const value = properties.credentialId ?? runtime.credentialId;
    return typeof value === 'string' ? value.trim() : '';
};

const resolveServiceId = (context: WorkflowNodeHandlerContext): string => {
    const schema = toRecord(toRecord(context.workflow.nodeModels)[String(context.node.modelId ?? '')]);
    const serviceId = schema.useCredentials;
    return typeof serviceId === 'string' ? serviceId.trim() : '';
};

export interface ResolvedNodeCredentialBinding {
    credentialId: string | null;
    credential: WorkflowResolvedCredential | null;
    error: string | null;
    host: WorkflowCredentialHostContext | null;
}

export const resolveNodeCredentialBinding = async (context: WorkflowNodeHandlerContext): Promise<ResolvedNodeCredentialBinding> => {
    const serviceId = resolveServiceId(context);
    if (!serviceId) {
        return {
            credentialId: null,
            credential: null,
            error: null,
            host: getWorkflowCredentialHostContext(context.hostContext),
        };
    }

    const credentialId = resolveSelectedCredentialId(context);
    const host = getWorkflowCredentialHostContext(context.hostContext);
    if (!credentialId) {
        return {
            credentialId: null,
            credential: null,
            error: null,
            host,
        };
    }

    if (!host?.fetchCredentialById) {
        return {
            credentialId,
            credential: null,
            error: `Credential "${credentialId}" was selected for node "${context.node.name}", but the executor host did not provide fetchCredentialById().`,
            host,
        };
    }

    try {
        const credential = await host.fetchCredentialById(credentialId);
        if (!credential) {
            return {
                credentialId,
                credential: null,
                error: `Credential "${credentialId}" could not be resolved.`,
                host,
            };
        }

        return {
            credentialId,
            credential,
            error: null,
            host,
        };
    } catch (error) {
        return {
            credentialId,
            credential: null,
            error: error instanceof Error ? error.message : 'Credential resolution failed.',
            host,
        };
    }
};
