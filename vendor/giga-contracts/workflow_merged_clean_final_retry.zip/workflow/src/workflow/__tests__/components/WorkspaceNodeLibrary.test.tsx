/** @vitest-environment jsdom */
import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import WorkspaceNodeLibrary from '@workflow/ui/workflow/components/node-library/workspace/WorkspaceNodeLibrary';
import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

const createItem = (overrides: Partial<WorkflowNodeLibraryItem>): WorkflowNodeLibraryItem =>
    ({
        id: overrides.id ?? overrides.modelId ?? 'node',
        modelId: overrides.modelId ?? 'node',
        gigaId: overrides.gigaId ?? overrides.modelId ?? 'node',
        label: overrides.label ?? 'Node',
        description: overrides.description ?? 'Node description',
        nodeType: overrides.nodeType ?? 'workflow',
        group: overrides.group ?? 'Flow Nodes',
        ...overrides
    }) as WorkflowNodeLibraryItem;

describe('WorkspaceNodeLibrary', () => {
    it('shows a close button in the header when onClose is provided', () => {
        const handleClose = vi.fn();
        render(<WorkspaceNodeLibrary visible items={[createItem({ id: 'start', modelId: 'start' })]} onClose={handleClose} />);

        fireEvent.click(screen.getByRole('button', { name: 'Close node library' }));

        expect(handleClose).toHaveBeenCalledTimes(1);
    });
});
