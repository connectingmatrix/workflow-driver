import { WorkflowNodeFieldMap } from '@workflow/ui/workflow/types';
import StartWebhookUsageInspectorSection from '@workflow/ui/workflow/components/inspector/modules/start/StartWebhookUsageInspectorSection';
import { WorkflowInspectorModuleDefinition } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import { resolveOutputFormatWorkspaceFields, resolveOutputFormatWorkspaceViewers } from '@workflow/ui/workflow/components/inspector/modules/output-format/output-format-workspace';

const START_FIELD_ORDER = ['triggerSource', 'webhookMethod', 'description', 'prompt', 'variables', 'forwardSessionLogs'];

const shouldDisplayStartField = (fieldKey: string, values: Record<string, unknown>, _fields: WorkflowNodeFieldMap): boolean => {
    if (fieldKey !== 'webhookMethod') return true;
    return String(values.triggerSource ?? 'programmatic').trim().toLowerCase() === 'webhook';
};

const MODULES: Record<string, WorkflowInspectorModuleDefinition> = {
    code: {
        workspace: {
            input: {
                acceptedFormats: ['CSV', 'JSON', 'PDF', 'Docs'],
                featureItems: [
                    {
                        id: 'schema-detection',
                        title: 'Schema detection',
                        description: 'Automatically reads columns and field types.',
                        icon: 'sparkles'
                    },
                    {
                        id: 'preview-safety',
                        title: 'Preview safety',
                        description: 'Sensitive values are masked in the viewer.',
                        icon: 'eye'
                    },
                    {
                        id: 'drag-drop',
                        title: 'Drag & drop',
                        description: 'Drop files directly into the input panel.',
                        icon: 'bolt'
                    }
                ]
            },
            parameters: {
                heroCard: {
                    title: 'Node settings',
                    description: 'Define behavior, safety, and debugging preferences for this JavaScript step.',
                    icon: 'play'
                },
                fieldPresentation: {
                    failureMitigation: 'execution-select',
                    forwardSessionLogs: 'execution-toggle'
                },
                fieldBadges: {
                    name: 'JavaScript'
                },
                fieldHelperText: {
                    failureMitigation: 'Choose what happens when execution fails.',
                    forwardSessionLogs: 'Expose runtime logs in downstream steps.'
                },
                hints: [
                    {
                        id: 'validate-output',
                        title: 'Validate output',
                        description: 'Return JSON-safe objects so downstream nodes can parse reliably.'
                    },
                    {
                        id: 'keep-names-descriptive',
                        title: 'Keep names descriptive',
                        description: 'Use descriptive names that describe the step instead of generic labels.'
                    },
                    {
                        id: 'log-strategically',
                        title: 'Log strategically',
                        description: 'Only forward logs when debugging to keep payloads lightweight.'
                    }
                ],
                sections: [
                    {
                        id: 'general',
                        title: 'General',
                        fieldKeys: ['name', 'description']
                    },
                    {
                        id: 'execution',
                        title: 'Execution',
                        fieldKeys: ['failureMitigation', 'retryCount', 'forwardSessionLogs'],
                        variant: 'execution-grid'
                    }
                ]
            },
            output: {
                summaryTip: 'Tip: return { count: items.length }'
            }
        }
    },
    'output-format': {
        workspace: {
            parameters: {
                resolveFields: resolveOutputFormatWorkspaceFields,
                heroCard: {
                    title: 'Output settings',
                    description: 'Shape the downstream response and optionally let an LLM refine the final format.',
                    icon: 'sparkles'
                },
                fieldPresentation: {
                    useAiFormatting: 'execution-toggle',
                    failureMitigation: 'execution-select',
                    forwardSessionLogs: 'execution-toggle'
                },
                fieldBadges: {
                    name: 'Formatter'
                },
                fieldHelperText: {
                    useAiFormatting: 'Use an attached LLM to polish the final response.',
                    failureMitigation: 'Choose what happens when execution fails.',
                    forwardSessionLogs: 'Expose runtime logs in downstream steps.'
                },
                sections: [
                    {
                        id: 'general',
                        title: 'General',
                        fieldKeys: ['name', 'description', 'format']
                    },
                    {
                        id: 'payload',
                        title: 'Payload',
                        fieldKeys: ['value']
                    },
                    {
                        id: 'ai',
                        title: 'AI formatting',
                        fieldKeys: ['useAiFormatting', 'modelId', 'aiPrompt']
                    },
                    {
                        id: 'execution',
                        title: 'Execution',
                        fieldKeys: ['failureMitigation', 'retryCount', 'forwardSessionLogs'],
                        variant: 'execution-grid'
                    }
                ],
                hints: [
                    {
                        id: 'keep-output-typed',
                        title: 'Keep output typed',
                        description: 'Prefer predictable JSON structures when downstream nodes consume this output.'
                    },
                    {
                        id: 'ai-formatting',
                        title: 'Use AI formatting selectively',
                        description: 'Turn on model formatting only when deterministic shaping is not enough.'
                    }
                ],
                icon: 'sparkles'
            },
            output: {
                icon: 'json',
                summaryTip: 'Tip: shape output into the final contract expected by downstream nodes.',
                resolveViewers: resolveOutputFormatWorkspaceViewers
            }
        }
    },
    'ai-governor': {
        workspace: {
            parameters: {
                heroCard: {
                    title: 'AI action planner',
                    description: 'Use a connected LLM to plan and run connected model/tool actions from one prompt.',
                    icon: 'sparkles'
                },
                fieldPresentation: {
                    failureMitigation: 'execution-select'
                },
                fieldBadges: {
                    name: 'LLM Governor'
                },
                fieldHelperText: {
                    selectionPromptMd: 'The first connected LLM turns this prompt and the connected tool catalog into an action array.',
                    failureMitigation: 'Choose what happens when execution fails.'
                },
                sections: [
                    {
                        id: 'general',
                        title: 'General',
                        fieldKeys: ['name', 'description']
                    },
                    {
                        id: 'prompts',
                        title: 'Selection Prompt',
                        fieldKeys: ['selectionPromptMd']
                    },
                    {
                        id: 'execution',
                        title: 'Execution',
                        fieldKeys: ['failureMitigation', 'retryCount'],
                        variant: 'execution-grid'
                    }
                ],
                hints: [
                    {
                        id: 'connect-planner',
                        title: 'Connect a planner LLM',
                        description: 'The first connected LLM creates the action array; all connected models and tools remain selectable actions.'
                    },
                    {
                        id: 'format-with-llm',
                        title: 'Format with an LLM action',
                        description: 'For a single clean shape, connect an LLM and let the planner choose it as the final action.'
                    }
                ],
                icon: 'sparkles'
            },
            output: {
                icon: 'json',
                summaryTip: 'Tip: keep the final governor output compact and structured for downstream routing.'
            }
        }
    },
    'ai-agent': {
        workspace: {
            parameters: {
                heroCard: {
                    title: 'AI workflow agent',
                    description: 'Plan, confirm, execute, and answer through connected LLM, tool, and workflow nodes.',
                    icon: 'sparkles'
                },
                fieldPresentation: {
                    failureMitigation: 'execution-select'
                },
                fieldBadges: {
                    name: 'Composite Agent'
                },
                fieldHelperText: {
                    selectionPromptMd: 'The connected LLM uses this prompt to plan tool and workflow actions before execution.',
                    workflowToolAllowlist: 'Limit workflow output actions to a subset of connected Workflow and Execute Workflow nodes.',
                    failureMitigation: 'Choose what happens when execution fails.'
                },
                sections: [
                    {
                        id: 'general',
                        title: 'General',
                        fieldKeys: ['name', 'description']
                    },
                    {
                        id: 'planning',
                        title: 'Planning',
                        fieldKeys: ['selectionPromptMd', 'executionMode', 'confirmationPolicy', 'modelActionPolicy']
                    },
                    {
                        id: 'workflow-tools',
                        title: 'Workflow Tools',
                        fieldKeys: ['workflowToolAllowlist']
                    },
                    {
                        id: 'execution',
                        title: 'Execution',
                        fieldKeys: ['failureMitigation', 'retryCount'],
                        variant: 'execution-grid'
                    }
                ],
                hints: [
                    {
                        id: 'connect-workflow-tools',
                        title: 'Connect workflow tools',
                        description: 'Use cmd:workflow for Workflow and Execute Workflow nodes when the agent should author or run workflows directly.'
                    },
                    {
                        id: 'keep-governor-available',
                        title: 'Keep AI Governor for split flows',
                        description: 'Use AI Governor when planning and response shaping should stay in separate workflow steps.'
                    }
                ],
                icon: 'sparkles'
            },
            output: {
                icon: 'json',
                summaryTip: 'Tip: keep the final text and agent metadata compact so downstream response nodes stay predictable.'
            }
        }
    },
    start: {
        propertyOrder: START_FIELD_ORDER,
        bodyClassName: 'wf-inspector-pane__body--scrollable',
        shouldDisplayField: shouldDisplayStartField,
        appendSection: StartWebhookUsageInspectorSection,
        workspace: {
            parameters: {
                sections: [
                    {
                        id: 'general',
                        title: 'General',
                        fieldKeys: ['triggerSource', 'webhookMethod', 'description']
                    },
                    {
                        id: 'webhook',
                        title: 'Webhook',
                        fieldKeys: ['prompt', 'variables', 'forwardSessionLogs']
                    }
                ]
            }
        }
    }
};

const FALLBACK_MODULE: WorkflowInspectorModuleDefinition = {
    workspace: {
        parameters: {
            sections: [
                {
                    id: 'general',
                    title: 'General',
                    fieldKeys: ['name', 'description']
                },
                {
                    id: 'execution',
                    title: 'Execution',
                    fieldKeys: ['failureMitigation', 'retryCount', 'forwardSessionLogs'],
                    variant: 'execution-grid'
                },
                {
                    id: 'parameters',
                    title: 'Parameters',
                    includeRemaining: true
                }
            ]
        }
    }
};

export const getWorkflowInspectorModule = (modelId: string): WorkflowInspectorModuleDefinition => MODULES[modelId] ?? FALLBACK_MODULE;
