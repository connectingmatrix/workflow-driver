import React from 'react';
import WorkflowSettingsSectionCard from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsSectionCard';

const NOTES = [
    {
        title: 'Inspector previews',
        description: 'The selected node inherits endpoint and auth context from these settings.'
    },
    {
        title: 'JSON output',
        description: 'Run results and logs use the same response contract shown in the inspector.'
    },
    {
        title: 'Safe defaults',
        description: 'Session auth and timeout values can still be overridden per workflow run.'
    }
];

export const WorkflowSettingsNotesCard: React.FC = () => (
    <WorkflowSettingsSectionCard icon="pi pi-align-left" title="Runtime notes" description="Preview behavior and environment hints aligned with the node inspector.">
        <div className="wf-workspace-settings__notes-list">
            {NOTES.map((note) => (
                <div key={note.title} className="wf-workspace-settings__note-item">
                    <span className="wf-workspace-settings__note-dot" />
                    <div>
                        <strong>{note.title}</strong>
                        <p>{note.description}</p>
                    </div>
                </div>
            ))}
        </div>
    </WorkflowSettingsSectionCard>
);
