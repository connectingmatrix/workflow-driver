import { describe, expect, it } from 'vitest';
import aiGovernorNodeModule from '@workflow/nodes/nodes/ai-governor/ai-governor-node';
import mergeNodeModule from '@workflow/nodes/nodes/merge/merge-node';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { mergeWorkflowRuntimeStateWithUpsert } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

describe('ai-governor schema + merge node execution', () => {
    it('defines governor ports and single selection prompt as expected', () => {
        const schema = aiGovernorNodeModule.schema;
        expect(Object.keys(schema.inputs)).toEqual(['input']);
        expect(Object.keys(schema.outputs)).toEqual(['output']);
        expect(Object.keys(schema.commands ?? {})).toEqual(['llm', 'models', 'tools']);
        expect(schema.commands?.llm.side).toBe('bottom');
        expect(schema.commands?.models.side).toBe('bottom');
        expect(schema.commands?.tools.side).toBe('bottom');
        expect(schema.inputs.input.side).toBe('left');
        expect(schema.outputs.output.side).toBe('right');
        expect(schema.fields.selectionPromptMd?.type).toBe('markdown');
        expect(schema.fields.executionMode?.defaultValue).toBe('plan-and-run');
        expect(schema.fields.evaluationLoopPromptMd).toBeUndefined();
        expect(schema.fields.outputConversionPromptMd).toBeUndefined();
        expect(schema.fields.maxIterations).toBeUndefined();
        expect(schema.render?.nodeWidth).toBe(320);
        expect(schema.render?.nodeHeight).toBe(150);
    });

    it('executes merge node as a shallow object merge across all five inputs', async () => {
        const workflow = createEmptyWorkflow('wf_merge_node');
        const mergeNode = createWorkflowNode(workflow, 'merge', 'Merge', 1);
        mergeNode.runtime = {
            ...(mergeNode.runtime ?? {}),
            input1Value: { ok: true, shared: 'first' },
            input2Value: { count: 2, shared: 'second' },
            input3Value: ['array-value'],
            input4Value: 'string-value'
        };

        const result = await mergeNodeModule.execute({
            node: mergeNode,
            workflow,
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: 'none',
                manualHeaders: {}
            },
            input: {}
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.output).toEqual({
            ok: true,
            count: 2,
            shared: 'second',
            input3: ['array-value'],
            input4: 'string-value',
            __activeOutputs: ['output']
        });
    });

    it('upserts server runtime nodes and hydrates missing render metadata', () => {
        const current = createEmptyWorkflow('wf_hydrate_current');
        const startNode = createWorkflowNode(current, 'start', 'Start', 1);
        current.nodes = [startNode];

        const incoming = createEmptyWorkflow('wf_hydrate_next');
        const updatedStart = { ...startNode, status: WorkflowNodeStatusEnum.Passed, output: { started: true } };
        const remoteOpenAi = {
            ...createWorkflowNode(incoming, 'openai', 'OpenAI', 2),
            render: undefined
        };
        incoming.nodes = [updatedStart, remoteOpenAi];
        incoming.connections = [{ id: 'c_1', name: 's->o', from: updatedStart.id, to: remoteOpenAi.id, sourceHandle: 'out:output', targetHandle: 'in:input' }];

        const merged = mergeWorkflowRuntimeStateWithUpsert(current, incoming);
        expect(merged.nodes).toHaveLength(2);
        const hydratedOpenAi = merged.nodes.find((node) => node.id === remoteOpenAi.id);
        expect(hydratedOpenAi?.render?.iconColor).toBeTruthy();
        expect(hydratedOpenAi?.render?.iconBackground).toBeTruthy();
    });

    it('hydrates node output from ports.out.output when legacy output field is missing', () => {
        const current = createEmptyWorkflow('wf_merge_output_ports');
        const startNode = createWorkflowNode(current, 'start', 'Start', 1);
        current.nodes = [startNode];

        const incoming = createEmptyWorkflow('wf_merge_output_ports_next');
        const updatedStart = {
            ...startNode,
            status: WorkflowNodeStatusEnum.Passed,
            output: undefined,
            ports: {
                ...startNode.ports,
                out: {
                    ...startNode.ports.out,
                    output: { started: true, source: 'ports-only' }
                }
            }
        };
        incoming.nodes = [updatedStart];

        const merged = mergeWorkflowRuntimeStateWithUpsert(current, incoming);
        const mergedStart = merged.nodes.find((node) => node.id === startNode.id);
        expect(mergedStart?.output).toEqual({ started: true, source: 'ports-only' });
        expect((mergedStart?.ports.out.output as { source?: string }).source).toBe('ports-only');
    });

    it('fails governor execution when no planner llm is connected', async () => {
        const workflow = createEmptyWorkflow('wf_ai_governor_no_targets');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        workflow.nodes = [governorNode];
        workflow.connections = [];

        const result = await aiGovernorNodeModule.execute({
            node: governorNode,
            workflow,
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: 'none',
                manualHeaders: {}
            },
            input: {}
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect((result.output as { error?: string }).error).toContain('LLM');
    });
});
