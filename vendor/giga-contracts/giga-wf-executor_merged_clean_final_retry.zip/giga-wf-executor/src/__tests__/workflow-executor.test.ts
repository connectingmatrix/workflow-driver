import { describe, expect, it } from 'vitest';
import { createWorkflowExecutor } from '../executor/create-workflow-executor';
import { WorkflowExecutorModeEnum, WorkflowNodeStatusEnum } from '../types';
import { createAdapters, createCodeNode, createConnection, createEndNode, createIfElseNode, createMetadataNode, createStartNode, createWorkflow } from './fixtures';

describe('shared workflow executor', () => {
    it('returns validation error when start/end nodes are missing', async () => {
        const workflow = createWorkflow();
        workflow.nodes = [createEndNode(1)];
        const executor = createWorkflowExecutor({ mode: WorkflowExecutorModeEnum.Local, adapters: createAdapters({}) });
        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(result.stopped).toBe(false);
        expect(result.events.some((item) => item.event === 'workflow.validation_failed')).toBe(true);
    });

    it('executes true branch and sends summary to end node', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const ifElse = createIfElseNode(2);
        const trueNode = createMetadataNode(3, 'True Node');
        const falseNode = createMetadataNode(4, 'False Node');
        const end = createEndNode(5);
        workflow.nodes = [start, ifElse, trueNode, falseNode, end];
        workflow.connections = [
            createConnection('c1', start.id, ifElse.id),
            createConnection('c2', ifElse.id, trueNode.id, 'out:true'),
            createConnection('c3', ifElse.id, falseNode.id, 'out:false'),
            createConnection('c4', trueNode.id, end.id),
            createConnection('c5', falseNode.id, end.id)
        ];

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                'if-else': async (_node, input) => {
                    const started = Boolean((input.input as Record<string, unknown>)[start.id]);
                    return { output: { passed: started, trueBranch: { outputPort: 'true', value: input }, falseBranch: { outputPort: 'false', value: null }, __activeOutputs: [started ? 'true' : 'false'] }, status: WorkflowNodeStatusEnum.Passed };
                },
                metadata: async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed }),
                'respond-end': async (_node, input) => ({ output: { summary: (input.__workflow as Record<string, unknown>) ?? {} }, status: WorkflowNodeStatusEnum.Passed })
            })
        });
        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const trueAfter = result.workflow.nodes.find((item) => item.id === trueNode.id);
        const falseAfter = result.workflow.nodes.find((item) => item.id === falseNode.id);
        const endAfter = result.workflow.nodes.find((item) => item.id === end.id);
        expect(trueAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(falseAfter?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect((endAfter?.ports.out.output as { summary?: unknown })?.summary).toBeTruthy();
    });

    it('retries failed node and succeeds before retry limit', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const flaky = createMetadataNode(2, 'Flaky Node');
        const end = createEndNode(3);
        flaky.runtime = { failureMitigation: 'retry-node', retryCount: 3 };
        workflow.nodes = [start, flaky, end];
        workflow.connections = [createConnection('c1', start.id, flaky.id), createConnection('c2', flaky.id, end.id)];

        let attempts = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => {
                    attempts += 1;
                    if (attempts < 3) return { output: { error: 'temporary' }, status: WorkflowNodeStatusEnum.Failed, logs: [`attempt ${attempts} failed`] };
                    return { output: { stable: true }, status: WorkflowNodeStatusEnum.Passed, logs: ['recovered'] };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed, logs: ['end reached'] })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const flakyAfter = result.workflow.nodes.find((item) => item.id === flaky.id);
        const endAfter = result.workflow.nodes.find((item) => item.id === end.id);
        const flakyLogs = result.events.filter((event) => event.nodeId === flaky.id && event.event === 'node.log').map((event) => String(event.message ?? ''));

        expect(attempts).toBe(3);
        expect(flakyAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(endAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(flakyLogs.some((line) => line.includes('Retrying (1/3)'))).toBe(true);
        expect(flakyLogs.some((line) => line.includes('Retrying (2/3)'))).toBe(true);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(true);
    });

    it('fails workflow after retry exhaustion', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const flaky = createMetadataNode(2, 'Always Fail');
        const end = createEndNode(3);
        flaky.runtime = { failureMitigation: 'retry-node', retryCount: 2 };
        workflow.nodes = [start, flaky, end];
        workflow.connections = [createConnection('c1', start.id, flaky.id), createConnection('c2', flaky.id, end.id)];

        let attempts = 0;
        let endCalls = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => {
                    attempts += 1;
                    return { output: { error: 'permanent' }, status: WorkflowNodeStatusEnum.Failed, logs: [`attempt ${attempts} failed`] };
                },
                'respond-end': async () => {
                    endCalls += 1;
                    return { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed };
                }
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const flakyAfter = result.workflow.nodes.find((item) => item.id === flaky.id);
        const endAfter = result.workflow.nodes.find((item) => item.id === end.id);

        expect(attempts).toBe(3);
        expect(endCalls).toBe(0);
        expect(flakyAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(endAfter?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect(result.events.some((event) => event.event === 'node.failed' && event.nodeId === flaky.id)).toBe(true);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(false);
    });

    it('stop-workflow mitigation fails immediately without retries', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const failing = createMetadataNode(2, 'Stop Mode');
        const end = createEndNode(3);
        failing.runtime = { failureMitigation: 'stop-workflow' };
        workflow.nodes = [start, failing, end];
        workflow.connections = [createConnection('c1', start.id, failing.id), createConnection('c2', failing.id, end.id)];

        let attempts = 0;
        let endCalls = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => {
                    attempts += 1;
                    return { output: { error: 'halt' }, status: WorkflowNodeStatusEnum.Failed, logs: ['halt'] };
                },
                'respond-end': async () => {
                    endCalls += 1;
                    return { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed };
                }
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const failingAfter = result.workflow.nodes.find((item) => item.id === failing.id);

        expect(attempts).toBe(1);
        expect(endCalls).toBe(0);
        expect(failingAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(false);
    });

    it('fails workflow when connection compatibility rules are violated', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const nonModelNode = createMetadataNode(2, 'Non Model');
        const governor = createMetadataNode(3, 'AI Governor');
        const end = createEndNode(4);
        governor.modelId = 'ai-governor';
        workflow.nodes = [start, nonModelNode, governor, end];
        workflow.connections = [
            createConnection('c1', start.id, nonModelNode.id),
            createConnection('c2', nonModelNode.id, governor.id, 'out:output', 'in:modelIn'),
            createConnection('c3', governor.id, end.id)
        ];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                group: 'Data',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } }
            },
            'ai-governor': {
                id: 'ai-governor',
                inputs: {
                    modelIn: {
                        allowMultipleArrows: true,
                        acceptedSourceGroups: ['AI Models']
                    },
                    input: { allowMultipleArrows: true }
                },
                outputs: { output: { allowMultipleArrows: true } }
            }
        };

        const executor = createWorkflowExecutor({ mode: WorkflowExecutorModeEnum.Local, adapters: createAdapters({}) });
        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });

        expect(result.events.some((event) => event.event === 'workflow.validation_failed')).toBe(true);
        const validationEvent = result.events.find((event) => event.event === 'workflow.validation_failed');
        expect(String(validationEvent?.message ?? '')).toContain('incompatible connection');
    });

    it('does not auto-run command peers when handler already ran planned actions', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const governor = createMetadataNode(2, 'AI Governor');
        const openai = createMetadataNode(3, 'OpenAI');
        const end = createEndNode(4);
        governor.modelId = 'ai-governor';
        openai.modelId = 'openai';
        workflow.nodes = [start, governor, openai, end];
        workflow.connections = [
            createConnection('c1', start.id, governor.id),
            createConnection('c2', governor.id, end.id),
            createConnection('c3', openai.id, governor.id, 'cmd:command', 'cmd:llm')
        ];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'ai-governor': {
                id: 'ai-governor',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { llm: { allowMultipleArrows: true, acceptedSourceGroups: ['AI Models'] } }
            },
            openai: {
                id: 'openai',
                group: 'AI Models',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { command: { allowMultipleArrows: true } }
            }
        };

        let openAiCalls = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                'ai-governor': async () => ({
                    output: { result: { ok: true }, intent: 'test', actionSummary: [], summaryStatus: 'passed', __activeOutputs: ['output'] },
                    status: WorkflowNodeStatusEnum.Passed,
                    skipCommandPeerAutoRun: true
                }),
                openai: async () => {
                    openAiCalls += 1;
                    return { output: { text: 'auto-run' }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const openAiAfter = result.workflow.nodes.find((item) => item.id === openai.id);

        expect(openAiCalls).toBe(0);
        expect(openAiAfter?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect(result.events.some((event) => event.event === 'workflow.completed')).toBe(true);
    });

    it('passes command peer output to downstream data inputs after peer execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const governor = createMetadataNode(2, 'AI Governor');
        const openai = createMetadataNode(3, 'OpenAI');
        const formatter = createMetadataNode(4, 'Formatter');
        const end = createEndNode(5);
        governor.modelId = 'ai-governor';
        openai.modelId = 'openai';
        workflow.nodes = [start, governor, openai, formatter, end];
        workflow.connections = [
            createConnection('c1', start.id, governor.id),
            createConnection('c2', governor.id, formatter.id),
            createConnection('c3', formatter.id, end.id),
            createConnection('c4', openai.id, governor.id, 'cmd:command', 'cmd:llm'),
            createConnection('c5', openai.id, formatter.id, 'out:output', 'in:llm')
        ];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'ai-governor': {
                id: 'ai-governor',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { llm: { allowMultipleArrows: true, acceptedSourceGroups: ['AI Models'] } }
            },
            openai: {
                id: 'openai',
                group: 'AI Models',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { command: { allowMultipleArrows: true } }
            },
            metadata: {
                id: 'metadata',
                inputs: {
                    input: { allowMultipleArrows: true },
                    llm: { allowMultipleArrows: true }
                },
                outputs: { output: { allowMultipleArrows: true } }
            }
        };

        let formatterLlmInput: unknown = null;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                'ai-governor': async () => ({ output: { plan: 'use llm', __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                openai: async () => ({ output: { text: 'peer output' }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async (_node, input) => {
                    const llmInput = input.llm || {};
                    formatterLlmInput = llmInput[openai.id] || null;
                    return { output: { llm: formatterLlmInput }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const openAiAfter = result.workflow.nodes.find((item) => item.id === openai.id);
        const formatterAfter = result.workflow.nodes.find((item) => item.id === formatter.id);

        expect(openAiAfter && openAiAfter.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(formatterAfter && formatterAfter.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(formatterLlmInput).toEqual({ text: 'peer output' });
    });

    it('does not feed downstream nodes with saved command peer output before current-run execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const governor = createMetadataNode(2, 'AI Governor');
        const openai = createMetadataNode(3, 'OpenAI');
        const formatter = createMetadataNode(4, 'Formatter');
        const end = createEndNode(5);
        governor.modelId = 'ai-governor';
        openai.modelId = 'openai';
        openai.ports.out = { output: { text: 'stale saved output' } };
        workflow.nodes = [start, governor, openai, formatter, end];
        workflow.connections = [
            createConnection('c1', start.id, governor.id),
            createConnection('c2', governor.id, formatter.id),
            createConnection('c3', formatter.id, end.id),
            createConnection('c4', openai.id, governor.id, 'cmd:command', 'cmd:llm'),
            createConnection('c5', openai.id, formatter.id, 'out:output', 'in:llm')
        ];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'ai-governor': {
                id: 'ai-governor',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { llm: { allowMultipleArrows: true } }
            },
            openai: {
                id: 'openai',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { command: { allowMultipleArrows: true } }
            },
            metadata: {
                id: 'metadata',
                inputs: {
                    input: { allowMultipleArrows: true },
                    llm: { allowMultipleArrows: true }
                },
                outputs: { output: { allowMultipleArrows: true } }
            }
        };

        let formatterLlmInput: unknown = 'not-called';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                'ai-governor': async () => ({ output: { markdown: 'done', __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed, skipCommandPeerAutoRun: true }),
                openai: async () => ({ output: { text: 'fresh output' }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async (_node, input) => {
                    formatterLlmInput = input.llm?.[openai.id] ?? null;
                    return { output: { llm: formatterLlmInput }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const formatterAfter = result.workflow.nodes.find((item) => item.id === formatter.id);

        expect(formatterAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(formatterLlmInput).toBeNull();
    });
});

describe('workflow variable resolution', () => {
    it('resolves runtime variable tokens before node execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Uses Variable');
        const end = createEndNode(3);
        metadata.runtime = { prompt: 'Use {{node_start_1.answer}}' };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { answer: '42', __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async (node) => {
                    seenPrompt = String(node.runtime.prompt ?? '');
                    return { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(seenPrompt).toBe('Use 42');
        expect(metadataAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('resolves default input variables without flattening command control buckets', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const code = createCodeNode(5);
        const governor = createMetadataNode(4, 'AI Governor');
        const openai = createMetadataNode(10, 'OpenAI');
        const end = createEndNode(6);
        governor.modelId = 'ai-governor';
        openai.modelId = 'openai';
        governor.runtime = { selectionPromptMd: 'Run {{input.node_code_5.query}} with {{input.node_code_5.maxResults}} results.' };
        workflow.nodes = [start, code, governor, openai, end];
        workflow.connections = [
            createConnection('c1', start.id, code.id),
            createConnection('c2', code.id, governor.id),
            createConnection('c3', governor.id, end.id),
            createConnection('c4', openai.id, governor.id, 'cmd:command', 'cmd:llm')
        ];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'ai-governor': {
                id: 'ai-governor',
                fields: { selectionPromptMd: { type: 'textarea', allowVariables: true } },
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { llm: { allowMultipleArrows: true } }
            },
            openai: {
                id: 'openai',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } },
                commands: { command: { allowMultipleArrows: true } }
            }
        };

        let seenPrompt = '';
        let seenGovernorInput: Record<string, Record<string, unknown>> = {};
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                code: async () => ({ output: { query: 'latest Iran threat news', maxResults: 12 }, status: WorkflowNodeStatusEnum.Passed }),
                'ai-governor': async (node, input) => {
                    seenPrompt = String(node.runtime.selectionPromptMd ?? '');
                    seenGovernorInput = input;
                    return { output: { markdown: '| title | threat |', __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed, skipCommandPeerAutoRun: true };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const governorAfter = result.workflow.nodes.find((item) => item.id === governor.id);
        expect(seenPrompt).toBe('Run latest Iran threat news with 12 results.');
        expect((seenGovernorInput.input?.[code.id] as Record<string, unknown>)?.query).toBe('latest Iran threat news');
        expect(Object.prototype.hasOwnProperty.call(seenGovernorInput, 'IN')).toBe(false);
        expect(Object.prototype.hasOwnProperty.call(seenGovernorInput, 'STATE')).toBe(false);
        expect(governorAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('resolves markdown escaped variable token paths', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const code = createCodeNode(5);
        const governor = createMetadataNode(4, 'AI Governor');
        const end = createEndNode(6);
        code.id = 'code_5';
        code.gigaId = 'code_5';
        governor.modelId = 'ai-governor';
        governor.runtime = { selectionPromptMd: 'Run {{code\\_5.query}}.' };
        workflow.nodes = [start, code, governor, end];
        workflow.connections = [
            createConnection('c1', start.id, code.id),
            createConnection('c2', code.id, governor.id),
            createConnection('c3', governor.id, end.id)
        ];
        workflow.nodeModels = {
            ...workflow.nodeModels,
            'ai-governor': {
                id: 'ai-governor',
                fields: { selectionPromptMd: { type: 'textarea', allowVariables: true } },
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { started: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                code: async () => ({ output: { query: 'latest Iran news' }, status: WorkflowNodeStatusEnum.Passed }),
                'ai-governor': async (node) => {
                    seenPrompt = String(node.runtime.selectionPromptMd ?? '');
                    return { output: { markdown: 'done', __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed, skipCommandPeerAutoRun: true };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const governorAfter = result.workflow.nodes.find((item) => item.id === governor.id);

        expect(seenPrompt).toBe('Run latest Iran news.');
        expect(governorAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('resolves workflow runtime and workflow input in variable tokens', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Workflow Context');
        const end = createEndNode(3);
        metadata.runtime = {
            prompt: 'Flow {{workflow.input.chatId}} / {{workflow.runtime.graphqlUrl}} / {{workflow.runtime.authMode}}'
        };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { ok: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async (node) => {
                    seenPrompt = String(node.runtime.prompt ?? '');
                    return { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, {
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            workflowInput: { chatId: 'chat_1' }
        });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(seenPrompt).toBe('Flow chat_1 / http://localhost/graphql / none');
        expect(metadataAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('passes resolved runtime to remote node execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Remote Workflow Context');
        const end = createEndNode(3);
        metadata.runtime = { prompt: 'Flow {{workflow.input.chatId}} / {{workflow.runtime.graphqlUrl}}' };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Server,
            adapters: createAdapters({})
        });

        const result = await executor.executeWorkflow(workflow, {
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            workflowInput: { chatId: 'chat_1' },
            isNodeLocalCapable: (modelId) => modelId !== 'metadata',
            executeNodeRemotely: async ({ workflow: remoteWorkflow, nodeId }) => {
                const remoteNode = remoteWorkflow.nodes.find((item) => item.id === nodeId);
                seenPrompt = String(remoteNode?.runtime?.prompt ?? '');
                return {
                    workflow: remoteWorkflow,
                    node: {
                        ...(remoteNode || metadata),
                        status: WorkflowNodeStatusEnum.Passed,
                        ports: { ...(remoteNode?.ports || metadata.ports), out: { output: { prompt: seenPrompt } } }
                    },
                    result: { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed, logs: [] }
                };
            }
        });

        expect(seenPrompt).toBe('Flow chat_1 / http://localhost/graphql');
        expect(result.workflow.nodes.find((item) => item.id === metadata.id)?.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('fails workflow node when variable token is unresolved', async () => {

        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Broken Variable');
        const end = createEndNode(3);
        metadata.runtime = { prompt: 'Use {{input.node_start_1.output.answer}}' };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { ok: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => ({ output: { ok: true }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(metadataAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.events.some((event) => event.event === 'node.failed' && event.nodeId === metadata.id)).toBe(true);
    });

    it('does not resolve variable tokens for inactive schema-conditioned fields', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Inactive Variable');
        const end = createEndNode(3);
        metadata.runtime = { prompt: 'Use {{input.missing}}', useAiFormatting: false };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true,
                        resolveVariablesWhen: { field: 'useAiFormatting', value: true }
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { ok: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async (node) => {
                    seenPrompt = String(node.runtime.prompt || '');
                    return { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed };
                },
                'respond-end': async (_node, input) => ({ output: { input }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(seenPrompt).toBe('Use {{input.missing}}');
        expect(metadataAfter && metadataAfter.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('keeps variable resolution strict for active schema-conditioned fields', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Active Variable');
        const end = createEndNode(3);
        metadata.runtime = { prompt: 'Use {{input.missing}}', useAiFormatting: true };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true,
                        resolveVariablesWhen: { field: 'useAiFormatting', value: true }
                    }
                }
            }
        };

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { ok: true, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => ({ output: { ok: true }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(metadataAfter && metadataAfter.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.events.some((event) => event.event === 'node.failed' && event.nodeId === metadata.id)).toBe(true);
    });

    it('fails when variable token is used in disallowed field', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const metadata = createMetadataNode(2, 'Disallowed Variable');
        const end = createEndNode(3);
        metadata.runtime = { queryLimit: '{{node_start_1.count}}' };
        workflow.nodes = [start, metadata, end];
        workflow.connections = [createConnection('c1', start.id, metadata.id), createConnection('c2', metadata.id, end.id)];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                fields: {
                    queryLimit: {
                        type: 'number',
                        allowVariables: false
                    }
                }
            }
        };

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                start: async () => ({ output: { count: 2, __activeOutputs: ['output'] }, status: WorkflowNodeStatusEnum.Passed }),
                metadata: async () => ({ output: { ok: true }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeWorkflow(workflow, { settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const metadataAfter = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(metadataAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
    });
});
