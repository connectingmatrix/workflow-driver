import type { KafkaConfig, ProducerRecord } from "kafkajs";
import type {
  WorkflowDefinition,
  WorkflowRunLogEvent,
  WorkflowRuntimeSettings,
} from "../types";

export type WorkflowQueueTriggerType = "chat" | "webhook" | "designer";
export type WorkflowQueueScope = "user" | "global" | "organization";
export type WorkflowQueueEventType = "started" | "log" | "completed" | "failed";
export type WorkflowQueueRequestContextMode = "admin" | "user";

export interface WorkflowQueueReference {
  workflowId: string;
  scope: WorkflowQueueScope;
  organizationId?: string | null;
  ownerUserId?: string | null;
}

export interface WorkflowQueueRequestContextSnapshot {
  mode: WorkflowQueueRequestContextMode;
  userId: string;
  authorization?: string | null;
  headers: Record<string, string>;
  method?: string | null;
  protocol?: string | null;
  host?: string | null;
  origin?: string | null;
  path?: string | null;
  originalUrl?: string | null;
  query?: Record<string, unknown> | null;
  body?: unknown;
  ip?: string | null;
}

export interface WorkflowQueueRequest {
  executionId: string;
  runId: string;
  queueKey: string;
  userId: string;
  broadcastId: string;
  broadcastChannelName: string;
  triggerType: WorkflowQueueTriggerType;
  workflowReference: WorkflowQueueReference;
  workflowVersionId?: string | null;
  workflow: WorkflowDefinition;
  settings: WorkflowRuntimeSettings;
  requestContext: WorkflowQueueRequestContextSnapshot;
  metadata?: Record<string, unknown> | null;
}

export interface WorkflowQueueExecutionResult {
  workflow?: WorkflowDefinition | null;
  stopped: boolean;
  runId: string;
  logs?: WorkflowRunLogEvent[];
  responsePayload?: unknown;
}

export interface WorkflowQueueStartedEvent {
  type: "started";
  timestamp: string;
  executionId: string;
  runId: string;
  workflowId: string;
  userId: string;
  broadcastId: string;
  broadcastChannelName: string;
  triggerType: WorkflowQueueTriggerType;
  workflowReference: WorkflowQueueReference;
}

export interface WorkflowQueueLogEvent {
  type: "log";
  timestamp: string;
  executionId: string;
  runId: string;
  workflowId: string;
  userId: string;
  broadcastId: string;
  broadcastChannelName: string;
  triggerType: WorkflowQueueTriggerType;
  workflowReference: WorkflowQueueReference;
  log: WorkflowRunLogEvent;
}

export interface WorkflowQueueCompletedEvent {
  type: "completed";
  timestamp: string;
  executionId: string;
  runId: string;
  workflowId: string;
  userId: string;
  broadcastId: string;
  broadcastChannelName: string;
  triggerType: WorkflowQueueTriggerType;
  workflowReference: WorkflowQueueReference;
  result: WorkflowQueueExecutionResult;
}

export interface WorkflowQueueFailedEvent {
  type: "failed";
  timestamp: string;
  executionId: string;
  runId: string;
  workflowId: string;
  userId: string;
  broadcastId: string;
  broadcastChannelName: string;
  triggerType: WorkflowQueueTriggerType;
  workflowReference: WorkflowQueueReference;
  errorMessage: string;
  logs?: WorkflowRunLogEvent[];
  workflow?: WorkflowDefinition;
  responsePayload?: unknown;
}

export type WorkflowQueueEvent =
  | WorkflowQueueStartedEvent
  | WorkflowQueueLogEvent
  | WorkflowQueueCompletedEvent
  | WorkflowQueueFailedEvent;

export interface WorkflowQueueRedpandaConfig {
  brokers: string[];
  clientId: string;
  ssl?: boolean;
  username?: string;
  password?: string;
  requestTopic: string;
  eventsTopic: string;
  requestConsumerGroupId: string;
  eventConsumerGroupId?: string;
  kafka?: Omit<KafkaConfig, "brokers" | "clientId" | "ssl" | "sasl">;
}

export interface WorkflowQueueSchedulerJob {
  request: WorkflowQueueRequest;
  execute: (signal: AbortSignal) => Promise<void>;
}

export interface WorkflowQueueRunState {
  activeCount?: number;
  broadcastChannelName: string;
  broadcastId: string;
  effectiveConcurrency?: number;
  executionId: string;
  queuedCount?: number;
  queueKey: string;
  requestedConcurrency?: number;
  runId: string;
  status: "queued" | "running";
  throttledBy?: "plan" | "default" | null;
  userId: string;
  workflowId: string;
}

export interface WorkflowQueueScheduler {
  enqueue: (job: WorkflowQueueSchedulerJob) => void;
  cancelRun: (runId: string) => number;
  cancelWorkflow: (workflowId: string) => number;
  getPendingCount: (queueKey: string) => number;
  getActiveCount: (queueKey: string) => number;
  getRunning: (workflowId?: string | null) => WorkflowQueueRunState[];
  close: (params?: { force?: boolean }) => Promise<void>;
}

export interface WorkflowQueueRequestProducer {
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  publish: (request: WorkflowQueueRequest) => Promise<void>;
}

export interface WorkflowQueueEventProducer {
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  publish: (event: WorkflowQueueEvent) => Promise<void>;
}

export interface WorkflowQueueWorker {
  start: () => Promise<void>;
  stop: (params?: { force?: boolean }) => Promise<void>;
  cancelRun: (runId: string) => number;
  cancelWorkflow: (workflowId: string) => number;
  getRunning: (workflowId?: string | null) => WorkflowQueueRunState[];
}

export interface WorkflowQueueMessagePayload {
  value: Buffer | string | null;
}

export interface WorkflowQueueRequestConsumer {
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  subscribe: (params: {
    topic: string;
    fromBeginning: boolean;
  }) => Promise<void>;
  run: (params: {
    eachMessage: (params: {
      message: WorkflowQueueMessagePayload;
    }) => Promise<void>;
  }) => Promise<void>;
}

export type WorkflowQueueKafkaMessage = ProducerRecord["messages"][number];
