import { describe, expect, it } from 'vitest';
import { WorkflowNodeStatusEnum } from '@workflow/ui';
import { executeNodeWorkflowPreview } from '../server/node-preview-runtime';

const WORKER_SOURCE = `import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
    fs.writefileSync('abeer.txt', 'Hello World');
    return { output: { ok: fs.readdirSync('.') }, status: 'passed', logs: ['user-node executed'] };
};`;

describe('playground node preview runtime', () => {
    it('runs node preview for sync fs user nodes without promise clone failures', async () => {
        const result = await executeNodeWorkflowPreview({
            workflow: {
                metadata: {
                    id: 'wf_preview_runtime',
                    name: 'Preview Runtime Test'
                },
                nodeModels: {
                    'user-node:test': {
                        id: 'user-node:test',
                        iconClass: 'pi pi-code',
                        inputs: { input: { allowMultipleArrows: true } },
                        outputs: { output: { allowMultipleArrows: true } }
                    }
                },
                nodes: [
                    {
                        id: 'node_preview_1',
                        gigaId: 'node_preview_1',
                        modelId: 'user-node:test',
                        type: 'workflowStep',
                        name: 'Preview Node',
                        description: '',
                        kind: 'process',
                        status: WorkflowNodeStatusEnum.Stopped,
                        position: { x: 0, y: 0 },
                        runtime: {},
                        ports: { in: {}, out: {} }
                    }
                ],
                connections: []
            },
            nodeId: 'node_preview_1',
            settings: { graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 },
            runId: 'run_preview_1',
            overrides: {
                previewRuntime: 'node',
                sourceFiles: {
                    'worker.ts': WORKER_SOURCE
                }
            },
            emitLog: () => undefined,
            emitState: () => undefined
        });

        expect(result.result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(Array.isArray((result.result.output as { ok?: unknown }).ok)).toBe(true);
        expect((result.result.output as { ok?: string[] }).ok).toContain('abeer.txt');
        expect(result.result.logs).toContain('user-node executed');
    }, 20000);
});
