import { WorkerExecuteHelpers, WorkerRuntimeEnvironmentEnum, WorkflowNodeHandler } from '../../types';
import { TypeScriptModuleLoader } from '../core/compiler/typescript-compiler';
import {
    createRegisteredWorkerRuntimeHelpers,
    createWorkerHelperId,
    executeLoadedWorkerModuleLifecycle,
    loadPreviewValidator,
    loadWorkerModule,
    registerWorkerRuntimeHelpers,
    resolveNodeSourceFilesFromHelper,
    unregisterWorkerRuntimeHelpers
} from '../core/compiler/worker-module-loader';
import { loadBrowserCompiledModule } from './browser-compiler';

export interface BrowserWorkerNodeRunnerArgs {
    modelId: string;
    executeHelpers?: WorkerExecuteHelpers;
    typescriptModuleLoader?: TypeScriptModuleLoader;
}

export const createBrowserWorkerNodeRunner = (args: BrowserWorkerNodeRunnerArgs): WorkflowNodeHandler => {
    return async (context) => {
        const helperId = createWorkerHelperId(context);
        const registeredHelpers = createRegisteredWorkerRuntimeHelpers({
            executeHelpers: args.executeHelpers,
            context
        });
        const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
            executeHelpers: args.executeHelpers,
            context,
            modelId: args.modelId
        });

        registerWorkerRuntimeHelpers(helperId, registeredHelpers);

        try {
            const module = await loadWorkerModule({
                modelId: args.modelId,
                workflow: context.workflow,
                helperId,
                runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                typescriptModuleLoader: args.typescriptModuleLoader,
                resolvedSourceFiles,
                loadCompiledModule: loadBrowserCompiledModule
            });
            const previewValidator = await loadPreviewValidator({
                modelId: args.modelId,
                workflow: context.workflow,
                helperId,
                runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                typescriptModuleLoader: args.typescriptModuleLoader,
                resolvedSourceFiles,
                loadCompiledModule: loadBrowserCompiledModule
            });

            return executeLoadedWorkerModuleLifecycle({
                context,
                runtimeEnvironment: WorkerRuntimeEnvironmentEnum.Browser,
                module,
                previewValidator
            });
        } finally {
            unregisterWorkerRuntimeHelpers(helperId);
        }
    };
};
