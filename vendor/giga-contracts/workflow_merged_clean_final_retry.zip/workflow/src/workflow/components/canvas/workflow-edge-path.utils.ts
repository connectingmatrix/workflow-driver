import { EdgeProps, getBezierPath } from '@xyflow/react';
import type { WorkflowCanvasEdgeStyle } from '@workflow/ui/workflow/types';

type WorkflowEdgePathInput = Pick<EdgeProps, 'sourceX' | 'sourceY' | 'targetX' | 'targetY' | 'sourcePosition' | 'targetPosition'> & {
    sourceLaneOffset?: number;
    targetLaneOffset?: number;
};
type Point = { x: number; y: number };

export interface WorkflowEdgePathResult {
    path: string;
    labelX: number;
    labelY: number;
    controlsX: number;
    controlsY: number;
}

const LABEL_GAP = 18;
const pushPoint = (points: Point[], point: Point): void => {
    const last = points[points.length - 1];
    if (last && last.x === point.x && last.y === point.y) return;
    points.push(point);
};

const buildRoundedPath = (points: Point[], borderRadius: number): string => {
    if (points.length < 2) return '';
    let path = `M ${points[0].x} ${points[0].y}`;

    for (let index = 1; index < points.length - 1; index += 1) {
        const previous = points[index - 1];
        const current = points[index];
        const next = points[index + 1];
        const previousDistance = Math.hypot(current.x - previous.x, current.y - previous.y);
        const nextDistance = Math.hypot(next.x - current.x, next.y - current.y);
        const radius = Math.min(borderRadius, previousDistance / 2, nextDistance / 2);

        if (!radius || (previous.x === current.x && current.x === next.x) || (previous.y === current.y && current.y === next.y)) {
            path += ` L ${current.x} ${current.y}`;
            continue;
        }

        const previousUnitX = (current.x - previous.x) / previousDistance;
        const previousUnitY = (current.y - previous.y) / previousDistance;
        const nextUnitX = (next.x - current.x) / nextDistance;
        const nextUnitY = (next.y - current.y) / nextDistance;
        path += ` L ${current.x - previousUnitX * radius} ${current.y - previousUnitY * radius}`;
        path += ` Q ${current.x} ${current.y} ${current.x + nextUnitX * radius} ${current.y + nextUnitY * radius}`;
    }

    const last = points[points.length - 1];
    return `${path} L ${last.x} ${last.y}`;
};

const resolveSegment = (points: Point[]): { labelX: number; labelY: number; isHorizontal: boolean } => {
    let best = { start: points[0], end: points[points.length - 1], length: 0 };

    for (let index = 0; index < points.length - 1; index += 1) {
        const start = points[index];
        const end = points[index + 1];
        const length = Math.hypot(end.x - start.x, end.y - start.y);
        if (length <= best.length) continue;
        best = { start, end, length };
    }

    return {
        labelX: (best.start.x + best.end.x) / 2,
        labelY: (best.start.y + best.end.y) / 2,
        isHorizontal: best.start.y === best.end.y
    };
};

const buildTrackedPath = (input: WorkflowEdgePathInput, borderRadius: number): WorkflowEdgePathResult => {
    const horizontal = input.sourcePosition === 'left' || input.sourcePosition === 'right' || input.targetPosition === 'left' || input.targetPosition === 'right';
    const sourceOffset = input.sourceLaneOffset ?? 0;
    const targetOffset = input.targetLaneOffset ?? 0;
    const points: Point[] = [];

    if (horizontal) {
        const gap = Math.max(36, Math.min(96, Math.abs(input.targetX - input.sourceX) * 0.35 || 48));
        const middleX = Math.round((input.sourceX + input.targetX) / 2);
        pushPoint(points, { x: input.sourceX, y: input.sourceY });
        pushPoint(points, { x: input.sourceX + gap, y: input.sourceY });
        pushPoint(points, { x: input.sourceX + gap, y: input.sourceY + sourceOffset });
        pushPoint(points, { x: middleX, y: input.sourceY + sourceOffset });
        pushPoint(points, { x: middleX, y: input.targetY + targetOffset });
        pushPoint(points, { x: input.targetX - gap, y: input.targetY + targetOffset });
        pushPoint(points, { x: input.targetX - gap, y: input.targetY });
        pushPoint(points, { x: input.targetX, y: input.targetY });
    } else {
        const gap = Math.max(30, Math.min(84, Math.abs(input.targetY - input.sourceY) * 0.35 || 44));
        const middleY = Math.round((input.sourceY + input.targetY) / 2);
        pushPoint(points, { x: input.sourceX, y: input.sourceY });
        pushPoint(points, { x: input.sourceX, y: input.sourceY + gap });
        pushPoint(points, { x: input.sourceX + sourceOffset, y: input.sourceY + gap });
        pushPoint(points, { x: input.sourceX + sourceOffset, y: middleY });
        pushPoint(points, { x: input.targetX + targetOffset, y: middleY });
        pushPoint(points, { x: input.targetX + targetOffset, y: input.targetY - gap });
        pushPoint(points, { x: input.targetX, y: input.targetY - gap });
        pushPoint(points, { x: input.targetX, y: input.targetY });
    }

    const segment = resolveSegment(points);
    return {
        path: buildRoundedPath(points, borderRadius),
        labelX: segment.labelX,
        labelY: segment.labelY,
        controlsX: segment.isHorizontal ? segment.labelX : segment.labelX + ((sourceOffset || targetOffset || input.targetX - input.sourceX) > 0 ? LABEL_GAP : -LABEL_GAP),
        controlsY: segment.isHorizontal ? segment.labelY + ((sourceOffset || targetOffset || input.targetY - input.sourceY) > 0 ? LABEL_GAP : -LABEL_GAP) : segment.labelY
    };
};

export const buildWorkflowEdgePath = (edgeStyle: WorkflowCanvasEdgeStyle, input: WorkflowEdgePathInput): WorkflowEdgePathResult => {
    if (edgeStyle === 'step') return buildTrackedPath(input, 0);
    if (edgeStyle === 'smoothstep') return buildTrackedPath(input, 20);

    const [path, labelX, labelY] =
        edgeStyle === 'straight'
            ? [`M ${input.sourceX} ${input.sourceY} L ${input.targetX} ${input.targetY}`, (input.sourceX + input.targetX) / 2, (input.sourceY + input.targetY) / 2]
            : getBezierPath(input);
    const deltaX = input.targetX - input.sourceX;
    const deltaY = input.targetY - input.sourceY;
    const length = Math.hypot(deltaX, deltaY) || 1;

    return {
        path,
        labelX,
        labelY,
        controlsX: labelX - (deltaY / length) * LABEL_GAP,
        controlsY: labelY + (deltaX / length) * LABEL_GAP
    };
};
