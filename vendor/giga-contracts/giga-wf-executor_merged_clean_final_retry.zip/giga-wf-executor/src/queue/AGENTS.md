# Workflow Queue Contracts

## Folder Purpose

- Own request/event queue models for workflow executions.
- Keep wire payloads and producers/consumers aligned across runtime and executor layers.

## Core Contracts

- `WorkflowQueueRequest` is the scheduled execution envelope:
  - `executionId`, `runId`, `broadcastId`, `broadcastChannelName`, `queueKey`, `userId`
  - `triggerType` (`chat` | `webhook` | `designer`)
  - `workflowReference` (workflowId, scope, organizationId, ownerUserId)
  - `workflow`, `settings`, `requestContext`, optional `metadata`.
- `WorkflowQueueEvent` unions:
  - `started | log | completed | failed`
  - All events include `executionId`, `runId`, `workflowId`, `userId`, `timestamp`, `broadcastId`, `broadcastChannelName`, `triggerType`, `workflowReference`.

## Serialization

- `parseWorkflowQueueRequest` / `parseWorkflowQueueEvent` accept Buffer or JSON string and return typed models.
- `toWorkflowQueueRequestMessage` / `toWorkflowQueueEventMessage` output Kafka message payloads.
- `executeQueuedWorkflowRequest` helpers should publish events through these serializers.

## Runtime Event Rules

- `started`: marks execution state as active.
- `log`: writes workflow run logs and emits transport logs.
- `completed`: finalizes successful runs with `result`.
- `failed`: finalizes failure with `errorMessage` and optional `workflow/logs`.
- Use non-empty `executionId`, `runId`, `workflowId` for event correlation.

## Local Rules

- No ad-hoc payload shapes outside `WorkflowQueue*` interfaces.
- Do not broaden queue types without updating both parser and message helper functions.

## Validation

- Update tests in `/src/__tests__` when queue event/request shape changes.
- Keep parser/serializer round-trip tested for request/event paths.
