import type { WorkflowNodeCatalog } from '@workflow/ui/workflow/driver';
import type { WorkflowDefinition } from '@workflow/ui/workflow/types';

type CanvasSearchNodeCatalog = Pick<WorkflowNodeCatalog, 'resolveNodeSchema' | 'getAllNodeSchemas'>;

const normalizeSearchText = (value: string | null | undefined): string => value?.trim().toLowerCase() ?? '';
const toSearchableText = (value: unknown): string => (typeof value === 'string' ? value : '');

const scoreSearchMatch = (candidate: string | null | undefined, query: string): number => {
    const normalizedCandidate = normalizeSearchText(candidate);
    if (!normalizedCandidate) return Number.POSITIVE_INFINITY;
    if (normalizedCandidate === query) return 0;
    if (normalizedCandidate.startsWith(query)) return 1;
    if (normalizedCandidate.includes(query)) return 2;
    return Number.POSITIVE_INFINITY;
};

export const findWorkflowCanvasSearchMatches = (workflow: WorkflowDefinition | null | undefined, search: string, nodeCatalog: CanvasSearchNodeCatalog): string[] => {
    const normalizedSearch = normalizeSearchText(search);
    if (!normalizedSearch || !workflow?.nodes?.length) {
        return [];
    }
    const ranked = workflow.nodes
        .map((node) => {
        const schema = nodeCatalog.resolveNodeSchema(node.modelId, workflow.nodeModels ?? nodeCatalog.getAllNodeSchemas());
        const searchScore = Math.min(
            scoreSearchMatch(node.name, normalizedSearch),
            scoreSearchMatch(node.modelId, normalizedSearch),
            scoreSearchMatch(toSearchableText((schema as { label?: unknown }).label), normalizedSearch),
            scoreSearchMatch(toSearchableText((schema as { group?: unknown }).group), normalizedSearch),
            scoreSearchMatch(schema.documentation?.nodeTypeLabel, normalizedSearch),
            scoreSearchMatch(toSearchableText((schema as { description?: unknown }).description), normalizedSearch)
        );
            return { id: node.id, score: searchScore };
        })
        .filter((entry) => Number.isFinite(entry.score))
        .sort((left, right) => left.score - right.score);
    return ranked.map((entry) => entry.id);
};
