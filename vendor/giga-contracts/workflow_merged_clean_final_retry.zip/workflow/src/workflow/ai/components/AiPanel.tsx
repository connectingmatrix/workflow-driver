import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { WorkflowAiChatMessage, WorkflowAiScope } from '../types';
import '../workflow-ai.scss';

interface AiPanelProps {
    visible: boolean;
    scope: WorkflowAiScope;
    isLoading: boolean;
    messages: WorkflowAiChatMessage[];
    onClose: () => void;
    onSwitchToWorkflowScope: () => void;
    onSend: (message: string) => Promise<void> | void;
    onClearSession: () => void;
}

const AiPanel: React.FC<AiPanelProps> = ({ visible, scope, isLoading, messages, onClose, onSwitchToWorkflowScope, onSend, onClearSession }) => {
    const [draft, setDraft] = useState<string>('');
    const listRef = useRef<HTMLDivElement>(null);
    const isNodeScope = scope.mode === 'node' && Boolean(scope.nodeId);
    const scopeLabel = useMemo(() => {
        if (!isNodeScope) return 'Workflow Scope';
        const nodeName = scope.nodeName?.trim() || scope.nodeId?.trim() || 'Node';
        const nodeType = scope.nodeType?.trim();
        return nodeType ? `${nodeName} (${nodeType})` : nodeName;
    }, [isNodeScope, scope.nodeId, scope.nodeName, scope.nodeType]);

    useEffect(() => {
        if (!visible) return;
        const host = listRef.current;
        if (!host) return;
        host.scrollTop = host.scrollHeight;
    }, [messages.length, visible, isLoading]);

    if (!visible) return null;

    return (
        <aside className="wf-ai-panel" aria-label="Workflow AI panel">
            <div className="wf-ai-panel__header">
                <div className="wf-ai-panel__title-wrap">
                    <span className="wf-ai-panel__title">Workflow AI</span>
                    <span className="wf-ai-panel__subtitle">Create, edit, debug, and execute workflows</span>
                </div>
                <div className="wf-ai-panel__header-actions">
                    <Button text icon="pi pi-trash" className="p-button-sm wf-ai-panel__header-btn" onClick={onClearSession} aria-label="Clear chat session" tooltip="Clear session chat" tooltipOptions={{ position: 'bottom' }} />
                    <Button text icon="pi pi-times" className="p-button-sm wf-ai-panel__header-btn" onClick={onClose} aria-label="Close workflow AI panel" tooltip="Close" tooltipOptions={{ position: 'bottom' }} />
                </div>
            </div>

            {isNodeScope ? (
                <div className="wf-ai-panel__scope-ribbon">
                    <span className="wf-ai-panel__scope-label">{scopeLabel}</span>
                    <Button text icon="pi pi-times" className="p-button-sm wf-ai-panel__scope-close" onClick={onSwitchToWorkflowScope} aria-label="Switch to workflow scope" tooltip="Switch to workflow scope" tooltipOptions={{ position: 'bottom' }} />
                </div>
            ) : null}

            <div className="wf-ai-panel__messages" ref={listRef}>
                {messages.length === 0 ? <div className="wf-ai-panel__empty">Ask AI to create, debug, or update this workflow. Hidden workflow context is sent automatically.</div> : null}
                {messages.map((message) => (
                    <div key={message.id} className={`wf-ai-panel__message wf-ai-panel__message--${message.role}`}>
                        <div className="wf-ai-panel__message-role">{message.role === 'assistant' ? 'AI' : 'You'}</div>
                        <div className="wf-ai-panel__message-text">{message.text}</div>
                    </div>
                ))}
                {isLoading ? (
                    <div className="wf-ai-panel__message wf-ai-panel__message--assistant">
                        <div className="wf-ai-panel__message-role">AI</div>
                        <div className="wf-ai-panel__message-text">Thinking…</div>
                    </div>
                ) : null}
            </div>

            <form
                className="wf-ai-panel__composer"
                onSubmit={async (event) => {
                    event.preventDefault();
                    const value = draft.trim();
                    if (!value || isLoading) return;
                    setDraft('');
                    await onSend(value);
                }}
            >
                <textarea
                    value={draft}
                    onChange={(event) => setDraft(event.target.value)}
                    placeholder={isNodeScope ? 'Ask AI to fix/debug this node...' : 'Ask AI to create or update this workflow...'}
                    className="wf-ai-panel__textarea"
                    rows={3}
                    onKeyDown={(event) => {
                        if (event.key !== 'Enter' || event.shiftKey) return;
                        event.preventDefault();
                        const value = draft.trim();
                        if (!value || isLoading) return;
                        setDraft('');
                        void onSend(value);
                    }}
                />
                <Button label="Send" icon="pi pi-send" type="submit" className="p-button-sm wf-ai-panel__send-btn" disabled={!draft.trim() || isLoading} />
            </form>
        </aside>
    );
};

export default AiPanel;
