import React, { useMemo } from 'react';

interface TableViewerProps {
    value: unknown;
}

const normalizeRows = (value: unknown): Record<string, unknown>[] => {
    if (Array.isArray(value)) {
        return value.filter((row): row is Record<string, unknown> => typeof row === 'object' && row !== null);
    }
    if (value && typeof value === 'object' && Array.isArray((value as { rows?: unknown[] }).rows)) {
        return normalizeRows((value as { rows: unknown[] }).rows);
    }
    return [];
};

const TableViewer: React.FC<TableViewerProps> = ({ value }) => {
    const rows = useMemo(() => normalizeRows(value), [value]);
    const columns = useMemo(() => Array.from(new Set(rows.flatMap((row) => Object.keys(row)))), [rows]);
    if (!rows.length) {
        return <div className="wf-inspector__hint">No table rows available.</div>;
    }
    return (
        <div className="wf-inspector__table-shell">
            <table className="wf-inspector__table">
                <thead>
                    <tr>
                        {columns.map((column) => (
                            <th key={column}>{column}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {rows.map((row, index) => (
                        <tr key={`row-${index}`}>
                            {columns.map((column) => (
                                <td key={`${index}-${column}`}>{String(row[column] ?? '')}</td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TableViewer;
