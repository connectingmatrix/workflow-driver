import React from 'react';

interface WorkspaceToolbarButtonProps {
    icon: string;
    label?: string;
    active?: boolean;
    disabled?: boolean;
    danger?: boolean;
    primary?: boolean;
    onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    ariaLabel: string;
    tooltip?: string;
    dataCy?: string;
}

export const WorkspaceToolbarButton: React.FC<WorkspaceToolbarButtonProps> = ({ icon, label, active = false, disabled = false, danger = false, primary = false, onClick, ariaLabel, tooltip, dataCy }) => (
    <button
        type="button"
        className={`wf-workspace-toolbar__button${label ? ' wf-workspace-toolbar__button--labeled' : ''}${active ? ' wf-workspace-toolbar__button--active' : ''}${danger ? ' wf-workspace-toolbar__button--danger' : ''}${primary ? ' wf-workspace-toolbar__button--primary' : ''}`}
        disabled={disabled}
        onClick={onClick}
        aria-label={ariaLabel}
        title={tooltip || ariaLabel}
        data-pr-tooltip={tooltip || ariaLabel}
        data-pr-position="bottom"
        data-cy={dataCy}
    >
        <i className={`${icon} wf-workspace-toolbar__button-icon${icon.includes('spinner') ? ' wf-workspace-toolbar__button-icon--busy' : ''}`} aria-hidden />
        {label ? <span>{label}</span> : null}
    </button>
);
