import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

export interface NodeLibraryProps {
    visible: boolean;
    items: WorkflowNodeLibraryItem[];
    onInsertItem?: (item: WorkflowNodeLibraryItem) => void;
    onClose?: () => void;
}
