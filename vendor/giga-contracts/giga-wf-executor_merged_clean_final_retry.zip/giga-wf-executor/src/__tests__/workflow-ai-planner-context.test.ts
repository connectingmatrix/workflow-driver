import { describe, expect, it } from 'vitest';
import { workflowPlannerContext } from '../workflow-ai-creation/planner-context';

describe('workflowPlannerContext', () => {
    it('includes chat-parity action nodes and confirmation hints for chat workflow requests', () => {
        const context = workflowPlannerContext('Create a chat workflow with Giga action parity and governor routing');

        expect(context).toContain('run-chat-action');
        expect(context).toContain('broadcastModelId');
        expect(context).toContain('serp-search');
        expect(context).toContain('confirmation gate');
        expect(context).toContain('text-analysis');
        expect(context).toContain('Execute Workflow');
        expect(context).toContain('execute-plan');
    });

    it('keeps generic workflow authoring context focused on core nodes', () => {
        const context = workflowPlannerContext('Create a hello world workflow and execute it');

        expect(context).toContain('Workflow node');
        expect(context).toContain('Execute Workflow');
        expect(context).not.toContain('run-channel-action');
    });
});
