import { describe, expect, it } from 'vitest';
import { createNodeExecutorSignature, createWorkerNodeHandler } from '../executor/worker-runtime';
import { WorkflowDefinition, WorkflowNodeHandlerContext, WorkflowNodeModel, WorkflowNodeStatusEnum } from '../types';

const toBase64 = (source: string) => Buffer.from(source, 'utf8').toString('base64');
const node = (id: string, modelId: string, name: string): WorkflowNodeModel => ({ id, gigaId: id, modelId, type: 'workflowStep', name, description: '', kind: 'process', status: WorkflowNodeStatusEnum.Stopped, position: { x: 0, y: 0 }, runtime: {}, ports: { in: {}, out: {} } });
const AI_AGENT_SOURCE = `export const validate=async()=>({ok:true,errors:[],warnings:[]});export const init=async()=>true;export const onUpdate=async()=>({ok:true});export const execute=async(payload)=>{const tool=Object.values(payload.NODE.CONTROL_NODES.tools||{})[0];const workflow=Object.values(payload.NODE.CONTROL_NODES.workflow||{})[0];const workflowRun=await workflow.execute();return{output:{groups:Object.keys(payload.NODE.CONTROL_NODES||{}),llmKeys:Object.keys(payload.NODE.CONTROL_NODES.llm||{}),toolSpec:await tool.commandToolSpec(),workflowSpec:await workflow.commandToolSpec(),workflowRun:workflowRun.result.output},status:'passed',logs:[]};};`;
const OPENAI_SOURCE = `export const validate=async()=>({ok:true,errors:[],warnings:[]});export const init=async()=>true;export const onUpdate=async()=>({ok:true});export const execute=async()=>({output:{text:'planned'},status:'passed',logs:[]});`;
const TOOL_SOURCE = `export const validate=async()=>({ok:true,errors:[],warnings:[]});export const init=async()=>true;export const onUpdate=async()=>({ok:true});export const commandToolSpec=async()=>({toolName:'Channel Actions',toolDescription:'Read channels.',inputContract:{required:[{key:'action'}],optional:[{key:'parameters'}]},outputContract:[{key:'action_result'}],metadata:{toolDomain:'content',mutating:false,workflowOutput:false,broadcastModelId:'run-channel-action'},executionKind:'tool'});export const execute=async()=>({output:{ok:true},status:'passed',logs:[]});`;
const WORKFLOW_SOURCE = `export const validate=async()=>({ok:true,errors:[],warnings:[]});export const init=async()=>true;export const onUpdate=async()=>({ok:true});export const commandToolSpec=async()=>({toolName:'Workflow Agent',toolDescription:'Create and execute workflows.',inputContract:{required:[{key:'operation'}]},outputContract:[{key:'workflow'}],metadata:{toolDomain:'workflow',mutating:true,workflowOutput:true,workflowActions:['create_workflow_from_cypher','execute_workflow']},executionKind:'tool'});export const execute=async()=>({output:{text:'workflow-done',editorUrl:'http://localhost/workflows/1'},status:'passed',logs:[]});`;

const createWorkflow = (): WorkflowDefinition => ({
    metadata: { id: 'wf_ai_agent', name: 'AI Agent Control Nodes' },
    nodeModels: {
        'ai-agent': { inputs: { input: {} }, outputs: { output: {} }, commands: { llm: { portType: 'bi-directional', allowMultipleArrows: true }, tools: { portType: 'bi-directional', allowMultipleArrows: true }, workflow: { portType: 'bi-directional', allowMultipleArrows: true } } },
        openai: { inputs: { input: {} }, outputs: { output: {} }, commands: { command: { portType: 'bi-directional', allowMultipleArrows: true } } },
        'action-router': { inputs: { input: {} }, outputs: { output: {} }, commands: { command: { portType: 'bi-directional', allowMultipleArrows: true } } },
        workflow: { inputs: { input: {} }, outputs: { output: {} }, commands: { command: { portType: 'bi-directional', allowMultipleArrows: true } } }
    },
    nodes: [node('agent_1', 'ai-agent', 'AI Agent'), node('llm_1', 'openai', 'OpenAI'), node('tool_1', 'action-router', 'Channel Router'), node('workflow_1', 'workflow', 'Workflow Agent')],
    connections: [
        { id: 'c1', name: 'OpenAI -> AI Agent', from: 'llm_1', to: 'agent_1', sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
        { id: 'c2', name: 'Tool -> AI Agent', from: 'tool_1', to: 'agent_1', sourceHandle: 'cmd:command', targetHandle: 'cmd:tools' },
        { id: 'c3', name: 'Workflow -> AI Agent', from: 'workflow_1', to: 'agent_1', sourceHandle: 'cmd:command', targetHandle: 'cmd:workflow' }
    ],
    NODE_EXECUTORS: { 'ai-agent': toBase64(AI_AGENT_SOURCE), openai: toBase64(OPENAI_SOURCE), 'action-router': toBase64(TOOL_SOURCE), workflow: toBase64(WORKFLOW_SOURCE) },
    NODE_EXECUTOR_SIGNATURES: {
        'ai-agent': createNodeExecutorSignature('ai-agent', AI_AGENT_SOURCE),
        openai: createNodeExecutorSignature('openai', OPENAI_SOURCE),
        'action-router': createNodeExecutorSignature('action-router', TOOL_SOURCE),
        workflow: createNodeExecutorSignature('workflow', WORKFLOW_SOURCE)
    }
});

const createContext = (workflow: WorkflowDefinition): WorkflowNodeHandlerContext => ({
    node: workflow.nodes[0],
    workflow,
    settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
    input: {}
});

describe('ai-agent control-node runtime', () => {
    it('keeps command peers grouped by port and preserves typed tool metadata', async () => {
        const result = await createWorkerNodeHandler({ modelId: 'ai-agent', runtimeEnvironment: 'node' })(createContext(createWorkflow()));
        const output = result.output as Record<string, any>;

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(output.groups).toEqual(['llm', 'tools', 'workflow']);
        expect(output.llmKeys).toEqual(['OpenAI']);
        expect(output.toolSpec.metadata).toMatchObject({ toolDomain: 'content', mutating: false, workflowOutput: false, broadcastModelId: 'run-channel-action' });
        expect(output.workflowSpec.metadata).toMatchObject({ toolDomain: 'workflow', mutating: true, workflowOutput: true, workflowActions: ['create_workflow_from_cypher', 'execute_workflow'] });
        expect(output.workflowRun).toEqual({ text: 'workflow-done', editorUrl: 'http://localhost/workflows/1' });
    }, 20000);
});
