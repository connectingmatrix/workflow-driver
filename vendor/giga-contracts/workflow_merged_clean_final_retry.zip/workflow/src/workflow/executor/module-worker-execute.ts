import { createBrowserWorkerNodeHandler } from '@workflow/executor/browser';
import type { WorkflowNodeHandler, WorkflowNodeHandlerContext, WorkflowNodeModel, WorkflowNodeHandlerResult } from '@workflow/executor';
import { executeNodeWorkerBackend } from '@workflow/ui/workflow/executor/backend-adapter';
import { invokeNodeWorkerConnection } from '@workflow/ui/workflow/executor/invoke-connected-node-adapter';
import { loadTypeScriptModule } from '@workflow/ui/workflow/executor/typescript-loader';
import { withNodeExecutors } from '@workflow/nodes/utils/workflow-node-executors.utils';

const withNodeInputPorts = (node: WorkflowNodeHandlerContext['node'], input: WorkflowNodeHandlerContext['input']): WorkflowNodeHandlerContext['node'] => ({
    ...node,
    ports: {
        ...(node.ports ?? { in: {}, out: {} }),
        in: input ?? {},
        out: node.ports?.out ?? {}
    }
});

const buildWorkflowWithExecutors = (workflow: WorkflowNodeHandlerContext['workflow'], node: WorkflowNodeHandlerContext['node']): WorkflowNodeHandlerContext['workflow'] => {
    if (workflow.NODE_EXECUTORS && workflow.NODE_EXECUTOR_SIGNATURES) {
        return workflow;
    }

    const hasNode = workflow.nodes.some((item) => item.id === node.id);
    return withNodeExecutors({
        ...workflow,
        nodes: hasNode ? workflow.nodes.map((item): WorkflowNodeModel => (item.id === node.id ? node : item)) : [...workflow.nodes, node]
    }) as WorkflowNodeHandlerContext['workflow'];
};

export const createNodeModuleWorkerExecute = (modelId: string): WorkflowNodeHandler => {
    const handler = createBrowserWorkerNodeHandler({
        modelId,
        typescriptModuleLoader: loadTypeScriptModule,
        executeHelpers: {
            executeBackend: executeNodeWorkerBackend,
            invokeConnectedNode: invokeNodeWorkerConnection
        } as any
    });

    return async (context: WorkflowNodeHandlerContext): Promise<WorkflowNodeHandlerResult> => {
        const normalizedNode = withNodeInputPorts(context.node, context.input);
        return handler({
            ...context,
            node: normalizedNode,
            workflow: buildWorkflowWithExecutors(context.workflow, normalizedNode)
        });
    };
};
