import type { WorkflowCredentialHostContext, WorkflowCredentialExecutionResultInput, WorkflowNodeHandlerResult } from '../../types';
import { WorkflowNodeStatusEnum } from '../../types';

export const recordNodeCredentialExecutionResult = async (params: {
    credentialId: string | null;
    host: WorkflowCredentialHostContext | null;
    result: WorkflowNodeHandlerResult;
}): Promise<void> => {
    if (!params.credentialId || !params.host?.recordCredentialExecutionResult) {
        return;
    }

    const input: WorkflowCredentialExecutionResultInput = {
        credentialId: params.credentialId,
        success: params.result.status !== WorkflowNodeStatusEnum.Failed,
    };

    await params.host.recordCredentialExecutionResult(input);
};
