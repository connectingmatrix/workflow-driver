import React from 'react';
import { Button } from 'primereact/button';
import type { WorkflowNodeFileValue } from '@workflow/ui/workflow/types';
import { parseWorkflowFileValue } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';

interface WorkspaceFileListFieldProps {
    fieldKey: string;
    value: unknown;
    editable: boolean;
    accept?: string;
    onChange: (fieldKey: string, value: unknown) => void;
}

const formatFileSize = (size: number): string => {
    if (!Number.isFinite(size) || size <= 0) return '0 KB';
    if (size >= 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    return `${Math.max(1, Math.round(size / 1024))} KB`;
};

const normalizeFiles = (value: unknown): WorkflowNodeFileValue[] => {
    if (!Array.isArray(value)) return [];
    return value.filter(
        (item): item is WorkflowNodeFileValue =>
            typeof item === 'object' &&
            item !== null &&
            typeof (item as WorkflowNodeFileValue).name === 'string' &&
            typeof (item as WorkflowNodeFileValue).mimeType === 'string' &&
            typeof (item as WorkflowNodeFileValue).size === 'number'
    );
};

export const WorkspaceFileListField: React.FC<WorkspaceFileListFieldProps> = ({ fieldKey, value, editable, accept, onChange }) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const files = React.useMemo(() => normalizeFiles(value), [value]);

    return (
        <div className="cnw-file-field cnw-file-field--list">
            <div className="cnw-file-field__summary">
                <span className="cnw-file-field__title">{files.length ? `${files.length} file${files.length === 1 ? '' : 's'} selected` : 'No files selected'}</span>
                <span className="cnw-file-field__meta">{files.length ? 'Uploaded files stay local to the workflow draft.' : 'Upload one or more files to drive this node.'}</span>
            </div>
            {files.length ? (
                <div className="cnw-file-field__list">
                    {files.map((file) => (
                        <div key={`${file.name}-${file.size}`} className="cnw-file-field__item">
                            <div className="cnw-file-field__item-content">
                                <span className="cnw-file-field__item-title">{file.name}</span>
                                <span className="cnw-file-field__item-meta">{`${file.mimeType} • ${formatFileSize(file.size)}`}</span>
                            </div>
                        </div>
                    ))}
                </div>
            ) : null}
            <div className="cnw-file-field__actions">
                <Button type="button" label={files.length ? 'Replace files' : 'Upload files'} icon="pi pi-paperclip" outlined disabled={!editable} onClick={() => inputRef.current?.click()} />
                {files.length ? (
                    <Button
                        type="button"
                        label="Clear"
                        icon="pi pi-times"
                        text
                        disabled={!editable}
                        onClick={() => onChange(fieldKey, [])}
                    />
                ) : null}
            </div>
            <input
                ref={inputRef}
                type="file"
                className="cnw-file-field__input"
                accept={accept}
                multiple
                onChange={async (event) => {
                    const selectedFiles = Array.from(event.target.files ?? []);
                    event.target.value = '';
                    if (!selectedFiles.length) return;
                    const nextValue = await Promise.all(selectedFiles.map((file) => parseWorkflowFileValue(file)));
                    onChange(fieldKey, nextValue);
                }}
            />
        </div>
    );
};
