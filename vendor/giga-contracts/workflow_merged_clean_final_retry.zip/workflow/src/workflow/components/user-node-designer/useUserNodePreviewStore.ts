import { useState } from 'react';
import { WorkflowPreviewLogEvent, WorkflowPreviewRuntime, WorkflowPreviewStateEvent } from '@workflow/ui/workflow/types';

export interface UserNodePreviewState {
    runId: string | null;
    status: 'idle' | 'running' | 'passed' | 'failed' | 'stopped' | 'cancelled';
    requestedRuntime: WorkflowPreviewRuntime | null;
    effectiveRuntime: 'browser' | 'node' | null;
    sourceMode: 'saved' | 'unsaved' | null;
    nodeModelId: string | null;
    nodeDefinitionId: string | null;
    logs: WorkflowPreviewLogEvent[];
    result: unknown;
    diagnostics: string[];
    validation: WorkflowPreviewStateEvent['validation'] | null;
    startedAt: string | null;
    durationMs: number | null;
    inputUsed: Record<string, unknown> | null;
    runtimeError: string | null;
    wasCancelled: boolean;
}

const INITIAL_STATE: UserNodePreviewState = {
    runId: null,
    status: 'idle',
    requestedRuntime: null,
    effectiveRuntime: null,
    sourceMode: null,
    nodeModelId: null,
    nodeDefinitionId: null,
    logs: [],
    result: null,
    diagnostics: [],
    validation: null,
    startedAt: null,
    durationMs: null,
    inputUsed: null,
    runtimeError: null,
    wasCancelled: false
};

export const useUserNodePreviewStore = () => {
    const [state, setState] = useState<UserNodePreviewState>(INITIAL_STATE);

    const startRun = (params: {
        runId: string;
        inputUsed: Record<string, unknown> | null;
        requestedRuntime: WorkflowPreviewRuntime;
        effectiveRuntime: 'browser' | 'node';
        sourceMode: 'saved' | 'unsaved';
        nodeModelId: string;
        nodeDefinitionId: string | null;
    }) => {
        setState((previous) => ({
            ...previous,
            runId: params.runId,
            status: 'running',
            requestedRuntime: params.requestedRuntime,
            effectiveRuntime: params.effectiveRuntime,
            sourceMode: params.sourceMode,
            nodeModelId: params.nodeModelId,
            nodeDefinitionId: params.nodeDefinitionId,
            logs: [],
            diagnostics: [],
            validation: null,
            runtimeError: null,
            startedAt: new Date().toISOString(),
            durationMs: null,
            inputUsed: params.inputUsed,
            wasCancelled: false
        }));
    };

    const appendLog = (event: WorkflowPreviewLogEvent) => {
        setState((previous) => ({ ...previous, logs: [...previous.logs, event] }));
    };

    const applyStateEvent = (event: WorkflowPreviewStateEvent) => {
        setState((previous) => ({
            ...previous,
            status: event.state === 'starting' || event.state === 'running' ? 'running' : event.state,
            requestedRuntime: event.requestedRuntime ?? previous.requestedRuntime,
            effectiveRuntime: event.runtime ?? previous.effectiveRuntime,
            startedAt: event.startedAt ?? previous.startedAt,
            durationMs: event.durationMs ?? previous.durationMs,
            diagnostics: event.validation ? [...(event.validation.warnings ?? []), ...(event.validation.errors ?? [])] : previous.diagnostics,
            validation: event.validation ?? previous.validation,
            wasCancelled: event.state === 'cancelled' ? true : previous.wasCancelled
        }));
    };

    const setResult = (result: unknown, status?: string) => {
        setState((previous) => ({
            ...previous,
            result,
            status: status === 'failed' ? 'failed' : status === 'passed' ? 'passed' : previous.status
        }));
    };

    const setRuntimeError = (message: string) => {
        setState((previous) => ({ ...previous, runtimeError: message, status: 'failed' }));
    };

    const setDiagnostics = (params: { errors?: string[]; warnings?: string[]; message?: string | null }) => {
        const errors = params.errors ?? [];
        const warnings = params.warnings ?? [];
        setState((previous) => ({
            ...previous,
            status: 'failed',
            diagnostics: [...warnings, ...errors],
            validation: {
                ok: errors.length === 0,
                warnings,
                errors
            },
            runtimeError: params.message ?? errors[0] ?? previous.runtimeError
        }));
    };

    const stopRun = (reason: 'completed' | 'cancelled' | 'failed') => {
        setState((previous) => ({
            ...previous,
            status: reason === 'cancelled' ? 'cancelled' : reason === 'failed' || previous.status === 'failed' ? 'failed' : previous.status === 'running' ? 'passed' : previous.status,
            durationMs: previous.startedAt ? Date.now() - new Date(previous.startedAt).getTime() : previous.durationMs,
            wasCancelled: reason === 'cancelled' ? true : previous.wasCancelled
        }));
    };

    const clearLogs = () => setState((previous) => ({ ...previous, logs: [] }));

    const reset = () => setState(INITIAL_STATE);

    return { state, actions: { startRun, appendLog, applyStateEvent, setResult, setRuntimeError, setDiagnostics, stopRun, clearLogs, reset } };
};
