export const WORKFLOW_NODE_PREVIEW_ENDPOINT = '/__workflow/preview/node';
