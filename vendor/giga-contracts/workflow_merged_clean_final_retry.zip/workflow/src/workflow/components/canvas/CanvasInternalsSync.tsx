import React, { useEffect } from 'react';
import { useUpdateNodeInternals } from '@xyflow/react';
import { WorkflowFlowEdge, WorkflowFlowNode } from '@workflow/ui/workflow/components/canvas/workflow-flow.types';

interface CanvasInternalsSyncProps {
    nodes: WorkflowFlowNode[];
    edges: WorkflowFlowEdge[];
}

const CanvasInternalsSync: React.FC<CanvasInternalsSyncProps> = ({ nodes, edges }) => {
    const updateNodeInternals = useUpdateNodeInternals();

    useEffect(() => {
        if (!nodes.length) return;
        let secondFrame = 0;
        const frame = window.requestAnimationFrame(() => {
            nodes.forEach((node) => updateNodeInternals(node.id));
            secondFrame = window.requestAnimationFrame(() => {
                nodes.forEach((node) => updateNodeInternals(node.id));
                window.dispatchEvent(new Event('resize'));
            });
        });
        return () => {
            window.cancelAnimationFrame(frame);
            if (secondFrame) window.cancelAnimationFrame(secondFrame);
        };
    }, [edges, nodes, updateNodeInternals]);

    return null;
};

export default CanvasInternalsSync;
