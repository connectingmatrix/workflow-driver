export interface WorkflowActionCatalogEntry {
  description: string;
  input_schema: Record<string, unknown>;
  mutating: boolean;
  name: string;
}

const schema = (input: Record<string, unknown>) => input;

export const readWorkflowActionCatalog = (): WorkflowActionCatalogEntry[] => [
  { name: 'fetch_all_workflows', description: 'List accessible workflows with identifiers, names, descriptions, scope, status, and timestamps only.', input_schema: schema({ organization_id: 'uuid optional', include_global: 'boolean optional' }), mutating: false },
  { name: 'fetch_workflow', description: 'Read one accessible workflow with metadata, node details, latest chat run, and editor link. If id is omitted, uses the last workflow in this chat.', input_schema: schema({ id: 'uuid optional', scope: 'user|organization optional', organization_id: 'uuid optional' }), mutating: false },
  { name: 'fetch_workflow_runs', description: 'Read run metadata and bounded output/error excerpts for one workflow.', input_schema: schema({ workflow_id: 'uuid', scope: 'user|organization optional', organization_id: 'uuid optional', filter: 'object optional' }), mutating: false },
  { name: 'fetch_workflow_revisions', description: 'Read workflow revision metadata without workflow snapshots.', input_schema: schema({ workflow_id: 'uuid', scope: 'user|organization optional', organization_id: 'uuid optional' }), mutating: false },
  { name: 'fetch_workflow_node_catalog', description: 'Fetch workflow node catalog with ids, docs summaries, ports, fields, and core authoring rules.', input_schema: schema({}), mutating: false },
  { name: 'fetch_workflow_node_details', description: 'Fetch full worker files, JSON schemas, README docs, ports, and rules for selected workflow node ids.', input_schema: schema({ model_ids: 'string[] required' }), mutating: false },
  { name: 'validate_workflow_cypher', description: 'Validate workflow Cypher and compile it into safe workflow JSON without writing records.', input_schema: schema({ name: 'string optional', description: 'string optional', cypher: 'string', executable: 'boolean optional default true' }), mutating: false },
  { name: 'create_workflow_from_cypher', description: 'Create a workflow from validated workflow Cypher. Use this for chat workflow creation; do not send raw workflow JSON. To attach the created workflow, provide attach_scope_type plus attach_scope_id or attach_scope_name.', input_schema: schema({ name: 'string', description: 'string optional', cypher: 'workflow cypher string', executable: 'boolean optional default true', execute_after_create: 'boolean optional', expected_output_contract: 'string optional', attach_scope_type: 'CHANNEL|CATEGORY|SUBJECT|POST optional', attach_scope_id: 'uuid optional', attach_scope_name: 'string optional' }), mutating: true },
  { name: 'update_workflow_from_cypher', description: 'Update an owned workflow from validated workflow Cypher. Use this instead of raw workflow JSON updates. To attach the updated workflow, provide attach_scope_type plus attach_scope_id or attach_scope_name.', input_schema: schema({ id: 'uuid', name: 'string optional', description: 'string optional', cypher: 'workflow cypher string', executable: 'boolean optional default true', attach_scope_type: 'CHANNEL|CATEGORY|SUBJECT|POST optional', attach_scope_id: 'uuid optional', attach_scope_name: 'string optional' }), mutating: true },
  { name: 'delete_workflow', description: 'Delete a workflow owned by the current user.', input_schema: schema({ id: 'uuid' }), mutating: true },
  { name: 'execute_workflow', description: 'Execute an existing workflow or a workflow created by a prior create_workflow_from_cypher action and return terminal output.', input_schema: schema({ workflow_id: 'uuid optional', workflow_action_id: 'action id optional', parameters: 'json optional' }), mutating: true },
  { name: 'get_workflow_output', description: 'Extract terminal output from workflow JSON or latest execution payload.', input_schema: schema({ workflow_id: 'uuid optional', workflow: 'json optional' }), mutating: false },
];
