import { buildNodeInputContext } from '../graph/run-context';
import { createRunId, emitNodeFailed, emitNodeFinished, emitNodeLogs, emitNodeStarted } from '../graph/log';
import { buildCompletedNodeState, buildFailedNodeState, buildRunningNodeState, replaceNodeById } from '../graph/state';
import { ExecuteNodeStepOptions, WorkflowDefinition, WorkflowExecutorAdapters, WorkflowExecutorMode, WorkflowNodeHandlerResult, WorkflowNodeModel, WorkflowNodeStatusEnum, WorkflowPreviewValidationSummary, WorkflowStepExecutorResult } from '../../../types';
import { buildRetryAttemptLog, resolveFailureMessageFromResult, resolveFailureRetryLimit, resolveResultStatus } from './failure-mitigation';
import { createEventCollector, getBiPeerNodeIds, isNodeEnabled, normalizeNodeStatus, publishBiControlState, toPortsIn, toPortsOut, toRunnerRecord as toRecord, toRuntimeError } from './runner-helpers';
import { buildExecutionWorkflow } from './public-context';
import { emitPreviewLogLine, emitPreviewLogs, emitPreviewState } from '../logging/preview-events';
import { formatVariableFailureMessage, resolveNodeRuntimeVariables } from './variable-manager';
import { validateWorkflowConnectionCompatibility } from './port-compatibility';
import { createPreviewLogInterceptor } from '../logging/preview-log-interceptor';

export interface WorkflowStepRunnerContext {
    mode: WorkflowExecutorMode;
    adapters: WorkflowExecutorAdapters;
}

const isDesignerPreviewMode = (overrides: ExecuteNodeStepOptions['overrides']): boolean => overrides?.previewMode === 'designer';

const resolveEffectivePreviewRuntime = (
    mode: WorkflowExecutorMode,
    overrides: ExecuteNodeStepOptions['overrides']
): 'node' | 'browser' => {
    if (overrides?.previewRuntime === 'node') return 'node';
    if (overrides?.previewRuntime === 'browser') return 'browser';
    return mode === 'server' ? 'node' : 'browser';
};

const toPreviewInputContext = (overrides: ExecuteNodeStepOptions['overrides']): Record<string, Record<string, unknown>> | null => {
    const previewInput = overrides?.previewInput;
    if (!previewInput || typeof previewInput !== 'object' || Array.isArray(previewInput)) {
        return null;
    }
    return {
        input: {
            preview_input: previewInput as Record<string, unknown>
        }
    };
};

const mergeHostContext = (
    baseHostContext: unknown,
    overrides: ExecuteNodeStepOptions['overrides']
): unknown => {
    if (!isDesignerPreviewMode(overrides) || !overrides?.sourceFiles) {
        return baseHostContext;
    }
    const existing = toRecord(baseHostContext);
    return {
        ...existing,
        __workflowPreview: {
            ...(toRecord(existing.__workflowPreview) ?? {}),
            sourceFiles: {
                ...(toRecord((existing as Record<string, unknown>).__workflowPreview)?.sourceFiles ?? {}),
                ...(overrides.sourceFiles ?? {})
            },
            previewRuntime: overrides.previewRuntime ?? 'auto',
            previewMode: 'designer'
        }
    };
};

const toPreviewValidation = (result: WorkflowNodeHandlerResult): WorkflowPreviewValidationSummary | undefined => {
    const value = (result as { previewValidation?: unknown }).previewValidation;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
    const record = value as Record<string, unknown>;
    const warnings = Array.isArray(record.warnings) ? record.warnings.map((entry) => String(entry)) : [];
    const errors = Array.isArray(record.errors) ? record.errors.map((entry) => String(entry)) : [];
    const normalizedRuntime = record.normalizedRuntime && typeof record.normalizedRuntime === 'object' && !Array.isArray(record.normalizedRuntime)
        ? (record.normalizedRuntime as Record<string, unknown>)
        : undefined;
    return {
        ok: record.ok !== false,
        warnings,
        errors,
        normalizedRuntime
    };
};

/** Purpose: executes a single workflow node with upstream ports context and returns updated canonical workflow state. */
export const executeNodeStepWithContext = async (runtime: WorkflowStepRunnerContext, options: ExecuteNodeStepOptions): Promise<WorkflowStepExecutorResult> => {
    const runId = createRunId('step');
    let workingWorkflow: WorkflowDefinition = buildExecutionWorkflow(options.workflow, options.settings, options.workflowInput);

    const { events, sink } = createEventCollector(options);
    const outputsByNode = new Map<string, Record<string, unknown>>();
    workingWorkflow.nodes.forEach((item) => outputsByNode.set(item.id, toPortsOut(item)));
    const executionStack = new Set<string>();

    const compatibilityViolations = validateWorkflowConnectionCompatibility(workingWorkflow);
    if (compatibilityViolations.length > 0) {
        const details = compatibilityViolations.map((item) => item.message).join(' ');
        const message = `Workflow has incompatible connection(s): ${details}`;
        const targetNode = workingWorkflow.nodes.find((item) => item.id === options.nodeId);
        if (!targetNode) {
            throw new Error(`Node "${options.nodeId}" not found for step execution.`);
        }
        const failedNode = publishBiControlState(workingWorkflow, buildFailedNodeState(targetNode, message));
        workingWorkflow = replaceNodeById(workingWorkflow, failedNode);
        emitNodeFailed(sink, options.workflow.metadata.id, runId, options.nodeId, message);
        emitNodeLogs(sink, options.workflow.metadata.id, runId, options.nodeId, [message]);
        return {
            workflow: workingWorkflow,
            node: failedNode,
            result: { output: { error: message, connectionViolations: compatibilityViolations }, status: WorkflowNodeStatusEnum.Failed, logs: [message] },
            events
        };
    }

    /** Purpose: recursively executes one node (and optionally connected nodes) while guarding against cycles in step mode. */
    const executeNodeById = async (targetNodeId: string, overrideInput?: Record<string, Record<string, unknown>>, nestedOverrides?: ExecuteNodeStepOptions['overrides']): Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }> => {
        if (executionStack.has(targetNodeId)) throw new Error(`Circular node invocation detected for "${targetNodeId}".`);
        const node = workingWorkflow.nodes.find((item) => item.id === targetNodeId);
        if (!node) throw new Error(`Node "${targetNodeId}" not found for step execution.`);
        if (!isNodeEnabled(node)) {
            const disabledNode = publishBiControlState(workingWorkflow, { ...node, status: WorkflowNodeStatusEnum.Stopped, runtime: { ...(node.runtime ?? {}), status: WorkflowNodeStatusEnum.Stopped } });
            workingWorkflow = replaceNodeById(workingWorkflow, disabledNode);
            return { node: disabledNode, result: { output: toPortsOut(node).output ?? null, status: WorkflowNodeStatusEnum.Stopped, logs: ['Node is disabled.'] } };
        }

        executionStack.add(targetNodeId);
        const runtimeOverrides = targetNodeId === options.nodeId ? options.overrides : nestedOverrides;
        const isPreviewTargetNode = targetNodeId === options.nodeId && isDesignerPreviewMode(runtimeOverrides);
        const previewRuntime = isPreviewTargetNode ? resolveEffectivePreviewRuntime(runtime.mode, runtimeOverrides) : undefined;
        const runningNode = publishBiControlState(
            workingWorkflow,
            buildRunningNodeState(node, { runtime: { ...(node.runtime ?? {}), ...(runtimeOverrides?.runtime ?? {}), ...(runtimeOverrides?.properties ?? {}) } })
        );
        workingWorkflow = replaceNodeById(workingWorkflow, runningNode);
        const previewInputContext = isPreviewTargetNode ? toPreviewInputContext(runtimeOverrides) : null;
        const input = overrideInput ?? previewInputContext ?? buildNodeInputContext(workingWorkflow, targetNodeId, outputsByNode, toPortsIn(runningNode));
        emitNodeStarted(sink, options.workflow.metadata.id, runId, runningNode);
        if (isPreviewTargetNode) {
            emitPreviewState({
                options,
                runId,
                nodeId: targetNodeId,
                state: 'starting',
                runtime: previewRuntime,
                startedAt: new Date().toISOString(),
                message: 'Preview execution started.'
            });
            emitPreviewLogLine({
                options,
                runId,
                nodeId: targetNodeId,
                source: 'runtime',
                runtime: previewRuntime,
                line: `Preview started using ${previewRuntime} runtime.`
            });
        }
        const startedAtMs = performance.now();
        const retryLimit = resolveFailureRetryLimit(runningNode);
        const retryAttemptLogs: string[] = [];
        const canRunLocally = options.isNodeLocalCapable ? options.isNodeLocalCapable(runningNode.modelId) : true;
        const variableResolution = resolveNodeRuntimeVariables(workingWorkflow, runningNode, input, options.settings);
        if (!variableResolution.ok) {
            const message = formatVariableFailureMessage(variableResolution.failures, runningNode.name);
            const failedNode = publishBiControlState(workingWorkflow, buildFailedNodeState(runningNode, message));
            workingWorkflow = replaceNodeById(workingWorkflow, failedNode);
            outputsByNode.set(runningNode.id, toPortsOut(failedNode));
            emitNodeFailed(sink, options.workflow.metadata.id, runId, targetNodeId, message);
            emitNodeLogs(sink, options.workflow.metadata.id, runId, targetNodeId, [message]);
            if (isPreviewTargetNode) {
                emitPreviewLogLine({
                    options,
                    runId,
                    nodeId: targetNodeId,
                    source: 'runtime',
                    runtime: previewRuntime,
                    line: message
                });
                emitPreviewState({
                    options,
                    runId,
                    nodeId: targetNodeId,
                    state: 'failed',
                    runtime: previewRuntime,
                    durationMs: Number((performance.now() - startedAtMs).toFixed(2)),
                    message
                });
            }
            return {
                node: failedNode,
                result: {
                    output: { error: message, variableFailures: variableResolution.failures },
                    status: WorkflowNodeStatusEnum.Failed,
                    logs: [message]
                }
            };
        }
        const executableNode: WorkflowNodeModel = {
            ...runningNode,
            runtime: { ...(runningNode.runtime ?? {}), ...variableResolution.runtime }
        };
        if (isPreviewTargetNode) {
            emitPreviewState({
                options,
                runId,
                nodeId: targetNodeId,
                state: 'running',
                runtime: previewRuntime,
                startedAt: new Date().toISOString(),
                message: 'Preview node execution running.'
            });
        }

        try {
            if (!canRunLocally && !options.executeNodeRemotely) throw new Error(`Node model "${runningNode.modelId}" requires server execution in "${runtime.mode}" mode.`);

            for (let attemptNumber = 1; attemptNumber <= retryLimit + 1; attemptNumber += 1) {
                if (!canRunLocally && options.executeNodeRemotely) {
                    const resolvedWorkflow = replaceNodeById(workingWorkflow, executableNode);
                    const remoteExecution = await options.executeNodeRemotely({ workflow: resolvedWorkflow, nodeId: runningNode.id, settings: options.settings, overrides: runtimeOverrides, hostContext: options.hostContext });
                    workingWorkflow = remoteExecution.workflow;
                    (remoteExecution.events ?? []).forEach(options.onEvent ?? (() => undefined));
                    const status = resolveResultStatus(remoteExecution.result, remoteExecution.node.status as WorkflowNodeStatusEnum);
                    const remotePreviewValidation = toPreviewValidation(remoteExecution.result);
                    const remoteNode = publishBiControlState(workingWorkflow, normalizeNodeStatus(remoteExecution.node, status));
                    workingWorkflow = replaceNodeById(workingWorkflow, remoteNode);
                    outputsByNode.set(runningNode.id, toPortsOut(remoteNode));

                    if (status === WorkflowNodeStatusEnum.Failed) {
                        const message = resolveFailureMessageFromResult(remoteExecution.result, toRuntimeError(remoteNode) ?? 'Step execution failed.');
                        const terminalAttemptLogs = [...(remoteExecution.result.logs ?? [])];
                        if (attemptNumber <= retryLimit) {
                            const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                            const iterationLogs = [...terminalAttemptLogs, retryLog];
                            retryAttemptLogs.push(...iterationLogs);
                            emitNodeLogs(sink, options.workflow.metadata.id, runId, runningNode.id, iterationLogs);
                            continue;
                        }

                        const failedNode = publishBiControlState(workingWorkflow, buildFailedNodeState(remoteNode, message));
                        workingWorkflow = replaceNodeById(workingWorkflow, failedNode);
                        outputsByNode.set(runningNode.id, toPortsOut(failedNode));
                        emitNodeFailed(sink, options.workflow.metadata.id, runId, targetNodeId, message);
                        const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                        emitNodeLogs(sink, options.workflow.metadata.id, runId, targetNodeId, terminalLogs);
                        if (isPreviewTargetNode) {
                            emitPreviewLogs({
                                options,
                                runId,
                                nodeId: targetNodeId,
                                source: 'worker',
                                runtime: previewRuntime,
                                lines: terminalLogs
                            });
                            emitPreviewState({
                                options,
                                runId,
                                nodeId: targetNodeId,
                                state: 'failed',
                                runtime: previewRuntime,
                                durationMs: Number((performance.now() - startedAtMs).toFixed(2)),
                                message,
                                validation: remotePreviewValidation
                            });
                        }
                        return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs: [...retryAttemptLogs, ...terminalLogs] } };
                    }

                    const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                    const terminalLogs = remoteExecution.result.logs ?? [];
                    emitNodeFinished(sink, options.workflow.metadata.id, runId, runningNode.id, remoteNode.status, durationMs, terminalLogs);
                    if (isPreviewTargetNode) {
                        emitPreviewLogs({
                            options,
                            runId,
                            nodeId: targetNodeId,
                            source: 'worker',
                            runtime: previewRuntime,
                            lines: terminalLogs
                        });
                        emitPreviewState({
                            options,
                            runId,
                            nodeId: targetNodeId,
                            state: 'passed',
                            runtime: previewRuntime,
                            durationMs,
                            message: 'Preview execution finished.',
                            validation: remotePreviewValidation
                        });
                    }
                    return { node: remoteNode, result: { ...remoteExecution.result, status: remoteNode.status, logs: [...retryAttemptLogs, ...terminalLogs] } };
                }

                const handler = runtime.adapters.getNodeHandler(executableNode.modelId);
                const previewLogInterceptor = isPreviewTargetNode && previewRuntime
                    ? createPreviewLogInterceptor({
                          runtime: previewRuntime,
                          emitLine: (source, line, stream) =>
                              emitPreviewLogLine({
                                  options,
                                  runId,
                                  nodeId: targetNodeId,
                                  source,
                                  runtime: previewRuntime,
                                  line,
                                  stream
                              })
                      })
                    : null;
                let result: WorkflowNodeHandlerResult;
                try {
                    result = await handler({
                        node: { ...executableNode, ports: { ...executableNode.ports, in: input } },
                        workflow: workingWorkflow,
                        settings: options.settings,
                        input,
                        signal: options.signal,
                        hostContext: mergeHostContext(options.hostContext, runtimeOverrides),
                        invokeConnectedNode: async ({ nodeId, input: connectedInput, overrides }) => executeNodeById(nodeId, connectedInput, overrides)
                    });
                } finally {
                    previewLogInterceptor?.flush();
                    previewLogInterceptor?.restore();
                }
                const previewValidation = toPreviewValidation(result);
                const status = resolveResultStatus(result);
                if (status === WorkflowNodeStatusEnum.Failed) {
                    const message = resolveFailureMessageFromResult(result, 'Step execution failed.');
                    const terminalAttemptLogs = [...(result.logs ?? [])];
                    if (attemptNumber <= retryLimit) {
                        const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                        const iterationLogs = [...terminalAttemptLogs, retryLog];
                        retryAttemptLogs.push(...iterationLogs);
                        emitNodeLogs(sink, options.workflow.metadata.id, runId, targetNodeId, iterationLogs);
                        continue;
                    }

                    const failedNode = publishBiControlState(workingWorkflow, buildFailedNodeState(runningNode, message));
                    workingWorkflow = replaceNodeById(workingWorkflow, failedNode);
                    outputsByNode.set(runningNode.id, toPortsOut(failedNode));
                    emitNodeFailed(sink, options.workflow.metadata.id, runId, targetNodeId, message);
                    const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                    emitNodeLogs(sink, options.workflow.metadata.id, runId, targetNodeId, terminalLogs);
                    if (isPreviewTargetNode) {
                        emitPreviewLogs({
                            options,
                            runId,
                            nodeId: targetNodeId,
                            source: 'worker',
                            runtime: previewRuntime,
                            lines: terminalLogs
                        });
                        emitPreviewState({
                            options,
                            runId,
                            nodeId: targetNodeId,
                            state: 'failed',
                            runtime: previewRuntime,
                            durationMs: Number((performance.now() - startedAtMs).toFixed(2)),
                            message,
                            validation: previewValidation
                        });
                    }
                    return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs: [...retryAttemptLogs, ...terminalLogs] } };
                }

                const normalizedResult = { ...result, status: status as WorkflowNodeStatusEnum };
                const completedNode = publishBiControlState(workingWorkflow, buildCompletedNodeState(runningNode, input, normalizedResult));
                workingWorkflow = replaceNodeById(workingWorkflow, completedNode);
                outputsByNode.set(runningNode.id, toPortsOut(completedNode));
                const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                const terminalLogs = result.logs ?? [];
                emitNodeFinished(sink, options.workflow.metadata.id, runId, targetNodeId, completedNode.status, durationMs, terminalLogs);
                if (isPreviewTargetNode) {
                    emitPreviewLogs({
                        options,
                        runId,
                        nodeId: targetNodeId,
                        source: 'worker',
                        runtime: previewRuntime,
                        lines: terminalLogs
                    });
                    emitPreviewState({
                        options,
                        runId,
                        nodeId: targetNodeId,
                        state: 'passed',
                        runtime: previewRuntime,
                        durationMs,
                        message: 'Preview execution finished.',
                        validation: previewValidation
                    });
                }
                return { node: completedNode, result: { ...normalizedResult, logs: [...retryAttemptLogs, ...terminalLogs] } };
            }

            throw new Error('Failure mitigation loop exited unexpectedly.');
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Step execution failed.';
            const failedNode = publishBiControlState(workingWorkflow, buildFailedNodeState(runningNode, message));
            workingWorkflow = replaceNodeById(workingWorkflow, failedNode);
            outputsByNode.set(runningNode.id, toPortsOut(failedNode));
            emitNodeFailed(sink, options.workflow.metadata.id, runId, targetNodeId, message);
            emitNodeLogs(sink, options.workflow.metadata.id, runId, targetNodeId, [message]);
            if (isPreviewTargetNode) {
                emitPreviewLogLine({
                    options,
                    runId,
                    nodeId: targetNodeId,
                    source: 'stderr',
                    runtime: previewRuntime,
                    line: message
                });
                emitPreviewState({
                    options,
                    runId,
                    nodeId: targetNodeId,
                    state: options.signal?.aborted ? 'cancelled' : 'failed',
                    runtime: previewRuntime,
                    durationMs: Number((performance.now() - startedAtMs).toFixed(2)),
                    message
                });
            }
            return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs: [...retryAttemptLogs, message] } };
        } finally {
            executionStack.delete(targetNodeId);
        }
    };

    const outcome = await executeNodeById(options.nodeId);
    if (outcome.node.status !== WorkflowNodeStatusEnum.Failed && !outcome.result.skipCommandPeerAutoRun) {
        const peerNodeIds = getBiPeerNodeIds(workingWorkflow, options.nodeId);
        for (const peerNodeId of peerNodeIds) {
            await executeNodeById(peerNodeId);
        }
    }
    return { workflow: workingWorkflow, node: outcome.node, result: outcome.result, events };
};
