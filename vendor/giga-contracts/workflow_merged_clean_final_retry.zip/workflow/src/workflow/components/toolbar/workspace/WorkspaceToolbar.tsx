import React, { useRef } from 'react';
import { Menu } from 'primereact/menu';
import { Tooltip } from 'primereact/tooltip';
import type { MenuItem } from 'primereact/menuitem';
import { WorkflowPlayLifecycleEnum, WorkflowPlayModeEnum } from '@workflow/ui/workflow/types';
import type { ToolbarProps } from '@workflow/ui/workflow/components/toolbar/toolbar.types';
import { WorkspaceToolbarButton } from '@workflow/ui/workflow/components/toolbar/workspace/WorkspaceToolbarButton';
import { WorkspaceToolbarCluster } from '@workflow/ui/workflow/components/toolbar/workspace/WorkspaceToolbarCluster';
import { readFileAsText, resolveWorkflowToolbarEditedLabel, resolveWorkflowToolbarStatus } from '@workflow/ui/workflow/components/toolbar/workspace/workspace-toolbar.utils';
import '@workflow/ui/workflow/components/toolbar/workspace/wf-workspace-toolbar.scss';

interface ToolbarMenuItemOptions {
    onClick: (event: React.SyntheticEvent) => void;
    onKeyDown?: (event: React.KeyboardEvent) => void;
    className: string;
    labelClassName: string;
    iconClassName: string;
    tabIndex?: number | null;
}

const renderToolbarMenuItem = (dataCy: string) => (item: MenuItem, options: ToolbarMenuItemOptions) => (
    <a href="#" role="menuitem" className={options.className} onClick={options.onClick} onKeyDown={options.onKeyDown} tabIndex={options.tabIndex ?? undefined} data-cy={dataCy}>
        {item.icon ? <span className={`${options.iconClassName} ${item.icon}`} aria-hidden /> : null}
        <span className={options.labelClassName}>{item.label}</span>
    </a>
);

const WorkspaceToolbar: React.FC<ToolbarProps> = ({
    metadata,
    isPlaying,
    playMode,
    playLifecycle,
    canPlay,
    isEditable,
    isExecutionMode = false,
    canReplayExecution = false,
    onPlayLocal,
    onPlayServer,
    onStop,
    onExportWorkflowOnly,
    onExportWithData,
    onClear,
    onToggleEditable,
    onImportJson,
    onShowMetadata,
    onShowLogs,
    onShowSettings,
    onSaveDraft,
    saveDraftDisabled = false,
    saveDraftBusy = false,
    onPublish,
    publishDisabled = false,
    publishBusy = false,
    onOpenCatalogImport,
    catalogImportDisabled = false,
    onOpenAi,
    onClose
}) => {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const playMenuRef = useRef<Menu>(null);
    const exportMenuRef = useRef<Menu>(null);
    const moreMenuRef = useRef<Menu>(null);

    const playMenuItems: MenuItem[] = [
        { label: 'Play Local', icon: 'pi pi-desktop', command: onPlayLocal, template: renderToolbarMenuItem('workflow-play-local') },
        { label: 'Play Server', icon: 'pi pi-server', command: onPlayServer, template: renderToolbarMenuItem('workflow-play-server') }
    ];
    const exportMenuItems: MenuItem[] = [
        { label: 'Export Workflow Only', icon: 'pi pi-share-alt', command: onExportWorkflowOnly, template: renderToolbarMenuItem('workflow-export-only') },
        { label: 'Export With Data', icon: 'pi pi-database', command: onExportWithData, template: renderToolbarMenuItem('workflow-export-with-data') }
    ];
    const moreMenuItems: MenuItem[] = [
        { label: 'Import JSON', icon: 'pi pi-upload', command: () => fileInputRef.current?.click(), template: renderToolbarMenuItem('workflow-import-json') },
        { label: 'Export Workflow', icon: 'pi pi-download', command: (event) => exportMenuRef.current?.toggle(event.originalEvent), template: renderToolbarMenuItem('workflow-export-menu') },
        { label: 'View Metadata', icon: 'pi pi-info-circle', command: onShowMetadata, template: renderToolbarMenuItem('workflow-metadata-open') },
        { label: 'View Logs', icon: 'pi pi-database', command: onShowLogs, template: renderToolbarMenuItem('workflow-logs-open') },
        { label: 'Workflow Settings', icon: 'pi pi-cog', command: onShowSettings, template: renderToolbarMenuItem('workflow-settings-open') },
        ...(onOpenAi ? [{ label: 'Open Workflow AI', icon: 'pi pi-sparkles', command: () => onOpenAi(), template: renderToolbarMenuItem('workflow-ai-open') }] : []),
        { label: 'Clear Workflow', icon: 'pi pi-trash', command: onClear, template: renderToolbarMenuItem('workflow-clear') }
    ];

    const isStarting = playLifecycle === WorkflowPlayLifecycleEnum.Starting;
    const isStopping = playLifecycle === WorkflowPlayLifecycleEnum.Stopping;
    const playIcon = isStarting || isStopping ? 'pi pi-spin pi-spinner' : isPlaying ? 'pi pi-stop' : 'pi pi-play';
    const playLabel = isPlaying ? 'Stop workflow' : 'Run workflow';
    const executionPlayLabel = isPlaying ? 'Stop emulation' : 'Play snapshot';
    const statusLabel = resolveWorkflowToolbarStatus(metadata);
    const editedLabel = resolveWorkflowToolbarEditedLabel(metadata);
    const breadcrumb = 'Workflow / Runtime';

    return (
        <header className="wf-workspace-toolbar">
            <Tooltip target=".wf-workspace-toolbar__button[data-pr-tooltip]" position="bottom" showDelay={120} hideDelay={60} />
            <div className="wf-workspace-toolbar__identity">
                <div className="wf-workspace-toolbar__glyph"><i className="pi pi-th-large wf-workspace-toolbar__glyph-icon" aria-hidden /></div>
                <div>
                    <div className="wf-workspace-toolbar__breadcrumb">{breadcrumb}</div>
                    <div className="wf-workspace-toolbar__title-row">
                        <h1>{metadata?.name ?? 'Workflow Designer'}</h1>
                        <span className="wf-workspace-toolbar__status-pill">{statusLabel}</span>
                        <span className="wf-workspace-toolbar__edited-label">{editedLabel}</span>
                    </div>
                </div>
            </div>
            <div className="wf-workspace-toolbar__actions">
                {isExecutionMode ? (
                    <>
                        <WorkspaceToolbarButton icon="database" disabled={!metadata} onClick={onShowLogs} ariaLabel="View workflow logs" tooltip="View workflow logs" dataCy="workflow-logs-open" />
                        <WorkspaceToolbarButton icon="settings" disabled={!metadata} onClick={onShowSettings} ariaLabel="Workflow settings" tooltip="Workflow settings" dataCy="workflow-settings-open" />
                        {canReplayExecution ? (
                            <WorkspaceToolbarButton
                                icon={playIcon}
                                label={executionPlayLabel}
                                primary
                                disabled={!isPlaying && !canPlay}
                                onClick={() => {
                                    if (isPlaying) {
                                        onStop();
                                        return;
                                    }
                                    onPlayLocal();
                                }}
                                ariaLabel={executionPlayLabel}
                                tooltip={executionPlayLabel}
                                dataCy="workflow-execution-replay"
                            />
                        ) : null}
                        <WorkspaceToolbarButton icon="x" onClick={onClose} ariaLabel="Close designer" tooltip="Close designer" dataCy="workflow-designer-close" />
                    </>
                ) : (
                    <>
                    <WorkspaceToolbarCluster>
                        <WorkspaceToolbarButton icon={saveDraftBusy ? 'pi pi-spin pi-spinner' : 'pi pi-save'} disabled={!onSaveDraft || saveDraftDisabled} onClick={() => onSaveDraft?.()} ariaLabel="Save draft" tooltip="Save draft" dataCy="workflow-save-draft" />
                        <WorkspaceToolbarButton icon={publishBusy ? 'pi pi-spin pi-spinner' : 'pi pi-send'} disabled={!onPublish || publishDisabled} onClick={() => onPublish?.()} ariaLabel="Publish workflow" tooltip="Publish workflow" dataCy="workflow-publish" />
                        <WorkspaceToolbarButton icon="pi pi-folder-open" disabled={!onOpenCatalogImport || catalogImportDisabled} onClick={() => onOpenCatalogImport?.()} ariaLabel="Import from workflow catalog" tooltip="Import from workflow catalog" dataCy="workflow-import-catalog" />
                        <WorkspaceToolbarButton icon="pi pi-sitemap" active={isEditable} onClick={onToggleEditable} ariaLabel={isEditable ? 'Hide node library' : 'Show node library'} tooltip={isEditable ? 'Hide node library' : 'Show node library'} dataCy="workflow-node-library-toggle" />
                        <WorkspaceToolbarButton icon="pi pi-ellipsis-h" onClick={(event) => moreMenuRef.current?.toggle(event)} ariaLabel="More actions" tooltip="More actions" dataCy="workflow-more-actions" />
                    </WorkspaceToolbarCluster>
                    <WorkspaceToolbarButton icon="pi pi-times" onClick={onClose} ariaLabel="Close designer" tooltip="Close designer" dataCy="workflow-designer-close" />
                <WorkspaceToolbarButton
                    icon={playIcon}
                    label={playLabel}
                    primary
                    disabled={!isPlaying && !canPlay}
                    onClick={(event) => {
                        if (isPlaying) {
                            onStop();
                            return;
                        }
                        playMenuRef.current?.toggle(event);
                    }}
                    ariaLabel={playLabel}
                    tooltip={playLabel}
                    dataCy="workflow-run-menu"
                />
                <Menu popup ref={playMenuRef} model={playMenuItems} />
                <Menu popup ref={moreMenuRef} model={moreMenuItems} />
                <Menu popup ref={exportMenuRef} model={exportMenuItems} />
                <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/json,.json"
                    className="wf-workspace-toolbar__file-input"
                    data-cy="workflow-import-json-input"
                    onChange={async (event) => {
                        const file = event.target.files?.[0];
                        event.target.value = '';
                        if (!file) return;
                        try {
                            const rawJson = await readFileAsText(file);
                            onImportJson(rawJson);
                        } catch {
                            window.alert('Could not read workflow JSON.');
                        }
                    }}
                />
                    </>
                )}
            </div>
        </header>
    );
};

export default WorkspaceToolbar;
