import { afterEach, describe, expect, it, vi } from 'vitest';
import type { WorkflowQueueRequest } from '../queue/types';
import { createExecutor } from '../service/createExecutor';

const connect = vi.fn(async () => undefined);
const disconnect = vi.fn(async () => undefined);
const publish = vi.fn(async () => undefined);
const start = vi.fn(async () => undefined);

vi.mock('../pubsub', async () => {
  const actual = await vi.importActual<typeof import('../pubsub')>('../pubsub');
  return {
    ...actual,
    consumeWorkflowExecutionEvents: vi.fn(),
    queueWorkflowForExecution: vi.fn(() => ({ connect, disconnect, publish })),
    runWorkflowExecutionQueue: vi.fn(),
    startWorkflowExecutionPubsub: vi.fn(() => ({
      start,
      stop: vi.fn(async () => undefined),
      cancelRun: vi.fn(() => 0),
      cancelWorkflow: vi.fn(() => 0),
      getRunning: vi.fn(() => []),
    })),
  };
});

afterEach(() => {
  vi.clearAllMocks();
});

describe('createExecutor enqueue', () => {
  it('publishes the created execution request and exposes only enqueue', async () => {
    const workflow = { metadata: { id: 'workflow-1', name: 'Workflow 1' }, nodes: [], connections: [] };
    const executionRequest: WorkflowQueueRequest = {
      executionId: 'execution-1',
      runId: 'run-1',
      queueKey: 'user-1',
      userId: 'user-1',
      broadcastId: 'user-1',
      broadcastChannelName: 'workflow-socket',
      triggerType: 'chat',
      workflowReference: { workflowId: 'workflow-1', scope: 'user', ownerUserId: 'user-1' },
      workflowVersionId: null,
      workflow: workflow as any,
      settings: { graphqlUrl: 'http://localhost', authMode: 'auto-from-current-session' } as any,
      requestContext: { mode: 'user', userId: 'user-1', headers: {} },
      metadata: null,
    };
    const executor = createExecutor();

    executor.setup({
      executeBackend: {
        execute: vi.fn(async () => ({ events: [], stopped: false, workflow: workflow as any })),
        workflowExecutionQueue: {
          applyExecutionEvent: vi.fn(async () => undefined),
          createExecutionRequest: vi.fn(() => executionRequest),
          runExecutionRequest: vi.fn(async () => undefined),
        },
      },
    });

    const result = await executor.enqueue('user-1', { request: executionRequest }, workflow as any);

    expect(publish).toHaveBeenCalledWith(executionRequest);
    expect(result).toEqual({ executionId: 'execution-1', runId: 'run-1', status: 'queued', workflowId: 'workflow-1' });
    expect('enqueu' in executor).toBe(false);
  });
});
