import { Node, Position } from '@xyflow/react';
import { BaseNodeData, BaseNodePort } from '@workflow/ui/workflow/nodes/BaseNode';
import { getAllNodeSchemas, getNodeModuleById, resolveNodeSchema } from '@workflow/nodes/node-utils';
import { WorkflowDefinition, WorkflowNodeModel, WorkflowNodePortProperty, WorkflowNodeSchema, WorkflowNodeStatusEnum, WorkflowPlayModeEnum } from '@workflow/ui/workflow/types';
import { resolveIconRenderer } from '@workflow/ui/workflow/utils/workflow-icon-render.utils';
import { BI_DIRECTIONAL_PORT_TYPE, getNormalizedCommandPorts, isCommandConnection } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';
import { normalizePublicOutput } from '@workflow/ui/workflow/utils/workflow-public-context.utils';

export const DESIGNER_NODE_WIDTH = 236;
export const DESIGNER_NODE_HEIGHT = 248;

interface CanvasNodeActionHandlers {
    onRenameNode?: (nodeId: string, nextName: string) => void;
    onOpenInspector?: (nodeId: string) => void;
    onOpenAi?: (nodeId: string) => void;
    onExecuteStep?: (nodeId: string) => void;
    onToggleEnabled?: (nodeId: string, nextEnabled: boolean) => void;
    onDeleteNode?: (nodeId: string) => void;
    onQuickAddFromPort?: (payload: { nodeId: string; outputPortId: string; anchor: HTMLElement }) => void;
    readOnly?: boolean;
}

const buildBaseNodeCacheKey = (payload: Record<string, unknown>): string => JSON.stringify(payload);

const buildPorts = (ports: Record<string, WorkflowNodePortProperty>): BaseNodePort[] => {
    return Object.entries(ports).map(([name, rules]) => ({ id: name, name, rules }));
};

const getNodeModel = (node: WorkflowNodeModel, nodeModels: Record<string, WorkflowNodeSchema>): WorkflowNodeSchema => {
    return resolveNodeSchema(node.modelId, nodeModels);
};
const parseRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const parseIconMode = (value: unknown): 'prime' | 'svg' | undefined => (value === 'prime' || value === 'svg' ? value : undefined);

const resolveHash = (value: string): number => value.split('').reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0);

const buildDeterministicFallbackRender = (modelId: string | undefined): Required<Pick<BaseNodeData['render'], 'iconClass' | 'iconColor' | 'iconBackground'>> => {
    const key = (modelId ?? 'node').trim() || 'node';
    const hash = Math.abs(resolveHash(key));
    const hue = hash % 360;
    return {
        iconClass: 'pi pi-box',
        iconColor: `hsl(${hue} 70% 28%)`,
        iconBackground: `hsl(${hue} 95% 92%)`
    };
};

const createFallbackIconRenderer = (modelId: string | undefined): ((size: number) => string) => {
    const text =
        (modelId ?? 'N')
            .replace(/[^a-z0-9]/gi, '')
            .slice(0, 2)
            .toUpperCase() || 'N';
    return (size: number) => `
<svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" aria-hidden="true">
  <rect x="5" y="5" width="38" height="38" rx="9" stroke="currentColor" stroke-width="2.6"/>
  <text x="24" y="30" text-anchor="middle" font-size="16" font-weight="700" fill="currentColor">${text}</text>
</svg>`;
};

const parseOutputPortName = (handleId: string | undefined, fallbackPort: string): string => {
    if (!handleId) return fallbackPort;
    const [, parsedPort] = handleId.split(':');
    return parsedPort?.trim() ? parsedPort : fallbackPort;
};

const parseInputPortName = (handleId: string | undefined, fallbackPort: string): string => {
    if (!handleId) return fallbackPort;
    const [, parsedPort] = handleId.split(':');
    return parsedPort?.trim() ? parsedPort : fallbackPort;
};

const buildOutputConnectionCount = (workflowState: WorkflowDefinition, node: WorkflowNodeModel, model: WorkflowNodeSchema): Record<string, number> => {
    const outputPorts = Object.keys(model.outputs);
    const fallbackPort = outputPorts[0] ?? 'output';
    return workflowState.connections.reduce<Record<string, number>>((acc, connection) => {
        if (connection.from !== node.id) return acc;
        const outputPortId = parseOutputPortName(connection.sourceHandle, fallbackPort);
        acc[outputPortId] = (acc[outputPortId] ?? 0) + 1;
        return acc;
    }, {});
};

export const buildInspectorInputContext = (workflowState: WorkflowDefinition | null, nodeId: string, fallbackInput: Record<string, unknown>): Record<string, unknown> => {
    if (!workflowState) return fallbackInput;
    const nodeById = new Map(workflowState.nodes.map((node) => [node.id, node]));
    const incoming = workflowState.connections.filter((connection) => connection.to === nodeId && !isCommandConnection(workflowState, connection));
    if (!incoming.length) return fallbackInput;
    const nextInput = incoming.reduce<Record<string, unknown>>((acc, connection) => {
        const sourceNode = nodeById.get(connection.from);
        if (!sourceNode) return acc;
        const portsOut = parseRecord(sourceNode.ports?.out);
        acc[sourceNode.id] = normalizePublicOutput(Object.prototype.hasOwnProperty.call(portsOut, 'output') ? portsOut.output : sourceNode.output);
        return acc;
    }, {});
    if (Object.keys(nextInput).length > 0) return nextInput;
    return fallbackInput;
};

export const buildCanvasNodes = (workflowState: WorkflowDefinition | null, orderedNodeIds: string[], activeIndex: number, isPlaying: boolean, playMode: WorkflowPlayModeEnum, handlers: CanvasNodeActionHandlers = {}): Node<BaseNodeData>[] => {
    if (!workflowState) return [];
    const activeNodeId = activeIndex >= 0 ? orderedNodeIds[activeIndex] ?? null : null;
    const executionOrderIndex = new Map<string, number>();
    orderedNodeIds.forEach((id, index) => {
        if (!executionOrderIndex.has(id)) {
            executionOrderIndex.set(id, index);
        }
    });
    const activeOrderIndex = activeNodeId ? executionOrderIndex.get(activeNodeId) ?? activeIndex : -1;
    const schemas = workflowState.nodeModels ?? getAllNodeSchemas();
    return workflowState.nodes.map((node, index) => {
        const localNodeModule = getNodeModuleById(node.modelId);
        const workflowModel = node.modelId ? schemas[node.modelId] : undefined;
        const model = getNodeModel(node, schemas);
        const commands = getNormalizedCommandPorts(model);
        const filteredInputs = Object.fromEntries(Object.entries(model.inputs).filter(([portId, rules]) => rules.portType !== BI_DIRECTIONAL_PORT_TYPE && !commands[portId]));
        const filteredOutputs = Object.fromEntries(Object.entries(model.outputs).filter(([portId, rules]) => rules.portType !== BI_DIRECTIONAL_PORT_TYPE && !commands[portId]));
        const fallbackRender = buildDeterministicFallbackRender(node.modelId);
        const outputConnectionCounts = buildOutputConnectionCount(workflowState, node, model);
        const isEnabled = parseRecord(node.runtime).enabled !== false;
        const nodeOrderIndex = executionOrderIndex.get(node.id) ?? index;
        const isNodeActive = Boolean(activeNodeId && node.id === activeNodeId);
        const isNodeRunning = node.status === WorkflowNodeStatusEnum.Running;
        const shouldShowProgress = isPlaying && (playMode === WorkflowPlayModeEnum.Server ? isNodeActive : isNodeActive || isNodeRunning);
        const resolvedIconSvg = node.render?.iconSvg ?? workflowModel?.render?.iconSvg ?? model.render?.iconSvg ?? (typeof model.iconSvg === 'string' ? model.iconSvg : undefined);
        const resolvedIconMode =
            node.render?.iconMode ??
            workflowModel?.render?.iconMode ??
            model.render?.iconMode ??
            parseIconMode(node.render?.iconMode ?? workflowModel?.iconMode ?? model.iconMode) ??
            (typeof resolvedIconSvg === 'string' && resolvedIconSvg.trim() ? 'svg' : 'prime');
        const resolvedIconClass = node.render?.iconClass ?? workflowModel?.render?.iconClass ?? model.render?.iconClass ?? model.iconClass ?? fallbackRender.iconClass;
        const renderConfig = {
            ...fallbackRender,
            ...(localNodeModule?.schema.render ?? {}),
            ...(workflowModel?.render ?? {}),
            ...(model.render ?? {}),
            ...(node.render ?? {}),
            iconClass: resolvedIconClass,
            iconKey: node.render?.iconKey ?? workflowModel?.render?.iconKey ?? model.render?.iconKey ?? node.modelId,
            iconMode: resolvedIconMode,
            iconSvg: resolvedIconSvg,
            iconColor: node.render?.iconColor ?? workflowModel?.render?.iconColor ?? model.render?.iconColor ?? fallbackRender.iconColor,
            iconBackground: node.render?.iconBackground ?? workflowModel?.render?.iconBackground ?? model.render?.iconBackground ?? fallbackRender.iconBackground
        };
        const inputPorts = buildPorts(filteredInputs);
        const outputPorts = buildPorts(filteredOutputs);
        const commandPorts = buildPorts(commands);
        const cacheKey = buildBaseNodeCacheKey({
            nodeId: node.id,
            title: node.name,
            nodeTypeLabel: model.documentation?.nodeTypeLabel ?? localNodeModule?.library.label ?? node.modelId,
            kind: node.kind,
            status: node.status,
            isActive: isNodeActive,
            isCompleted: activeOrderIndex >= 0 && nodeOrderIndex >= 0 && nodeOrderIndex < activeOrderIndex,
            isLoading: shouldShowProgress,
            progressIndicatorMode: shouldShowProgress ? (playMode === WorkflowPlayModeEnum.Server ? 'server' : 'local') : null,
            nameEditable: model.name.editable,
            isEnabled,
            outputConnectionCounts,
            render: renderConfig,
            inputs: inputPorts.map((port) => ({ id: port.id, name: port.name, rules: port.rules })),
            outputs: outputPorts.map((port) => ({ id: port.id, name: port.name, rules: port.rules })),
                commands: commandPorts.map((port) => ({ id: port.id, name: port.name, rules: port.rules }))
        });
        return {
            id: node.id,
            type: node.type ?? 'workflowStep',
            position: node.position,
            sourcePosition: Position.Right,
            targetPosition: Position.Left,
            data: {
                nodeId: node.id,
                cacheKey,
                title: node.name,
                nodeTypeLabel: model.documentation?.nodeTypeLabel ?? localNodeModule?.library.label ?? node.modelId,
                kind: node.kind,
                status: node.status,
                isActive: isNodeActive,
                isCompleted: activeOrderIndex >= 0 && nodeOrderIndex >= 0 && nodeOrderIndex < activeOrderIndex,
                isLoading: shouldShowProgress,
                progressIndicatorMode: shouldShowProgress ? (playMode === WorkflowPlayModeEnum.Server ? 'server' : 'local') : null,
                nameEditable: model.name.editable,
                isEnabled,
                outputConnectionCounts,
                render: renderConfig,
                renderIcon: resolveIconRenderer(
                    {
                        ...(localNodeModule?.schema.render ?? {}),
                        ...(workflowModel?.render ?? {}),
                        ...(model.render ?? {}),
                        ...(node.render ?? {}),
                        iconClass: resolvedIconClass,
                        iconMode: resolvedIconMode,
                        iconSvg: resolvedIconSvg
                    },
                    localNodeModule?.renderIcon ?? createFallbackIconRenderer(node.modelId)
                ),
                inputs: inputPorts,
                outputs: outputPorts,
                commands: commandPorts,
                readOnly: handlers.readOnly === true,
                onRename: handlers.onRenameNode,
                onOpenInspector: handlers.onOpenInspector,
                onOpenAi: handlers.readOnly ? undefined : handlers.onOpenAi,
                onExecuteStep: handlers.readOnly ? undefined : handlers.onExecuteStep,
                onToggleEnabled: handlers.readOnly ? undefined : handlers.onToggleEnabled,
                onDeleteNode: handlers.readOnly ? undefined : handlers.onDeleteNode,
                onQuickAddFromPort: handlers.readOnly ? undefined : handlers.onQuickAddFromPort
            }
        };
    });
};
