# Giga AI merge update — clean + May 14 final + May 15 retry

Baseline: clean zips were treated as the stable deployed branch. The May 14 final branch was overlaid first, then the May 15 retry bundle was overlaid and resolved against the clean baseline.

## Implemented

### AI Agent ingestion
- Added backend GraphQL mutations for ingestion mode updates, rebuilds, and file removal:
  - `updateAiAgentIngestion`
  - `rebuildAiAgentIngestion`
  - `deleteAiAgentFile`
- Extended `AgentFileShape` fields so the UI can render mode, strategy, progress, analytics, summaries, storage and search metadata.
- Added an ingestion files table in the AI Agent editor with:
  - Multi-select rows.
  - Multi-select ingestion mode dropdown with icons.
  - Progress bar column.
  - Bulk apply/rebuild/remove actions.
- Kept the agent ingestion backend functional by wiring the existing ingestion service instead of stubbing new operations.

### Faster default chat / real agent runtime
- Added OpenAI Agents SDK import memoization and reusable sandbox client setup in `openai-agents-sdk.ts`.
- Preserved the existing fast default chat path for default replies while keeping real agent execution for selected AI Agent/Workflow/Swarm modes.
- Normalized chat assistant outputs so JSON-shaped responses and string responses render as clean user-facing messages.

### Slash commands, tree, workflow, and confirmation chain
- Routed slash commands through GraphQL `executeSlashCommand` instead of sending them as regular socket chat text.
- Fixed `/workflow list`, `/workflow running`, `/workflow logs`, `/workflow live`, `/workflow run`, `/workflow publish`, `/workflow debug`, `/node ...`, `/tree`, `/channel`, `/categories`, and `/chart` entry points.
- Added typo recovery for `/worflow` -> `/workflow`.
- Added `confirmed` and `confirmationId` to slash command execution input.
- Wired `InlineConfirmation` back into Unified Chat so confirmation-required slash results can be confirmed/cancelled from the UI kit.

### Agent Projects source archives and DB migration
- Added source archive columns to `AIAgentProjectEntity`:
  - `source_archive_bucket`
  - `source_archive_path`
  - `source_archive_sha256`
  - `source_archive_bytes`
  - `source_archive_encoding`
  - `source_archive_base64`
- Added migration script:
  - `giga-ai-backend/sql/20260515_ai_agent_project_source_archives.sql`
- The backend now creates DEFLATE level 9 zip archives with:
  - `giga-project-source.json`
  - `database/manifest.json`
  - `database/migrations.json`
  - project files
- The archive is uploaded to Supabase Storage bucket `ai-agent-project-sources` and mirrored as base64 in DB so local-to-dev deploys retain sources.
- The project editor shows a skeleton with “Downloading the sources…” while loading.
- The frontend can restore files from `sourceArchiveBase64` using JSZip when project file rows are not present.

### Agent Projects build/run/deploy APIs
- Added backend GraphQL contract/resolvers for AI Agent Projects:
  - list/load/create/update/delete
  - read/write/create-folder/delete-file
  - database query/alter
  - build/run/deploy
  - external database verify/database viewer launch
- Reworked `AIAgentProjects` to use real project data instead of generic application loaders.
- Reworked `AIAgentProjectEditor` to use real project create/update/file/build/run/deploy APIs.
- Added UI Build and Run buttons with log entries and runtime process IDs.

### Agent Output Designer, charts, and Excel viewer
- Upgraded Agent Output Viewer into an editable Agent Output Designer in the AI Agent editor.
- `AgentOutputPreview` now supports:
  - `[chart]...[/chart]`
  - `[charts]...[/charts]`
  - `[[chart:id]]`
  - `[excel]...[/excel]`
  - `[[excel:sheet]]`
  - Mermaid blocks
- Replaced plain table rendering with an Excel-style viewer that includes sheet tabs, row numbers, column letters, sticky headers, and row/column counts.
- Chat markdown now renders through the same output preview path so workflow-node chart markdown works in chat.

### Access layer / signed permission matrix
- Frontend now forwards compact `X-Giga-Permission-Matrix`, `X-Giga-Permission-Scope`, and `X-Giga-Organization-Id` headers with GraphQL calls.
- Backend ORM access now verifies permissions from the signed app access token permission matrix first.
- If the matrix header is present, backend compares it against the signed token policy before trusting it.
- Backend only falls back to cached permission reads when the signed matrix is absent.
- CRUD+Execute actions are mapped across the supported modules, including AI Agent Projects, AI Agents, Chat, Tree, Workflows, and Nodes.
- AI Agent Project service scopes records by organization/user and rejects cross-user/cross-organization project access.

## Validation performed

The following syntax/bundling checks were run with esbuild using package imports externalized:

```bash
# UI
npx --yes esbuild@0.28.0 src/app/screens/AIAgentProjectEditor.tsx --bundle --platform=browser --format=esm --packages=external
npx --yes esbuild@0.28.0 src/app/screens/AIAgentEditor.tsx --bundle --platform=browser --format=esm --packages=external
npx --yes esbuild@0.28.0 src/dataloaders/chat.loader.ts --bundle --platform=browser --format=esm --packages=external
npx --yes esbuild@0.28.0 src/orm/agent-projects.ts --bundle --platform=browser --format=esm --packages=external
npx --yes esbuild@0.28.0 src/dataloaders/agent-projects.loader.ts --bundle --platform=browser --format=esm --packages=external

# Backend
npx --yes esbuild@0.28.0 packages/apps/ai-agents/src/services/ai-agents/projects/agent-project-service.ts --bundle --platform=node --format=cjs --packages=external
npx --yes esbuild@0.28.0 packages/apps/ai-agents/src/services/ai-agents/runtime/openai-agents-sdk.ts --bundle --platform=node --format=cjs --packages=external
npx --yes esbuild@0.28.0 packages/apps/orm-access/src/services/graphql/entity/integration/ai-agent-project-resolvers.ts --bundle --platform=node --format=cjs --packages=external
npx --yes esbuild@0.28.0 packages/apps/orm-access/src/services/graphql/entity-request-context.ts --bundle --platform=node --format=cjs --packages=external
npx --yes esbuild@0.28.0 packages/apps/chat/src/services/chat/slash/slash-command-registry.ts --bundle --platform=node --format=cjs --packages=external
```

All listed esbuild checks completed successfully.

## Notes

- A full dependency install and production `vite build`/backend monorepo build were not completed in this sandbox because the repository does not include installed `node_modules`, and the local workflow packages expect Yarn build hooks while Yarn is not available here.
- `giga-ai-ui/package.json` and `yarn.lock` were updated for `jszip` so frontend source archive extraction is available after a normal dependency install.
