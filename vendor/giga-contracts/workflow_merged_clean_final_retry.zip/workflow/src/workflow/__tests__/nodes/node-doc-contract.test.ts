import { describe, expect, it } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getAllNodeSchemas } from '@workflow/nodes/node-utils';

const TEST_DIR = path.dirname(fileURLToPath(import.meta.url));
const LOCAL_DOC_NODES = ['start', 'code', 'merge', 'output-format', 'metadata', 'file', 'if-else', 'respond-end', 'stop-error', 'wait', 'current-subjects', 'graphql', 'http-request', 'excel', 'ai-governor', 'text-analysis', 'action-router', 'chat-plan-policy', 'validate-workflow-cypher', 'workflow', 'execute-workflow'] as const;
const SCHEMA_ONLY_LOCAL_DOC_NODES = ['ai-agent'] as const;
const SERVER_DOC_NODES = {
    'run-channel-action': 'executeGroupedActionNode',
    'run-category-action': 'executeGroupedActionNode',
    'run-subject-action': 'executeGroupedActionNode',
    'run-post-action': 'executeGroupedActionNode',
    'run-user-tree-action': 'executeGroupedActionNode',
    'run-chat-action': 'executeGroupedActionNode',
    'mcp-runtime': 'executeMcpRuntimeNode',
    'mcp-capabilities': 'executeMcpCapabilitiesNode',
    'current-chat': 'executeCurrentChatNode'
} as const;

const readNodeReadme = (nodeId: string): string => {
    const fullPath = path.resolve(TEST_DIR, `../../../../../workflow-nodes/src/nodes/${nodeId}/README.md`);
    return fs.readFileSync(fullPath, 'utf8');
};

describe('node docs contract', () => {
    it('documents local worker-owned nodes as having no backend mapping metadata', () => {
        const schemas = getAllNodeSchemas();

        LOCAL_DOC_NODES.forEach((nodeId) => {
            expect(schemas[nodeId]?.documentation?.backend).toBeUndefined();
            expect(readNodeReadme(nodeId)).toContain('No backend service is used.');
        });
    });

    it('documents schema-only local worker-owned nodes without backend mappings', () => {
        const schemas = getAllNodeSchemas();

        SCHEMA_ONLY_LOCAL_DOC_NODES.forEach((nodeId) => {
            expect(schemas[nodeId]?.documentation?.backend).toBeUndefined();
            expect(schemas[nodeId]?.documentation?.summary).toBeTruthy();
            expect(schemas[nodeId]?.documentation?.usage).toBeTruthy();
        });
    });

    it('documents server-backed MCP nodes with explicit backend handlers', () => {
        const schemas = getAllNodeSchemas();

        Object.entries(SERVER_DOC_NODES).forEach(([nodeId, handlerName]) => {
            expect(schemas[nodeId]?.documentation?.backend?.handler).toBe(handlerName);
            expect(readNodeReadme(nodeId)).toContain(handlerName);
        });
    });
});
