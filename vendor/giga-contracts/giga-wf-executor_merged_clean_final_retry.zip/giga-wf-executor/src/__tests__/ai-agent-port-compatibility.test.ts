import { describe, expect, it } from 'vitest';
import { validateWorkflowConnectionCompatibility } from '../executor/port-compatibility';
import { WorkflowDefinition, WorkflowNodeModel, WorkflowNodeStatusEnum } from '../types';

const node = (id: string, modelId: string, name: string): WorkflowNodeModel => ({
    id,
    gigaId: id,
    modelId,
    type: 'workflowStep',
    name,
    description: '',
    kind: 'process',
    status: WorkflowNodeStatusEnum.Stopped,
    position: { x: 0, y: 0 },
    runtime: {},
    ports: { in: {}, out: {} }
});

const workflow = (connections: WorkflowDefinition['connections']): WorkflowDefinition => ({
    metadata: { id: 'wf_tools', name: 'AI Agent Tools Compatibility' },
    nodeModels: {
        'ai-agent': { id: 'ai-agent', inputs: { input: {} }, outputs: { output: {} }, commands: { tools: { portType: 'bi-directional', allowMultipleArrows: true, acceptedSourceModelIds: ['action-router'] } } },
        'action-router': { id: 'action-router', inputs: { input: {} }, outputs: { output: {} }, commands: { command: { portType: 'bi-directional', allowMultipleArrows: true } } },
        workflow: { id: 'workflow', inputs: { input: {} }, outputs: { output: {} }, commands: { command: { portType: 'bi-directional', allowMultipleArrows: true } } }
    },
    nodes: [node('agent_1', 'ai-agent', 'AI Agent'), node('router_1', 'action-router', 'Action Router'), node('workflow_1', 'workflow', 'Workflow')],
    connections
});

describe('ai-agent tools compatibility', () => {
    it('rejects non-router command peers on the tools port', () => {
        const violations = validateWorkflowConnectionCompatibility(workflow([
            { id: 'c1', name: 'Workflow -> AI Agent', from: 'workflow_1', to: 'agent_1', sourceHandle: 'cmd:command', targetHandle: 'cmd:tools' }
        ]));

        expect(violations).toHaveLength(1);
        expect(String(violations[0]?.message || '')).toContain('incompatible connection');
    });

    it('accepts action-router command peers on the tools port', () => {
        const violations = validateWorkflowConnectionCompatibility(workflow([
            { id: 'c1', name: 'Action Router -> AI Agent', from: 'router_1', to: 'agent_1', sourceHandle: 'cmd:command', targetHandle: 'cmd:tools' }
        ]));

        expect(violations).toEqual([]);
    });
});
