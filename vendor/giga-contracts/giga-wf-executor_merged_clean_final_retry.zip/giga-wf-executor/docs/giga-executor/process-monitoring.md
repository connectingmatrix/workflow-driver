# Workflow Executor Process Monitoring

The executor emits runtime events for workflow queued/running/completed/failed/cancelled/killed and for node-level progress.

## Required event fields

- `processId`
- `scopeType`
- `scopeId` or `parentScopeId`
- `userId`
- `cpu`
- `ramMb`
- `status`
- `iteration` when node/agent iteration is available

```mermaid
graph TD
  A[Workflow queued] --> B[Register process]
  B --> C[Run node]
  C --> D{AI Agent node?}
  D -->|yes| E[Launch AI Agent child process]
  D -->|no| F[Run node handler]
  E --> G[Emit child logs]
  F --> H[Emit node logs]
  G --> I{More nodes?}
  H --> I
  I -->|yes| C
  I -->|no| J[Complete workflow]
```
