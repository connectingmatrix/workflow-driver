import React from 'react';
import type { WorkflowLogsRecord } from '@workflow/ui/workflow/components/logs/logs-dialog.types';

interface WorkflowLogsViewerProps {
    records: WorkflowLogsRecord[];
}

const LEVEL_LABELS: Record<WorkflowLogsRecord['level'], string> = {
    info: 'INFO',
    warn: 'WARN',
    error: 'ERROR'
};

export const WorkflowLogsViewer: React.FC<WorkflowLogsViewerProps> = ({ records }) => {
    if (records.length === 0) {
        return <div className="wf-workspace-logs__empty">No logs match the current filters.</div>;
    }

    return (
        <div className="wf-workspace-logs__viewer">
            <div className="wf-workspace-logs__viewer-toolbar">
                <span className="wf-workspace-logs__viewer-chip">JSONL</span>
            </div>
            <div className="wf-workspace-logs__viewer-scroll">
                {records.map((record) => (
                    <div key={record.id} className={`wf-workspace-logs__line wf-workspace-logs__line--${record.level}`}>
                        <span className="wf-workspace-logs__line-number">{record.lineNumber}</span>
                        <pre className="wf-workspace-logs__line-text">{record.formatted}</pre>
                        <span className={`wf-workspace-logs__line-level wf-workspace-logs__line-level--${record.level}`}>{LEVEL_LABELS[record.level]}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};
