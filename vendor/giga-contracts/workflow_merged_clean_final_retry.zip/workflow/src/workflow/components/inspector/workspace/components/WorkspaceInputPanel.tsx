import React from 'react';
import type { WorkspaceInputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { WorkspacePanelFrame } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspacePanelFrame';
import { WorkspaceSegmentedTabs } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceSegmentedTabs';
import { WorkspaceInputContent } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceInputContent';

interface WorkspaceInputPanelProps {
    model: WorkspaceInputPanelModel;
    showAcceptedFormats: boolean;
    showInputFeatures: boolean;
    onTabChange: (tabId: string) => void;
    onAction: (actionId: string) => void;
}

export const WorkspaceInputPanel: React.FC<WorkspaceInputPanelProps> = ({ model, showAcceptedFormats, showInputFeatures, onTabChange, onAction }) => {
    return (
        <WorkspacePanelFrame panelClassName="cnw-panel--input" bodyClassName="cnw-panel__body--input" title={model.title} description={model.description} icon={model.icon}>
            <div className="cnw-input-panel">
                <WorkspaceSegmentedTabs items={model.tabs} activeId={model.activeTab} onChange={onTabChange} />
                <div className="cnw-input-panel__scroll">
                    <WorkspaceInputContent model={model} onAction={onAction} />

                    {showAcceptedFormats && model.acceptedFormats?.length ? (
                        <div className="cnw-subsection">
                            <h4 className="cnw-subsection__title">Accepted formats</h4>
                            <div className="cnw-chip-row">
                                {model.acceptedFormats.map((format) => (
                                    <span key={format} className="cnw-chip">
                                        {format}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ) : null}

                    {showInputFeatures && model.featureItems?.length ? (
                        <div className="cnw-feature-list">
                            {model.featureItems.map((item) => (
                                <div key={item.id} className="cnw-feature-card">
                                    <div className="cnw-feature-card__dot">
                                        <WorkspaceGlyph name={item.icon ?? 'sparkles'} className="cnw-feature-card__dot-icon" />
                                    </div>
                                    <div>
                                        <p className="cnw-feature-card__title">{item.title}</p>
                                        {item.description ? <p className="cnw-feature-card__description">{item.description}</p> : null}
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : null}
                </div>
            </div>
        </WorkspacePanelFrame>
    );
};
