import React from 'react';
import { classNames } from 'primereact/utils';
import { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';

interface DependingFieldProps {
    primary: React.ReactNode;
    dependent: React.ReactNode;
    separator?: React.ReactNode;
    className?: string;
}

const normalizeDependencyKey = (value: unknown): string =>
    String(value ?? '')
        .trim()
        .toLowerCase();

const resolveDependencyRange = (definition: WorkflowNodeFieldDefinition, values: Record<string, unknown>): { min?: number; max?: number; step?: number } | null => {
    const dependsOn = definition.dependsOn;
    if (!dependsOn) return null;

    const dependencyValue = normalizeDependencyKey(values[dependsOn.field]);
    const mapped = dependencyValue ? dependsOn.map?.[dependencyValue] : undefined;
    const fallback = dependsOn.fallback;

    if (!mapped && !fallback) return null;

    return {
        min: mapped?.min ?? fallback?.min,
        max: mapped?.max ?? fallback?.max,
        step: mapped?.step ?? fallback?.step
    };
};

export const resolveDependingFieldDefinition = (definition: WorkflowNodeFieldDefinition, values: Record<string, unknown>): WorkflowNodeFieldDefinition => {
    const range = resolveDependencyRange(definition, values);
    if (!range) return definition;
    return {
        ...definition,
        min: range.min ?? definition.min,
        max: range.max ?? definition.max,
        step: range.step ?? definition.step
    };
};

export const clampDependingFieldNumberValue = (value: number, definition: WorkflowNodeFieldDefinition): number => {
    if (!Number.isFinite(value)) return value;
    let nextValue = value;
    if (typeof definition.min === 'number') {
        nextValue = Math.max(definition.min, nextValue);
    }
    if (typeof definition.max === 'number') {
        nextValue = Math.min(definition.max, nextValue);
    }
    return nextValue;
};

const DependingField: React.FC<DependingFieldProps> = ({ primary, dependent, separator = ':', className }) => {
    return (
        <div className={classNames('wf-depending-field', className)}>
            <div className="wf-depending-field__primary">{primary}</div>
            <span className="wf-depending-field__separator" aria-hidden>
                {separator}
            </span>
            <div className="wf-depending-field__dependent">{dependent}</div>
        </div>
    );
};

export default DependingField;
export type { DependingFieldProps };
