import { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { isRespondEndWorkflowModel, isStartWorkflowModel } from '@workflow/ui/workflow/utils/workflow-model-id.utils';

export const getMissingPlayValidationNodes = (workflow: WorkflowDefinition): string[] => {
    const issues: string[] = [];
    const startCount = workflow.nodes.filter((node) => isStartWorkflowModel(node)).length;
    const endNodes = workflow.nodes.filter((node) => isRespondEndWorkflowModel(node));
    const endCount = endNodes.length;

    if (startCount === 0) {
        issues.push('Exactly one Start node is required before playing the workflow.');
    } else if (startCount > 1) {
        issues.push('Only one Start node is allowed per workflow.');
    }

    if (endCount === 0) {
        issues.push('Exactly one Respond/End node is required before playing the workflow.');
    } else if (endCount > 1) {
        issues.push('Only one Respond/End node is allowed per workflow.');
    }

    if (endCount === 1) {
        const endNodeId = String(endNodes[0]?.id ?? '');
        const incomingConnectionCount = workflow.connections.filter((connection) => connection.to === endNodeId).length;
        if (incomingConnectionCount > 1) {
            issues.push('Respond/End node can have only one incoming connection.');
        }
    }

    return issues;
};
