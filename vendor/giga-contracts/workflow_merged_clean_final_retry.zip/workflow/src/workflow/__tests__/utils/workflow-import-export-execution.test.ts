import { describe, expect, it } from 'vitest';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import { exportPayloadToWorkflow, workflowToExportPayload } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { WorkflowAuthModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('workflow import/export after execution', () => {
    it('exports runtime outputs correctly and imports them back with data', async () => {
        const workflow = createEmptyWorkflow('wf_export_runtime');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const ifElse = createWorkflowNode(workflow, 'if-else', 'If Else', 2);
        const code = createWorkflowNode(workflow, 'code', 'Code', 3);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 4);

        ifElse.runtime = {
            ...(ifElse.runtime ?? {}),
            value: { route: true },
            leftPath: 'route',
            operator: 'truthy'
        };
        code.runtime = {
            ...(code.runtime ?? {}),
            code: 'console.log("code-node executed"); return { transformed: true, value: 123 };'
        };
        end.runtime = {
            ...(end.runtime ?? {}),
            response: `{{${code.id}}}`
        };

        workflow.nodes = [start, ifElse, code, end];
        workflow.connections = [createConnection('c1', start.id, ifElse.id, 'out:output', 'in:input'), createConnection('c2', ifElse.id, code.id, 'out:true', 'in:input'), createConnection('c3', code.id, end.id, 'out:output', 'in:input')];

        const executed = await workflowExecutor.executeWorkflow(workflow, {
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: WorkflowAuthModeEnum.None,
                manualHeaders: {}
            }
        });

        const payload = workflowToExportPayload(executed.workflow, 'with-data');
        expect(payload.nodes.Start.ports.out.output).toBeTruthy();
        expect((payload.nodes['If Else'].ports.out.output as { selectedBranch?: string })?.selectedBranch).toBe('true');
        expect(payload.nodes.Code.ports.out.output).toEqual({ transformed: true, value: 123 });
        expect(payload.nodes.End.ports.out.output).toEqual({ transformed: true, value: 123 });
        expect((payload as { nodeModels?: Record<string, { documentation?: { summary?: string } }> }).nodeModels).toBeTruthy();
        expect(payload.nodeModels?.code?.documentation?.summary).toBeTruthy();

        const imported = exportPayloadToWorkflow(payload);
        const importedCode = imported.nodes.find((node) => node.name === 'Code');
        const importedEnd = imported.nodes.find((node) => node.name === 'End');
        expect(importedCode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(importedCode?.ports.out.output).toEqual({ transformed: true, value: 123 });
        expect(importedEnd?.ports.out.output).toEqual({ transformed: true, value: 123 });
        expect(imported.connections).toHaveLength(3);
    });
});
