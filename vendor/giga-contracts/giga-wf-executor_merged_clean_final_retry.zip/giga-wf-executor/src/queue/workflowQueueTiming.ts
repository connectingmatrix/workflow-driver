const WORKFLOW_QUEUE_META_KEY = '__workflowQueue';

const recordValue = (value: unknown): Record<string, any> =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, any>) : {};

const resolveMeta = (value: unknown) => {
  const meta = recordValue(recordValue(value)[WORKFLOW_QUEUE_META_KEY]);
  return { queued_at: typeof meta.queued_at === 'string' ? meta.queued_at : null, execution_started_at: typeof meta.execution_started_at === 'string' ? meta.execution_started_at : null };
};

const readWorkflowTimeoutSeconds = (workflowSnapshot: unknown, defaultSeconds: number): number => {
  const settings = recordValue(recordValue(recordValue(recordValue(workflowSnapshot).metadata).runtime).settings);
  const timeoutSeconds = Number(settings.maxExecutionSeconds);
  return Number.isFinite(timeoutSeconds) && timeoutSeconds > 0 ? timeoutSeconds : defaultSeconds;
};

const toSeconds = (milliseconds: number): number => Math.max(0, Math.floor(milliseconds / 1000));

export const createWorkflowQueueTimingPayload = (queuedAt: string) => ({ [WORKFLOW_QUEUE_META_KEY]: { queued_at: queuedAt, execution_started_at: null } });
export const withWorkflowQueueExecutionStarted = (payload: unknown, startedAt: string) => ({ ...recordValue(payload), [WORKFLOW_QUEUE_META_KEY]: { ...resolveMeta(payload), execution_started_at: startedAt } });
export const withWorkflowQueueTimingPayload = (payload: unknown, queuedAt: string, executionStartedAt?: string | null) => ({ ...recordValue(payload), [WORKFLOW_QUEUE_META_KEY]: { queued_at: queuedAt, execution_started_at: executionStartedAt || null } });
export const mergeWorkflowQueueTimingPayload = (payload: unknown, currentPayload: unknown, fallbackQueuedAt?: string | null) => withWorkflowQueueTimingPayload(payload, resolveMeta(payload).queued_at || resolveMeta(currentPayload).queued_at || fallbackQueuedAt || new Date().toISOString(), resolveMeta(payload).execution_started_at || resolveMeta(currentPayload).execution_started_at || null);

export const resolveWorkflowQueueTiming = (params: { createdAt?: string | null; completedAt?: string | null; now?: Date; responsePayload?: unknown }) => {
  const meta = resolveMeta(params.responsePayload);
  const endAt = params.completedAt || (params.now || new Date()).toISOString();
  const queuedAt = meta.queued_at || params.createdAt || null;
  const executionStartedAt = meta.execution_started_at || null;
  return {
    queuedAt,
    executionStartedAt,
    timeElapsed: queuedAt && !Number.isNaN(new Date(queuedAt).getTime()) ? toSeconds(new Date(endAt).getTime() - new Date(queuedAt).getTime()) : 0,
    executionTime: executionStartedAt && !Number.isNaN(new Date(executionStartedAt).getTime()) ? toSeconds(new Date(endAt).getTime() - new Date(executionStartedAt).getTime()) : 0,
  };
};

export const isWorkflowQueueExecutionStalled = (params: { createdAt?: string | null; now?: Date; responsePayload?: unknown; workflowSnapshot?: unknown; defaultTimeoutSeconds?: number; graceSeconds?: number }): boolean => {
  const now = params.now || new Date();
  const timing = resolveWorkflowQueueTiming({ createdAt: params.createdAt, now, responsePayload: params.responsePayload });
  const startedAt = new Date(timing.executionStartedAt || timing.queuedAt || params.createdAt || '').getTime();
  if (!Number.isFinite(startedAt)) return false;
  return now.getTime() - startedAt > (readWorkflowTimeoutSeconds(params.workflowSnapshot, Number(params.defaultTimeoutSeconds) || 300) + (Number(params.graceSeconds) || 15)) * 1000;
};
