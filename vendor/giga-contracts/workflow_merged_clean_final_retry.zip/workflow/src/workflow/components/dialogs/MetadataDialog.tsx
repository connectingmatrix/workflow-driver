import React from 'react';
import { Dialog } from 'primereact/dialog';
import { WorkflowMetadata } from '@workflow/ui/workflow/types';

interface MetadataDialogProps {
    visible: boolean;
    metadata: WorkflowMetadata | null;
    onHide: () => void;
}

const MetadataDialog: React.FC<MetadataDialogProps> = ({ visible, metadata, onHide }) => {
    return (
        <Dialog visible={visible} onHide={onHide} header="Workflow Metadata" modal dismissableMask style={{ width: 'min(90vw, 700px)' }}>
            <pre className="wf-dialog-json">{JSON.stringify(metadata || {}, null, 2)}</pre>
        </Dialog>
    );
};

export default MetadataDialog;
