import { WorkflowNodeFieldTypeEnum, WorkflowNodePortSideEnum, WorkflowNodeSchema } from '@workflow/ui/workflow/types';

export interface UserNodeFieldDraft {
    id: string;
    key: string;
    label: string;
    type: string;
    order: number;
    hidden: boolean;
    editable: boolean;
    allowVariables: boolean;
    placeholder: string;
}

export interface UserNodePortDraft {
    id: string;
    kind: UserNodePortDraftKind;
    key: string;
    label: string;
    side: string;
    order: number;
    allowMultipleArrows: boolean;
    portType?: string;
    acceptedSourceGroups: string;
    acceptedSourceModelIds: string;
    showQuickAdd: boolean;
}

export type UserNodePortDraftKind = 'input' | 'output' | 'command';

export interface UserNodeSchemaDraft {
    iconMode: 'prime' | 'svg';
    iconClass: string;
    iconColor: string;
    iconSvg: string;
    useCredentials: string;
    fields: UserNodeFieldDraft[];
    ports: UserNodePortDraft[];
    passthrough: Record<string, unknown>;
}

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const createDraftId = (prefix: string): string => `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
const parseStringArray = (value: unknown): string[] => (Array.isArray(value) ? value.map((entry) => String(entry).trim()).filter(Boolean) : []);
const toCsv = (value: unknown): string => parseStringArray(value).join(', ');
const fromCsv = (value: string): string[] => value.split(',').map((entry) => entry.trim()).filter(Boolean);

const sortByOrder = <T extends { order: number }>(items: T[]): T[] => [...items].sort((left, right) => left.order - right.order || String((left as { key?: string }).key ?? '').localeCompare(String((right as { key?: string }).key ?? '')));

const getDefaultPortSide = (kind: UserNodePortDraftKind): WorkflowNodePortSideEnum => {
    switch (kind) {
        case 'input':
            return WorkflowNodePortSideEnum.Left;
        case 'output':
            return WorkflowNodePortSideEnum.Right;
        case 'command':
        default:
            return WorkflowNodePortSideEnum.Bottom;
    }
};

const normalizePortKindMetadata = (port: UserNodePortDraft, kind: UserNodePortDraftKind): UserNodePortDraft => ({
    ...port,
    kind,
    side: port.side || getDefaultPortSide(kind),
    portType: kind === 'command' ? 'bi-directional' : undefined,
    acceptedSourceGroups: kind === 'command' ? port.acceptedSourceGroups : '',
    acceptedSourceModelIds: kind === 'command' ? port.acceptedSourceModelIds : '',
    showQuickAdd: kind === 'output' ? port.showQuickAdd : false
});

const deserializeFieldDrafts = (schema: Record<string, unknown>): UserNodeFieldDraft[] =>
    sortByOrder(
        Object.entries(toRecord(schema.fields)).map(([fieldKey, rawField], index) => {
            const field = toRecord(rawField);
            return {
                id: createDraftId('field'),
                key: fieldKey,
                label: String(field.label ?? fieldKey),
                type: String(field.type ?? WorkflowNodeFieldTypeEnum.String),
                order: Number(field.order ?? index + 1) || index + 1,
                hidden: field.hidden === true,
                editable: field.editable !== false,
                allowVariables: field.allowVariables !== false,
                placeholder: String(field.placeholder ?? '')
            };
        })
    );

const deserializePortDrafts = (ports: unknown, prefix: string, fallbackSide: string, kind: UserNodePortDraftKind): UserNodePortDraft[] =>
    sortByOrder(
        Object.entries(toRecord(ports)).map(([portKey, rawPort], index) => {
            const port = toRecord(rawPort);
            return normalizePortKindMetadata({
                id: createDraftId(prefix),
                kind,
                key: portKey,
                label: String(port.label ?? portKey),
                side: String(port.side ?? fallbackSide),
                order: Number(port.order ?? index + 1) || index + 1,
                allowMultipleArrows: port.allowMultipleArrows !== false,
                portType: typeof port.portType === 'string' ? port.portType : undefined,
                acceptedSourceGroups: toCsv(port.acceptedSourceGroups),
                acceptedSourceModelIds: toCsv(port.acceptedSourceModelIds),
                showQuickAdd: port.showQuickAdd === true
            }, kind);
        })
    );

export const createEmptyUserNodeSchemaDraft = (): UserNodeSchemaDraft => ({
    iconMode: 'prime',
    iconClass: 'pi pi-code',
    iconColor: '#334155',
    iconSvg: '',
    useCredentials: '',
    fields: [],
    ports: [
        createPortDraft('input', 1),
        createPortDraft('output', 2)
    ],
    passthrough: {}
});

export const deserializeUserNodeSchemaDraft = (value: Record<string, unknown> | null | undefined): UserNodeSchemaDraft => {
    const schema = toRecord(value);
    const passthrough = { ...schema };
    delete passthrough.fields;
    delete passthrough.inputs;
    delete passthrough.outputs;
    delete passthrough.commands;
    delete passthrough.useCredentials;
    const render = toRecord(schema.render);
    const iconSvg = String(render.iconSvg ?? schema.iconSvg ?? '');
    const iconMode = render.iconMode === 'svg' || render.iconMode === 'prime' ? render.iconMode : schema.iconMode === 'svg' || schema.iconMode === 'prime' ? schema.iconMode : iconSvg.trim() ? 'svg' : 'prime';
    return {
        iconMode,
        iconClass: String(render.iconClass ?? schema.iconClass ?? 'pi pi-code'),
        iconColor: String(render.iconColor ?? schema.iconColor ?? '#334155'),
        iconSvg,
        useCredentials: String(schema.useCredentials ?? ''),
        fields: deserializeFieldDrafts(schema),
        ports: sortByOrder([
            ...deserializePortDrafts(schema.inputs, 'input', WorkflowNodePortSideEnum.Left, 'input'),
            ...deserializePortDrafts(schema.outputs, 'output', WorkflowNodePortSideEnum.Right, 'output'),
            ...deserializePortDrafts(schema.commands, 'command', WorkflowNodePortSideEnum.Bottom, 'command')
        ]),
        passthrough
    };
};

const serializeFieldDrafts = (fields: UserNodeFieldDraft[]): Record<string, Record<string, unknown>> =>
    sortByOrder(fields).reduce<Record<string, Record<string, unknown>>>((acc, field, index) => {
        if (!field.key.trim()) return acc;
        acc[field.key.trim()] = {
            type: field.type || WorkflowNodeFieldTypeEnum.String,
            label: field.label.trim() || field.key.trim(),
            order: index + 1,
            hidden: field.hidden,
            editable: field.editable,
            allowVariables: field.allowVariables,
            ...(field.placeholder.trim() ? { placeholder: field.placeholder.trim() } : {})
        };
        return acc;
    }, {});

const serializePortDrafts = (ports: UserNodePortDraft[], kind: UserNodePortDraftKind): Record<string, Record<string, unknown>> =>
    sortByOrder(ports.filter((port) => port.kind === kind)).reduce<Record<string, Record<string, unknown>>>((acc, port, index) => {
        if (!port.key.trim()) return acc;
        acc[port.key.trim()] = {
            label: port.label.trim() || port.key.trim(),
            side: port.side,
            order: index + 1,
            allowMultipleArrows: port.allowMultipleArrows,
            ...(kind === 'command' ? { portType: 'bi-directional' } : {}),
            ...(kind === 'command' && fromCsv(port.acceptedSourceGroups).length ? { acceptedSourceGroups: fromCsv(port.acceptedSourceGroups) } : {}),
            ...(kind === 'command' && fromCsv(port.acceptedSourceModelIds).length ? { acceptedSourceModelIds: fromCsv(port.acceptedSourceModelIds) } : {}),
            ...(kind === 'output' && port.showQuickAdd ? { showQuickAdd: true } : {})
        };
        return acc;
    }, {});

export const serializeUserNodeSchemaDraft = (draft: UserNodeSchemaDraft): WorkflowNodeSchema => {
    const render = toRecord(draft.passthrough.render);
    return {
        ...draft.passthrough,
        iconClass: draft.iconClass,
        iconColor: draft.iconColor,
        iconMode: draft.iconMode,
        ...(draft.useCredentials.trim() ? { useCredentials: draft.useCredentials.trim() } : {}),
        ...(draft.iconSvg.trim() ? { iconSvg: draft.iconSvg.trim() } : {}),
        render: {
            ...render,
            iconClass: draft.iconClass,
            iconColor: draft.iconColor,
            iconMode: draft.iconMode,
            ...(draft.iconSvg.trim() ? { iconSvg: draft.iconSvg.trim() } : {})
        },
        fields: serializeFieldDrafts(draft.fields),
        inputs: serializePortDrafts(draft.ports, 'input'),
        outputs: serializePortDrafts(draft.ports, 'output'),
        commands: serializePortDrafts(draft.ports, 'command')
    };
};

export const createFieldDraft = (order: number): UserNodeFieldDraft => ({
    id: createDraftId('field'),
    key: `field_${order}`,
    label: `Field ${order}`,
    type: WorkflowNodeFieldTypeEnum.String,
    order,
    hidden: false,
    editable: true,
    allowVariables: true,
    placeholder: ''
});

export const createPortDraft = (kind: 'input' | 'output' | 'command', order: number): UserNodePortDraft => ({
    id: createDraftId(kind),
    kind,
    key: `${kind}_${order}`,
    label: kind === 'command' ? `Command ${order}` : `${kind[0].toUpperCase()}${kind.slice(1)} ${order}`,
    side: getDefaultPortSide(kind),
    order,
    allowMultipleArrows: kind !== 'input',
    portType: kind === 'command' ? 'bi-directional' : undefined,
    acceptedSourceGroups: '',
    acceptedSourceModelIds: '',
    showQuickAdd: kind === 'output'
});

export const updatePortDraftKind = (port: UserNodePortDraft, kind: UserNodePortDraftKind): UserNodePortDraft =>
    normalizePortKindMetadata(
        {
            ...port,
            kind,
            side: getDefaultPortSide(kind),
            allowMultipleArrows: kind === 'input' ? port.allowMultipleArrows : true,
            showQuickAdd: kind === 'output' ? port.showQuickAdd : false
        },
        kind
    );
