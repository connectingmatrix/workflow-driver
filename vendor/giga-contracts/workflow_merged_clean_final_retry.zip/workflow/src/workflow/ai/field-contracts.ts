import { WorkflowNodeLibraryItem, WorkflowNodeSchema } from '@workflow/ui/workflow/types';
import { getNormalizedCommandPorts } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';

export const buildWorkflowNodeContract = (
    item: WorkflowNodeLibraryItem,
    schema: WorkflowNodeSchema
) => ({
    modelId: item.modelId,
    group: item.group || schema.group,
    ports: {
        inputs: Object.entries(schema.inputs).map(([id, port]) => ({ id, label: port.label, portType: port.portType, acceptedSourceGroups: port.acceptedSourceGroups, acceptedSourceModelIds: port.acceptedSourceModelIds })),
        outputs: Object.entries(schema.outputs).map(([id, port]) => ({ id, label: port.label, portType: port.portType })),
        commands: Object.entries(getNormalizedCommandPorts(schema)).map(([id, port]) => ({ id, label: port.label, portType: port.portType, acceptedSourceGroups: port.acceptedSourceGroups, acceptedSourceModelIds: port.acceptedSourceModelIds }))
    },
    fields: Object.entries(schema.fields)
        .filter(([, field]) => !field.hidden && field.editable !== false)
        .map(([key, field]) => ({
            key,
            type: field.type,
            label: field.label,
            required: field.required,
            defaultValue: field.defaultValue,
            options: field.options,
            allowVariables: field.allowVariables,
            aiWriteMode: field.aiWriteMode,
            aiSourcePort: field.aiSourcePort,
            resolveVariablesWhen: field.resolveVariablesWhen
        })),
    instruction: schema.instruction
});
