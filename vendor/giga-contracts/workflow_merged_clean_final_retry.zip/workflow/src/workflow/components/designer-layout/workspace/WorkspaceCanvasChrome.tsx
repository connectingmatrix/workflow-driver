import React from 'react';
import { InputText } from 'primereact/inputtext';

interface WorkspaceCanvasChromeProps {
    searchValue: string;
    onSearchChange: (value: string) => void;
    onSearchKeyDown: (event: React.KeyboardEvent<HTMLInputElement>) => void;
    matchCount: number;
    activeMatchIndex: number;
    onNextMatch: () => void;
    onPreviousMatch: () => void;
    nodeCount: number;
    connectionCount: number;
}

const WorkspaceCanvasChrome: React.FC<WorkspaceCanvasChromeProps> = ({ searchValue, onSearchChange, onSearchKeyDown, matchCount, activeMatchIndex, onNextMatch, onPreviousMatch, nodeCount, connectionCount }) => {
    const showNavigation = matchCount > 1;
    return (
        <>
            <div className="wf-workspace-canvas-chrome__search-shell">
                <i className="pi pi-search" aria-hidden />
                <InputText value={searchValue} onChange={(event) => onSearchChange(event.target.value)} onKeyDown={onSearchKeyDown} placeholder="Search on canvas" className="wf-workspace-canvas-chrome__search-input" />
                {showNavigation ? (
                    <div className="wf-workspace-canvas-chrome__search-nav">
                        <span className="wf-workspace-canvas-chrome__search-meta">
                            {activeMatchIndex + 1} of {matchCount}
                        </span>
                        <button type="button" className="wf-workspace-canvas-chrome__search-nav-btn" onClick={onPreviousMatch} aria-label="Previous search result">
                            <i className="pi pi-angle-up" aria-hidden />
                        </button>
                        <button type="button" className="wf-workspace-canvas-chrome__search-nav-btn" onClick={onNextMatch} aria-label="Next search result">
                            <i className="pi pi-angle-down" aria-hidden />
                        </button>
                    </div>
                ) : null}
            </div>
            <div className="wf-workspace-canvas-chrome__stats">{nodeCount} nodes • {connectionCount} active edges</div>
        </>
    );
};

export default WorkspaceCanvasChrome;
