import React from 'react';
import type { ToolbarProps } from '@workflow/ui/workflow/components/toolbar/toolbar.types';
import WorkspaceToolbar from '@workflow/ui/workflow/components/toolbar/workspace/WorkspaceToolbar';

const Toolbar: React.FC<ToolbarProps> = (props) => <WorkspaceToolbar {...props} />;

export type { ToolbarProps };
export default Toolbar;
