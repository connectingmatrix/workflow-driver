import React, { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { TabPanel, TabView } from 'primereact/tabview';
import UserNodeCodeWorkspace from '@workflow/ui/workflow/components/user-node-designer/UserNodeCodeWorkspace';
import UserNodeDefinitionPanel from '@workflow/ui/workflow/components/user-node-designer/UserNodeDefinitionPanel';
import UserNodeInspectorDesignerTab from '@workflow/ui/workflow/components/user-node-designer/designer/UserNodeInspectorDesignerTab';
import { useUserNodeDesignerController } from '@workflow/ui/workflow/components/user-node-designer/useUserNodeDesignerController';
import type { WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import UserNodeDesignerSkeleton from '@workflow/ui/workflow/skeletons/UserNodeDesignerSkeleton';
import { WorkflowUserNodeDefinition } from '@workflow/ui/workflow/types';
import '@workflow/ui/workflow/components/user-node-designer/user-node-designer.scss';

interface UserNodeDesignerDialogProps {
    driver: WorkflowUiDriver;
    onHide: () => void;
    onNodesChanged?: (nodes: WorkflowUserNodeDefinition[]) => void;
    upstreamInputContext?: Record<string, unknown> | null;
    visible: boolean;
}

const UserNodeDesignerDialog: React.FC<UserNodeDesignerDialogProps> = ({ driver, onHide, onNodesChanged, upstreamInputContext, visible }) => {
    const [activeTab, setActiveTab] = useState<number>(0);
    const { state, preview, actions } = useUserNodeDesignerController({
        driver,
        visible,
        onNodesChanged,
        upstreamInputContext
    });

    return (
        <Dialog visible={visible} onHide={onHide} header="Node Designer Studio" modal style={{ width: 'min(96vw, 1400px)', height: '90vh' }} contentStyle={{ height: 'calc(90vh - 5rem)', overflow: 'hidden' }}>
            <div className="wf-user-node-designer" data-cy="user-node-designer-dialog">
                {state.isLoading ? (
                    <UserNodeDesignerSkeleton />
                ) : (
                    <TabView activeIndex={activeTab} onTabChange={(event) => setActiveTab(event.index)} className="wf-user-node-designer__tabs">
                        <TabPanel header="Node Properties">
                            <UserNodeDefinitionPanel
                                nodes={state.nodes}
                                selectedNodeId={state.selectedNodeId}
                                name={state.name}
                                description={state.description}
                                groupName={state.groupName}
                                slug={state.slug}
                                onNameChange={actions.setName}
                                onDescriptionChange={actions.setDescription}
                                onGroupNameChange={actions.setGroupName}
                                onCreateNew={() => actions.hydrateFromDefinition(null)}
                                onDelete={() => void actions.deleteNode()}
                                onSelectNode={(nodeId) => actions.hydrateFromDefinition(state.nodes.find((node) => node.id === nodeId) ?? null)}
                            />
                        </TabPanel>
                        <TabPanel header="Inspector Designer">
                            <UserNodeInspectorDesignerTab draft={state.schemaDraft} onChange={actions.setSchemaDraft} />
                        </TabPanel>
                        <TabPanel header="Node Code">
                            <div className="wf-user-node-designer__code-tab">
                                <UserNodeCodeWorkspace
                                    activeFile={state.activeFile}
                                    inputMode={state.inputMode}
                                    isRunning={preview.state.status === 'running'}
                                    browserRuntimeAllowed={state.browserRuntimeAllowed}
                                    runtimeMode={state.runtimeMode}
                                    runtimeResolved={state.effectiveRuntime}
                                    runtimeFallbackReason={state.runtimeFallbackReason}
                                    sampleInputJson={state.sampleInputJson}
                                    upstreamInputAvailable={state.upstreamInputAvailable}
                                    workerTs={state.workerTs}
                                    validateTs={state.validateTs}
                                    previewState={preview.state}
                                    onSwitchFile={actions.setActiveFile}
                                    onInputModeChange={actions.setInputMode}
                                    onRun={() => void actions.runPreview()}
                                    onRunOnServer={() => void actions.runPreviewOnServer()}
                                    onStop={actions.stopRun}
                                    onSave={() => void actions.saveNode()}
                                    onRevert={() => actions.hydrateFromDefinition(state.selectedNode)}
                                    onWorkerChange={actions.setWorkerTs}
                                    onValidateChange={actions.setValidateTs}
                                    setSampleInputJson={actions.setSampleInputJson}
                                    setRuntimeMode={actions.setRuntimeMode}
                                    onClearLogs={preview.actions.clearLogs}
                                />
                            </div>
                        </TabPanel>
                    </TabView>
                )}
            </div>
        </Dialog>
    );
};

export default UserNodeDesignerDialog;
