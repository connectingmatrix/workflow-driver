import type { WorkflowQueueCompletedEvent, WorkflowQueueFailedEvent } from './types';

export type WorkflowQueueTerminalEvent = WorkflowQueueCompletedEvent | WorkflowQueueFailedEvent;

const waiterByExecutionId = new Map<string, { resolve: (event: WorkflowQueueTerminalEvent) => void; reject: (error: Error) => void }>();

export const waitForWorkflowQueueCompletion = (executionId: string, signal?: AbortSignal): Promise<WorkflowQueueTerminalEvent> =>
  new Promise((resolve, reject) => {
    const onAbort = () => {
      waiterByExecutionId.delete(executionId);
      reject(new Error('Workflow queue wait aborted.'));
    };

    waiterByExecutionId.set(executionId, {
      resolve: (event) => {
        signal?.removeEventListener('abort', onAbort);
        resolve(event);
      },
      reject: (error) => {
        signal?.removeEventListener('abort', onAbort);
        reject(error);
      },
    });

    signal?.addEventListener('abort', onAbort, { once: true });
  });

export const resolveWorkflowQueueCompletion = (event: WorkflowQueueTerminalEvent): void => {
  const waiter = waiterByExecutionId.get(event.executionId);
  if (!waiter) return;
  waiterByExecutionId.delete(event.executionId);
  waiter.resolve(event);
};
