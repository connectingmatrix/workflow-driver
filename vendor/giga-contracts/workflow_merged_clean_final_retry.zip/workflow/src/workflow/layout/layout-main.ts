import { WORKFLOW_LAYOUT_LANE_GAP, WORKFLOW_LAYOUT_STAGE_GAP, WORKFLOW_LAYOUT_START_X, WORKFLOW_LAYOUT_START_Y } from '@workflow/ui/workflow/layout/layout-constants';
import type { WorkflowLayoutGraph } from '@workflow/ui/workflow/layout/layout-graph';

interface WorkflowMainLayout {
    stages: Record<string, number>;
    lanes: Record<string, number>;
    positions: Record<string, { x: number; y: number }>;
}

const siblingOffset = (count: number, index: number): number => {
    if (count <= 1) return 0;
    const split = Math.floor(count / 2);
    return count % 2 ? index - split : index < split ? index - split : index - split + 1;
};

const nearestLane = (used: Set<number>, preferred: number): number => {
    const rounded = Math.round(preferred);
    if (!used.has(rounded)) return rounded;
    for (let step = 1; step < 32; step += 1) {
        if (!used.has(rounded - step)) return rounded - step;
        if (!used.has(rounded + step)) return rounded + step;
    }
    return rounded + used.size + 1;
};

const readStages = (graph: WorkflowLayoutGraph): Record<string, number> => {
    const cache: Record<string, number> = {};
    const visit = (nodeId: string): number => {
        if (cache[nodeId] || cache[nodeId] === 0) return cache[nodeId];
        const parents = graph.parentsById[nodeId] || [];
        cache[nodeId] = parents.length ? Math.max(...parents.map(visit)) + 1 : 0;
        return cache[nodeId];
    };
    graph.mainNodeIds.forEach((nodeId) => visit(nodeId));
    return cache;
};

export const placeMainNodes = (graph: WorkflowLayoutGraph): WorkflowMainLayout => {
    const stages = readStages(graph);
    const roots = graph.roots.reduce<Record<string, number>>((record, nodeId, index) => ({ ...record, [nodeId]: index * 2 }), {});
    const stageIds = [...new Set(graph.mainNodeIds.map((nodeId) => stages[nodeId] || 0))].sort((left, right) => left - right);
    const lanes: Record<string, number> = {};
    stageIds.forEach((stage) => {
        const used = new Set<number>();
        const nodes = graph.mainNodeIds.filter((nodeId) => (stages[nodeId] || 0) === stage);
        const preferred = (nodeId: string): number => {
            const parents = graph.parentsById[nodeId] || [];
            if (!parents.length) return roots[nodeId] || 0;
            if (parents.length > 1) return parents.reduce((sum, parentId) => sum + (lanes[parentId] || 0), 0) / parents.length;
            const siblings = (graph.childrenById[parents[0]] || []).filter((childId) => (stages[childId] || 0) === stage).sort((left, right) => (graph.orderById[left] || 0) - (graph.orderById[right] || 0));
            return (lanes[parents[0]] || 0) + siblingOffset(siblings.length, siblings.indexOf(nodeId));
        };
        nodes.sort((left, right) => preferred(left) - preferred(right) || (graph.orderById[left] || 0) - (graph.orderById[right] || 0)).forEach((nodeId) => {
            const lane = nearestLane(used, preferred(nodeId));
            used.add(lane);
            lanes[nodeId] = lane;
        });
    });
    const minLane = Math.min(...Object.values(lanes), 0);
    const positions = graph.mainNodeIds.reduce<Record<string, { x: number; y: number }>>((record, nodeId) => {
        record[nodeId] = { x: WORKFLOW_LAYOUT_START_X + (lanes[nodeId] - minLane) * WORKFLOW_LAYOUT_LANE_GAP, y: WORKFLOW_LAYOUT_START_Y + (stages[nodeId] || 0) * WORKFLOW_LAYOUT_STAGE_GAP };
        return record;
    }, {});
    return { stages, lanes, positions };
};
