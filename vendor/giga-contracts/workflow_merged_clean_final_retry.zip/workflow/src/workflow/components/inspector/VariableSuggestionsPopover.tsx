import React, { useEffect, useState } from 'react';
import { classNames } from 'primereact/utils';
import { WorkflowVariableSuggestion } from '@workflow/ui/workflow/utils/workflow-variables.utils';

export interface WorkflowVariableSuggestionKeyboardEvent {
    key: string;
    preventDefault: () => void;
}

interface WorkflowVariableSuggestionControllerArgs {
    open: boolean;
    suggestions: WorkflowVariableSuggestion[];
    onSelect: (suggestion: WorkflowVariableSuggestion) => void;
    onClose: () => void;
}

interface WorkflowVariableSuggestionControllerResult {
    activeIndex: number;
    setActiveIndex: (nextIndex: number) => void;
    handleKeyDown: (event: WorkflowVariableSuggestionKeyboardEvent) => boolean;
}

const clampSuggestionIndex = (index: number, size: number): number => {
    if (size <= 0) return -1;
    if (index < 0) return size - 1;
    if (index >= size) return 0;
    return index;
};

export const useWorkflowVariableSuggestionController = ({ open, suggestions, onSelect, onClose }: WorkflowVariableSuggestionControllerArgs): WorkflowVariableSuggestionControllerResult => {
    const [activeIndex, setActiveIndexState] = useState<number>(-1);

    useEffect(() => {
        if (!open || suggestions.length === 0) {
            setActiveIndexState(-1);
            return;
        }
        setActiveIndexState(0);
    }, [open, suggestions]);

    const setActiveIndex = (nextIndex: number): void => {
        setActiveIndexState(clampSuggestionIndex(nextIndex, suggestions.length));
    };

    const handleKeyDown = (event: WorkflowVariableSuggestionKeyboardEvent): boolean => {
        if (!open || suggestions.length === 0) return false;

        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                setActiveIndexState((currentIndex) => clampSuggestionIndex(currentIndex + 1, suggestions.length));
                return true;
            case 'ArrowUp':
                event.preventDefault();
                setActiveIndexState((currentIndex) => clampSuggestionIndex(currentIndex - 1, suggestions.length));
                return true;
            case 'Enter':
            case 'Tab': {
                const targetIndex = activeIndex >= 0 ? activeIndex : 0;
                const selectedSuggestion = suggestions[targetIndex];
                if (!selectedSuggestion) return false;
                event.preventDefault();
                onSelect(selectedSuggestion);
                return true;
            }
            case 'Escape':
                event.preventDefault();
                onClose();
                return true;
            default:
                return false;
        }
    };

    return {
        activeIndex,
        setActiveIndex,
        handleKeyDown
    };
};

interface VariableSuggestionsPopoverProps {
    suggestions: WorkflowVariableSuggestion[];
    activeIndex: number;
    onActiveIndexChange: (nextIndex: number) => void;
    onSelect: (suggestion: WorkflowVariableSuggestion) => void;
    className?: string;
    listboxId?: string;
}

const resolveSuggestionTitle = (suggestion: WorkflowVariableSuggestion): string => {
    if (!suggestion.preview) return suggestion.path;
    return `Current value: ${suggestion.preview}`;
};

const VariableSuggestionsPopover: React.FC<VariableSuggestionsPopoverProps> = ({ suggestions, activeIndex, onActiveIndexChange, onSelect, className, listboxId }) => (
    <div id={listboxId} className={classNames('wf-variable-field__suggestions', className)} role="listbox">
        {suggestions.slice(0, 50).map((suggestion, index) => (
            <button
                key={suggestion.path}
                type="button"
                className={classNames('wf-variable-field__suggestion-item', { 'wf-variable-field__suggestion-item--active': activeIndex === index })}
                role="option"
                aria-selected={activeIndex === index}
                title={resolveSuggestionTitle(suggestion)}
                onMouseEnter={() => onActiveIndexChange(index)}
                onMouseDown={(event) => {
                    event.preventDefault();
                    onSelect(suggestion);
                }}
            >
                <span className="wf-variable-field__suggestion-path">{suggestion.path}</span>
                {suggestion.preview ? <span className="wf-variable-field__suggestion-preview">{suggestion.preview}</span> : null}
            </button>
        ))}
    </div>
);

export default VariableSuggestionsPopover;
