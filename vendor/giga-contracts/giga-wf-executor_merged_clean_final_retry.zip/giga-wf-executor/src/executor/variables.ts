export * from './core/execution/variable-manager';
