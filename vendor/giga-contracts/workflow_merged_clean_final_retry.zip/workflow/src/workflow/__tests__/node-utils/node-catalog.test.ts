import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { NODE_MODULES, getAllNodeSchemas, getNodeLibraryItems } from '@workflow/nodes/node-utils';
import { WorkflowAuthModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

const { evaluateJavascriptInIframeMock, runGraphqlRequestMock, resolveAuthHeadersMock } = vi.hoisted(() => ({
    evaluateJavascriptInIframeMock: vi.fn(),
    runGraphqlRequestMock: vi.fn(),
    resolveAuthHeadersMock: vi.fn()
}));

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', () => ({
    evaluateJavascriptInIframe: evaluateJavascriptInIframeMock
}));

vi.mock('@workflow/nodes/nodes/graphql/graphql-client', () => ({
    runGraphqlRequest: runGraphqlRequestMock,
    resolveAuthHeaders: resolveAuthHeadersMock
}));

describe('NODE_MODULES contract', () => {
    beforeEach(() => {
        evaluateJavascriptInIframeMock.mockReset();
        runGraphqlRequestMock.mockReset();
        resolveAuthHeadersMock.mockReset();
        evaluateJavascriptInIframeMock.mockImplementation(async (code: string) => {
            if (String(code).includes('return { true')) {
                return { result: { true: { ok: true } }, logs: [], error: null };
            }
            return { result: { ok: true }, logs: [], error: null };
        });
        resolveAuthHeadersMock.mockReturnValue({});
        runGraphqlRequestMock.mockResolvedValue({
            ok: true,
            status: 200,
            response: {
                data: {
                    ai_chat_messagesCollection: { edges: [{ node: { id: 'msg-1', text: 'hello' } }] },
                    ai_subjectsCollection: { edges: [{ node: { id: 'sub-1', title: 'Subject' } }] }
                }
            }
        });
        vi.stubGlobal(
            'fetch',
            vi.fn(async () => ({
                ok: true,
                status: 200,
                text: async () => JSON.stringify({ success: true })
            }))
        );
    });

    afterEach(() => {
        vi.unstubAllGlobals();
    });

    it('builds and executes every node module with mocked dependencies', async () => {
        const nodeSchemas = getAllNodeSchemas();
        const nodeLibraryByModel = getNodeLibraryItems().reduce<Record<string, ReturnType<typeof getNodeLibraryItems>[number]>>((acc, item) => {
            acc[item.modelId] = item;
            return acc;
        }, {});
        const workflow = createEmptyWorkflow('wf_node_catalog');
        workflow.nodeModels = nodeSchemas;
        workflow.input = {
            chatId: 'chat-1',
            subjectIds: ['sub-1']
        };

        for (const [index, nodeModule] of NODE_MODULES.entries()) {
            const libraryItem = nodeLibraryByModel[nodeModule.id];
            const node = nodeModule.buildInitialNode({
                nodeId: `node_${index + 1}`,
                nodeName: `${libraryItem.label} ${index + 1}`,
                schema: nodeSchemas[nodeModule.id],
                libraryItem,
                position: { x: index * 320, y: 120 }
            });

            if (node.modelId === 'http-request') {
                node.runtime = { ...(node.runtime ?? {}), url: 'http://localhost/test', method: 'GET' };
            }
            if (node.modelId === 'if-else') {
                node.runtime = {
                    ...(node.runtime ?? {}),
                    code: `const data = input;
return { true: data };`
                };
            }
            if (node.modelId === 'wait') {
                node.runtime = { ...(node.runtime ?? {}), time: 0, unit: 'seconds' };
            }
            if (node.modelId === 'stop-error') {
                node.runtime = { ...(node.runtime ?? {}), mode: 'stop' };
            }

            if (nodeModule.ui?.serverOnly) {
                expect(nodeModule.ui.localCapable).toBe(false);
                continue;
            }

            const result = await nodeModule.execute({
                node,
                workflow,
                settings: {
                    graphqlUrl: 'http://localhost/graphql',
                    authMode: WorkflowAuthModeEnum.None,
                    manualHeaders: {}
                },
                input: { input: { flag: true } }
            });

            expect(result).toBeTruthy();
            expect(Object.values(WorkflowNodeStatusEnum)).toContain(result.status ?? WorkflowNodeStatusEnum.Passed);
            expect(result).toHaveProperty('output');
        }
    });

    it('returns ordered workflow groups with required Giga group mappings and icons', () => {
        const items = getNodeLibraryItems();
        const byModelId = items.reduce<Record<string, (typeof items)[number]>>((acc, item) => {
            acc[item.modelId] = item;
            return acc;
        }, {});

        expect(byModelId.start.group).toBe('Flow Nodes');
        expect(byModelId['run-channel-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['run-category-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['run-subject-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['run-post-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['run-user-tree-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['run-chat-action'].group).toBe('Giga Action Nodes');
        expect(byModelId['ai-agent'].group).toBe('Giga AI Nodes');
        expect(byModelId['ai-governor'].group).toBe('Giga AI Nodes');
        expect(byModelId['text-analysis'].group).toBe('Giga AI Nodes');
        expect(byModelId['action-router'].group).toBe('Giga AI Nodes');
        expect(byModelId['chat-plan-policy'].group).toBe('Giga AI Nodes');
        expect(byModelId['validate-workflow-cypher'].group).toBe('Giga AI Nodes');
        expect(byModelId['workflow'].group).toBe('Giga AI Nodes');
        expect(byModelId['execute-workflow'].group).toBe('Flow Nodes');
        expect(byModelId['mcp-runtime'].group).toBe('MCP Group');
        expect(byModelId['output-format'].group).toBe('Output Nodes');
        expect(byModelId['create-subject']).toBeUndefined();
        expect(byModelId['agent-runtime']).toBeUndefined();
        expect(byModelId['giga-context']).toBeUndefined();

        items.forEach((item) => {
            expect(item.iconClass || item.renderIcon).toBeTruthy();
        });
    });
});
