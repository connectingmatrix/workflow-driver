import React from 'react';
import type { WorkspaceAction, WorkspaceIconName } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceActionButton } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceActionButton';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';

interface WorkspacePanelFrameProps {
    panelClassName?: string;
    bodyClassName?: string;
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
    accent?: boolean;
    headerAction?: WorkspaceAction;
    onAction?: (actionId: string) => void;
    children: React.ReactNode;
}

export const WorkspacePanelFrame: React.FC<WorkspacePanelFrameProps> = ({ panelClassName = '', bodyClassName = '', title, description, icon, accent = false, headerAction, onAction, children }) => {
    return (
        <section className={`cnw-panel ${panelClassName}`.trim()}>
            <div className={`cnw-panel__header${headerAction ? ' cnw-panel__header--with-action' : ''}`}>
                {accent ? <div className="cnw-panel__accent" /> : null}
                <div className="cnw-panel__title-row">
                    <div className="cnw-panel__icon-wrap">{icon ? <WorkspaceGlyph name={icon} className="cnw-panel__icon" /> : null}</div>
                    <div>
                        <h3 className="cnw-panel__title">{title}</h3>
                        {description ? <p className="cnw-panel__subtitle">{description}</p> : null}
                    </div>
                </div>
                {headerAction ? <WorkspaceActionButton action={headerAction} onClick={onAction} /> : null}
            </div>
            <div className={`cnw-panel__body ${bodyClassName}`.trim()}>{children}</div>
        </section>
    );
};
