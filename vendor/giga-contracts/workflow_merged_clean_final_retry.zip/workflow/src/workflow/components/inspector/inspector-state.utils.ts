import { parseEditableStringValue } from '@workflow/ui/workflow/utils/value-utils';

export { parseEditableStringValue };

export const buildPropertiesEditorState = (properties: Record<string, unknown>): Record<string, string> => {
    return Object.entries(properties).reduce<Record<string, string>>((acc, [key, value]) => {
        acc[key] = parseEditableStringValue(value);
        return acc;
    }, {});
};
