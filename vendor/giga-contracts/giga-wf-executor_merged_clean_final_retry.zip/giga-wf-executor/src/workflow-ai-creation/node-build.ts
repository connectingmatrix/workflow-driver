import type { WorkflowNodeModel, WorkflowNodeSchema } from '../types';
import { WorkflowCypherNodeSpec } from './types';

function cleanSegment(value: string) {
  return String(value || 'node')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || 'node';
}

function titleFor(schema: any, spec: WorkflowCypherNodeSpec, sequence: number) {
  return spec.name || schema?.documentation?.nodeTypeLabel || schema?.id || `Node ${sequence}`;
}

function defaultRuntime(schema: any) {
  return Object.entries(schema?.fields || {}).reduce<Record<string, unknown>>((acc, [key, value]: [string, any]) => {
    if (Object.prototype.hasOwnProperty.call(value || {}, 'defaultValue')) acc[key] = value.defaultValue;
    return acc;
  }, {});
}

function portInput(schema: any) {
  return Object.keys(schema?.inputs || {}).reduce<Record<string, Record<string, unknown>>>((acc, key) => {
    acc[key] = {};
    return acc;
  }, {});
}

function portOutput(schema: any) {
  return Object.keys(schema?.outputs || {}).reduce<Record<string, unknown>>((acc, key) => {
    acc[key] = null;
    return acc;
  }, {});
}

function viewers(schema: any) {
  return (schema?.outputViewers || []).map((viewer: any) => ({
    id: viewer.id || 'json',
    label: viewer.label || viewer.id || 'JSON',
    type: viewer.type || 'json',
    value: null,
  }));
}

export function buildWorkflowNode(spec: WorkflowCypherNodeSpec, schema: WorkflowNodeSchema, sequence: number): WorkflowNodeModel {
  const id = `${cleanSegment(spec.modelId)}-${sequence}`;
  const runtime = { ...defaultRuntime(schema), ...spec.runtime };
  const ports = { in: portInput(schema), out: portOutput(schema) };
  const name = titleFor(schema, spec, sequence);
  return {
    id,
    gigaId: id,
    modelId: spec.modelId,
    type: 'workflowStep',
    name,
    description: String(runtime.description || (schema?.documentation as any)?.summary || ''),
    kind: spec.modelId === 'respond-end' ? 'output' : spec.modelId === 'stop-error' ? 'error' : 'process',
    status: 'stopped',
    position: { x: 140 + sequence * 260, y: 180 + (sequence % 2) * 80 },
    runtime,
    ports,
    input: ports.in.input || {},
    output: ports.out.output ?? null,
    properties: runtime,
    render: schema?.render || {},
    inspector: {
      title: name,
      input: ports.in.input || {},
      properties: runtime,
      fields: schema?.fields || {},
      code: String(runtime.code || ''),
      markdown: String(runtime.markdown || ''),
      viewers: viewers(schema),
    },
  } as WorkflowNodeModel;
}
