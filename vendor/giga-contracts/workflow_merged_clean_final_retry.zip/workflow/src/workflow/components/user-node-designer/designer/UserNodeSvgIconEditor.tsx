import React from 'react';
import { InputTextarea } from 'primereact/inputtextarea';

interface UserNodeSvgIconEditorProps {
    iconSvg: string;
    onChange: (value: string) => void;
}

const UserNodeSvgIconEditor: React.FC<UserNodeSvgIconEditorProps> = ({ iconSvg, onChange }) => (
    <div className="wf-user-node-designer__svg-editor">
        <InputTextarea
            value={iconSvg}
            onChange={(event) => onChange(event.target.value)}
            autoResize
            rows={8}
            className="w-full"
            placeholder="Paste inline SVG markup. Use currentColor to inherit the chosen icon color."
            data-cy="user-node-icon-svg-input"
        />
        <div className="wf-user-node-designer__svg-help">SVG mode renders the saved markup directly on the canvas and in the node library.</div>
    </div>
);

export default UserNodeSvgIconEditor;
