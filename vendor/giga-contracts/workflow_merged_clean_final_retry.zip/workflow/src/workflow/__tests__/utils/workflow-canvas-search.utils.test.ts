import { describe, expect, it } from 'vitest';
import type { WorkflowNodeCatalog } from '@workflow/ui/workflow/driver';
import type { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { findWorkflowCanvasSearchMatches } from '@workflow/ui/workflow/utils/workflow-canvas-search.utils';

const workflow = {
    metadata: { id: 'wf', name: 'Workflow' },
    nodes: [
        { id: 'node-start', modelId: 'start', name: 'Start', position: { x: 0, y: 0 } },
        { id: 'node-code', modelId: 'code', name: 'Code Transform', position: { x: 200, y: 0 } },
        { id: 'node-ai', modelId: 'ai-governor', name: 'AI Governor', position: { x: 400, y: 0 } }
    ],
    connections: [],
    nodeModels: []
} as unknown as WorkflowDefinition;

const nodeCatalog = {
    getAllNodeSchemas: () => [],
    resolveNodeSchema: (modelId: string) => ({
        modelId,
        label: modelId === 'code' ? 'Code' : modelId === 'ai-governor' ? 'AI Governor' : 'Start',
        group: modelId === 'ai-governor' ? 'Giga AI Nodes' : 'Flow Nodes',
        documentation: { nodeTypeLabel: modelId === 'code' ? 'Code node' : undefined },
        description: modelId === 'code' ? 'Transform payloads' : 'Node'
    })
} as unknown as Pick<WorkflowNodeCatalog, 'resolveNodeSchema' | 'getAllNodeSchemas'>;

describe('findWorkflowCanvasSearchMatches', () => {
    it('matches node names first and returns ordered node ids', () => {
        expect(findWorkflowCanvasSearchMatches(workflow, 'code transform', nodeCatalog)).toEqual(['node-code']);
    });

    it('falls back to schema labels and descriptions and keeps best score first', () => {
        expect(findWorkflowCanvasSearchMatches(workflow, 'node', nodeCatalog)).toEqual(['node-start', 'node-ai', 'node-code']);
        expect(findWorkflowCanvasSearchMatches(workflow, 'transform payloads', nodeCatalog)).toEqual(['node-code']);
    });

    it('returns empty list for empty or unmatched searches', () => {
        expect(findWorkflowCanvasSearchMatches(workflow, '', nodeCatalog)).toEqual([]);
        expect(findWorkflowCanvasSearchMatches(workflow, 'missing', nodeCatalog)).toEqual([]);
    });
});
