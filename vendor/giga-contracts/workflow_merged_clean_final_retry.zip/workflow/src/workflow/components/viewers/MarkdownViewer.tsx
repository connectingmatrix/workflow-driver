import React from 'react';
import MarkdownRenderer from '@workflow/ui/workflow/components/chat/MarkdownRenderer';

interface MarkdownViewerProps {
    content: string;
}

const MarkdownViewer: React.FC<MarkdownViewerProps> = ({ content }) => {
    return (
        <div className="wf-markdown-viewer">
            <MarkdownRenderer content={content} />
        </div>
    );
};

export default MarkdownViewer;
