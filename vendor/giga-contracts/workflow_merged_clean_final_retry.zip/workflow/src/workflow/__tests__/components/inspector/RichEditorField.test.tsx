// @vitest-environment jsdom
import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import RichEditorField from '@workflow/ui/workflow/components/form/rich-editor-field';

const editorHarness = vi.hoisted(() => ({
    convert: vi.fn((value: unknown) => ({ ops: [value] })),
    setContents: vi.fn(),
    setText: vi.fn(),
    hasFocus: vi.fn(() => false)
}));

vi.mock('primereact/editor', async () => {
    const ReactModule = await vi.importActual<typeof import('react')>('react');

    return {
        Editor: ({
            value,
            onTextChange,
            onLoad
        }: {
            value?: string;
            onTextChange?: (event: { htmlValue: string | null; textValue: string; delta: unknown; source?: string }) => void;
            onLoad?: (quill: unknown) => void;
        }) => {
            ReactModule.useEffect(() => {
                onLoad?.({
                    clipboard: { convert: editorHarness.convert },
                    setContents: editorHarness.setContents,
                    setText: editorHarness.setText,
                    hasFocus: editorHarness.hasFocus
                });
            }, [onLoad]);
            return ReactModule.createElement(
                'div',
                null,
                ReactModule.createElement('div', { 'data-testid': 'editor-value' }, value),
                ReactModule.createElement('button', { type: 'button', onClick: () => onTextChange?.({ htmlValue: '<p>api reset</p>', textValue: 'api reset', delta: {}, source: 'api' }) }, 'Emit API Change'),
                ReactModule.createElement('button', { type: 'button', onClick: () => onTextChange?.({ htmlValue: '<p>user prompt</p>', textValue: 'user prompt', delta: {}, source: 'user' }) }, 'Emit User Change'),
                ReactModule.createElement('button', { type: 'button', onClick: () => onTextChange?.({ htmlValue: '<p>browser prompt</p>', textValue: 'browser prompt', delta: {} }) }, 'Emit Browser Change')
            );
        }
    };
});

describe('RichEditorField', () => {
    beforeEach(() => {
        editorHarness.convert.mockClear();
        editorHarness.setContents.mockClear();
        editorHarness.setText.mockClear();
        editorHarness.hasFocus.mockClear();
        editorHarness.hasFocus.mockReturnValue(false);
    });

    it('ignores controlled editor api changes while preserving user edits', () => {
        const onChange = vi.fn();
        render(<RichEditorField value="<p>saved prompt</p>" onChange={onChange} />);

        fireEvent.click(screen.getByRole('button', { name: 'Emit API Change' }));
        expect(onChange).not.toHaveBeenCalled();

        fireEvent.click(screen.getByRole('button', { name: 'Emit User Change' }));
        expect(onChange).toHaveBeenCalledWith('<p>user prompt</p>');

        fireEvent.click(screen.getByRole('button', { name: 'Emit Browser Change' }));
        expect(onChange).toHaveBeenCalledWith('<p>browser prompt</p>');
    });

    it('hydrates saved html with the Quill 2 clipboard contract', async () => {
        render(<RichEditorField value="<h2>saved prompt</h2>" onChange={() => undefined} />);

        await waitFor(() => {
            expect(editorHarness.convert).toHaveBeenCalledWith({ html: '<h2>saved prompt</h2>', text: '' });
        });
        expect(editorHarness.setContents).toHaveBeenCalledWith({ ops: [{ html: '<h2>saved prompt</h2>', text: '' }] }, 'api');
    });
});
