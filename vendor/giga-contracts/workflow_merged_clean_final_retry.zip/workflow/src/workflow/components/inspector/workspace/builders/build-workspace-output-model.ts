import type { WorkflowExecutionResult, WorkflowInspectorConfig, WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowInspectorModuleDefinition } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';
import type { WorkspaceOutputActivityItem, WorkspaceOutputPanelModel, WorkspaceOutputSummary } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WORKSPACE_ACTION_IDS } from '@workflow/ui/workflow/components/inspector/workspace/constants';
import { describeWorkspaceOutputShape } from '@workflow/ui/workflow/components/inspector/workspace/utils/workspace-output.utils';

interface BuildWorkspaceOutputModelArgs {
    config: WorkflowInspectorConfig;
    moduleDefinition: WorkflowInspectorModuleDefinition | null;
    propertiesEditorState: Record<string, unknown>;
    activeTab: string;
    executionResult: WorkflowExecutionResult | null;
    renderedMarkdown: string;
}

const buildOutputSummary = (viewer: WorkflowInspectorViewer | null, summaryTip?: string): WorkspaceOutputSummary | undefined => {
    if (!viewer) return undefined;
    const shape = describeWorkspaceOutputShape(viewer.value);
    if (viewer.type === WorkflowViewerTypeEnum.Json && viewer.value && typeof viewer.value === 'object' && !Array.isArray(viewer.value) && Object.keys(viewer.value as Record<string, unknown>).length === 0) {
        return {
            title: 'Output summary',
            description: 'The node returned an empty object. Add fields to the return statement to expose values downstream.',
            tip: summaryTip
        };
    }
    return {
        title: 'Output summary',
        description: `The current ${viewer.label.toLowerCase()} viewer resolved to a ${shape}.`,
        tip: summaryTip
    };
};

const buildOutputActivities = (executionResult: WorkflowExecutionResult | null, viewer: WorkflowInspectorViewer | null): WorkspaceOutputActivityItem[] => {
    if (!executionResult && !viewer) {
        return [];
    }
    const activities: WorkspaceOutputActivityItem[] = [];
    if (executionResult) {
        activities.push({
            id: 'execution',
            title: executionResult.error ? 'Execution failed' : 'Execution complete',
            description: executionResult.error || (executionResult.logs.length > 0 ? `${executionResult.logs.length} log line(s) captured.` : 'No warnings or errors detected.'),
            tone: executionResult.error ? 'danger' : 'success'
        });
    }
    if (viewer) {
        activities.push({
            id: 'viewer',
            title: 'Viewer updated',
            description: `${viewer.label} preview refreshed.`,
            tone: 'info'
        });
        activities.push({
            id: 'shape',
            title: 'Schema unchanged',
            description: `Output type remains ${describeWorkspaceOutputShape(viewer.value)}.`,
            tone: 'default'
        });
    }
    return activities;
};

export const buildWorkspaceOutputPanelModel = ({
    config,
    moduleDefinition,
    propertiesEditorState,
    activeTab,
    executionResult,
    renderedMarkdown
}: BuildWorkspaceOutputModelArgs): WorkspaceOutputPanelModel => {
    const liveViewers = config.viewers.map((viewer) => {
        if (!executionResult) {
            return viewer;
        }
        if (viewer.type === WorkflowViewerTypeEnum.Markdown) {
            return { ...viewer, value: renderedMarkdown || executionResult.output };
        }
        if (viewer.type === WorkflowViewerTypeEnum.Table) {
            return {
                ...viewer,
                value: Array.isArray(executionResult.output)
                    ? executionResult.output
                    : (executionResult.output as { rows?: unknown[] } | null)?.rows ?? executionResult.output
            };
        }
        return {
            ...viewer,
            value: executionResult.output
        };
    });
    const resolvedViewers =
        moduleDefinition?.workspace?.output?.resolveViewers?.({
            config,
            viewers: liveViewers,
            propertiesEditorState,
            executionResult,
            renderedMarkdown
        }) ?? liveViewers;
    const tabs = resolvedViewers.map((viewer) => ({ id: viewer.id, label: viewer.label }));
    const activeViewer = resolvedViewers.find((viewer) => viewer.id === activeTab) ?? resolvedViewers[0] ?? null;
    return {
        title: 'Output',
        description: 'Review structured output from this node',
        icon: moduleDefinition?.workspace?.output?.icon ?? 'json',
        tabs,
        activeTab: activeViewer?.id ?? '',
        copyAction: {
            id: WORKSPACE_ACTION_IDS.CopyOutput,
            label: 'Copy',
            tone: 'secondary'
        },
        status: executionResult
            ? {
                  label: executionResult.error ? 'Failed' : 'Ready',
                  tone: executionResult.error ? 'danger' : 'success',
                  meta: executionResult.error ? 'Last run • with errors' : 'Last run • just now'
              }
            : undefined,
        summary: buildOutputSummary(activeViewer, moduleDefinition?.workspace?.output?.summaryTip),
        activities: buildOutputActivities(executionResult, activeViewer),
        editor: {
            height: 230,
            theme: 'vs-dark',
            language: activeViewer?.type === WorkflowViewerTypeEnum.Raw ? 'text' : 'json',
            options: {
                minimap: { enabled: false },
                readOnly: true,
                lineNumbersMinChars: 2,
                scrollBeyondLastLine: false,
                renderLineHighlight: 'none',
                folding: false,
                fontSize: 13,
                padding: { top: 14, bottom: 14 }
            }
        },
        activeViewer,
        renderedMarkdown
    };
};
