import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { basename, dirname, join, relative } from 'node:path';
import { WorkflowNodeSource } from './types';

const requireFromHere = createRequire(join(process.cwd(), 'package.json'));
let sourceCache: WorkflowNodeSource[] | null = null;

function packageRoot() {
    const localSource = join(process.cwd(), '../workflow-nodes/src');
    if (existsSync(join(localSource, 'nodes'))) return localSource;
    return dirname(requireFromHere.resolve('@workflow/nodes'));
}

function nodesRoot() {
    const root = join(packageRoot(), 'nodes');
    if (!existsSync(root)) throw new Error('@workflow/nodes package does not expose src/nodes.');
    return root;
}

function schemaFiles(root: string): string[] {
    const files: string[] = [];
    for (const entry of readdirSync(root, { withFileTypes: true })) {
        const path = join(root, entry.name);
        if (entry.isDirectory()) files.push(...schemaFiles(path));
        if (entry.isFile() && entry.name.endsWith('-schema.json')) files.push(path);
    }
    return files;
}

function readOptional(path: string) {
    return existsSync(path) ? readFileSync(path, 'utf8') : '';
}

function tsSourceFiles(directory: string, root = directory, output: Record<string, string> = {}): Record<string, string> {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
        const fullPath = join(directory, entry.name);
        if (entry.isDirectory()) {
            if (entry.name === '__tests__') continue;
            tsSourceFiles(fullPath, root, output);
            continue;
        }
        if (!entry.isFile() || !entry.name.endsWith('.ts') || entry.name.endsWith('.test.ts')) continue;
        output[relative(root, fullPath)] = readFileSync(fullPath, 'utf8');
    }
    return output;
}

export function workflowNodeSources() {
    if (sourceCache) return sourceCache;
    sourceCache = schemaFiles(nodesRoot())
        .map((schemaPath) => {
            const schemaText = readFileSync(schemaPath, 'utf8');
            const schema = JSON.parse(schemaText);
            const directory = dirname(schemaPath);
            return {
                id: String(schema.id || basename(directory)).trim(),
                schema,
                schemaText,
                readme: readOptional(join(directory, 'README.md')),
                worker: readOptional(join(directory, 'worker.ts')),
                sourceFiles: tsSourceFiles(directory),
                directory
            };
        })
        .filter((source) => source.id);
    return sourceCache;
}

export function workflowNodeById() {
    return workflowNodeSources().reduce<Record<string, WorkflowNodeSource>>((acc, source) => {
        acc[source.id] = source;
        return acc;
    }, {});
}

export function selectedWorkflowNodeSources(modelIds: string[]) {
    const byId = workflowNodeById();
    return modelIds.map((id) => byId[String(id || '').trim()]).filter(Boolean);
}
