import { WorkflowRuntimeSettings } from '../../../types';

export const WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS = [50, 100, 150, 200, 250, 300] as const;
export const DEFAULT_WORKFLOW_MAX_EXECUTION_SECONDS = 300;

export type WorkflowMaxExecutionSeconds = (typeof WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS)[number];

export const normalizeWorkflowMaxExecutionSeconds = (value: unknown): number => {
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed > 0) {
        return Math.round(parsed);
    }
    return DEFAULT_WORKFLOW_MAX_EXECUTION_SECONDS;
};

export const resolveWorkflowExecutionTimeoutMs = (settings?: Pick<WorkflowRuntimeSettings, 'maxExecutionSeconds'> | null): number => {
    const seconds = normalizeWorkflowMaxExecutionSeconds(settings?.maxExecutionSeconds);
    return seconds * 1000;
};

export interface WorkflowExecutionTimeoutController {
    cleanup: () => void;
    didTimeout: () => boolean;
    signal: AbortSignal;
    timeoutMs: number;
}

export const createWorkflowExecutionTimeoutController = (params: {
    label?: string;
    settings?: Pick<WorkflowRuntimeSettings, 'maxExecutionSeconds'> | null;
    signal?: AbortSignal;
} = {}): WorkflowExecutionTimeoutController => {
    const timeoutMs = resolveWorkflowExecutionTimeoutMs(params.settings);
    const label = params.label?.trim() || 'Workflow execution';
    const controller = new AbortController();
    let timedOut = false;

    const onAbort = (): void => {
        if (!controller.signal.aborted) {
            controller.abort(params.signal?.reason);
        }
    };

    if (params.signal) {
        if (params.signal.aborted) {
            onAbort();
        } else {
            params.signal.addEventListener('abort', onAbort, { once: true });
        }
    }

    const timeoutId = setTimeout(() => {
        timedOut = true;
        if (!controller.signal.aborted) {
            controller.abort(new Error(`${label} timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
        }
    }, timeoutMs);

    return {
        cleanup: () => {
            clearTimeout(timeoutId);
            params.signal?.removeEventListener('abort', onAbort);
        },
        didTimeout: () => timedOut,
        signal: controller.signal,
        timeoutMs
    };
};
