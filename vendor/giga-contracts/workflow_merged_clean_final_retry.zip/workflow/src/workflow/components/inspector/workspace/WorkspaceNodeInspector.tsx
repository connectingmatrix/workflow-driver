import React from 'react';
import { Dialog } from 'primereact/dialog';
import { useWorkflowNodeInspectorState } from '@workflow/ui/workflow/components/inspector/useWorkflowNodeInspectorState';
import type { NodeInspectorProps } from '@workflow/ui/workflow/components/inspector/node-inspector.types';
import { buildVariableSuggestionsFromContext } from '@workflow/ui/workflow/utils/workflow-variables.utils';
import { buildWorkspaceInspectorModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-inspector-model';
import { DEFAULT_WORKSPACE_INSPECTOR_FLAGS, WORKSPACE_ACTION_IDS } from '@workflow/ui/workflow/components/inspector/workspace/constants';
import { WorkspaceHeader } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceHeader';
import { WorkspaceInputPanel } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceInputPanel';
import { WorkspaceParametersPanel } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceParametersPanel';
import { WorkspaceOutputPanel } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceOutputPanel';
import { WorkspaceActionButton } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceActionButton';
import { buildWorkspaceCredentialSelectorModel } from '@workflow/ui/workflow/components/inspector/workspace/credentials/build-workspace-credential-selector-model';
import { useWorkspaceCredentialOptions } from '@workflow/ui/workflow/components/inspector/workspace/credentials/use-workspace-credential-options';
import { buildWorkspaceWorkflowSelectorModel } from '@workflow/ui/workflow/components/inspector/workspace/workflows/build-workspace-workflow-selector-model';
import { useWorkspaceWorkflowOptions } from '@workflow/ui/workflow/components/inspector/workspace/workflows/use-workspace-workflow-options';
import { useWorkspaceFieldOptions } from '@workflow/ui/workflow/components/inspector/workspace/selectors/use-workspace-field-options';
import { buildWorkspaceOutputEditorValue } from '@workflow/ui/workflow/components/inspector/workspace/utils/workspace-output.utils';
import '@workflow/ui/workflow/components/inspector/wf-inspector-layout.scss';
import '@workflow/ui/workflow/components/inspector/wf-inspector-viewers.scss';
import '@workflow/ui/workflow/components/inspector/workspace/workspace-inspector.scss';

const EMPTY_WORKFLOW_SCOPES: Array<'user' | 'organization'> = [];

const getDefaultInputTab = (config: NonNullable<NodeInspectorProps['config']>): string => {
    if (config.controlNodes && Object.keys(config.controlNodes).length > 0) {
        return 'control-nodes';
    }
    return 'table';
};

const WorkspaceNodeInspector: React.FC<NodeInspectorProps> = ({ visible, readOnly = false, config, fetchCredentials, fetchExecutableWorkflows, fetchNodeFieldOptions, onHide, onExecuteStep, onDraftChange, onSave, openCredentialManager }) => {
    const state = useWorkflowNodeInspectorState({ config, readOnly, onExecuteStep, onDraftChange, onSave });
    const inputPanelRef = React.useRef<HTMLDivElement | null>(null);
    const parametersPanelRef = React.useRef<HTMLDivElement | null>(null);
    const outputPanelRef = React.useRef<HTMLDivElement | null>(null);
    const [activeInputTab, setActiveInputTab] = React.useState<string>('table');
    const [activeParametersTab, setActiveParametersTab] = React.useState<string>('properties');
    const [activeInstructionTab, setActiveInstructionTab] = React.useState<string>('code');
    const [activeOutputTab, setActiveOutputTab] = React.useState<string>('');
    const [activePane, setActivePane] = React.useState<'input' | 'parameters' | 'output'>('parameters');
    const [compactPanes, setCompactPanes] = React.useState<boolean>(false);
    const lastVisibleNodeIdRef = React.useRef<string | null>(null);

    React.useEffect(() => {
        if (!visible || !config) {
            return;
        }
        if (lastVisibleNodeIdRef.current === config.nodeId) {
            return;
        }
        lastVisibleNodeIdRef.current = config.nodeId;
        setActiveInputTab(getDefaultInputTab(config));
        setActiveParametersTab('properties');
        setActiveInstructionTab(config.instruction.markdown ? 'markdown' : 'code');
        setActiveOutputTab(config.viewers[0]?.id ?? '');
    }, [config, visible]);

    React.useEffect(() => {
        if (visible) {
            return;
        }
        lastVisibleNodeIdRef.current = null;
    }, [visible]);
    React.useEffect(() => {
        if (typeof window === 'undefined') return;
        const onResize = (): void => setCompactPanes(window.innerWidth <= 1480);
        onResize();
        window.addEventListener('resize', onResize);
        return () => window.removeEventListener('resize', onResize);
    }, []);

    const requestClose = React.useCallback((): void => {
        if (state.canClose()) {
            onHide();
        }
    }, [onHide, state]);
    const forceClose = React.useCallback((): void => onHide(), [onHide]);

    const variableContext = React.useMemo<Record<string, unknown>>(
        () => ({
            ...(config?.input || {}),
            workflow: config?.workflowVariableContext ?? {}
        }),
        [config?.input, config?.workflowVariableContext]
    );
    const variableSuggestions = React.useMemo(() => buildVariableSuggestionsFromContext(variableContext), [variableContext]);
    const credentialOptionsState = useWorkspaceCredentialOptions({
        visible,
        serviceId: config?.useCredentials ?? null,
        fetchCredentials
    });
    const workflowOptionsState = useWorkspaceWorkflowOptions({
        visible,
        scopes: config?.useWorkflows ?? EMPTY_WORKFLOW_SCOPES,
        fetchExecutableWorkflows
    });
    const fieldOptionsState = useWorkspaceFieldOptions({
        visible,
        config,
        propertiesEditorState: state.propertiesEditorState,
        fetchNodeFieldOptions
    });

    const model = React.useMemo(() => {
        if (!config) return null;
        const inspectorModel = buildWorkspaceInspectorModel({
            config,
            propertiesEditorState: state.propertiesEditorState,
            activeInputTab,
            activeParametersTab,
            activeInstructionTab,
            activeOutputTab,
            executionResult: state.executionResult,
            isExecuting: state.isExecuting,
            renderedMarkdown: state.executionResult?.renderedMarkdown ?? '',
            hasUnsavedChanges: state.hasUnsavedChanges,
            readOnly
        });
        const rawCredentialId = state.propertiesEditorState.credentialId;
        const selectedCredentialId = typeof rawCredentialId === 'string' && rawCredentialId.trim() ? rawCredentialId.trim() : null;
        const credentialSelector = buildWorkspaceCredentialSelectorModel({
            serviceId: config.useCredentials ?? null,
            selectedCredentialId,
            options: credentialOptionsState.options,
            state: credentialOptionsState.status,
            message: credentialOptionsState.message
        });
        const rawWorkflowId = state.propertiesEditorState.workflowId;
        const selectedWorkflowId = typeof rawWorkflowId === 'string' && rawWorkflowId.trim() ? rawWorkflowId.trim() : null;
        const workflowSelector =
            config.useWorkflows?.length
                ? buildWorkspaceWorkflowSelectorModel({
                      selectedWorkflowId,
                      options: workflowOptionsState.options,
                      state: workflowOptionsState.status,
                      message: workflowOptionsState.message
                  })
                : undefined;

        return {
            ...inspectorModel,
            parameters: {
                ...inspectorModel.parameters,
                credentialSelector,
                workflowSelector,
                sections: inspectorModel.parameters.sections.map((section) => ({
                    ...section,
                    fields: section.fields.map((field) => {
                        const optionsState = fieldOptionsState[field.key];
                        if (!optionsState) return field;
                        return {
                            ...field,
                            definition: {
                                ...field.definition,
                                options: optionsState.options
                            },
                            helperText:
                                optionsState.status === 'loading'
                                    ? 'Loading options from the current tree path.'
                                    : optionsState.status === 'ready'
                                      ? field.helperText
                                      : optionsState.message || field.helperText
                        };
                    })
                }))
            }
        };
    }, [
        activeInputTab,
        activeInstructionTab,
        activeOutputTab,
        activeParametersTab,
        config,
        credentialOptionsState.message,
        credentialOptionsState.options,
        credentialOptionsState.status,
        fieldOptionsState,
        state.executionResult,
        state.isExecuting,
        state.hasUnsavedChanges,
        state.propertiesEditorState,
        readOnly,
        workflowOptionsState.message,
        workflowOptionsState.options,
        workflowOptionsState.status
    ]);

    const focusPanel = React.useCallback((panelId: 'input' | 'parameters' | 'output') => {
        const target = panelId === 'input' ? inputPanelRef.current : panelId === 'parameters' ? parametersPanelRef.current : outputPanelRef.current;
        target?.focus({ preventScroll: true });
    }, []);

    const copyOutput = React.useCallback(() => {
        if (!model) return;
        const text = buildWorkspaceOutputEditorValue(model.output.activeViewer);
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
            void navigator.clipboard.writeText(text);
        }
    }, [model]);

    const handleAction = React.useCallback(
        (actionId: string) => {
            switch (actionId) {
                case WORKSPACE_ACTION_IDS.RunNode:
                    void state.runCurrentCode();
                    return;
                case WORKSPACE_ACTION_IDS.SaveChanges:
                    state.saveChanges();
                    return;
                case WORKSPACE_ACTION_IDS.CloseNode:
                    requestClose();
                    return;
                case WORKSPACE_ACTION_IDS.Preview:
                    setActiveOutputTab((previous) => previous || config.viewers[0]?.id || '');
                    return;
                case WORKSPACE_ACTION_IDS.RefreshNode:
                    setActiveOutputTab((previous) => previous || config.viewers[0]?.id || '');
                    return;
                case WORKSPACE_ACTION_IDS.InspectNode:
                    setActiveParametersTab('properties');
                    return;
                case WORKSPACE_ACTION_IDS.CopyOutput:
                    copyOutput();
                    return;
                case WORKSPACE_ACTION_IDS.AddInput:
                    setActiveInputTab((previous) => previous || getDefaultInputTab(config));
                    return;
                default:
                    return;
            }
        },
        [config, copyOutput, focusPanel, requestClose, state]
    );

    if (!config || !model) {
        return null;
    }

    return (
        <Dialog visible={visible} onHide={requestClose} showHeader={false} className="wf-inspector-dialog wf-inspector-dialog--workspace" contentClassName="wf-inspector-dialog__content wf-inspector-dialog__content--workspace" modal dismissableMask style={{ width: 'min(98vw, 1780px)', height: 'min(96vh, 1160px)' }}>
            <div className="cnw-shell" data-cy="workflow-node-inspector" data-node-id={config.nodeId} data-node-title={model.header.title}>
                <WorkspaceHeader model={model.header} onAction={handleAction} onRename={(nextName) => state.setProperty('name', nextName)} />
                {compactPanes ? (
                    <div className="cnw-pane-tabs" role="tablist" aria-label="Inspector panes">
                        <button type="button" className={`cnw-pane-tab ${activePane === 'input' ? 'cnw-pane-tab--active' : ''}`} onClick={() => setActivePane('input')}>
                            Input
                        </button>
                        <button type="button" className={`cnw-pane-tab ${activePane === 'parameters' ? 'cnw-pane-tab--active' : ''}`} onClick={() => setActivePane('parameters')}>
                            Parameters
                        </button>
                        <button type="button" className={`cnw-pane-tab ${activePane === 'output' ? 'cnw-pane-tab--active' : ''}`} onClick={() => setActivePane('output')}>
                            Output
                        </button>
                    </div>
                ) : null}
                <div className="cnw-body">
                    <div ref={inputPanelRef} tabIndex={-1} className={`cnw-panel-anchor ${compactPanes && activePane !== 'input' ? 'cnw-panel-anchor--hidden' : ''}`} data-cy="workflow-inspector-input-panel">
                        <WorkspaceInputPanel
                            model={model.input}
                            showAcceptedFormats={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showAcceptedFormats}
                            showInputFeatures={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showInputFeatures}
                            onTabChange={setActiveInputTab}
                            onAction={handleAction}
                        />
                    </div>
                    <div ref={parametersPanelRef} tabIndex={-1} className={`cnw-panel-anchor ${compactPanes && activePane !== 'parameters' ? 'cnw-panel-anchor--hidden' : ''}`} data-cy="workflow-inspector-parameters-panel">
                        <WorkspaceParametersPanel
                            model={model.parameters}
                            readOnly={readOnly}
                            showParametersHero={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showParametersHero}
                            showBestPracticeHints={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showBestPracticeHints}
                            propertiesEditorState={state.propertiesEditorState}
                            onTabChange={setActiveParametersTab}
                            onInstructionTabChange={setActiveInstructionTab}
                            onFieldChange={readOnly ? () => undefined : state.setProperty}
                            onCodeChange={readOnly ? () => undefined : state.onCodeChange}
                            onMarkdownChange={readOnly ? () => undefined : state.onMarkdownChange}
                            onAction={handleAction}
                            onRefreshCredentialOptions={credentialOptionsState.reload}
                            onOpenCredentialManager={openCredentialManager}
                            variableContext={variableContext}
                            variableSuggestions={variableSuggestions}
                            inspectorColumns={config.inspectorColumns}
                            code={state.code}
                            markdown={state.markdown}
                        />
                    </div>
                    <div ref={outputPanelRef} tabIndex={-1} className={`cnw-panel-anchor ${compactPanes && activePane !== 'output' ? 'cnw-panel-anchor--hidden' : ''}`} data-cy="workflow-inspector-output-panel">
                        <WorkspaceOutputPanel model={model.output} showOutputSummary={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showOutputSummary} showRecentActivity={DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showRecentActivity} onTabChange={setActiveOutputTab} onAction={handleAction} />
                    </div>
                </div>
                {!readOnly && DEFAULT_WORKSPACE_INSPECTOR_FLAGS.showFooterAction && model.parameters.footerAction ? (
                    <footer className="cnw-shell__footer">
                        {state.hasUnsavedChanges ? (
                            <>
                                <WorkspaceActionButton action={{ id: 'discard-node-inspector-changes', label: 'Discard changes', tone: 'secondary' }} onClick={forceClose} />
                                <WorkspaceActionButton action={model.parameters.footerAction} onClick={handleAction} />
                            </>
                        ) : (
                            <WorkspaceActionButton action={{ id: 'close-node-inspector', label: 'Close', tone: 'secondary' }} onClick={forceClose} />
                        )}
                    </footer>
                ) : null}
            </div>
        </Dialog>
    );
};

export default WorkspaceNodeInspector;
