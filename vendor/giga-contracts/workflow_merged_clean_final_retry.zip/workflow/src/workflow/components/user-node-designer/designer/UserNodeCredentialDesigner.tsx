import React from 'react';

interface UserNodeCredentialDesignerProps {
    useCredentials: string;
    onChange: (value: string) => void;
}

const UserNodeCredentialDesigner: React.FC<UserNodeCredentialDesignerProps> = ({ useCredentials, onChange }) => {
    return (
        <div className="wf-user-node-designer__section">
            <div className="wf-user-node-designer__section-header">
                <div>
                    <h4>Credential Binding</h4>
                    <p>Set the service id that this node should request credentials for at runtime. Leave empty if the node does not require stored credentials.</p>
                </div>
            </div>
            <div className="wf-user-node-designer__card-grid">
                <label>
                    <span>Service Id</span>
                    <input
                        type="text"
                        value={useCredentials}
                        onChange={(event) => onChange(event.target.value)}
                        placeholder="openai"
                        data-cy="user-node-use-credentials"
                    />
                </label>
            </div>
        </div>
    );
};

export default UserNodeCredentialDesigner;
