import { Edge, Node, ReactFlowInstance } from '@xyflow/react';

export type WorkflowFlowNode = Node<Record<string, unknown>>;
export type WorkflowFlowEdge = Edge;
export type WorkflowFlowInstance = ReactFlowInstance<WorkflowFlowNode, WorkflowFlowEdge>;
