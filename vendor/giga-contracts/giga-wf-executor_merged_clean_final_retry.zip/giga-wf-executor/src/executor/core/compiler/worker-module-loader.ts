import {
    WorkerExecuteHelpers,
    WorkerModuleExports,
    WorkerPayload,
    WorkerRuntimeEnvironment,
    WorkerScope,
    WorkerSelfState,
    WorkerUpdateResult,
    WorkerValidateResult,
    WorkflowDefinition,
    WorkflowNodeHandler,
    WorkflowNodeHandlerContext,
    WorkflowNodeHandlerResult,
    WorkflowNodeModel,
    WorkflowNodePorts,
    WorkflowNodeStatusEnum,
    WorkflowPreviewValidationSummary,
    WorkflowSourceFiles
} from '../../../types';
import {
    createCompileWorkflowCypherHelper,
    createExecuteBackendHelper,
    createExecuteGigaServiceHelper,
    createInvokeConnectedNodeHelper,
    createUpdateNodeHelper,
    globalWorkerHelpers
} from './worker-helper-bindings';
import {
    createNodeExecutorSignature,
    fromBase64,
    TypeScriptModuleLoader
} from './typescript-compiler';

type WorkerValidatorModuleExports = {
    validate?: (payload: WorkerPayload) => Promise<unknown> | unknown;
    default?: ((payload: WorkerPayload) => Promise<unknown> | unknown) | Record<string, unknown>;
};

const MAX_ON_UPDATE_REENTRY = 6;

export interface WorkerCompiledModuleLoaderArgs {
    source: string;
    modelId: string;
    helperId: string;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    sourceSignature: string;
    typescriptModuleLoader?: TypeScriptModuleLoader;
    moduleLabel: 'worker' | 'validator';
}

export type WorkerCompiledModuleLoader = (params: WorkerCompiledModuleLoaderArgs) => Promise<Record<string, unknown>>;

export const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as T)
        : ({} as T);

const normalizeStatus = (status: unknown): WorkflowNodeStatusEnum => {
    if (status === WorkflowNodeStatusEnum.Failed) return WorkflowNodeStatusEnum.Failed;
    if (status === WorkflowNodeStatusEnum.Warning) return WorkflowNodeStatusEnum.Warning;
    if (status === WorkflowNodeStatusEnum.Running) return WorkflowNodeStatusEnum.Running;
    if (status === WorkflowNodeStatusEnum.Stopped) return WorkflowNodeStatusEnum.Stopped;
    return WorkflowNodeStatusEnum.Passed;
};

export const normalizeResult = (result: unknown): WorkflowNodeHandlerResult => {
    if (!result || typeof result !== 'object' || Array.isArray(result)) {
        return {
            output: result ?? null,
            status: WorkflowNodeStatusEnum.Passed,
            logs: []
        };
    }

    const record = result as Record<string, unknown>;
    const logs = Array.isArray(record.logs)
        ? record.logs.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
        : [];

    return {
        output: Object.prototype.hasOwnProperty.call(record, 'output') ? record.output : record,
        status: normalizeStatus(record.status),
        logs,
        ...(record.skipCommandPeerAutoRun === true ? { skipCommandPeerAutoRun: true } : {})
    };
};

export const toErrorResult = (
    message: unknown,
    logs: string[] = [],
    previewValidation: WorkflowPreviewValidationSummary | null = null
): WorkflowNodeHandlerResult => ({
    output: { error: String(message) },
    status: WorkflowNodeStatusEnum.Failed,
    logs: [...logs, String(message)],
    previewValidation
});

const mergePreviewValidation = (
    base: WorkflowPreviewValidationSummary | null,
    next: WorkerValidateResult
): WorkflowPreviewValidationSummary => {
    const warnings = [...(base?.warnings ?? []), ...(next.warnings ?? [])];
    const errors = [...(base?.errors ?? []), ...(next.errors ?? [])];
    return {
        ok: (base?.ok ?? true) && next.ok,
        warnings,
        errors,
        normalizedRuntime: Object.keys(next.normalizedRuntime ?? {}).length > 0 ? next.normalizedRuntime : base?.normalizedRuntime
    };
};

const toNodePortsFacade = (node: WorkflowNodeModel): Record<string, unknown> => {
    const portsIn = toRecord(node.ports?.in);
    const portsOut = toRecord(node.ports?.out);
    const facade: Record<string, unknown> = {
        IN: portsIn,
        OUT: portsOut
    };

    Object.entries(portsIn).forEach(([portId, value]) => {
        facade[portId.toUpperCase()] = value;
    });

    return facade;
};

const toNodeFacade = (
    node: WorkflowNodeModel,
    credential: WorkflowNodeHandlerContext['credential'] = null,
    controlNodes: WorkerPayload['NODE']['CONTROL_NODES'] = {}
): WorkerPayload['NODE'] => ({
    ...node,
    PORTS: toNodePortsFacade(node),
    PROPERTIES: toRecord(node.runtime),
    OUTPUT: toRecord(node.ports?.out).output ?? null,
    CREDENTIAL: credential ?? null,
    CONTROL_NODES: controlNodes
});

export const toNode = (payload: unknown): WorkerPayload['NODE'] => {
    const root = toRecord(payload);
    return toRecord<WorkerPayload['NODE']>(root.NODE);
};

export const buildWorkerPayload = (
    context: WorkflowNodeHandlerContext,
    scope: WorkerScope,
    outputValue: unknown,
    runtimeEnvironment: WorkerRuntimeEnvironment,
    nodeOverride?: WorkflowNodeModel,
    controlNodes: WorkerPayload['NODE']['CONTROL_NODES'] = {}
): WorkerPayload => {
    const node = nodeOverride ?? context.node;
    const executionNode: WorkflowNodeModel = {
        ...node,
        ports: {
            in: Object.keys(context.input ?? {}).length > 0 ? context.input : toRecord<WorkflowNodePorts['in']>(node.ports?.in),
            out: toRecord<WorkflowNodePorts['out']>(node.ports?.out)
        }
    };
    const workflowMetadata: WorkflowDefinition['metadata'] = {
        ...(context.workflow.metadata ?? {}),
        runtime: {
            ...toRecord(context.workflow.metadata?.runtime),
            settings: context.settings
        }
    };

    return {
        workflow: {
            ...context.workflow,
            metadata: workflowMetadata
        },
        ENVIRONMENT: runtimeEnvironment,
        EXECUTOR: {
            environment: runtimeEnvironment
        },
        HOST_CONTEXT: context.hostContext,
        NODE_SCOPE: scope,
        NODE: toNodeFacade(executionNode, context.credential ?? null, controlNodes),
        self: {
            status: node.status,
            PORTS: executionNode.ports,
            OUTPUT: outputValue
        } satisfies WorkerSelfState
    };
};

export const normalizeValidationResult = (result: unknown): WorkerValidateResult => {
    if (result === true || typeof result === 'undefined') {
        return { ok: true, errors: [], warnings: [] };
    }

    if (result === false) {
        return {
            ok: false,
            errors: ['Worker validation failed.'],
            warnings: []
        };
    }

    const record = toRecord(result);
    return {
        ok: typeof record.ok === 'boolean' ? record.ok : true,
        errors: Array.isArray(record.errors)
            ? record.errors.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
            : [],
        warnings: Array.isArray(record.warnings)
            ? record.warnings.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
            : [],
        normalizedRuntime: toRecord(record.normalizedRuntime)
    };
};

export const normalizeUpdateResult = (result: unknown): WorkerUpdateResult => {
    if (result === false) {
        return {
            ok: false,
            error: 'Worker onUpdate returned false.'
        };
    }

    if (result === true || typeof result === 'undefined') {
        return { ok: true };
    }

    const record = toRecord(result);
    return {
        ok: typeof record.ok === 'boolean' ? record.ok : true,
        error: typeof record.error === 'string' ? record.error : undefined
    };
};

const toRuntimePatchedNode = (node: WorkflowNodeModel, normalizedRuntime?: Record<string, unknown>): WorkflowNodeModel => {
    if (!normalizedRuntime || Object.keys(normalizedRuntime).length === 0) return node;
    return {
        ...node,
        runtime: {
            ...(node.runtime ?? {}),
            ...normalizedRuntime
        }
    };
};

export const resolveNodeSourceFilesFromHelper = async (params: {
    executeHelpers?: WorkerExecuteHelpers;
    context: WorkflowNodeHandlerContext;
    modelId: string;
}): Promise<WorkflowSourceFiles | null> => {
    const workflowSourceFiles = (() => {
        const encoded = params.context.workflow.NODE_SOURCE_FILES?.[params.modelId];
        if (typeof encoded !== 'string' || !encoded.trim()) return {} as WorkflowSourceFiles;
        try {
            const parsed = JSON.parse(fromBase64(encoded)) as Record<string, unknown>;
            return Object.entries(parsed).reduce<WorkflowSourceFiles>((acc, [fileName, source]) => {
                if (typeof source === 'string' && source.trim()) acc[fileName] = source;
                return acc;
            }, {});
        } catch {
            return {} as WorkflowSourceFiles;
        }
    })();
    const runtimeSourceFiles = toRecord<Record<string, unknown>>(toRecord(params.context.node.runtime).__sourceFiles);
    const fallbackFromRuntime: WorkflowSourceFiles | null =
        Object.keys(runtimeSourceFiles).length === 0 && Object.keys(workflowSourceFiles).length === 0
            ? null
            : {
                  ...workflowSourceFiles,
                  ...(typeof runtimeSourceFiles['worker.ts'] === 'string' ? { 'worker.ts': runtimeSourceFiles['worker.ts'] } : {}),
                  ...(typeof runtimeSourceFiles['validate.ts'] === 'string' ? { 'validate.ts': runtimeSourceFiles['validate.ts'] } : {}),
                  ...Object.entries(runtimeSourceFiles).reduce<WorkflowSourceFiles>((acc, [fileName, source]) => {
                      if (fileName === 'worker.ts' || fileName === 'validate.ts') return acc;
                      if (typeof source === 'string' && source.trim()) acc[fileName] = source;
                      return acc;
                  }, {})
              };
    if (typeof params.executeHelpers?.resolveNodeSourceFiles !== 'function') {
        return fallbackFromRuntime && (fallbackFromRuntime['worker.ts'] || fallbackFromRuntime['validate.ts'])
            ? fallbackFromRuntime
            : null;
    }
    try {
        const resolved = await params.executeHelpers.resolveNodeSourceFiles({
            context: params.context,
            modelId: params.modelId
        });
        if (!resolved || typeof resolved !== 'object') return null;
        const normalized: WorkflowSourceFiles = {
            ...workflowSourceFiles,
            ...(typeof resolved['worker.ts'] === 'string' ? { 'worker.ts': resolved['worker.ts'] } : {}),
            ...(typeof resolved['validate.ts'] === 'string' ? { 'validate.ts': resolved['validate.ts'] } : {}),
            ...Object.entries(resolved).reduce<WorkflowSourceFiles>((acc, [fileName, source]) => {
                if (fileName === 'worker.ts' || fileName === 'validate.ts') return acc;
                if (typeof source === 'string' && source.trim()) acc[fileName] = source;
                return acc;
            }, {})
        };
        if (normalized['worker.ts'] || normalized['validate.ts']) {
            return normalized;
        }
        return fallbackFromRuntime && (fallbackFromRuntime['worker.ts'] || fallbackFromRuntime['validate.ts'])
            ? fallbackFromRuntime
            : null;
    } catch {
        return fallbackFromRuntime && (fallbackFromRuntime['worker.ts'] || fallbackFromRuntime['validate.ts'])
            ? fallbackFromRuntime
            : null;
    }
};

const decodeAndVerifySignedSource = (params: {
    modelId: string;
    encodedSource: string | undefined;
    expectedSignature: string | undefined;
    signatureRequiredMessage: string;
    sourceMissingMessage: string;
}): string => {
    if (typeof params.encodedSource !== 'string' || params.encodedSource.trim().length === 0) {
        throw new Error(params.sourceMissingMessage);
    }
    const source = fromBase64(params.encodedSource);
    const computedSignature = createNodeExecutorSignature(params.modelId, source);
    if (typeof params.expectedSignature !== 'string' || params.expectedSignature.trim().length === 0) {
        throw new Error(params.signatureRequiredMessage);
    }
    if (params.expectedSignature !== computedSignature) {
        throw new Error(`Worker signature mismatch for model "${params.modelId}".`);
    }
    return source;
};

export interface ResolvedWorkerSource {
    source: string;
    sourceSignature: string;
}

export const resolveWorkerSource = (params: {
    modelId: string;
    workflow: WorkflowDefinition;
    resolvedSourceFiles?: WorkflowSourceFiles | null;
}): ResolvedWorkerSource => {
    const encodedSource = params.workflow.NODE_EXECUTORS?.[params.modelId];
    const signature = params.workflow.NODE_EXECUTOR_SIGNATURES?.[params.modelId];
    const sourceFromResolver = params.resolvedSourceFiles?.['worker.ts'];
    const source =
        typeof sourceFromResolver === 'string' && sourceFromResolver.trim().length > 0
            ? sourceFromResolver
            : typeof encodedSource === 'string' && encodedSource.trim().length > 0
            ? decodeAndVerifySignedSource({
                  modelId: params.modelId,
                  encodedSource,
                  expectedSignature: signature,
                  sourceMissingMessage: `Missing NODE_EXECUTORS entry for model "${params.modelId}".`,
                  signatureRequiredMessage: `Missing NODE_EXECUTOR_SIGNATURES entry for model "${params.modelId}".`
              })
            : (() => {
                  throw new Error(`Missing NODE_EXECUTORS entry for model "${params.modelId}".`);
              })();
    const sourceSignature =
        typeof sourceFromResolver === 'string' && sourceFromResolver.trim().length > 0
            ? createNodeExecutorSignature(params.modelId, source)
            : typeof signature === 'string' && signature.trim().length > 0
            ? signature
            : createNodeExecutorSignature(params.modelId, source);

    return {
        source,
        sourceSignature
    };
};

export const resolvePreviewValidatorSource = (params: {
    modelId: string;
    workflow: WorkflowDefinition;
    resolvedSourceFiles?: WorkflowSourceFiles | null;
}): ResolvedWorkerSource | null => {
    const encodedSource = params.workflow.NODE_VALIDATORS?.[params.modelId];
    const signature = params.workflow.NODE_VALIDATOR_SIGNATURES?.[params.modelId];
    const sourceFromResolver = params.resolvedSourceFiles?.['validate.ts'];

    if (typeof sourceFromResolver === 'string' && sourceFromResolver.trim().length > 0) {
        return {
            source: sourceFromResolver,
            sourceSignature: createNodeExecutorSignature(`${params.modelId}:validator`, sourceFromResolver)
        };
    }

    if (typeof encodedSource !== 'string' || encodedSource.trim().length === 0) {
        return null;
    }

    const source = decodeAndVerifySignedSource({
        modelId: `${params.modelId}:validator`,
        encodedSource,
        expectedSignature: signature,
        sourceMissingMessage: `Missing NODE_VALIDATORS entry for model "${params.modelId}".`,
        signatureRequiredMessage: `Missing NODE_VALIDATOR_SIGNATURES entry for model "${params.modelId}".`
    });

    return {
        source,
        sourceSignature:
            typeof signature === 'string' && signature.trim().length > 0
                ? signature
                : createNodeExecutorSignature(`${params.modelId}:validator`, source)
    };
};

export const loadWorkerModule = async (params: {
    modelId: string;
    workflow: WorkflowDefinition;
    helperId: string;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    typescriptModuleLoader?: TypeScriptModuleLoader;
    resolvedSourceFiles?: WorkflowSourceFiles | null;
    loadCompiledModule: WorkerCompiledModuleLoader;
}): Promise<WorkerModuleExports> => {
    const { source, sourceSignature } = resolveWorkerSource({
        modelId: params.modelId,
        workflow: params.workflow,
        resolvedSourceFiles: params.resolvedSourceFiles
    });
    const workerModule = (await params.loadCompiledModule({
        source,
        modelId: params.modelId,
        helperId: params.helperId,
        runtimeEnvironment: params.runtimeEnvironment,
        sourceSignature,
        typescriptModuleLoader: params.typescriptModuleLoader,
        moduleLabel: 'worker'
    })) as Partial<WorkerModuleExports>;

    if (typeof workerModule.validate !== 'function') throw new Error(`Worker validate export is missing for model "${params.modelId}".`);
    if (typeof workerModule.init !== 'function') throw new Error(`Worker init export is missing for model "${params.modelId}".`);
    if (typeof workerModule.onUpdate !== 'function') throw new Error(`Worker onUpdate export is missing for model "${params.modelId}".`);
    if (typeof workerModule.execute !== 'function') throw new Error(`Worker execute export is missing for model "${params.modelId}".`);

    return workerModule as WorkerModuleExports;
};

export const loadPreviewValidator = async (params: {
    modelId: string;
    workflow: WorkflowDefinition;
    helperId: string;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    typescriptModuleLoader?: TypeScriptModuleLoader;
    resolvedSourceFiles?: WorkflowSourceFiles | null;
    loadCompiledModule: WorkerCompiledModuleLoader;
}): Promise<((payload: WorkerPayload) => Promise<unknown> | unknown) | null> => {
    const resolvedSource = resolvePreviewValidatorSource({
        modelId: params.modelId,
        workflow: params.workflow,
        resolvedSourceFiles: params.resolvedSourceFiles
    });

    if (!resolvedSource) {
        return null;
    }

    const module = (await params.loadCompiledModule({
        source: resolvedSource.source,
        modelId: `${params.modelId}:validator`,
        helperId: params.helperId,
        runtimeEnvironment: params.runtimeEnvironment,
        sourceSignature: resolvedSource.sourceSignature,
        typescriptModuleLoader: params.typescriptModuleLoader,
        moduleLabel: 'validator'
    })) as WorkerValidatorModuleExports;
    const validateExport =
        typeof module.validate === 'function'
            ? module.validate
            : typeof module.default === 'function'
            ? module.default
            : null;
    return validateExport;
};

export const createWorkerHelperId = (context: WorkflowNodeHandlerContext): string => {
    const workflowId = String(context.workflow.metadata.id || 'workflow');
    return `${workflowId}:${context.node.id}:${Date.now().toString(36)}:${Math.random().toString(36).slice(2)}`;
};

export interface RegisteredWorkerRuntimeHelpers {
    executeGigaService?: (...workerArgs: unknown[]) => Promise<WorkflowNodeHandlerResult>;
    executeBackend?: (...workerArgs: unknown[]) => Promise<WorkflowNodeHandlerResult>;
    compileWorkflowCypher?: (...workerArgs: unknown[]) => Promise<unknown>;
    invokeConnectedNode?: (...workerArgs: unknown[]) => Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }>;
    updateNode?: (workflow: unknown, nodeId: unknown, patch: unknown) => Promise<void> | void;
}

export const createRegisteredWorkerRuntimeHelpers = (params: {
    executeHelpers?: WorkerExecuteHelpers;
    context: WorkflowNodeHandlerContext;
}): RegisteredWorkerRuntimeHelpers => {
    const executeGigaServiceHelper = createExecuteGigaServiceHelper(params.executeHelpers, params.context);
    return {
        executeGigaService: executeGigaServiceHelper,
        executeBackend: createExecuteBackendHelper(params.executeHelpers, params.context) ?? executeGigaServiceHelper,
        compileWorkflowCypher: createCompileWorkflowCypherHelper(params.executeHelpers),
        invokeConnectedNode: createInvokeConnectedNodeHelper(params.executeHelpers, params.context),
        updateNode: createUpdateNodeHelper(params.executeHelpers, params.context, toRecord)
    };
};

export const registerWorkerRuntimeHelpers = (helperId: string, helpers: RegisteredWorkerRuntimeHelpers): void => {
    globalWorkerHelpers.__WF_EXECUTE_HELPERS__ = {
        ...(globalWorkerHelpers.__WF_EXECUTE_HELPERS__ ?? {}),
        [helperId]: helpers
    };
};

export const unregisterWorkerRuntimeHelpers = (helperId: string): void => {
    const helpers = globalWorkerHelpers.__WF_EXECUTE_HELPERS__ ?? {};
    delete helpers[helperId];
    globalWorkerHelpers.__WF_EXECUTE_HELPERS__ = helpers;
};

export const executeLoadedWorkerModuleLifecycle = async (params: {
    context: WorkflowNodeHandlerContext;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    module: WorkerModuleExports;
    previewValidator?: ((payload: WorkerPayload) => Promise<unknown> | unknown) | null;
    controlNodes?: WorkerPayload['NODE']['CONTROL_NODES'];
}): Promise<WorkflowNodeHandlerResult> => {
    let previewValidationSummary: WorkflowPreviewValidationSummary | null = null;

    try {
        const nodeScope: WorkerScope = {};
        const controlNodes = params.controlNodes ?? {};
        const initPayload = buildWorkerPayload(params.context, nodeScope, null, params.runtimeEnvironment, undefined, controlNodes);

        if (params.previewValidator) {
            const previewValidationResult = normalizeValidationResult(await params.previewValidator(initPayload));
            previewValidationSummary = mergePreviewValidation(previewValidationSummary, previewValidationResult);
            if (!previewValidationResult.ok) {
                const firstError = previewValidationResult.errors[0] ?? `Preview validation failed for node "${params.context.node.name}".`;
                return toErrorResult(firstError, previewValidationSummary.warnings ?? [], previewValidationSummary);
            }
        }

        await params.module.init(initPayload);
        await params.module.onUpdate(initPayload);

        const validationResult = normalizeValidationResult(
            await params.module.validate(buildWorkerPayload(params.context, nodeScope, null, params.runtimeEnvironment, undefined, controlNodes))
        );
        previewValidationSummary = mergePreviewValidation(previewValidationSummary, validationResult);
        if (!validationResult.ok) {
            const firstError = validationResult.errors[0] ?? `Worker validation failed for node "${params.context.node.name}".`;
            return toErrorResult(firstError, previewValidationSummary.warnings ?? [], previewValidationSummary);
        }

        const executionNode = toRuntimePatchedNode(params.context.node, validationResult.normalizedRuntime);
        const warningLogs = (previewValidationSummary?.warnings ?? []).map((entry) => `WARN ${entry}`);
        const preUpdateResult = normalizeUpdateResult(
            await params.module.onUpdate(buildWorkerPayload(params.context, nodeScope, null, params.runtimeEnvironment, executionNode, controlNodes))
        );
        if (!preUpdateResult.ok) {
            const message = preUpdateResult.error ?? `Worker onUpdate rejected node "${params.context.node.name}" before execute.`;
            return toErrorResult(message, warningLogs, previewValidationSummary);
        }

        let attempts = 0;
        let result = toErrorResult('Worker execution did not produce a result.', warningLogs, previewValidationSummary);

        while (attempts < MAX_ON_UPDATE_REENTRY) {
            attempts += 1;
            result = normalizeResult(
                await params.module.execute(buildWorkerPayload(params.context, nodeScope, result.output ?? null, params.runtimeEnvironment, executionNode, controlNodes))
            );
            const postUpdateResult = normalizeUpdateResult(
                await params.module.onUpdate(buildWorkerPayload(params.context, nodeScope, result.output ?? null, params.runtimeEnvironment, executionNode, controlNodes))
            );
            if (postUpdateResult.ok) {
                break;
            }
            if (attempts >= MAX_ON_UPDATE_REENTRY) {
                return toErrorResult(
                    `Worker execute reentry limit (${MAX_ON_UPDATE_REENTRY}) reached for node "${params.context.node.name}".`,
                    warningLogs,
                    previewValidationSummary
                );
            }
        }

        return {
            ...result,
            logs: [...warningLogs, ...(result.logs ?? [])],
            previewValidation: previewValidationSummary
        };
    } catch (error) {
        const message = error instanceof Error ? error.message : 'Worker execution failed.';
        return toErrorResult(message, [], previewValidationSummary);
    }
};
