import { WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT } from '../config';
import type { WorkflowQueueRunState, WorkflowQueueScheduler, WorkflowQueueSchedulerJob } from './types';

type UserExecutionQueue = {
  enqueue: (job: WorkflowQueueSchedulerJob, onComplete: () => void) => void;
  cancelRun: (runId: string) => number;
  cancelWorkflow: (workflowId: string) => number;
  pendingCount: () => number;
  activeCount: () => number;
  running: (workflowId?: string | null) => WorkflowQueueRunState[];
  close: (params?: { force?: boolean }) => Promise<void>;
};

export const resolveWorkflowUserParallelExecutionLimit = (settings?: { maxConcurrentExecutionsPerUser?: number } | null): number => {
  const parsed = Number(settings?.maxConcurrentExecutionsPerUser);
  return Number.isFinite(parsed) && parsed > 0 ? Math.round(parsed) : WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT;
};

export const createUserExecutionQueue = (): UserExecutionQueue => {
  const pending: WorkflowQueueSchedulerJob[] = [];
  const inFlight = new Map<string, { controller: AbortController; limit: number; promise: Promise<void>; state: WorkflowQueueRunState }>();
  const readQueueLimit = () => {
    const explicitLimits = pending
      .map((job) => Number(job.request.settings?.maxConcurrentExecutionsPerUser))
      .filter((value) => Number.isFinite(value) && value > 0)
      .concat(Array.from(inFlight.values()).map((entry) => entry.limit).filter((value) => value !== WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT));
    return explicitLimits.length ? Math.max(...explicitLimits.map((value) => Math.round(value))) : WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT;
  };
  const drain = () => {
    const effectiveLimit = readQueueLimit();
    while (pending.length > 0 && inFlight.size < effectiveLimit) {
      const next = pending.shift();
      if (!next) return;
      const limit = resolveWorkflowUserParallelExecutionLimit(next.request.settings);
      const controller = new AbortController();
      const state: WorkflowQueueRunState = { activeCount: inFlight.size + 1, broadcastChannelName: next.request.broadcastChannelName, broadcastId: next.request.broadcastId, effectiveConcurrency: effectiveLimit, executionId: next.request.executionId, queuedCount: pending.length, queueKey: next.request.queueKey, requestedConcurrency: limit, runId: next.request.runId, status: 'running', throttledBy: limit === WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT ? 'default' : 'plan', userId: next.request.userId, workflowId: next.request.workflowReference.workflowId };
      const running = next.execute(controller.signal).catch(() => undefined).finally(() => {
        inFlight.delete(next.request.runId);
        drain();
      });
      inFlight.set(next.request.runId, { controller, limit, promise: running, state });
    }
  };
  const cancelPending = (predicate: (job: WorkflowQueueSchedulerJob) => boolean) => {
    const kept = pending.filter((job) => !predicate(job));
    const removed = pending.length - kept.length;
    pending.splice(0, pending.length, ...kept);
    return removed;
  };
  const cancelActive = (predicate: (state: WorkflowQueueRunState) => boolean) => {
    let removed = 0;
    inFlight.forEach((entry) => {
      if (!predicate(entry.state)) return;
      removed += 1;
      entry.controller.abort();
    });
    return removed;
  };

  return {
    enqueue: (job, onComplete) => {
      pending.push({ ...job, execute: async (signal) => { try { await job.execute(signal); } finally { onComplete(); } } });
      drain();
    },
    cancelRun: (runId) => cancelPending((job) => job.request.runId === runId) + cancelActive((state) => state.runId === runId),
    cancelWorkflow: (workflowId) => cancelPending((job) => job.request.workflowReference.workflowId === workflowId) + cancelActive((state) => state.workflowId === workflowId),
    pendingCount: () => pending.length,
    activeCount: () => inFlight.size,
    running: (workflowId) => {
      const active = Array.from(inFlight.values()).map((entry) => entry.state);
      const effectiveLimit = readQueueLimit();
      const queued = pending.map((job) => ({ activeCount: inFlight.size, broadcastChannelName: job.request.broadcastChannelName, broadcastId: job.request.broadcastId, effectiveConcurrency: effectiveLimit, executionId: job.request.executionId, queuedCount: pending.length, queueKey: job.request.queueKey, requestedConcurrency: resolveWorkflowUserParallelExecutionLimit(job.request.settings), runId: job.request.runId, status: 'queued' as const, throttledBy: resolveWorkflowUserParallelExecutionLimit(job.request.settings) === WORKFLOW_USER_PARALLEL_EXECUTION_LIMIT ? 'default' as const : 'plan' as const, userId: job.request.userId, workflowId: job.request.workflowReference.workflowId }));
      return active.concat(queued).filter((entry) => !workflowId || entry.workflowId === workflowId);
    },
    close: async (params) => {
      if (params?.force) {
        pending.splice(0, pending.length);
        inFlight.forEach((entry) => entry.controller.abort());
      }
      await Promise.all(Array.from(inFlight.values()).map((entry) => entry.promise));
    },
  };
};

export const createWorkflowQueueScheduler = (): WorkflowQueueScheduler => {
  const queues = new Map<string, UserExecutionQueue>();
  const resolveQueue = (queueKey: string): UserExecutionQueue => {
    const current = queues.get(queueKey);
    if (current) return current;
    const created = createUserExecutionQueue();
    queues.set(queueKey, created);
    return created;
  };
  const cleanupQueue = (queueKey: string) => {
    const queue = queues.get(queueKey);
    if (queue && queue.pendingCount() === 0 && queue.activeCount() === 0) queues.delete(queueKey);
  };

  return {
    enqueue: (job) => resolveQueue(job.request.queueKey).enqueue(job, () => cleanupQueue(job.request.queueKey)),
    cancelRun: (runId) => Array.from(queues.values()).reduce((count, queue) => count + queue.cancelRun(runId), 0),
    cancelWorkflow: (workflowId) => Array.from(queues.values()).reduce((count, queue) => count + queue.cancelWorkflow(workflowId), 0),
    getPendingCount: (queueKey: string) => queues.get(queueKey)?.pendingCount() || 0,
    getActiveCount: (queueKey: string) => queues.get(queueKey)?.activeCount() || 0,
    getRunning: (workflowId) => Array.from(queues.values()).flatMap((queue) => queue.running(workflowId)),
    close: async (params) => {
      await Promise.all(Array.from(queues.values()).map((queue) => queue.close(params)));
      queues.clear();
    },
  };
};
