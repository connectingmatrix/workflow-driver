import { describe, expect, it } from 'vitest';
import outputFormatNodeModule from '@workflow/nodes/nodes/output-format/output-format-node';
import { createEmptyWorkflow, createWorkflowNode, createConnection } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WorkflowNodeFieldTypeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: 'none',
    manualHeaders: {}
} as const;

describe('output format node', () => {
    it('switches the value field editor with the selected format and exposes connected llm options', () => {
        const workflow = createEmptyWorkflow('wf_output_format_fields');
        const outputNode = createWorkflowNode(workflow, 'output-format', 'Output Format', 1);
        const llmNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        workflow.nodes = [outputNode, llmNode];
        workflow.connections = [createConnection('c1', llmNode.id, outputNode.id, 'cmd:command', 'cmd:llm')];
        outputNode.runtime = {
            ...(outputNode.runtime ?? {}),
            format: 'markdown',
            useAiFormatting: true
        };

        const fields = outputFormatNodeModule.resolveInspectorFields?.({
            workflow,
            node: outputNode,
            fields: outputFormatNodeModule.schema.fields
        });

        expect(fields?.value?.type).toBe(WorkflowNodeFieldTypeEnum.Markdown);
        expect(fields?.modelId?.hidden).toBe(false);
        expect(fields?.modelId?.options).toEqual([{ label: `OpenAI (${llmNode.modelId})`, value: llmNode.id }]);
        expect(fields?.aiPrompt?.hidden).toBe(false);
        expect(fields?.aiPrompt?.type).toBe(WorkflowNodeFieldTypeEnum.Markdown);
    });

    it('formats table output through the selected connected llm when ai formatting is enabled', async () => {
        const workflow = createEmptyWorkflow('wf_output_format_exec');
        const node = createWorkflowNode(workflow, 'output-format', 'Output Format', 1);
        const llmNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        workflow.nodes = [node, llmNode];
        workflow.connections = [createConnection('c1', llmNode.id, node.id, 'cmd:command', 'cmd:llm')];
        node.runtime = {
            ...(node.runtime ?? {}),
            format: 'table',
            value: [{ name: 'A', score: 1 }],
            useAiFormatting: true,
            aiPrompt: 'Format this nicely',
            modelId: llmNode.id
        };

        const result = await outputFormatNodeModule.execute({
            node,
            workflow,
            settings,
            invokeConnectedNode: async ({ nodeId, input, overrides }: any) => {
                expect(nodeId).toBe(llmNode.id);
                if (!input) {
                    return { node: { ...llmNode, status: WorkflowNodeStatusEnum.Passed }, result: { status: WorkflowNodeStatusEnum.Passed, output: {}, logs: [] } };
                }
                expect(input.input[node.id].requestedFormat).toBe('table');
                expect(input.input[node.id].originalOutput).toEqual([{ name: 'A', score: 1 }]);
                expect(String(overrides.runtime.prompt ?? '')).toContain('Format this nicely');
                return {
                    node: { ...llmNode, status: WorkflowNodeStatusEnum.Passed },
                    result: {
                        status: WorkflowNodeStatusEnum.Passed,
                        output: {
                            answer: {
                                text: JSON.stringify({
                                    columns: ['name', 'score', 'notes'],
                                    rows: [{ name: 'A', score: 1, notes: 'Expanded' }]
                                })
                            }
                        },
                        logs: ['llm formatted']
                    }
                };
            },
            input: {}
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain(`AI formatting executed through connected model ${llmNode.id}.`);
        expect(result.logs).toContain('llm formatted');
        expect(result.output).toEqual({
            columns: ['name', 'score', 'notes'],
            rows: [{ name: 'A', score: 1, notes: 'Expanded' }]
        });
    });

    it('falls back to the only connected llm when ai formatting is enabled without a saved model selection', async () => {
        const workflow = createEmptyWorkflow('wf_output_format_single_llm');
        const node = createWorkflowNode(workflow, 'output-format', 'Output Format', 1);
        const llmNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        workflow.nodes = [node, llmNode];
        workflow.connections = [createConnection('c1', llmNode.id, node.id, 'cmd:command', 'cmd:llm')];
        node.runtime = {
            ...(node.runtime ?? {}),
            format: 'markdown',
            value: { message: 'hello' },
            useAiFormatting: true,
            aiPrompt: 'Expand this'
        };

        const result = await outputFormatNodeModule.execute({
            node,
            workflow,
            settings,
            invokeConnectedNode: async ({ nodeId, input }: any) => {
                expect(nodeId).toBe(llmNode.id);
                if (!input) {
                    return { node: { ...llmNode, status: WorkflowNodeStatusEnum.Passed }, result: { status: WorkflowNodeStatusEnum.Passed, output: {}, logs: [] } };
                }
                expect(input.input[node.id].requestedFormat).toBe('markdown');
                return {
                    node: { ...llmNode, status: WorkflowNodeStatusEnum.Passed },
                    result: {
                        status: WorkflowNodeStatusEnum.Passed,
                        output: {
                            answer: {
                                text: 'Expanded markdown output'
                            }
                        },
                        logs: ['llm formatted']
                    }
                };
            },
            input: {}
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain(`AI formatting executed through connected model ${llmNode.id}.`);
        expect(result.output).toBe('Expanded markdown output');
    });
});
