import { describe, expect, it } from 'vitest';
import { WorkflowFlowNode } from '@workflow/ui/workflow/components/canvas/workflow-flow.types';
import { mergeCanvasNodes } from '@workflow/ui/workflow/utils/workflow-canvas-merge.utils';

const createNode = (id: string, x: number, y: number, dimensions?: { measured?: { width?: number; height?: number }; width?: number; height?: number }): WorkflowFlowNode => ({
    id,
    type: 'workflowStep',
    position: { x, y },
    data: {},
    ...(dimensions?.measured ? { measured: dimensions.measured } : {}),
    ...(dimensions?.width !== undefined ? { width: dimensions.width } : {}),
    ...(dimensions?.height !== undefined ? { height: dimensions.height } : {})
});

describe('workflow canvas merge', () => {
    it('keeps previous nodes when non-destructive update produces empty list', () => {
        const previous = [createNode('node_1', 10, 20)];
        const merged = mergeCanvasNodes(previous, [], 1, false);
        expect(merged).toHaveLength(1);
        expect(merged[0].id).toBe('node_1');
    });

    it('preserves drag position during interaction sync', () => {
        const previous = [createNode('node_1', 300, 220)];
        const next = [createNode('node_1', 50, 40)];
        const merged = mergeCanvasNodes(previous, next, 1, true);
        expect(merged[0].position.x).toBe(300);
        expect(merged[0].position.y).toBe(220);
    });

    it('retains prior dimensions during non-interacting sync', () => {
        const previous = [createNode('node_1', 300, 220, { measured: { width: 236, height: 248 }, width: 236, height: 248 })];
        const next = [createNode('node_1', 50, 40)];
        const merged = mergeCanvasNodes(previous, next, 1, false);

        expect(merged[0].measured?.width).toBe(236);
        expect(merged[0].measured?.height).toBe(248);
        expect(merged[0].width).toBe(236);
        expect(merged[0].height).toBe(248);
    });

    it('retains prior dimensions during interacting sync', () => {
        const previous = [createNode('node_1', 300, 220, { measured: { width: 236, height: 248 }, width: 236, height: 248 })];
        const next = [createNode('node_1', 50, 40)];
        const merged = mergeCanvasNodes(previous, next, 1, true);

        expect(merged[0].position.x).toBe(300);
        expect(merged[0].position.y).toBe(220);
        expect(merged[0].measured?.width).toBe(236);
        expect(merged[0].measured?.height).toBe(248);
        expect(merged[0].width).toBe(236);
        expect(merged[0].height).toBe(248);
    });
});
