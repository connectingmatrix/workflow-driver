import { WorkflowNodeFieldDefinition, WorkflowNodeFieldTypeEnum, WorkflowNodeObjectArraySubFieldDefinition } from '@workflow/ui/workflow/types';

export type WorkflowObjectArrayEditorRow = Record<string, unknown>;

type UnknownRecord = Record<string, unknown>;

const isObjectRecord = (value: unknown): value is UnknownRecord => typeof value === 'object' && value !== null && !Array.isArray(value);
const isString = (value: unknown): value is string => typeof value === 'string';

const parseJsonValue = (value: unknown): unknown => {
    if (!isString(value)) return value;
    const normalized = value.trim();
    if (!normalized) return {};
    try {
        return JSON.parse(normalized);
    } catch {
        return {};
    }
};

const toSubFieldEntries = (definition: WorkflowNodeFieldDefinition): Array<[string, WorkflowNodeObjectArraySubFieldDefinition]> => Object.entries(definition.subFields ?? {});

const createEmptyRow = (definition: WorkflowNodeFieldDefinition): WorkflowObjectArrayEditorRow => {
    return toSubFieldEntries(definition).reduce<WorkflowObjectArrayEditorRow>((acc, [fieldKey, fieldDefinition]) => {
        if (fieldDefinition.defaultValue !== undefined) {
            acc[fieldKey] = fieldDefinition.defaultValue;
            return acc;
        }
        switch (fieldDefinition.type) {
            case WorkflowNodeFieldTypeEnum.Boolean:
                acc[fieldKey] = false;
                break;
            case WorkflowNodeFieldTypeEnum.Number:
                acc[fieldKey] = null;
                break;
            default:
                acc[fieldKey] = '';
        }
        return acc;
    }, {});
};

const normalizeRow = (definition: WorkflowNodeFieldDefinition, source: unknown): WorkflowObjectArrayEditorRow => {
    const row = isObjectRecord(source) ? source : {};
    return toSubFieldEntries(definition).reduce<WorkflowObjectArrayEditorRow>((acc, [fieldKey]) => {
        const value = row[fieldKey];
        acc[fieldKey] = value === undefined ? createEmptyRow(definition)[fieldKey] : value;
        return acc;
    }, {});
};

const ensureMinimumRows = (definition: WorkflowNodeFieldDefinition, rows: WorkflowObjectArrayEditorRow[]): WorkflowObjectArrayEditorRow[] => {
    const minimum = Math.max(0, Number(definition.minimum ?? 0) || 0);
    const next = [...rows];
    while (next.length < minimum) {
        next.push(createEmptyRow(definition));
    }
    return next;
};

const normalizeRecordValue = (definition: WorkflowNodeFieldDefinition, value: unknown): WorkflowObjectArrayEditorRow[] => {
    const keyField = definition.keyField ?? 'key';
    const valueField = definition.valueField ?? 'value';
    if (Array.isArray(value)) {
        return value.map((entry) => normalizeRow(definition, entry));
    }
    const source = isObjectRecord(value) ? value : parseJsonValue(value);
    if (!isObjectRecord(source)) return [];
    return Object.entries(source).map(([entryKey, entryValue]) => normalizeRow(definition, { [keyField]: entryKey, [valueField]: entryValue }));
};

const normalizeStringArrayValue = (definition: WorkflowNodeFieldDefinition, value: unknown): WorkflowObjectArrayEditorRow[] => {
    const valueField = definition.valueField ?? 'value';
    const source = Array.isArray(value) ? value : parseJsonValue(value);
    if (!Array.isArray(source)) return [];
    return source.map((entry) => normalizeRow(definition, { [valueField]: entry }));
};

const normalizeObjectArrayValue = (definition: WorkflowNodeFieldDefinition, value: unknown): WorkflowObjectArrayEditorRow[] => {
    const source = Array.isArray(value) ? value : parseJsonValue(value);
    if (!Array.isArray(source)) return [];
    return source.map((entry) => normalizeRow(definition, entry));
};

const hasMeaningfulValue = (value: unknown): boolean => {
    if (value === null || value === undefined) return false;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return Number.isFinite(value);
    if (Array.isArray(value)) return value.length > 0;
    if (isObjectRecord(value)) return Object.keys(value).length > 0;
    return String(value).trim().length > 0;
};

const hasRowValues = (definition: WorkflowNodeFieldDefinition, row: WorkflowObjectArrayEditorRow): boolean => {
    return toSubFieldEntries(definition).some(([fieldKey]) => hasMeaningfulValue(row[fieldKey]));
};

const parseBooleanValue = (value: unknown): boolean => {
    if (typeof value === 'boolean') return value;
    const normalized = String(value ?? '').trim().toLowerCase();
    return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
};

const parseNumberValue = (value: unknown): number | null => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    const normalized = String(value ?? '').trim();
    if (!normalized) return null;
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
};

const serializeSubFieldValue = (definition: WorkflowNodeObjectArraySubFieldDefinition, value: unknown): unknown => {
    switch (definition.type) {
        case WorkflowNodeFieldTypeEnum.Boolean:
            return parseBooleanValue(value);
        case WorkflowNodeFieldTypeEnum.Number:
            return parseNumberValue(value);
        case WorkflowNodeFieldTypeEnum.Json:
            return parseJsonValue(value);
        default:
            return isString(value) ? value : String(value ?? '');
    }
};

export const buildObjectArrayEditorRows = (definition: WorkflowNodeFieldDefinition, value: unknown): WorkflowObjectArrayEditorRow[] => {
    const mode = definition.valueMode ?? 'object-array';
    const rows = mode === 'record' ? normalizeRecordValue(definition, value) : mode === 'string-array' ? normalizeStringArrayValue(definition, value) : normalizeObjectArrayValue(definition, value);
    return ensureMinimumRows(definition, rows);
};

export const serializeObjectArrayEditorRows = (definition: WorkflowNodeFieldDefinition, value: unknown): unknown => {
    const rows = (Array.isArray(value) ? value : []).filter((entry): entry is WorkflowObjectArrayEditorRow => isObjectRecord(entry)).map((entry) => normalizeRow(definition, entry)).filter((entry) => hasRowValues(definition, entry));
    const mode = definition.valueMode ?? 'object-array';
    if (mode === 'record') {
        const keyField = definition.keyField ?? 'key';
        const valueField = definition.valueField ?? 'value';
        return rows.reduce<Record<string, unknown>>((acc, row) => {
            const recordKey = String(row[keyField] ?? '').trim();
            if (!recordKey) return acc;
            acc[recordKey] = serializeSubFieldValue((definition.subFields ?? {})[valueField] ?? { type: WorkflowNodeFieldTypeEnum.String }, row[valueField]);
            return acc;
        }, {});
    }
    if (mode === 'string-array') {
        const valueField = definition.valueField ?? 'value';
        return rows
            .map((row) => serializeSubFieldValue((definition.subFields ?? {})[valueField] ?? { type: WorkflowNodeFieldTypeEnum.String }, row[valueField]))
            .filter((entry) => hasMeaningfulValue(entry))
            .map((entry) => String(entry));
    }
    return rows.map((row) =>
        toSubFieldEntries(definition).reduce<Record<string, unknown>>((acc, [fieldKey, fieldDefinition]) => {
            acc[fieldKey] = serializeSubFieldValue(fieldDefinition, row[fieldKey]);
            return acc;
        }, {})
    );
};

export const createObjectArrayEditorRow = (definition: WorkflowNodeFieldDefinition): WorkflowObjectArrayEditorRow => createEmptyRow(definition);
