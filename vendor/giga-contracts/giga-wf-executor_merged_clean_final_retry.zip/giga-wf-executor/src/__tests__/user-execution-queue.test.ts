import { describe, expect, it } from 'vitest';
import { resolveWorkflowUserParallelExecutionLimit } from '../queue/createWorkflowQueueScheduler';

describe('user execution queue limits', () => {
    it('uses the request runtime setting when present', () => {
        expect(resolveWorkflowUserParallelExecutionLimit({ maxConcurrentExecutionsPerUser: 4 })).toBe(4);
        expect(resolveWorkflowUserParallelExecutionLimit({ maxConcurrentExecutionsPerUser: 0 })).toBe(40);
        expect(resolveWorkflowUserParallelExecutionLimit({ maxConcurrentExecutionsPerUser: 400 })).toBe(400);
    });
});
