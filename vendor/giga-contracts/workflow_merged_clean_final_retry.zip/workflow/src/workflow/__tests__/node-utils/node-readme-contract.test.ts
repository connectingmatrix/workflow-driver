import fs from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';

const NODES_ROOT = path.resolve(process.cwd(), '../workflow-nodes/src/nodes');
const requiresSection = (content: string, heading: string): boolean => content.includes(heading) || content.includes('No backend service is used.');
const hasSectionContract = (content: string): boolean =>
    requiresSection(content, '## Usage') && requiresSection(content, '## Inputs') && requiresSection(content, '## Outputs') && requiresSection(content, '## Backend Mapping');
const hasCompactContract = (content: string): boolean =>
    content.startsWith('# ') && content.includes('Worker-owned') && content.includes('- ') && /backend service|executeBackend|emits|@workflow\/charts|LLM|tool/i.test(content);

describe('node README contract', () => {
    it('ensures every node folder with schema has README sections for usage/io/backend mapping', () => {
        const directories = fs
            .readdirSync(NODES_ROOT)
            .filter((entry) => fs.statSync(path.join(NODES_ROOT, entry)).isDirectory())
            .filter((entry) => fs.existsSync(path.join(NODES_ROOT, entry, `${entry}-schema.json`)));

        directories.forEach((directory) => {
            const readmePath = path.join(NODES_ROOT, directory, 'README.md');
            expect(fs.existsSync(readmePath)).toBe(true);
            const content = fs.readFileSync(readmePath, 'utf8');
            expect(hasSectionContract(content) || hasCompactContract(content)).toBe(true);
        });
    });
});
