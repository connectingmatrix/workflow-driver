import React from 'react';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';

interface WorkspaceTextFieldProps {
    id: string;
    value: string;
    editable: boolean;
    allowVariables: boolean;
    placeholder?: string;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: string) => void;
}

export const WorkspaceTextField: React.FC<WorkspaceTextFieldProps> = ({ id, value, editable, allowVariables, placeholder, variableContext, variableSuggestions, onChange }) => {
    return <VariableTextField id={id} value={value} onChange={onChange} allowVariables={allowVariables} variableContext={variableContext} variableSuggestions={variableSuggestions} disabled={!editable} placeholder={placeholder} />;
};
