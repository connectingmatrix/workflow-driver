#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const argIndex = process.argv.indexOf('--project-root');
const rootArg = argIndex > -1 ? process.argv[argIndex + 1] : '.';
const projectRoot = path.resolve(process.cwd(), rootArg || '.');
const workflowNodesRoot = path.resolve(projectRoot, '../workflow-nodes/src');
const viteCacheRoot = path.resolve(projectRoot, 'node_modules/.vite');
const depsRoot = path.resolve(viteCacheRoot, 'deps');

const newestMtime = (targetPath) => {
    if (!fs.existsSync(targetPath)) return 0;
    const stat = fs.statSync(targetPath);
    if (!stat.isDirectory()) return stat.mtimeMs;
    let newest = stat.mtimeMs;
    for (const entry of fs.readdirSync(targetPath)) {
        const entryTime = newestMtime(path.resolve(targetPath, entry));
        newest = entryTime > newest ? entryTime : newest;
    }
    return newest;
};

if (!fs.existsSync(workflowNodesRoot) || !fs.existsSync(depsRoot)) {
    process.exit(0);
}

const nodesMtime = newestMtime(workflowNodesRoot);
const cacheMtime = newestMtime(depsRoot);
if (nodesMtime <= cacheMtime) {
    process.exit(0);
}

for (const entry of fs.readdirSync(depsRoot)) {
    if (!entry.includes('workflow') && !entry.includes('_metadata')) continue;
    fs.rmSync(path.resolve(depsRoot, entry), { recursive: true, force: true });
}

console.log(`Invalidated workflow-node Vite prebundle cache in ${path.relative(projectRoot, depsRoot)}`);
