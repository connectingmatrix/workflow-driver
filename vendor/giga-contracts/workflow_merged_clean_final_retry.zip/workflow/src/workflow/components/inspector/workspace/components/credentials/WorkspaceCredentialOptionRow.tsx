import React from 'react';
import type { WorkflowCredentialOption } from '@workflow/ui/workflow/types';
import { WorkflowServiceIcon } from '@workflow/ui/workflow/icons';

interface WorkspaceCredentialOptionRowProps {
    option: WorkflowCredentialOption;
    selected: boolean;
    onSelect: (credentialId: string) => void;
}

export const WorkspaceCredentialOptionRow: React.FC<WorkspaceCredentialOptionRowProps> = ({ option, selected, onSelect }) => {
    return (
        <button
            type="button"
            className={`cnw-credential-option${selected ? ' cnw-credential-option--selected' : ''}`}
            onClick={() => onSelect(option.credentialId)}
        >
            <WorkflowServiceIcon serviceIcon={option.serviceIcon} serviceName={option.serviceName ?? option.serviceId} className="cnw-credential-option__icon" />
            <span className="cnw-credential-option__content">
                <span className="cnw-credential-option__title">{option.credentialName}</span>
                <span className="cnw-credential-option__meta">
                    <span>{option.serviceName ?? option.serviceId}</span>
                    <code>{option.credentialId}</code>
                </span>
            </span>
            <span className={`cnw-credential-option__scope cnw-credential-option__scope--${option.scope.toLowerCase()}`}>{option.scopeTag}</span>
        </button>
    );
};
