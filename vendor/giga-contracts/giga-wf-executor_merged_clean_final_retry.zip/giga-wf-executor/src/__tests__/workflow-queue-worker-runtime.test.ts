import { describe, expect, it, vi } from 'vitest';
import { runWorkflowExecutionQueueRuntime } from '../pubsub/runWorkflowExecutionQueue';
import { waitForWorkflowQueueCompletion } from '../queue/workflowQueueCompletion';
import type {
  WorkflowQueueEvent,
  WorkflowQueueEventProducer,
  WorkflowQueueRequest,
  WorkflowQueueRequestConsumer,
  WorkflowQueueScheduler,
} from '../queue/types';

type QueueMessageHandler = (params: { message: { value: Buffer | string | null } }) => Promise<void>;

const createRequest = (executionId: string, queueKey = 'user-a'): WorkflowQueueRequest => ({
  executionId,
  runId: `run-${executionId}`,
  queueKey,
  userId: queueKey,
  broadcastId: queueKey,
  broadcastChannelName: 'workflow-socket',
  triggerType: 'chat',
  workflowReference: {
    workflowId: `workflow-${executionId}`,
    scope: 'user',
    ownerUserId: queueKey,
  },
  workflowVersionId: null,
  workflow: {
    metadata: { id: `workflow-${executionId}`, name: `Workflow ${executionId}` },
    nodes: [],
    connections: [],
  },
  settings: {
    graphqlUrl: 'http://localhost:3001/api/v2/graphql',
    authMode: 'auto-from-current-session',
  },
  requestContext: {
    mode: 'user',
    userId: queueKey,
    headers: {},
  },
  metadata: null,
});

describe('runWorkflowExecutionQueueRuntime', () => {
  it('connects, subscribes, parses queue requests, and schedules execution', async () => {
    const enqueuedIds: string[] = [];
    const publishedEvents: WorkflowQueueEvent[] = [];
    const messageHandlerRef: { current: QueueMessageHandler | null } = { current: null };
    const executePromises: Promise<void>[] = [];

    const consumer: WorkflowQueueRequestConsumer = {
      connect: vi.fn(async () => undefined),
      disconnect: vi.fn(async () => undefined),
      subscribe: vi.fn(async () => undefined),
      run: vi.fn(async ({ eachMessage }) => {
        messageHandlerRef.current = eachMessage;
      }),
    };

    const eventPublisher: WorkflowQueueEventProducer = {
      connect: vi.fn(async () => undefined),
      disconnect: vi.fn(async () => undefined),
      publish: vi.fn(async (event) => {
        publishedEvents.push(event);
      }),
    };

    const scheduler: WorkflowQueueScheduler = {
      enqueue: vi.fn((job) => {
        enqueuedIds.push(job.request.executionId);
        executePromises.push(job.execute(new AbortController().signal));
      }),
      cancelRun: vi.fn(() => 0),
      cancelWorkflow: vi.fn(() => 0),
      getPendingCount: vi.fn(() => 0),
      getActiveCount: vi.fn(() => 0),
      getRunning: vi.fn(() => []),
      close: vi.fn(async () => undefined),
    };

    const runtime = runWorkflowExecutionQueueRuntime({
      consumer,
      eventPublisher,
      scheduler,
      requestTopic: 'workflow-execution-requests',
      runExecutionRequest: async (request, helpers) => {
        await helpers.publishEvent({
          type: 'started',
          timestamp: new Date().toISOString(),
          executionId: request.executionId,
          runId: request.runId,
          workflowId: request.workflowReference.workflowId,
          userId: request.userId,
          broadcastId: request.broadcastId,
          broadcastChannelName: request.broadcastChannelName,
          triggerType: request.triggerType,
          workflowReference: request.workflowReference,
        });
        await helpers.publishEvent({
          type: 'completed',
          timestamp: new Date().toISOString(),
          executionId: request.executionId,
          runId: request.runId,
          workflowId: request.workflowReference.workflowId,
          userId: request.userId,
          broadcastId: request.broadcastId,
          broadcastChannelName: request.broadcastChannelName,
          triggerType: request.triggerType,
          workflowReference: request.workflowReference,
          result: {
            workflow: request.workflow,
            stopped: false,
            runId: request.runId,
            logs: [],
          },
        });
      },
    });

    await runtime.start();
    expect(consumer.connect).toHaveBeenCalledOnce();
    expect(eventPublisher.connect).toHaveBeenCalledOnce();
    expect(consumer.subscribe).toHaveBeenCalledWith({
      topic: 'workflow-execution-requests',
      fromBeginning: false,
    });

    if (!messageHandlerRef.current) {
      throw new Error('Queue worker runtime did not register a message handler.');
    }
    await messageHandlerRef.current({
      message: {
        value: JSON.stringify(createRequest('execution-1')),
      },
    });
    await Promise.all(executePromises);

    expect(enqueuedIds).toEqual(['execution-1']);
    expect(publishedEvents.map((event) => event.type)).toEqual(['started', 'completed']);
    expect(publishedEvents[0]).toMatchObject({
      broadcastId: 'user-a',
      broadcastChannelName: 'workflow-socket',
    });
    await runtime.stop();
    expect(scheduler.close).toHaveBeenCalledOnce();
    expect(consumer.disconnect).toHaveBeenCalledOnce();
    expect(eventPublisher.disconnect).toHaveBeenCalledOnce();
  });

  it('ignores empty queue messages', async () => {
    const messageHandlerRef: { current: QueueMessageHandler | null } = { current: null };
    const scheduler: WorkflowQueueScheduler = {
      enqueue: vi.fn(),
      cancelRun: vi.fn(() => 0),
      cancelWorkflow: vi.fn(() => 0),
      getPendingCount: vi.fn(() => 0),
      getActiveCount: vi.fn(() => 0),
      getRunning: vi.fn(() => []),
      close: vi.fn(async () => undefined),
    };

    const runtime = runWorkflowExecutionQueueRuntime({
      consumer: {
        connect: vi.fn(async () => undefined),
        disconnect: vi.fn(async () => undefined),
        subscribe: vi.fn(async () => undefined),
        run: vi.fn(async ({ eachMessage }) => {
          messageHandlerRef.current = eachMessage;
        }),
      },
      eventPublisher: {
        connect: vi.fn(async () => undefined),
        disconnect: vi.fn(async () => undefined),
        publish: vi.fn(async () => undefined),
      },
      scheduler,
      requestTopic: 'workflow-execution-requests',
      runExecutionRequest: vi.fn(async () => undefined),
    });

    await runtime.start();
    if (!messageHandlerRef.current) {
      throw new Error('Queue worker runtime did not register a message handler.');
    }
    await messageHandlerRef.current({
      message: {
        value: '   ',
      },
    });

    expect(scheduler.enqueue).not.toHaveBeenCalled();
  });

  it('signals same-process completion before waiting for the event publisher', async () => {
    const executionId = 'execution-local-completion';
    const messageHandlerRef: { current: QueueMessageHandler | null } = { current: null };
    let releasePublish = () => undefined;
    const stalledPublish = new Promise<void>((resolve) => {
      releasePublish = resolve;
    });

    const runtime = runWorkflowExecutionQueueRuntime({
      consumer: {
        connect: vi.fn(async () => undefined),
        disconnect: vi.fn(async () => undefined),
        subscribe: vi.fn(async () => undefined),
        run: vi.fn(async ({ eachMessage }) => {
          messageHandlerRef.current = eachMessage;
        }),
      },
      eventPublisher: {
        connect: vi.fn(async () => undefined),
        disconnect: vi.fn(async () => undefined),
        publish: vi.fn(async (event) => {
          if (event.type === 'completed') await stalledPublish;
        }),
      },
      scheduler: {
        enqueue: vi.fn((job) => {
          void job.execute(new AbortController().signal);
        }),
        cancelRun: vi.fn(() => 0),
        cancelWorkflow: vi.fn(() => 0),
        getPendingCount: vi.fn(() => 0),
        getActiveCount: vi.fn(() => 0),
        getRunning: vi.fn(() => []),
        close: vi.fn(async () => undefined),
      },
      requestTopic: 'workflow-execution-requests',
      runExecutionRequest: async (request, helpers) => {
        await helpers.publishEvent({
          type: 'completed',
          timestamp: new Date().toISOString(),
          executionId: request.executionId,
          runId: request.runId,
          workflowId: request.workflowReference.workflowId,
          userId: request.userId,
          broadcastId: request.broadcastId,
          broadcastChannelName: request.broadcastChannelName,
          triggerType: request.triggerType,
          workflowReference: request.workflowReference,
          result: {
            workflow: request.workflow,
            stopped: false,
            runId: request.runId,
            logs: [],
          },
        });
      },
    });

    await runtime.start();
    if (!messageHandlerRef.current) throw new Error('Queue worker runtime did not register a message handler.');

    const completion = waitForWorkflowQueueCompletion(executionId);
    await messageHandlerRef.current({ message: { value: JSON.stringify(createRequest(executionId)) } });
    await expect(completion).resolves.toMatchObject({ executionId, type: 'completed' });
    releasePublish();
    await runtime.stop({ force: true });
  });
});
