import fs from 'node:fs/promises';
import path from 'node:path';

const MAX_CAT_BYTES = Number(process.env.WF_SANDBOX_CAT_MAX_BYTES || 1024 * 1024);
const resolveInside = (root: string, relative: string) => {
  const target = path.resolve(root, relative || '.');
  const base = path.resolve(root);
  if (!target.startsWith(base)) throw new Error('Sandbox path escapes workspace.');
  return target;
};

export const createSandboxFileTools = (root: string) => ({
  async wc(file: string) {
    const content = await fs.readFile(resolveInside(root, file), 'utf8');
    return { lines: content.split(/\r?\n/).length, words: content.trim() ? content.trim().split(/\s+/).length : 0, bytes: Buffer.byteLength(content) };
  },
  async cat(file: string, maxBytes = MAX_CAT_BYTES) {
    const handle = await fs.open(resolveInside(root, file), 'r');
    try {
      const buffer = Buffer.alloc(Math.max(1, Math.min(maxBytes, MAX_CAT_BYTES)));
      const read = await handle.read(buffer, 0, buffer.length, 0);
      return buffer.subarray(0, read.bytesRead).toString('utf8');
    } finally { await handle.close(); }
  },
  async tail(file: string, lines = 100) {
    const content = await fs.readFile(resolveInside(root, file), 'utf8');
    return content.split(/\r?\n/).slice(-Math.max(1, Math.min(lines, 1000))).join('\n');
  },
  async ls(dir = '.') {
    const entries = await fs.readdir(resolveInside(root, dir), { withFileTypes: true });
    return entries.map((entry) => ({ name: entry.name, type: entry.isDirectory() ? 'dir' : entry.isFile() ? 'file' : 'other' }));
  },
});
