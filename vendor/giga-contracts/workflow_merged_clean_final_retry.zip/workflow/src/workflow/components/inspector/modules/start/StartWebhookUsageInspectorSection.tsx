import React from 'react';
import StartWebhookUsageCard from '@workflow/ui/workflow/nodes/start/start-webhook-usage-card';
import { WorkflowInspectorModuleSectionProps } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const toSafeString = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

const StartWebhookUsageInspectorSection: React.FC<WorkflowInspectorModuleSectionProps> = ({ propertiesEditorState, workflowData = {} }) => {
    const triggerSource = String(propertiesEditorState.triggerSource ?? 'programmatic').trim().toLowerCase();
    if (triggerSource !== 'webhook') return null;
    const webhook = toRecord(toRecord(toRecord(workflowData).metadata).webhook);

    const copyValue = async (value: string): Promise<void> => {
        if (!value) return;
        await navigator.clipboard.writeText(value);
    };

    return (
        <StartWebhookUsageCard
            method={webhook.method === 'GET' || webhook.method === 'POST' ? webhook.method : 'POST'}
            onCopy={copyValue}
            publishedUrl={toSafeString(webhook.publishedUrl)}
            secret={toSafeString(webhook.secret)}
            testUrl={toSafeString(webhook.testUrl)}
        />
    );
};

export default StartWebhookUsageInspectorSection;
