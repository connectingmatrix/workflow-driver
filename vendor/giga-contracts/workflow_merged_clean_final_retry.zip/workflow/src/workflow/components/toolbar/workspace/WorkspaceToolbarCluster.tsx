import React from 'react';

export const WorkspaceToolbarCluster: React.FC<{ children: React.ReactNode }> = ({ children }) => <div className="wf-workspace-toolbar__cluster">{children}</div>;
