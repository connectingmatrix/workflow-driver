import { describe, expect, it } from 'vitest';
import { buildWorkflowSearchText, buildWorkflowWebhookUrls } from '@/modules/workflow-catalog/services/workflow-catalog.service';
import { WorkflowDefinition } from '@workflow/ui/workflow/types';

const createWorkflowFixture = (): WorkflowDefinition => ({
    metadata: {
        id: 'workflow_1',
        name: 'Intel Collection',
        description: 'Investigate regional energy logistics'
    },
    nodes: [
        {
            id: 'node_start',
            gigaId: 'StartNode',
            modelId: 'start',
            type: 'workflowStep',
            name: 'Start',
            description: 'Workflow entry point',
            kind: 'process',
            status: 'stopped',
            position: { x: 0, y: 0 },
            runtime: {},
            ports: { in: {}, out: { output: {} } }
        },
        {
            id: 'node_search',
            gigaId: 'SearchNode',
            modelId: 'http-request',
            type: 'workflowStep',
            name: 'OpenSource Search',
            description: 'Search node descriptions for pipeline discovery',
            kind: 'process',
            status: 'stopped',
            position: { x: 200, y: 0 },
            runtime: {},
            ports: { in: {}, out: { output: {} } }
        }
    ],
    connections: []
});

describe('workflow catalog service helpers', () => {
    it('builds webhook test and published URLs from the workflow id', () => {
        const urls = buildWorkflowWebhookUrls('workflow_1');
        expect(urls.testUrl).toContain('/api/v2/workflows/workflow_1/webhook/test');
        expect(urls.publishedUrl).toContain('/api/v2/workflows/workflow_1/webhook/published');
    });

    it('includes workflow and node descriptions in searchable text', () => {
        const workflow = createWorkflowFixture();
        const searchText = buildWorkflowSearchText(workflow, workflow.metadata.description || '');
        expect(searchText).toContain('intel collection');
        expect(searchText).toContain('regional energy logistics');
        expect(searchText).toContain('opensource search');
        expect(searchText).toContain('pipeline discovery');
    });
});
