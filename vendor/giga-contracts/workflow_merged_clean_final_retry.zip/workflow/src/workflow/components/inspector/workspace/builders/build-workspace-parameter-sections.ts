import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowInspectorModuleDefinition } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.types';
import { buildVisibleInspectorFields } from '@workflow/ui/workflow/components/inspector/inspector-properties-pane.utils';
import { WorkflowNodeFieldTypeEnum, type WorkflowNodeFieldMap } from '@workflow/ui/workflow/types';
import type { WorkspaceParameterSectionModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface BuildWorkspaceParameterSectionsArgs {
    config: WorkflowInspectorConfig;
    fields: WorkflowNodeFieldMap;
    propertiesEditorState: Record<string, unknown>;
    hiddenFieldKeys: string[];
    moduleDefinition: WorkflowInspectorModuleDefinition | null;
}

type WorkspaceSectionConfig = {
    id: string;
    title: string;
    description?: string;
    fieldKeys?: string[];
    includeRemaining?: boolean;
    variant?: WorkspaceParameterSectionModel['variant'];
};

const DEFAULT_SECTION_CONFIG = [
    {
        id: 'general',
        title: 'General',
        fieldKeys: ['description']
    },
    {
        id: 'parameters',
        title: 'Parameters',
        includeRemaining: true
    },
    {
        id: 'execution',
        title: 'Execution',
        fieldKeys: ['failureMitigation', 'retryCount', 'forwardSessionLogs']
    }
] as const;
const EXECUTION_FIELD_KEYS = ['failureMitigation', 'retryCount', 'forwardSessionLogs'];

const injectExecutionFields = (fields: WorkflowNodeFieldMap): WorkflowNodeFieldMap => ({
    ...fields,
    failureMitigation: fields.failureMitigation || {
        type: WorkflowNodeFieldTypeEnum.Select,
        label: 'Failure Mitigation',
        editable: true,
        defaultValue: 'stop-workflow',
        options: [
            { label: 'Retry Node', value: 'retry-node' },
            { label: 'Stop Workflow', value: 'stop-workflow' }
        ]
    },
    retryCount: fields.retryCount || {
        type: WorkflowNodeFieldTypeEnum.Select,
        label: 'Retries',
        editable: true,
        defaultValue: '1',
        options: [{ label: '1', value: '1' }, { label: '2', value: '2' }, { label: '3', value: '3' }, { label: '4', value: '4' }, { label: '5', value: '5' }, { label: '6', value: '6' }]
    },
    forwardSessionLogs: fields.forwardSessionLogs || {
        type: WorkflowNodeFieldTypeEnum.Boolean,
        label: 'Forward Session Logs',
        editable: true,
        defaultValue: false
    }
});

export const buildWorkspaceParameterSections = ({
    config,
    fields,
    propertiesEditorState,
    hiddenFieldKeys,
    moduleDefinition
}: BuildWorkspaceParameterSectionsArgs): WorkspaceParameterSectionModel[] => {
    const resolvedFields = moduleDefinition?.workspace?.parameters?.resolveFields?.({
        config,
        fields,
        propertiesEditorState
    }) ?? fields;
    const fieldsWithExecution = injectExecutionFields(resolvedFields);
    const visibleFields = buildVisibleInspectorFields({
        fields: fieldsWithExecution,
        values: propertiesEditorState,
        hiddenFieldKeys,
        propertyOrder: moduleDefinition?.propertyOrder,
        shouldDisplayField: moduleDefinition?.shouldDisplayField
    }).filter(([fieldKey]) => fieldKey !== 'name');

    const usedFieldKeys = new Set<string>();
    const baseSectionConfig = (moduleDefinition?.workspace?.parameters?.sections ?? DEFAULT_SECTION_CONFIG) as WorkspaceSectionConfig[];
    const executionSectionConfig = baseSectionConfig.find((section) => section.id === 'execution') ?? {
        id: 'execution',
        title: 'Execution',
        fieldKeys: EXECUTION_FIELD_KEYS
    } as WorkspaceSectionConfig;
    const executionFieldKeys = [...(executionSectionConfig.fieldKeys ?? [])];
    for (const key of EXECUTION_FIELD_KEYS) {
        if (!executionFieldKeys.includes(key)) executionFieldKeys.push(key);
    }

    const sections: WorkspaceParameterSectionModel[] = [];
    const pushSection = (sectionId: string, title: string, description: string | undefined, variant: WorkspaceParameterSectionModel['variant'] | undefined, fieldKeys: string[], includeRemaining: boolean): void => {
        const resolvedFields: [string, WorkflowNodeFieldMap[string]][] = [];
        for (const fieldKey of fieldKeys) {
            for (const visibleField of visibleFields) {
                if (visibleField[0] !== fieldKey || usedFieldKeys.has(fieldKey)) continue;
                resolvedFields.push(visibleField);
                usedFieldKeys.add(fieldKey);
                break;
            }
        }
        if (includeRemaining) {
            for (const visibleField of visibleFields) {
                const fieldKey = visibleField[0];
                if (usedFieldKeys.has(fieldKey) || fieldKeys.includes(fieldKey) || EXECUTION_FIELD_KEYS.includes(fieldKey)) continue;
                resolvedFields.push(visibleField);
                usedFieldKeys.add(fieldKey);
            }
        }
        if (resolvedFields.length === 0) return;
        sections.push({
            id: sectionId,
            title,
            description,
            variant,
            fields: resolvedFields.map(([fieldKey, definition]) => ({
                id: fieldKey,
                key: fieldKey,
                definition,
                value: propertiesEditorState[fieldKey],
                presentation: moduleDefinition?.workspace?.parameters?.fieldPresentation?.[fieldKey],
                badge: moduleDefinition?.workspace?.parameters?.fieldBadges?.[fieldKey],
                helperText: moduleDefinition?.workspace?.parameters?.fieldHelperText?.[fieldKey]
            }))
        });
    };

    for (const section of baseSectionConfig) {
        if (section.id === 'execution') continue;
        pushSection(section.id, section.title, section.description, section.variant, [...(section.fieldKeys ?? [])], Boolean(section.includeRemaining));
    }

    const unassignedFields = visibleFields.filter(([fieldKey]) => !usedFieldKeys.has(fieldKey) && !EXECUTION_FIELD_KEYS.includes(fieldKey));
    if (unassignedFields.length > 0) {
        sections.push({
            id: 'more',
            title: 'More',
            fields: unassignedFields.map(([fieldKey, definition]) => ({
                id: fieldKey,
                key: fieldKey,
                definition,
                value: propertiesEditorState[fieldKey],
                presentation: moduleDefinition?.workspace?.parameters?.fieldPresentation?.[fieldKey],
                badge: moduleDefinition?.workspace?.parameters?.fieldBadges?.[fieldKey],
                helperText: moduleDefinition?.workspace?.parameters?.fieldHelperText?.[fieldKey]
            }))
        });
        for (const [fieldKey] of unassignedFields) {
            usedFieldKeys.add(fieldKey);
        }
    }

    pushSection(executionSectionConfig.id, executionSectionConfig.title, executionSectionConfig.description, executionSectionConfig.variant, executionFieldKeys, false);

    return sections;
};
