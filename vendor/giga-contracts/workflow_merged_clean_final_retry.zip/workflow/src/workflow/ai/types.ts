import { WorkflowExportPayload } from '@workflow/ui/workflow/types';

export type WorkflowAiScopeMode = 'workflow' | 'node';

export interface WorkflowAiScope {
    mode: WorkflowAiScopeMode;
    nodeId?: string;
    nodeName?: string;
    nodeType?: string;
}

export interface WorkflowAiChatMessage {
    id: string;
    role: 'user' | 'assistant';
    text: string;
    createdAt: string;
}

export interface WorkflowAiAction {
    type: string;
    [key: string]: unknown;
}

export interface WorkflowAiDiagnostics {
    summary?: string;
    likelyCause?: string;
    recommendedFix?: string;
    [key: string]: unknown;
}

export interface WorkflowAiResponse {
    reply: string;
    actions: WorkflowAiAction[];
    diagnostics?: WorkflowAiDiagnostics;
}

export interface WorkflowAiHiddenContext {
    workflowId: string;
    workflowName?: string;
    scope: WorkflowAiScope;
    workflowExportWithData: WorkflowExportPayload;
    workflowCypher: string;
    graphHealth: string[];
    knowledge: Array<{
        id: string;
        problem: string;
        solutionCypher: string;
        tags: string[];
        notes?: string;
    }>;
    recentLogs: Array<Record<string, unknown>>;
    capabilities: string[];
    nodeCatalog: Array<{
        modelId: string;
        label: string;
        description: string;
        group?: string;
    }>;
    nodeContracts?: Array<{
        modelId: string;
        group?: string;
        ports: {
            inputs: Array<{
                id: string;
                label?: string;
                portType?: string;
                acceptedSourceGroups?: string[];
                acceptedSourceModelIds?: string[];
            }>;
            outputs: Array<{
                id: string;
                label?: string;
                portType?: string;
            }>;
            commands: Array<{
                id: string;
                label?: string;
                portType?: string;
                acceptedSourceGroups?: string[];
                acceptedSourceModelIds?: string[];
            }>;
        };
        fields: Array<{
            key: string;
            type?: string;
            label?: string;
            required?: boolean;
            defaultValue?: unknown;
            options?: Array<{ label: string; value: string }>;
            allowVariables?: boolean;
            aiWriteMode?: 'allow' | 'connected-options-only' | 'deny';
            aiSourcePort?: string;
            resolveVariablesWhen?: unknown;
        }>;
        instruction?: unknown;
    }>;
}
