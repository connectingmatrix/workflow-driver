const mockState = {
    executeBackend: async (): Promise<{ status: 'passed'; output: Record<string, unknown>; logs: string[]; error: null }> => ({
        status: 'passed',
        output: {},
        logs: [],
        error: null
    }),
    invokeConnectedNode: async (): Promise<{ node: { id: string; status: 'passed' }; result: { status: 'passed'; output: Record<string, unknown>; logs: string[] } }> => ({
        node: { id: 'node_mock', status: 'passed' },
        result: {
            status: 'passed',
            output: {},
            logs: []
        }
    })
};

export const __setWorkflowExecuteMock = (next: Partial<typeof mockState>): void => {
    if (next.executeBackend) mockState.executeBackend = next.executeBackend;
    if (next.invokeConnectedNode) mockState.invokeConnectedNode = next.invokeConnectedNode;
};

export const __resetWorkflowExecuteMock = (): void => {
    mockState.executeBackend = async () => ({
        status: 'passed',
        output: {},
        logs: [],
        error: null
    });
    mockState.invokeConnectedNode = async () => ({
        node: { id: 'node_mock', status: 'passed' },
        result: {
            status: 'passed',
            output: {},
            logs: []
        }
    });
};

export const executeBackend = async (...args: unknown[]) => mockState.executeBackend(...args);
export const invokeConnectedNode = async (...args: unknown[]) => mockState.invokeConnectedNode(...args);
export const updateNode = (): void => undefined;
