import {
  WorkflowCommandToolSpec,
  WorkerControlNodeFacade,
  WorkflowControlNodeExecuteInputsArgs,
  WorkerValidateResult,
  WorkflowControlNodeExecuteArgs,
  WorkflowControlNodePatch,
  WorkflowControlNodeSnapshot,
  WorkflowControlNodeValidateArgs,
  WorkflowNodeHandlerContext,
  WorkflowNodeHandlerResult,
  WorkflowNodeModel,
  WorkflowNodeSchema,
  WorkflowNodeStatusEnum,
  WorkflowNodePorts,
  WorkflowSourceFiles,
} from "../../../types";
import { buildNodeInputContext } from "../graph/run-context";
import {
  getCommandPeersForPort,
  getNodeSchema,
  getNormalizedCommandPorts,
} from "../graph/command-ports";

const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as T)
    : ({} as T);

export const cloneControlValue = <T>(value: T): T => {
  if (
    value == null ||
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  )
    return value;
  if (typeof value === "function" || typeof value === "symbol")
    return undefined as T;
  if (Array.isArray(value))
    return value.map((entry) => cloneControlValue(entry)) as T;
  if (value instanceof Date) return new Date(value.getTime()) as T;
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    Object.entries(value as Record<string, unknown>).forEach(([key, entry]) => {
      const next = cloneControlValue(entry);
      if (typeof next !== "undefined") out[key] = next;
    });
    return out as T;
  }
  return value;
};

const toSourceFiles = (value: unknown): WorkflowSourceFiles | undefined => {
  const record = toRecord(value);
  const workerTs =
    typeof record["worker.ts"] === "string" ? record["worker.ts"] : undefined;
  const validateTs =
    typeof record["validate.ts"] === "string"
      ? record["validate.ts"]
      : undefined;
  if (!workerTs && !validateTs) return undefined;
  return {
    ...(workerTs ? { "worker.ts": workerTs } : {}),
    ...(validateTs ? { "validate.ts": validateTs } : {}),
  };
};

const buildOutputsByNode = (
  workflow: WorkflowNodeHandlerContext["workflow"],
): Map<string, Record<string, unknown>> =>
  new Map(workflow.nodes.map((node) => [node.id, toRecord(node.ports?.out)]));

const getCurrentNode = (
  workflow: WorkflowNodeHandlerContext["workflow"],
  nodeId: string,
): WorkflowNodeModel => {
  const node = workflow.nodes.find((entry) => entry.id === nodeId);
  if (!node) throw new Error(`Control node "${nodeId}" was not found.`);
  return node;
};

export const buildControlNodeSnapshot = (
  workflow: WorkflowNodeHandlerContext["workflow"],
  nodeId: string,
): WorkflowControlNodeSnapshot => {
  const node = getCurrentNode(workflow, nodeId);
  const sourceFiles = toSourceFiles(toRecord(node.runtime).__sourceFiles);
  return {
    nodeId: node.id,
    name: node.name,
    modelId: node.modelId,
    status: (node.status ??
      WorkflowNodeStatusEnum.Stopped) as WorkflowNodeStatusEnum,
    properties: cloneControlValue(toRecord(node.runtime)),
    runtime: cloneControlValue(toRecord(node.runtime)),
    input: cloneControlValue(
      buildNodeInputContext(
        workflow,
        node.id,
        buildOutputsByNode(workflow),
        toRecord<WorkflowNodePorts["in"]>(node.ports?.in),
      ),
    ),
    output: cloneControlValue(toRecord(node.ports?.out).output ?? null),
    ...(sourceFiles ? { sourceFiles } : {}),
  };
};

export const normalizeControlNodeSchema = (
  workflow: WorkflowNodeHandlerContext["workflow"],
  nodeId: string,
): WorkflowNodeSchema => {
  const schema = getNodeSchema(workflow, nodeId);
  if (!schema)
    throw new Error(`Control node schema for "${nodeId}" was not found.`);
  const commands = getNormalizedCommandPorts(schema);
  if (Object.keys(commands).length === 0) return cloneControlValue(schema);
  return {
    ...cloneControlValue(schema),
    commands,
  };
};

const applyPatchRecord = (
  target: Record<string, unknown>,
  patch: Record<string, unknown> | undefined,
): Record<string, unknown> => {
  const next = { ...target };
  if (!patch) return next;
  Object.entries(patch).forEach(([key, value]) => {
    if (value === undefined) delete next[key];
    else next[key] = value;
  });
  return next;
};

export const applyControlNodePatch = (
  node: WorkflowNodeModel,
  patch: WorkflowControlNodePatch,
): WorkflowNodeModel => {
  const runtime = toRecord(node.runtime);
  const properties = toRecord(node.properties);
  const patchedProperties = applyPatchRecord(properties, patch.properties);
  const patchedRuntime = applyPatchRecord(
    applyPatchRecord(runtime, patch.properties),
    patch.runtime,
  );
  const nextSourceFiles = patch.sourceFiles
    ? {
        ...(toSourceFiles(patchedRuntime.__sourceFiles) ?? {}),
        ...patch.sourceFiles,
      }
    : toSourceFiles(patchedRuntime.__sourceFiles);

  return {
    ...node,
    properties: patchedProperties,
    runtime: {
      ...patchedRuntime,
      ...(typeof patch.code === "string" ? { code: patch.code } : {}),
      ...(typeof patch.markdown === "string"
        ? { markdown: patch.markdown }
        : {}),
      ...(nextSourceFiles ? { __sourceFiles: nextSourceFiles } : {}),
    },
  };
};

export const persistControlNodePatch = (
  workflow: WorkflowNodeHandlerContext["workflow"],
  nodeId: string,
  patch: WorkflowControlNodePatch,
): WorkflowNodeModel => {
  const index = workflow.nodes.findIndex((entry) => entry.id === nodeId);
  if (index < 0) throw new Error(`Control node "${nodeId}" was not found.`);
  const nextNode = applyControlNodePatch(
    workflow.nodes[index] as WorkflowNodeModel,
    patch,
  );
  workflow.nodes[index] = nextNode;
  return nextNode;
};

const buildPeerKeys = (nodes: WorkflowNodeModel[]): Map<string, string> => {
  const counts = new Map<string, number>();
  nodes.forEach((node) =>
    counts.set(node.name, (counts.get(node.name) ?? 0) + 1),
  );
  return new Map(
    nodes.map((node) => [
      node.id,
      (counts.get(node.name) ?? 0) > 1
        ? `${node.name}__${node.id.slice(0, 8)}`
        : node.name,
    ]),
  );
};

export interface ControlNodeRuntimeFacadeArgs {
  context: WorkflowNodeHandlerContext;
  validatePeer: (args: {
    nodeId: string;
    args?: WorkflowControlNodeValidateArgs;
  }) => Promise<WorkerValidateResult>;
  executePeerInputs: (args: {
    nodeId: string;
    args?: WorkflowControlNodeExecuteInputsArgs;
  }) => Promise<WorkflowControlNodeSnapshot>;
  executePeer: (args: {
    nodeId: string;
    args?: WorkflowControlNodeExecuteArgs;
  }) => Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }>;
  commandToolSpecPeer: (args: {
    nodeId: string;
  }) => Promise<WorkflowCommandToolSpec | null>;
}

export const buildControlNodeFacadeMap = (
  args: ControlNodeRuntimeFacadeArgs,
): Record<string, Record<string, WorkerControlNodeFacade>> => {
  const schema = getNodeSchema(args.context.workflow, args.context.node.id);
  const commands = getNormalizedCommandPorts(schema);
  const entries = Object.keys(commands).sort((left, right) => {
    const leftOrder = commands[left]?.order ?? Number.MAX_SAFE_INTEGER;
    const rightOrder = commands[right]?.order ?? Number.MAX_SAFE_INTEGER;
    return leftOrder - rightOrder || left.localeCompare(right);
  });

  return entries.reduce<
    Record<string, Record<string, WorkerControlNodeFacade>>
  >((acc, commandPortId) => {
    const peerConnections = getCommandPeersForPort(
      args.context.workflow,
      args.context.node.id,
      commandPortId,
    );
    const peers = peerConnections
      .map((connection) =>
        getCurrentNode(
          args.context.workflow,
          connection.from === args.context.node.id
            ? connection.to
            : connection.from,
        ),
      )
      .filter(
        (node, index, list) =>
          list.findIndex((entry) => entry.id === node.id) === index,
      );
    const peerKeys = buildPeerKeys(peers);

    acc[commandPortId] = peers.reduce<Record<string, WorkerControlNodeFacade>>(
      (group, peerNode) => {
        const key = peerKeys.get(peerNode.id) ?? peerNode.name;
        group[key] = {
          get: async () =>
            buildControlNodeSnapshot(args.context.workflow, peerNode.id),
          getSchema: async () =>
            normalizeControlNodeSchema(args.context.workflow, peerNode.id),
          set: async (patch) => {
            persistControlNodePatch(args.context.workflow, peerNode.id, patch);
            return buildControlNodeSnapshot(args.context.workflow, peerNode.id);
          },
          validate: async (validationArgs) =>
            args.validatePeer({ nodeId: peerNode.id, args: validationArgs }),
          executeInputs: async (executeInputsArgs) =>
            args.executePeerInputs({
              nodeId: peerNode.id,
              args: executeInputsArgs,
            }),
          commandToolSpec: async () =>
            args.commandToolSpecPeer({ nodeId: peerNode.id }),
          execute: async (executeArgs) => {
            const executed = await args.executePeer({
              nodeId: peerNode.id,
              args: executeArgs,
            });
            return {
              node: buildControlNodeSnapshot(
                args.context.workflow,
                executed.node.id,
              ),
              result: cloneControlValue(executed.result),
            };
          },
        };
        return group;
      },
      {},
    );
    return acc;
  }, {});
};
