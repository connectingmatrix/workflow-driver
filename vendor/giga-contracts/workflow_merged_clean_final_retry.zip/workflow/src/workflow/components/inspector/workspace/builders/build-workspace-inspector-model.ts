import type { WorkflowExecutionResult, WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import { getWorkflowInspectorModule } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.registry';
import { buildWorkspaceHeaderModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-header-model';
import { buildWorkspaceInputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-input-model';
import { buildWorkspaceParametersPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-parameters-model';
import { buildWorkspaceOutputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-output-model';
import type { WorkspaceInspectorModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface BuildWorkspaceInspectorModelArgs {
    config: WorkflowInspectorConfig;
    propertiesEditorState: Record<string, unknown>;
    activeInputTab: string;
    activeParametersTab: string;
    activeInstructionTab: string;
    activeOutputTab: string;
    executionResult: WorkflowExecutionResult | null;
    isExecuting: boolean;
    renderedMarkdown: string;
    hasUnsavedChanges: boolean;
    readOnly?: boolean;
}

export const buildWorkspaceInspectorModel = (args: BuildWorkspaceInspectorModelArgs): WorkspaceInspectorModel => {
    const moduleDefinition = getWorkflowInspectorModule(args.config.modelId);
    return {
        header: buildWorkspaceHeaderModel(args.config, args.isExecuting, args.readOnly, String(args.propertiesEditorState.name ?? '').trim()),
        input: buildWorkspaceInputPanelModel({
            config: args.config,
            moduleDefinition,
            activeTab: args.activeInputTab
        }),
        parameters: buildWorkspaceParametersPanelModel({
            config: args.config,
            moduleDefinition,
            propertiesEditorState: args.propertiesEditorState,
            activeTab: args.activeParametersTab,
            activeInstructionTab: args.activeInstructionTab,
            hasUnsavedChanges: args.hasUnsavedChanges,
            readOnly: args.readOnly
        }),
        output: buildWorkspaceOutputPanelModel({
            config: args.config,
            moduleDefinition,
            propertiesEditorState: args.propertiesEditorState,
            activeTab: args.activeOutputTab,
            executionResult: args.executionResult,
            renderedMarkdown: args.renderedMarkdown
        })
    };
};
