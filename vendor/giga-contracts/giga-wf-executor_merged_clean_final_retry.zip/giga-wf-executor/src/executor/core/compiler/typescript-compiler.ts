type TypeScriptModuleApi = typeof import('typescript');

export type TypeScriptModuleLoader = () => Promise<unknown>;

const utf8Encoder = new TextEncoder();
const utf8Decoder = new TextDecoder();
const compiledWorkerSourceBySignature = new Map<string, string>();

const isModuleContainer = (value: unknown): value is Record<string, unknown> | ((...args: unknown[]) => unknown) =>
    (typeof value === 'object' && value !== null && !Array.isArray(value)) || typeof value === 'function';

const getModuleContainerValues = (value: Record<string, unknown> | ((...args: unknown[]) => unknown)): unknown[] => {
    const keys = Reflect.ownKeys(value as object);
    const values: unknown[] = [];
    keys.forEach((key) => {
        try {
            values.push((value as Record<PropertyKey, unknown>)[key]);
        } catch {
            // Ignore property-access failures from exotic module wrappers.
        }
    });
    return values;
};

const unwrapModuleDefault = (moduleRef: unknown): unknown => {
    let current: unknown = moduleRef;
    for (let index = 0; index < 4; index += 1) {
        if (!isModuleContainer(current)) return current;
        if (typeof (current as { transpileModule?: unknown }).transpileModule === 'function') return current;
        if (!Object.prototype.hasOwnProperty.call(current, 'default')) return current;
        current = (current as Record<string, unknown>).default;
    }
    return current;
};

const findTypeScriptApiCandidate = (moduleRef: unknown): TypeScriptModuleApi | null => {
    const visited = new Set<unknown>();
    const queue: unknown[] = [moduleRef];
    let depth = 0;

    while (queue.length > 0 && depth < 64) {
        const current = queue.shift();
        depth += 1;
        if (!isModuleContainer(current) || visited.has(current)) continue;
        visited.add(current);
        if (typeof (current as { transpileModule?: unknown }).transpileModule === 'function') {
            return current as TypeScriptModuleApi;
        }

        getModuleContainerValues(current).forEach((value) => {
            if (isModuleContainer(value) && !visited.has(value)) {
                queue.push(value);
            }
        });
    }

    return null;
};

const resolveTypescriptModuleApi = (moduleRef: unknown): TypeScriptModuleApi => {
    const resolved = unwrapModuleDefault(moduleRef);
    const directCandidate =
        isModuleContainer(resolved) && typeof (resolved as { transpileModule?: unknown }).transpileModule === 'function'
            ? (resolved as TypeScriptModuleApi)
            : null;
    const candidate = directCandidate ?? findTypeScriptApiCandidate(resolved);
    if (!candidate) {
        throw new Error('TypeScript module is missing transpileModule.');
    }
    return candidate;
};

const getTypescriptModule = async (moduleLoader?: TypeScriptModuleLoader): Promise<TypeScriptModuleApi> => {
    const errors: string[] = [];
    const candidates: Array<{ label: string; load: () => Promise<unknown> }> = [];

    if (moduleLoader) {
        candidates.push({
            label: 'custom-loader',
            load: moduleLoader
        });
    }

    candidates.push(
        {
            label: 'import("typescript/lib/typescript.js")',
            load: () => import('typescript/lib/typescript.js')
        },
        {
            label: 'import("typescript")',
            load: () => import('typescript')
        },
        {
            label: 'globalThis.ts',
            load: async () => (globalThis as Record<string, unknown>).ts
        },
        {
            label: 'globalThis.TypeScript',
            load: async () => (globalThis as Record<string, unknown>).TypeScript
        }
    );

    for (const candidate of candidates) {
        try {
            const moduleRef = await candidate.load();
            return resolveTypescriptModuleApi(moduleRef);
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Unknown TypeScript bootstrap error.';
            errors.push(`[${candidate.label}] ${message}`);
        }
    }

    const finalError = errors.length > 0 ? errors[errors.length - 1] : 'Unknown TypeScript bootstrap error.';
    throw new Error(`Worker TypeScript compiler bootstrap failed: ${finalError}`);
};

const resolveEnumNumber = (enumSource: unknown, key: string, fallback: number): number => {
    if (!enumSource || typeof enumSource !== 'object' || Array.isArray(enumSource)) return fallback;
    const value = (enumSource as Record<string, unknown>)[key];
    return typeof value === 'number' ? value : fallback;
};

const resolveCompilerOptions = (tsModule: TypeScriptModuleApi): Record<string, number | boolean> => ({
    target: resolveEnumNumber((tsModule as unknown as Record<string, unknown>).ScriptTarget, 'ES2022', 9),
    module: resolveEnumNumber((tsModule as unknown as Record<string, unknown>).ModuleKind, 'ESNext', 99),
    moduleResolution: resolveEnumNumber((tsModule as unknown as Record<string, unknown>).ModuleResolutionKind, 'Bundler', 100),
    importsNotUsedAsValues: resolveEnumNumber((tsModule as unknown as Record<string, unknown>).ImportsNotUsedAsValues, 'Remove', 0),
    isolatedModules: true,
    skipLibCheck: true,
    esModuleInterop: true,
    allowSyntheticDefaultImports: true,
    resolveJsonModule: true,
    strict: true
});

const formatCompileDiagnostics = (tsModule: TypeScriptModuleApi, diagnostics: unknown[] | undefined): string[] => {
    if (!diagnostics || diagnostics.length === 0) return [];

    const flattenDiagnosticMessageText: (messageText: unknown, newLine: string) => string =
        typeof tsModule.flattenDiagnosticMessageText === 'function'
            ? (messageText, newLine) => tsModule.flattenDiagnosticMessageText(messageText as import('typescript').DiagnosticMessageChain | string | undefined, newLine)
            : (messageText) => String(messageText ?? '');

    return diagnostics.map((diagnostic) => {
        const diagnosticRecord = diagnostic && typeof diagnostic === 'object' && !Array.isArray(diagnostic) ? (diagnostic as Record<string, unknown>) : {};
        const message = flattenDiagnosticMessageText(diagnosticRecord.messageText, '\n');
        const file = diagnosticRecord.file && typeof diagnosticRecord.file === 'object' && !Array.isArray(diagnosticRecord.file) ? (diagnosticRecord.file as Record<string, unknown>) : {};
        const getLineAndCharacterOfPosition = file.getLineAndCharacterOfPosition;
        if (typeof getLineAndCharacterOfPosition !== 'function') return message;

        try {
            const lineAndCharacter = getLineAndCharacterOfPosition(diagnosticRecord.start ?? 0) as Record<string, unknown>;
            const line = Number(lineAndCharacter.line ?? 0) + 1;
            const character = Number(lineAndCharacter.character ?? 0) + 1;
            const fileName = typeof file.fileName === 'string' ? file.fileName : '<worker>';
            return `${fileName}:${line}:${character} ${message}`;
        } catch {
            return message;
        }
    });
};

export const clearCompiledWorkerSourceCache = (): void => {
    compiledWorkerSourceBySignature.clear();
};

export const toBase64 = (source: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(source, 'utf8').toString('base64');
    }

    const bytes = utf8Encoder.encode(source);
    let binary = '';
    bytes.forEach((byte) => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
};

export const fromBase64 = (encoded: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(encoded, 'base64').toString('utf8');
    }

    const binary = atob(encoded);
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    return utf8Decoder.decode(bytes);
};

export const toDataUrl = (source: string): string => `data:text/javascript;base64,${toBase64(source)}`;

export const rewriteWorkerSourceSpecifiers = (
    source: string,
    executeModuleSpecifier: string,
    executorModuleSpecifier: string,
    builtinStubSpecifier?: string
): string => {
    let rewritten = source
        .replace(/from\s+['"]@workflow\/execute['"]/g, `from '${executeModuleSpecifier}'`)
        .replace(/import\(\s*['"]@workflow\/execute['"]\s*\)/g, `import('${executeModuleSpecifier}')`)
        .replace(/from\s+['"]@workflow\/executor['"]/g, `from '${executorModuleSpecifier}'`)
        .replace(/import\(\s*['"]@workflow\/executor['"]\s*\)/g, `import('${executorModuleSpecifier}')`);

    if (builtinStubSpecifier) {
        rewritten = rewritten
            .replace(/from\s+['"]@workflow\/node-builtin-stub['"]/g, `from '${builtinStubSpecifier}'`)
            .replace(/import\(\s*['"]@workflow\/node-builtin-stub['"]\s*\)/g, `import('${builtinStubSpecifier}')`);
    }

    return rewritten;
};

export const createNodeExecutorSignature = (modelId: string, source: string): string => {
    let hash = 5381;
    const input = `${modelId}:${source}`;
    for (let index = 0; index < input.length; index += 1) {
        hash = ((hash << 5) + hash) ^ input.charCodeAt(index);
    }
    return `wf-sign-v1-${(hash >>> 0).toString(16)}`;
};

export const compileWorkerSource = async (params: {
    modelId: string;
    source: string;
    sourceSignature: string;
    cacheKey?: string;
    moduleLoader?: TypeScriptModuleLoader;
}): Promise<string> => {
    const cacheKey = params.cacheKey ?? `${params.modelId}:${params.sourceSignature}`;
    const cached = compiledWorkerSourceBySignature.get(cacheKey);
    if (cached) {
        return cached;
    }

    const tsModule = await getTypescriptModule(params.moduleLoader);
    const transpileResult = tsModule.transpileModule(params.source, {
        fileName: `${params.modelId}.worker.ts`,
        reportDiagnostics: true,
        compilerOptions: resolveCompilerOptions(tsModule)
    });

    const diagnostics = Array.isArray(transpileResult.diagnostics) ? transpileResult.diagnostics : [];
    const errorCategory = resolveEnumNumber((tsModule as unknown as Record<string, unknown>).DiagnosticCategory, 'Error', 1);
    const hasError = diagnostics.some((diagnostic: unknown) => {
        const record = diagnostic && typeof diagnostic === 'object' && !Array.isArray(diagnostic) ? (diagnostic as Record<string, unknown>) : {};
        return Number(record.category ?? -1) === errorCategory;
    });
    if (hasError) {
        const formatted = formatCompileDiagnostics(tsModule, diagnostics);
        throw new Error(`Worker TypeScript compile failed for model "${params.modelId}": ${formatted.join(' | ')}`);
    }

    if (typeof transpileResult.outputText !== 'string') {
        throw new Error(`Worker TypeScript compile failed for model "${params.modelId}": transpile output was not generated.`);
    }

    compiledWorkerSourceBySignature.set(cacheKey, transpileResult.outputText);
    return transpileResult.outputText;
};

export const importCompiledModule = async <T extends Record<string, unknown>>(params: {
    source: string;
    modelId: string;
    moduleLabel: 'worker' | 'validator';
}): Promise<T> => {
    const moduleSpecifier = toDataUrl(params.source);
    try {
        return (await import(/* webpackIgnore: true */ moduleSpecifier)) as T;
    } catch (error) {
        const message = error instanceof Error ? error.message : `Failed to load ${params.moduleLabel} module.`;
        throw new Error(`Unable to load ${params.moduleLabel} module for model "${params.modelId}": ${message}`);
    }
};
