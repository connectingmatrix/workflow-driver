/// <reference types="cypress" />

const WORKER_SOURCE = `import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
    fs.writefileSync('abeer.txt', 'Hello World');
    return { output: { ok: fs.readdirSync('.') }, status: 'passed', logs: ['user-node executed'] };
};`;

const FAILURE_MARKERS = ['#<Promise> could not be cloned', 'TypeScript module is missing transpileModule', '[custom-loader]', '[import("typescript")]'];

const setCodeEditorValue = (editorId: string, value: string): void => {
    cy.window().then((win) => {
        const editors = (win as Window & { __workflowCodeEditors?: Record<string, { setValue: (nextValue: string) => void }> }).__workflowCodeEditors;
        expect(editors?.[editorId], `expected ${editorId} editor bridge`).to.exist;
        editors?.[editorId]?.setValue(value);
    });
};

const assertNoFailureMarkers = (text: string): void => {
    FAILURE_MARKERS.forEach((marker) => {
        expect(text, `expected output to not include ${marker}`).not.to.contain(marker);
    });
};

describe('workflow-ui user node preview node runtime', () => {
    it('runs a user node with sync fs access without promise clone failures', () => {
        cy.visit('/');
        cy.contains('Workflow UI Playground').should('exist');

        cy.get('[data-cy="open-user-node-designer-studio"]').click();
        cy.get('[data-cy="user-node-designer-dialog"]').should('exist');
        cy.contains('.p-tabview-nav-link', 'Node Code').click();

        cy.window().its('__workflowCodeEditors').should('have.property', 'user-node-worker-monaco');
        setCodeEditorValue('user-node-worker-monaco', WORKER_SOURCE);

        cy.contains('[data-cy="user-node-runtime-badge"]', 'Node').should('exist');
        cy.get('[data-cy="user-node-run"]').click();

        cy.contains('[data-cy="user-node-preview-status"]', 'passed', { timeout: 20000 }).should('exist');
        cy.get('[data-cy="user-node-preview-output"]', { timeout: 20000 })
            .invoke('text')
            .then((text) => {
                assertNoFailureMarkers(text);
                expect(text).to.contain('abeer.txt');
            });

        cy.contains('.p-tabview-nav-link', 'Logs').click();
        cy.get('[data-cy="user-node-preview-logs"]', { timeout: 20000 })
            .invoke('text')
            .then((text) => {
                assertNoFailureMarkers(text);
                expect(text).to.contain('user-node executed');
            });
    });
});
