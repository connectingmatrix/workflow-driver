import React from 'react';
import UserNodeCredentialDesigner from './UserNodeCredentialDesigner';
import UserNodeFieldDesigner from './UserNodeFieldDesigner';
import UserNodeIconDesigner from './UserNodeIconDesigner';
import UserNodePortDesigner from './UserNodePortDesigner';
import { UserNodeSchemaDraft, createFieldDraft } from './user-node-schema-draft.utils';

interface UserNodeInspectorDesignerTabProps {
    draft: UserNodeSchemaDraft;
    onChange: (draft: UserNodeSchemaDraft) => void;
}

const UserNodeInspectorDesignerTab: React.FC<UserNodeInspectorDesignerTabProps> = ({ draft, onChange }) => {
    return (
        <div className="wf-user-node-designer__designer-tab">
            <UserNodeIconDesigner
                iconMode={draft.iconMode}
                iconClass={draft.iconClass}
                iconColor={draft.iconColor}
                iconSvg={draft.iconSvg}
                onChange={({ iconMode, iconClass, iconColor, iconSvg }) => onChange({ ...draft, iconMode, iconClass, iconColor, iconSvg })}
            />
            <UserNodeCredentialDesigner useCredentials={draft.useCredentials} onChange={(useCredentials) => onChange({ ...draft, useCredentials })} />
            <UserNodeFieldDesigner fields={draft.fields} onChange={(fields) => onChange({ ...draft, fields })} onAdd={() => onChange({ ...draft, fields: [...draft.fields, createFieldDraft(draft.fields.length + 1)] })} />
            <UserNodePortDesigner ports={draft.ports} onChange={(ports) => onChange({ ...draft, ports })} />
        </div>
    );
};

export default UserNodeInspectorDesignerTab;
