import { describe, expect, it } from 'vitest';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { buildInspectorInputContext } from '@workflow/ui/workflow/utils/workflow-canvas-node.utils';

describe('workflow canvas node input preview', () => {
    it('shows data inputs without command peers in inspector JSON', () => {
        const workflow = createEmptyWorkflow('wf_canvas_input_governor');
        const code = createWorkflowNode(workflow, 'code', 'Code Node 5', 1);
        const openai = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serp = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        const governor = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 4);
        code.ports.out.output = { query: 'Iran news', task: 'threat analysis' };
        workflow.nodes = [code, openai, serp, governor];
        workflow.connections = [
            createConnection('c_data', code.id, governor.id, 'out:output', 'in:input'),
            createConnection('c_llm', openai.id, governor.id, 'cmd:command', 'cmd:llm'),
            createConnection('c_tool', serp.id, governor.id, 'cmd:command', 'cmd:tools')
        ];
        workflow.nodeModels = undefined;

        const input = buildInspectorInputContext(workflow, governor.id, { fallback: true });

        expect(input).toEqual({
            [code.id]: {
                query: 'Iran news',
                task: 'threat analysis'
            }
        });
    });

    it('keeps fallback input when only command peers are attached', () => {
        const workflow = createEmptyWorkflow('wf_canvas_input_command_only');
        const openai = createWorkflowNode(workflow, 'openai', 'OpenAI', 1);
        const governor = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 2);
        workflow.nodes = [openai, governor];
        workflow.connections = [createConnection('c_llm', openai.id, governor.id, 'cmd:command', 'cmd:llm')];

        expect(buildInspectorInputContext(workflow, governor.id, { input: 'manual' })).toEqual({ input: 'manual' });
    });
});
