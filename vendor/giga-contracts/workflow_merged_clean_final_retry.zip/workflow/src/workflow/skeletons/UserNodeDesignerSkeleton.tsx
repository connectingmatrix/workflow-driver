import React from 'react';
import { Skeleton } from 'primereact/skeleton';

const UserNodeDesignerSkeleton: React.FC = () => (
    <div className="p-3">
        <div className="flex gap-2 mb-3">
            <Skeleton width="12rem" height="2.5rem" />
            <Skeleton width="8rem" height="2.5rem" />
        </div>
        <div className="grid">
            <div className="col-12 md:col-6">
                <Skeleton width="100%" height="2.5rem" className="mb-2" />
                <Skeleton width="100%" height="2.5rem" className="mb-2" />
                <Skeleton width="100%" height="2.5rem" className="mb-2" />
                <Skeleton width="100%" height="6rem" />
            </div>
            <div className="col-12 md:col-6">
                <Skeleton width="100%" height="12rem" className="mb-2" />
                <Skeleton width="100%" height="10rem" />
            </div>
        </div>
    </div>
);

export default UserNodeDesignerSkeleton;
