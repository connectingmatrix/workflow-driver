import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

const NODES_ROOT = path.resolve(process.cwd(), '../workflow-nodes/src/nodes');

const getNodeDirectories = (): string[] =>
    readdirSync(NODES_ROOT)
        .map((name) => path.join(NODES_ROOT, name))
        .filter((entryPath) => statSync(entryPath).isDirectory())
        .filter((entryPath) => readdirSync(entryPath).some((name) => name.endsWith('-schema.json')))
        .sort((a, b) => a.localeCompare(b));

const STATIC_IMPORT_PATTERN = /^\s*import\s+[^('"].*$/gm;

const REQUIRED_EXPORTS = ['validate', 'init', 'onUpdate', 'execute'];

describe('node worker contract', () => {
    const nodeDirectories = getNodeDirectories();

    it('ensures each node directory has worker.ts with required exports', () => {
        expect(nodeDirectories.length).toBeGreaterThan(0);

        nodeDirectories.forEach((nodeDirectory) => {
            const workerPath = path.join(nodeDirectory, 'worker.ts');
            const source = readFileSync(workerPath, 'utf8');
            REQUIRED_EXPORTS.forEach((exportName) => {
                expect(source.includes(`export const ${exportName}`), `${workerPath} missing export ${exportName}`).toBe(true);
            });
        });
    });

    it('ensures workers use shared helper modules without redeclaring legacy helpers', () => {
        nodeDirectories.forEach((nodeDirectory) => {
            const workerPath = path.join(nodeDirectory, 'worker.ts');
            const source = readFileSync(workerPath, 'utf8');
            const matches = source.match(STATIC_IMPORT_PATTERN) ?? [];
            expect(matches.length, `${workerPath} should contain at least one static import`).toBeGreaterThan(0);
            expect(/from ['"]@workflow\/(executor|nodes|charts)/.test(source), `${workerPath} should import shared workflow helpers`).toBe(true);
            expect(source.includes('const toRecord ='), `${workerPath} must not redeclare toRecord`).toBe(false);
            expect(source.includes('const toErrorResult ='), `${workerPath} must not redeclare toErrorResult`).toBe(false);
            expect(source.includes('const toNode ='), `${workerPath} must not redeclare toNode`).toBe(false);
            expect(source.includes('const normalizeResult ='), `${workerPath} must not redeclare normalizeResult`).toBe(false);
        });
    });

    it('ensures standalone validate.ts files are removed', () => {
        nodeDirectories.forEach((nodeDirectory) => {
            const validatePath = path.join(nodeDirectory, 'validate.ts');
            expect(() => statSync(validatePath)).toThrow();
        });
    });
});
