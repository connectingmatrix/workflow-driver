import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWorkerNodeHandler, WorkflowNodeStatusEnum } from '@workflow/executor';
import { getNodeModule } from '@workflow/nodes/node-utils';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WorkflowAuthModeEnum } from '@workflow/ui/workflow/types';
import { withNodeExecutors } from '@workflow/ui/workflow/utils/workflow-node-executors.utils';

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: WorkflowAuthModeEnum.None,
    manualHeaders: {}
};

describe('wait node', () => {
    afterEach(() => {
        vi.useRealTimers();
    });

    it('clamps configured wait duration to 300 seconds max', async () => {
        vi.useFakeTimers();
        const workflow = createEmptyWorkflow('wf_wait_clamp');
        const node = createWorkflowNode(workflow, 'wait', 'Wait', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            time: 10,
            unit: 'minutes',
            value: { value: 123 }
        };

        const module = getNodeModule('wait');
        const execution = module.execute({
            node,
            workflow,
            settings,
            input: {}
        } as any);

        await vi.runAllTimersAsync();
        const result = await execution;
        const output = (result.output ?? {}) as Record<string, any>;

        expect(output.wait?.applied?.milliseconds).toBe(300000);
        expect(output.wait?.applied?.clamped).toBe(true);
        expect(output.value).toBe(123);
    });

    it('validates negative wait time as invalid', async () => {
        const workflow = createEmptyWorkflow('wf_wait_validate');
        const node = createWorkflowNode(workflow, 'wait', 'Wait', 1);
        node.runtime = {
            ...(node.runtime ?? {}),
            time: -5,
            unit: 'seconds'
        };
        workflow.nodes = [node];

        const executableWorkflow = withNodeExecutors(workflow);
        const executionNode = executableWorkflow.nodes.find((entry) => entry.id === node.id);
        if (!executionNode) throw new Error('Wait node not found.');

        const handler = createWorkerNodeHandler({
            modelId: executionNode.modelId,
            runtimeEnvironment: 'browser'
        });
        const result = await handler({
            node: executionNode,
            workflow: executableWorkflow,
            settings,
            input: {}
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('greater than or equal to 0');
    });
});
