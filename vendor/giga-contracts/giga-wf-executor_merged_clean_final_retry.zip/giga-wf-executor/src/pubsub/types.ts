export type WorkflowPubsubEventName =
  | 'workflow:catalog:status'
  | 'workflow:execution:update'
  | 'workflow:event'
  | 'workflow:step:result'
  | 'workflow:error'
  | 'workflow:preview:log'
  | 'workflow:preview:state'
  | 'workflow:preview:result'
  | 'workflow:preview:stop'
  | 'workflow:preview:error'
  | 'workflow:webhook:test:invoke';

export type WorkflowPubsubEvent = {
  eventName: WorkflowPubsubEventName;
  payload: unknown;
  roomName: string;
};

export type WorkflowPubsubHandler = (roomName: string, event: WorkflowPubsubEvent) => void;

export type WorkflowPubsub = {
  clear: () => void;
  listen: (roomName: string, handler: WorkflowPubsubHandler) => () => void;
  publish: (roomName: string, eventName: WorkflowPubsubEventName, payload: unknown) => void;
};
