import { assertDynamicNodeSourcePolicy, readDynamicDependencyPolicyFromEnv, validateDynamicDependencies, ensureDynamicPackageCache } from '../executor/agent-runtime';

export type GeneratedDynamicWorkflowNode = {
  id: string;
  modelId: string;
  name: string;
  sourceFiles: Record<string, string>;
  runtime?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  dependencies?: string[];
  dependencyCacheDir?: string | null;
};

const text = (value: unknown): string => String(value ?? '').trim();

export const createDynamicWorkflowNodeDefinition = async (input: Partial<GeneratedDynamicWorkflowNode> & { prompt?: string | null }): Promise<GeneratedDynamicWorkflowNode> => {
  const sourceFiles = input.sourceFiles || {
    'worker.ts': `import type { WorkerExecuteResult, WorkerPayload } from '@workflow/executor';\n\nexport const execute = async (_payload: WorkerPayload): Promise<WorkerExecuteResult> => ({\n  output: { message: ${JSON.stringify(text(input.prompt || 'Dynamic node executed.'))} },\n  status: 'passed',\n});\n`,
  };
  assertDynamicNodeSourcePolicy(sourceFiles);
  const dependencyPolicy = validateDynamicDependencies({ ...readDynamicDependencyPolicyFromEnv(), dependencies: input.dependencies || [] });
  if (!dependencyPolicy.ok) throw new Error(dependencyPolicy.denied.map((item) => `${item.dependency}: ${item.reason}`).join('\n'));
  const cache = await ensureDynamicPackageCache(dependencyPolicy.allowed);
  return {
    id: text(input.id || `dynamic-node-${Date.now()}`),
    modelId: text(input.modelId || 'dynamic-node'),
    name: text(input.name || 'Dynamic Workflow Node'),
    sourceFiles,
    dependencies: dependencyPolicy.allowed,
    dependencyCacheDir: cache.dir,
    runtime: input.runtime || {},
    metadata: { ...(input.metadata || {}), generatedBy: 'ai-agent', generatedAt: new Date().toISOString(), dependencyCacheDir: cache.dir },
  };
};
