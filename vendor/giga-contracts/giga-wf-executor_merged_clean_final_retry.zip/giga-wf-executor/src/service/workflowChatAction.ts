import { compileWorkflowCypher } from '../workflow-ai-creation';
import { workflowNodeCatalog, workflowNodeDetails } from '../workflow-ai-creation';
import type { ExecutorChatAdapter } from './types';

const record = (value: unknown) => (value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {});
const text = (value: unknown) => String(value || '').trim();

const executeWorkflowChatAction = async (params: {
  executeHostAction?: (name: string, runtime: unknown, input?: Record<string, unknown>) => Promise<Record<string, unknown>>;
  name: string;
  runtime: unknown;
  input?: Record<string, unknown>;
}) => {
  if (params.name === 'fetch_workflow_node_catalog') {
    const catalog = workflowNodeCatalog();
    return { data: { catalog }, retrievedChunks: [], sources: [], summary: `Fetched ${catalog.length} workflow node definitions.` };
  }
  if (params.name === 'fetch_workflow_node_details') {
    const modelIds = Array.isArray(record(params.input).model_ids) ? (record(params.input).model_ids as unknown[]).map((item) => text(item)).filter(Boolean) : [];
    const nodes = workflowNodeDetails(modelIds);
    return { data: { nodes }, retrievedChunks: [], sources: [], summary: `Fetched ${nodes.length} workflow node source bundle(s).` };
  }
  if (params.name === 'validate_workflow_cypher') {
    const compiled = compileWorkflowCypher({
      cypher: text(record(params.input).cypher),
      description: text(record(params.input).description),
      executable: record(params.input).executable !== false,
      metadata: {},
      name: text(record(params.input).name) || 'Workflow',
    });
    return { data: compiled, retrievedChunks: [], sources: [], summary: compiled.validation.ok ? 'Workflow Cypher is valid.' : 'Workflow Cypher has validation errors.' };
  }
  if (!params.executeHostAction) throw new Error(`Workflow chat action ${params.name} is not configured.`);
  return params.executeHostAction(params.name, params.runtime, params.input);
};

export const readWorkflowChatAdapter = (params: {
  catalog: ExecutorChatAdapter['catalog'];
  executeHostAction?: (name: string, runtime: unknown, input?: Record<string, unknown>) => Promise<Record<string, unknown>>;
}): ExecutorChatAdapter => ({
  catalog: params.catalog,
  execute: (name, runtime, input) => executeWorkflowChatAction({ executeHostAction: params.executeHostAction, name, runtime, input }),
});
