import { describe, expect, it } from "vitest";
import {
  createNodeExecutorSignature,
  createWorkerNodeHandler,
} from "../executor/worker-runtime";
import { WorkflowNodeStatusEnum } from "../types";

const toBase64 = (source: string) =>
  Buffer.from(source, "utf8").toString("base64");
const LARGE_TEXT = "y".repeat(512 * 1024);
const GOVERNOR_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = payload.NODE.CONTROL_NODES.llm?.OpenAI;
  const executed = await peer.execute();
  return { output: { length: String(executed.result.output?.text || '').length }, status: 'passed', logs: [] };
};`;
const OPENAI_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { text: ${JSON.stringify(LARGE_TEXT)} }, status: 'passed', logs: [] });`;
const PATCH_GOVERNOR_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => {
  const peer = payload.NODE.CONTROL_NODES.llm?.OpenAI;
  const executed = await peer.execute({ patch: { properties: { prompt: 'patched prompt' } } });
  return { output: executed.result.output, status: 'passed', logs: [] };
};`;
const PATCH_OPENAI_SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({ output: { prompt: payload.NODE.properties.prompt }, status: 'passed', logs: [] });`;

describe("control node ipc", () => {
  it("delivers large control-peer results back to the waiting sandbox worker", async () => {
    const governor = {
      id: "node_1",
      gigaId: "node_1",
      modelId: "governor-ipc",
      type: "workflowStep",
      name: "Governor",
      description: "",
      kind: "process",
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: {},
      ports: { in: {}, out: {} },
    };
    const openai = {
      id: "node_2",
      gigaId: "node_2",
      modelId: "openai",
      type: "workflowStep",
      name: "OpenAI",
      description: "",
      kind: "process",
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: {},
      ports: { in: {}, out: {} },
    };
    const workflow = {
      metadata: { id: "wf_control_ipc", name: "Control IPC" },
      nodeModels: {
        "governor-ipc": {
          inputs: { input: {} },
          outputs: { output: {} },
          commands: {
            llm: { portType: "bi-directional", allowMultipleArrows: true },
          },
        },
        openai: {
          inputs: { input: {} },
          outputs: { output: {} },
          commands: {
            command: { portType: "bi-directional", allowMultipleArrows: true },
          },
        },
      },
      nodes: [governor, openai],
      connections: [
        {
          id: "c1",
          name: "OpenAI -> Governor",
          from: "node_2",
          to: "node_1",
          sourceHandle: "cmd:command",
          targetHandle: "cmd:llm",
        },
      ],
      NODE_EXECUTORS: {
        "governor-ipc": toBase64(GOVERNOR_SOURCE),
        openai: toBase64(OPENAI_SOURCE),
      },
      NODE_EXECUTOR_SIGNATURES: {
        "governor-ipc": createNodeExecutorSignature(
          "governor-ipc",
          GOVERNOR_SOURCE,
        ),
        openai: createNodeExecutorSignature("openai", OPENAI_SOURCE),
      },
    };
    const result = await createWorkerNodeHandler({
      modelId: "governor-ipc",
      runtimeEnvironment: "node",
    })({
      node: governor,
      workflow,
      settings: { graphqlUrl: "http://localhost/graphql", authMode: "none" },
      input: {},
      requestContext: {
        request: { headers: {} },
        supabase: {},
        userId: "user_1",
      },
      hostContext: {},
    } as any);

    expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
    expect(Number((result.output as Record<string, unknown>).length || 0)).toBe(
      LARGE_TEXT.length,
    );
  }, 20000);

  it("passes transient properties patches to control-peer execution", async () => {
    const governor = {
      id: "node_1",
      gigaId: "node_1",
      modelId: "governor-ipc",
      type: "workflowStep",
      name: "Governor",
      description: "",
      kind: "process",
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: {},
      properties: {},
      ports: { in: {}, out: {} },
    };
    const openai = {
      id: "node_2",
      gigaId: "node_2",
      modelId: "openai",
      type: "workflowStep",
      name: "OpenAI",
      description: "",
      kind: "process",
      status: WorkflowNodeStatusEnum.Stopped,
      position: { x: 0, y: 0 },
      runtime: {},
      properties: { prompt: "original prompt" },
      ports: { in: {}, out: {} },
    };
    const workflow = {
      metadata: { id: "wf_control_patch", name: "Control Patch" },
      nodeModels: {
        "governor-ipc": {
          inputs: { input: {} },
          outputs: { output: {} },
          commands: {
            llm: { portType: "bi-directional", allowMultipleArrows: true },
          },
        },
        openai: {
          inputs: { input: {} },
          outputs: { output: {} },
          commands: {
            command: { portType: "bi-directional", allowMultipleArrows: true },
          },
        },
      },
      nodes: [governor, openai],
      connections: [
        {
          id: "c1",
          name: "OpenAI -> Governor",
          from: "node_2",
          to: "node_1",
          sourceHandle: "cmd:command",
          targetHandle: "cmd:llm",
        },
      ],
      NODE_EXECUTORS: {
        "governor-ipc": toBase64(PATCH_GOVERNOR_SOURCE),
        openai: toBase64(PATCH_OPENAI_SOURCE),
      },
      NODE_EXECUTOR_SIGNATURES: {
        "governor-ipc": createNodeExecutorSignature(
          "governor-ipc",
          PATCH_GOVERNOR_SOURCE,
        ),
        openai: createNodeExecutorSignature("openai", PATCH_OPENAI_SOURCE),
      },
    };
    const result = await createWorkerNodeHandler({
      modelId: "governor-ipc",
      runtimeEnvironment: "node",
    })({
      node: governor,
      workflow,
      settings: { graphqlUrl: "http://localhost/graphql", authMode: "none" },
      input: {},
      requestContext: {
        request: { headers: {} },
        supabase: {},
        userId: "user_1",
      },
      hostContext: {},
    } as any);

    expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
    expect((result.output as Record<string, unknown>).prompt).toBe(
      "patched prompt",
    );
  }, 20000);
});
