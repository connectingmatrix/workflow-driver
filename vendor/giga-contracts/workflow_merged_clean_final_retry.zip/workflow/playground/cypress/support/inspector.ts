/// <reference types="cypress" />

export const openNodeInspector = (nodeName: string): void => {
    cy.contains('.base-node__name', nodeName)
        .closest('.base-node')
        .as('targetNode');

    cy.get('@targetNode').click({ force: true });
    cy.get('@targetNode').find('button[title="More Actions"]').click({ force: true });
    cy.contains('.p-menuitem-text', 'Open Inspector').click({ force: true });
};

export const closeNodeInspector = (): void => {
    cy.get('[data-cy="workflow-inspector-action-close-node"]').click({ force: true });
};

export const assertWorkspaceInspectorShell = (title: string): void => {
    cy.contains('.cnw-header__title', title).should('be.visible');
    cy.contains('.cnw-panel__title', 'Input').should('be.visible');
    cy.contains('.cnw-panel__title', 'Parameters').should('be.visible');
    cy.contains('.cnw-panel__title', 'Output').should('be.visible');
    cy.get('.cnw-input-panel__scroll').should('exist');
    cy.get('.cnw-parameters-panel__scroll').should('exist');
    cy.get('.cnw-output-panel__scroll').should('exist');
};

export const selectWorkspaceParametersTab = (label: string): void => {
    cy.contains('.cnw-segmented-tabs__button', label).click({ force: true });
};

export const scrollParametersSectionIntoView = (title: string): void => {
    cy.contains('.cnw-section-block__title', title)
        .scrollIntoView({ block: 'center' })
        .should('be.visible');
};
