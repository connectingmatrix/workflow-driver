import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWorkflowExecutorHostContext, getWorkflowMcpRuntimeManager } from '@workflow/ui/workflow/executor/mcp-runtime.manager';
import { getNodeModule } from '@workflow/nodes/node-utils';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WorkflowAuthModeEnum } from '@workflow/ui/workflow/types';

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: WorkflowAuthModeEnum.None,
    manualHeaders: {}
};

const originalFetch = globalThis.fetch;

const createResponse = (body: unknown, status = 200, headers: Record<string, string> = {}): Response =>
    new Response(body ? JSON.stringify(body) : '', { status, headers });

const createMcpHostContext = () => ({
    ...createWorkflowExecutorHostContext(),
    fetchCredentialById: vi.fn(async () => ({
        id: 'cred-mcp-1',
        credentialId: 'cred-mcp-1',
        credentialName: 'Demo MCP',
        serviceId: 'mcp',
        serviceName: 'MCP',
        serviceIcon: null,
        scope: 'PERSONAL' as const,
        values: {
            mcpServers: {
                demo: {
                    type: 'streamable-http',
                    url: 'https://demo.example.com/mcp'
                }
            }
        }
    }))
});

afterEach(() => {
    globalThis.fetch = originalFetch;
    vi.restoreAllMocks();
});

describe('mcp runtime manager', () => {
    it('creates fallback manager when host context is missing', () => {
        const manager = getWorkflowMcpRuntimeManager(undefined);
        expect(manager.listServers()).toEqual([]);
    });

    it('lists real MCP tools from the capabilities node', async () => {
        globalThis.fetch = vi
            .fn()
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-1', result: { protocolVersion: '2024-11-05', serverInfo: { name: 'Demo MCP Server' }, capabilities: { tools: { list: true, call: true } } } }))
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }, { name: 'GenerateBike' }] } })) as typeof fetch;

        const workflow = createEmptyWorkflow('wf_mcp_capabilities');
        const node = createWorkflowNode(workflow, 'mcp-capabilities', 'MCP Capabilities', 1);
        node.runtime = { ...(node.runtime ?? {}), credentialId: 'cred-mcp-1' };

        const result = await getNodeModule('mcp-capabilities').execute({
            node,
            workflow,
            settings,
            input: {},
            hostContext: createMcpHostContext()
        } as any);

        const output = result.output as Record<string, any>;
        expect(output.protocolVersion).toBe('2024-11-05');
        expect(output.serverInfo.name).toBe('Demo MCP Server');
        expect(output.tools.map((tool: Record<string, unknown>) => tool.name)).toEqual(['GreetMe', 'GenerateBike']);
    });

    it('calls a real MCP tool when connected workflow input provides toolName and toolArguments', async () => {
        globalThis.fetch = vi
            .fn()
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-1', result: { protocolVersion: '2024-11-05', serverInfo: { name: 'Demo MCP Server' }, capabilities: { tools: { list: true, call: true } } } }))
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }] } }))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-3', result: { content: [{ type: 'text', text: 'Hello Abeer!' }] } })) as typeof fetch;

        const workflow = createEmptyWorkflow('wf_mcp_runtime');
        const node = createWorkflowNode(workflow, 'mcp-runtime', 'MCP Runtime', 1);
        node.runtime = { ...(node.runtime ?? {}), credentialId: 'cred-mcp-1', capabilityQuery: 'debug tools', sourceValue: { input: { build_greet_request: { toolName: 'GreetMe', toolArguments: { name: 'Abeer' } } } } };

        const result = await getNodeModule('mcp-runtime').execute({
            node,
            workflow,
            settings,
            input: { input: { build_greet_request: { toolName: 'GreetMe', toolArguments: { name: 'Abeer' } } } },
            hostContext: createMcpHostContext()
        } as any);

        const output = result.output as Record<string, any>;
        expect(output.toolCall.name).toBe('GreetMe');
        expect(output.toolCall.arguments).toEqual({ name: 'Abeer' });
        expect(output.toolResult.content[0].text).toBe('Hello Abeer!');
        expect(output.tools[0].name).toBe('GreetMe');
    });

    it('calls a real MCP tool when inspector current input provides toolName and toolArguments', async () => {
        globalThis.fetch = vi
            .fn()
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-1', result: { protocolVersion: '2024-11-05', serverInfo: { name: 'Demo MCP Server' }, capabilities: { tools: { list: true, call: true } } } }))
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }] } }))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-3', result: { content: [{ type: 'text', text: 'Hello Abeer!' }] } })) as typeof fetch;

        const workflow = createEmptyWorkflow('wf_mcp_runtime_current');
        const node = createWorkflowNode(workflow, 'mcp-runtime', 'MCP Runtime', 1);
        node.runtime = { ...(node.runtime ?? {}), credentialId: 'cred-mcp-1', sourceValue: { current: { toolName: 'GreetMe', toolArguments: { name: 'Abeer' } } } };

        const result = await getNodeModule('mcp-runtime').execute({
            node,
            workflow,
            settings,
            input: {},
            hostContext: createMcpHostContext()
        } as any);

        const output = result.output as Record<string, any>;
        expect(output.toolCall.name).toBe('GreetMe');
        expect(output.toolResult.content[0].text).toBe('Hello Abeer!');
    });

    it('fails when multiple upstream tool calls are present', async () => {
        globalThis.fetch = vi
            .fn()
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-1', result: { protocolVersion: '2024-11-05', serverInfo: { name: 'Demo MCP Server' }, capabilities: { tools: { list: true, call: true } } } }))
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }, { name: 'GenerateBike' }] } })) as typeof fetch;

        const workflow = createEmptyWorkflow('wf_mcp_runtime_ambiguous');
        const node = createWorkflowNode(workflow, 'mcp-runtime', 'MCP Runtime', 1);
        node.runtime = { ...(node.runtime ?? {}), credentialId: 'cred-mcp-1', sourceValue: { input: { first_node: { toolName: 'GreetMe', toolArguments: { name: 'Abeer' } }, second_node: { toolName: 'GenerateBike', toolArguments: {} } } } };

        const result = await getNodeModule('mcp-runtime').execute({
            node,
            workflow,
            settings,
            input: {},
            hostContext: createMcpHostContext()
        } as any);

        expect(result.status).toBe('failed');
        expect((result.output as Record<string, any>).error).toContain('multiple MCP tool call candidates');
    });

    it('routes to loop output when no tool call is provided', async () => {
        globalThis.fetch = vi
            .fn()
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-1', result: { protocolVersion: '2024-11-05', serverInfo: { name: 'Demo MCP Server' }, capabilities: { tools: { list: true, call: true } } } }))
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }] } })) as typeof fetch;

        const workflow = createEmptyWorkflow('wf_mcp_loop');
        const node = createWorkflowNode(workflow, 'mcp-runtime', 'MCP Runtime', 1);
        node.runtime = { ...(node.runtime ?? {}), credentialId: 'cred-mcp-1', forwardNonMcpWork: true, loopNonMcpWork: true, maxLoopPasses: 3, sourceValue: { topic: 'hello' } };

        const result = await getNodeModule('mcp-runtime').execute({
            node,
            workflow,
            settings,
            input: { input: { topic: 'hello' } },
            hostContext: createMcpHostContext()
        } as any);

        const output = result.output as Record<string, any>;
        expect(output.__activeOutputs[0]).toBe('loop');
        expect(output.forwardedPayload.topic).toBe('hello');
        expect(output.tools[0].name).toBe('GreetMe');
    });

    it('rejects MCP execution when no credential is selected', async () => {
        const workflow = createEmptyWorkflow('wf_mcp_stdio');
        const node = createWorkflowNode(workflow, 'mcp-runtime', 'MCP Runtime', 1);
        node.runtime = { ...(node.runtime ?? {}) };

        const result = await getNodeModule('mcp-runtime').execute({
            node,
            workflow,
            settings,
            input: {},
            hostContext: createWorkflowExecutorHostContext()
        } as any);

        expect(result.status).toBe('failed');
        expect((result.output as Record<string, any>).error).toContain('MCP credential is required');
    });
});
