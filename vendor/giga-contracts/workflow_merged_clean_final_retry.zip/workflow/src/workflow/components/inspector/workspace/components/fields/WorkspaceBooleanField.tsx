import { InputSwitch } from 'primereact/inputswitch';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import { parseWorkspaceFieldString } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/workspace-field.utils';

interface WorkspaceBooleanFieldProps {
    id: string;
    checked: boolean;
    editable: boolean;
    compact?: boolean;
    allowVariables: boolean;
    variableMode: boolean;
    value: unknown;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: unknown) => void;
}

export const WorkspaceBooleanField = ({ id, checked, editable, compact = false, allowVariables, variableMode, value, variableContext, variableSuggestions, onChange }: WorkspaceBooleanFieldProps): JSX.Element => {

    if (!allowVariables) {
        return (
            <div className={`cnw-switch-field${compact ? ' cnw-switch-field--compact' : ''}`}>
                <span className={`cnw-switch-field__state${checked ? ' is-active' : ''}`}>{checked ? 'On' : 'Off'}</span>
                <InputSwitch inputId={id} checked={checked} onChange={(event) => onChange(event.value === true)} disabled={!editable} />
            </div>
        );
    }

    if (variableMode) {
        return (
            <VariableTextField id={id} value={parseWorkspaceFieldString(value)} onChange={onChange} allowVariables variableContext={variableContext} variableSuggestions={variableSuggestions} disabled={!editable} className="cnw-prime-input" />
        );
    }

    return (
        <div className={`cnw-switch-field${compact ? ' cnw-switch-field--compact' : ''}`}>
            <span className={`cnw-switch-field__state${checked ? ' is-active' : ''}`}>{checked ? 'On' : 'Off'}</span>
            <InputSwitch inputId={id} checked={checked} onChange={(event) => onChange(event.value === true)} disabled={!editable} />
        </div>
    );
};
