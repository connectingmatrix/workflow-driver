import path from 'node:path';
import { fileURLToPath } from 'node:url';

const repoRoot = fileURLToPath(new URL('.', import.meta.url));
const srcRoot = path.resolve(repoRoot, 'src');
const uiRoot = path.resolve(repoRoot, '../giga-ai-ui/src');
const uiCacheRoot = path.resolve(repoRoot, '../giga-ai-ui/cache');
const workflowNodesRoot = path.resolve(repoRoot, '../workflow-nodes/src');
const workflowChartsRoot = path.resolve(repoRoot, 'node_modules/@workflow/charts/dist');
const executorRoot = path.resolve(repoRoot, '../giga-wf-executor/src');

export const workflowResolveAliases = [
    {
        find: /^@workflow\/ui$/,
        replacement: srcRoot
    },
    {
        find: /^@workflow\/ui\/(.*)$/,
        replacement: `${srcRoot}/$1`
    },
    {
        find: /^@\/(.*)$/,
        replacement: `${uiRoot}/$1`
    },
    {
        find: /^@cache$/,
        replacement: `${uiCacheRoot}/index.ts`
    },
    {
        find: /^@cache\/(.*)$/,
        replacement: `${uiCacheRoot}/$1`
    },
    {
        find: /^@workflow\/nodes$/,
        replacement: workflowNodesRoot
    },
    {
        find: /^@workflow\/nodes\/(.*)$/,
        replacement: `${workflowNodesRoot}/$1`
    },
    {
        find: /^@workflow\/charts$/,
        replacement: `${workflowChartsRoot}/index.js`
    },
    {
        find: /^@workflow\/charts\/(.*)$/,
        replacement: `${workflowChartsRoot}/$1.js`
    },
    {
        find: /^@workflow\/executor$/,
        replacement: executorRoot
    },
    {
        find: /^@workflow\/executor\/(.*)$/,
        replacement: `${executorRoot}/$1`
    },
    {
        find: /^@workflow\/execute$/,
        replacement: path.resolve(executorRoot, 'types/index.ts')
    },
    {
        find: /^xlsx$/,
        replacement: path.resolve(repoRoot, 'node_modules/xlsx')
    },
    {
        find: /^typescript$/,
        replacement: path.resolve(repoRoot, 'node_modules/typescript/lib/typescript.js')
    },
    {
        find: /^typescript\/lib\/typescript\.js$/,
        replacement: path.resolve(repoRoot, 'node_modules/typescript/lib/typescript.js')
    }
];

export const workflowResolveDedupe = ['react', 'react-dom'];

export const workflowOptimizeDepsExclude = ['@workflow/ui', '@workflow/nodes', '@workflow/executor'];
