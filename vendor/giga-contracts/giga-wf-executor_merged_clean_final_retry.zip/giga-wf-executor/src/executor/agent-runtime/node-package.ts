import { createHash } from 'node:crypto';

export type NodePackageFile = { path: string; content: string; encoding?: 'utf8' | 'base64' };
export type NodePackageManifest = {
  packageFormat: 'giga.node.package/v2';
  id: string;
  name: string;
  version: string;
  kind: string;
  modelId: string;
  description?: string;
  schemaPath: string;
  nodePath: string;
  workerPath: string;
  readmePath: string;
  testsPath: string;
  packageJsonPath: string;
  checksumsPath: string;
  dependencies: Array<{ name: string; version?: string; reason?: string }>;
  permissions: string[];
  backendCommands: string[];
  rules: { allowNetwork: boolean; allowPackageInstall: boolean; requiresBackend: boolean };
  createdAt: string;
  metadata?: Record<string, unknown>;
};
export type NodePackage = { filename: string; manifest: NodePackageManifest; files: NodePackageFile[] };
export type NodePackageValidation = { ok: boolean; errors: string[]; warnings: string[]; fileCount: number; checksums: Record<string, string> };

const text = (value: unknown): string => String(value ?? '').trim();
const requiredPaths = (manifest: NodePackageManifest): string[] => [manifest.schemaPath, manifest.nodePath, manifest.workerPath, manifest.readmePath, manifest.testsPath, manifest.packageJsonPath, manifest.checksumsPath].filter(Boolean);
const pathIsSafe = (path: string): boolean => Boolean(path) && !path.startsWith('/') && !path.includes('..') && /^[a-zA-Z0-9_./-]+$/.test(path);
const sha = (content: string): string => createHash('sha256').update(content).digest('hex');
const unsafeSource = /child_process|\beval\s*\(|new Function|process\.env|from ['"](?:fs|net|tls|http|https)['"]|require\(['"](?:fs|net|tls|http|https)['"]\)|@supabase|neo4j|neogma|npm\s+install|yarn\s+add|pnpm\s+add|bun\s+add/i;

export const computeNodePackageChecksums = (pkg: Pick<NodePackage, 'files'>): Record<string, string> => {
  const rows: Record<string, string> = {};
  for (const file of pkg.files) if (file.path !== 'checksums.json') rows[file.path] = sha(file.content);
  return rows;
};

export const validateNodePackage = (pkg: NodePackage): NodePackageValidation => {
  const errors: string[] = [];
  const warnings: string[] = [];
  const manifest = pkg.manifest;
  if (!pkg.filename?.endsWith('.node')) errors.push('Dynamic node package filename must end in .node.');
  if (manifest.packageFormat !== 'giga.node.package/v2') errors.push('manifest.packageFormat must be giga.node.package/v2.');
  if (!text(manifest.id)) errors.push('manifest.id is required.');
  if (!text(manifest.modelId)) errors.push('manifest.modelId is required.');
  if (!text(manifest.version)) warnings.push('manifest.version is empty; default to 0.0.1.');
  if (!Array.isArray(manifest.backendCommands)) errors.push('manifest.backendCommands must be an array.');
  if (manifest.rules?.requiresBackend && !manifest.backendCommands.includes('executeBackend')) errors.push('Backend-requiring node packages must declare executeBackend command access.');
  const paths = new Set(pkg.files.map((file) => file.path));
  for (const path of requiredPaths(manifest)) {
    if (!pathIsSafe(path)) errors.push(`Unsafe required path: ${path}`);
    if (!paths.has(path)) errors.push(`Required file is missing from package: ${path}`);
  }
  for (const file of pkg.files) {
    if (!pathIsSafe(file.path)) errors.push(`Unsafe package file path: ${file.path}`);
    if (file.path.endsWith('.ts') && unsafeSource.test(file.content)) errors.push(`Node package source violates node rules: ${file.path}`);
  }
  const checksums = computeNodePackageChecksums(pkg);
  const checksumFile = pkg.files.find((file) => file.path === manifest.checksumsPath)?.content;
  if (checksumFile) {
    try {
      const declared = JSON.parse(checksumFile) as Record<string, string>;
      for (const [path, hash] of Object.entries(checksums)) if (declared[path] && declared[path] !== hash) errors.push(`Checksum mismatch for ${path}.`);
    } catch { errors.push('checksums.json is not valid JSON.'); }
  }
  return { ok: errors.length === 0, errors, warnings, fileCount: pkg.files.length, checksums };
};

export const encodeNodePackage = (pkg: NodePackage): string => {
  const validation = validateNodePackage(pkg);
  if (!validation.ok) throw new Error(`Invalid .node package: ${validation.errors.join('; ')}`);
  return JSON.stringify({ ...pkg, validation }, null, 2);
};
export const decodeNodePackage = (content: string): NodePackage => {
  const parsed = JSON.parse(content) as NodePackage;
  const validation = validateNodePackage(parsed);
  if (!validation.ok) throw new Error(`Invalid .node package: ${validation.errors.join('; ')}`);
  return parsed;
};
export const assertNodePackageFilename = (filename: string): void => { if (!filename.endsWith('.node')) throw new Error('Dynamic node package filename must end in .node.'); };
