/// <reference types="cypress" />
import { assertWorkspaceInspectorShell, openNodeInspector, selectWorkspaceParametersTab } from '../../support/inspector';

describe('code node workspace inspector', () => {
    it('keeps the inspector stable while saving and running the code node', () => {
        cy.visit('/?scenario=code');
        cy.contains('Workflow UI Playground').should('exist');

        openNodeInspector('Code Node 1');
        assertWorkspaceInspectorShell('Code Node 1');

        cy.contains('.cnw-empty-state__title', 'No input values yet').should('be.visible');
        selectWorkspaceParametersTab('Properties');

        cy.get('[data-field-id="description"] textarea')
            .first()
            .clear({ force: true })
            .type('JavaScript execution node for transforming inputs and returning a structured response. ', { force: true });
        cy.contains('button', 'Save changes').click();
        cy.contains('.cnw-header__title', 'Code Node 1').should('exist');

        cy.contains('button', 'Run Node').click();
        cy.get('.cnw-editor-card', { timeout: 20000 }).should('be.visible');
        cy.get('.cnw-editor-card__content', { timeout: 20000 }).should('contain.text', '{}');
        cy.contains('.cnw-activity-card__title', 'Execution complete', { timeout: 20000 }).should('be.visible');

        cy.screenshot('workspace-inspector-code-node', { capture: 'viewport' });
    });
});
