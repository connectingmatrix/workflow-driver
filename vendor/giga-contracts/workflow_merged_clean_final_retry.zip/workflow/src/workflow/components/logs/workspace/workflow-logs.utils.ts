import type { WorkflowRunLogEvent } from '@workflow/ui/workflow/types';
import type { WorkflowLogsFilter, WorkflowLogsRecord } from '@workflow/ui/workflow/components/logs/logs-dialog.types';

const normalizeLevel = (value: unknown): WorkflowLogsRecord['level'] => {
    const normalized = String(value ?? 'info').trim().toLowerCase();
    if (normalized === 'warn' || normalized === 'warning') return 'warn';
    if (normalized === 'error') return 'error';
    return 'info';
};

const formatStructuredRecord = (record: Record<string, unknown>, prettyPrint: boolean): string => JSON.stringify(record, null, prettyPrint ? 2 : 0);

const parseJsonLine = (rawLine: string, lineNumber: number): WorkflowLogsRecord => {
    const trimmed = rawLine.trim();
    if (!trimmed) {
        return {
            id: `log-${lineNumber}`,
            lineNumber,
            raw: rawLine,
            formatted: rawLine,
            level: 'info',
            searchableText: rawLine.toLowerCase()
        };
    }

    try {
        const parsed = JSON.parse(trimmed) as Record<string, unknown>;
        const level = normalizeLevel(parsed.level);
        return {
            id: `log-${lineNumber}`,
            lineNumber,
            raw: rawLine,
            formatted: formatStructuredRecord(parsed, false),
            level,
            timestamp: typeof parsed.ts === 'string' ? parsed.ts : typeof parsed.timestamp === 'string' ? parsed.timestamp : undefined,
            event: typeof parsed.event === 'string' ? parsed.event : undefined,
            nodeId: typeof parsed.node === 'string' ? parsed.node : typeof parsed.nodeId === 'string' ? parsed.nodeId : undefined,
            runId: typeof parsed.runId === 'string' ? parsed.runId : undefined,
            data: parsed,
            searchableText: JSON.stringify(parsed).toLowerCase()
        };
    } catch {
        const lowered = rawLine.toLowerCase();
        return {
            id: `log-${lineNumber}`,
            lineNumber,
            raw: rawLine,
            formatted: rawLine,
            level: lowered.includes('error') ? 'error' : lowered.includes('warn') ? 'warn' : 'info',
            searchableText: lowered
        };
    }
};

export const buildWorkflowLogsRecords = (jsonl: string, events?: WorkflowRunLogEvent[], prettyPrint = false): WorkflowLogsRecord[] => {
    if (Array.isArray(events) && events.length > 0) {
        return events.map((event, index) => {
            const payload = {
                ts: event.timestamp,
                level: event.level,
                node: event.nodeId,
                event: event.event,
                runId: event.runId,
                workflowId: event.workflowId,
                message: event.message,
                data: event.data
            } satisfies Record<string, unknown>;
            return {
                id: `${event.runId}-${event.timestamp}-${index}`,
                lineNumber: index + 1,
                raw: JSON.stringify(payload),
                formatted: formatStructuredRecord(payload, prettyPrint),
                level: normalizeLevel(event.level),
                timestamp: event.timestamp,
                event: event.event,
                nodeId: event.nodeId,
                runId: event.runId,
                data: event.data,
                searchableText: JSON.stringify(payload).toLowerCase()
            } satisfies WorkflowLogsRecord;
        });
    }

    return jsonl
        .split(/\r?\n/)
        .filter((line) => line.trim().length > 0)
        .map((line, index) => {
            const record = parseJsonLine(line, index + 1);
            if (!prettyPrint) {
                return record;
            }
            if (record.data && typeof record.data === 'object' && !Array.isArray(record.data)) {
                return {
                    ...record,
                    formatted: formatStructuredRecord(record.data as Record<string, unknown>, true)
                };
            }
            return record;
        });
};

export const filterWorkflowLogsRecords = (records: WorkflowLogsRecord[], filter: WorkflowLogsFilter, search: string): WorkflowLogsRecord[] => {
    const normalizedSearch = search.trim().toLowerCase();
    return records.filter((record) => {
        const matchesFilter = filter === 'all' ? true : record.level === filter;
        if (!matchesFilter) return false;
        if (!normalizedSearch) return true;
        return record.searchableText.includes(normalizedSearch);
    });
};

export const getWorkflowLogsCounts = (records: WorkflowLogsRecord[]) =>
    records.reduce(
        (acc, record) => {
            acc.total += 1;
            if (record.level === 'warn') acc.warn += 1;
            if (record.level === 'error') acc.error += 1;
            return acc;
        },
        { total: 0, warn: 0, error: 0 }
    );

export const formatWorkflowLogsBytes = (value: number): string => {
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(1)} MB`;
};

export const getWorkflowLogsRunId = (records: WorkflowLogsRecord[]): string => records.find((record) => record.runId)?.runId ?? 'run_local';

export const getWorkflowLogsDurationSeconds = (records: WorkflowLogsRecord[]): string => {
    const timestamps = records.map((record) => (record.timestamp ? Date.parse(record.timestamp) : NaN)).filter((value) => Number.isFinite(value));
    if (timestamps.length < 2) return '0.00 s';
    const durationMs = Math.max(...timestamps) - Math.min(...timestamps);
    return `${(durationMs / 1000).toFixed(2)} s`;
};

export const getWorkflowLogsOutputContract = (records: WorkflowLogsRecord[]): string => {
    for (let index = records.length - 1; index >= 0; index -= 1) {
        const candidate = records[index]?.data;
        if (candidate && typeof candidate === 'object' && !Array.isArray(candidate) && typeof (candidate as Record<string, unknown>).contract === 'string') {
            return String((candidate as Record<string, unknown>).contract);
        }
    }
    return 'n/a';
};

export const downloadWorkflowLogs = (jsonl: string, fileNamePrefix: string): void => {
    const blob = new Blob([jsonl], { type: 'application/x-ndjson' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${fileNamePrefix}-${Date.now()}.jsonl`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
};

export const copyWorkflowLogs = async (jsonl: string): Promise<void> => {
    try {
        await navigator.clipboard.writeText(jsonl);
    } catch {
        // Ignore clipboard failures in unsupported browsers.
    }
};
