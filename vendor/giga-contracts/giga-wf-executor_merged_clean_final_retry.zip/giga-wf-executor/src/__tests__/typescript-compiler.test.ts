import { beforeEach, describe, expect, it, vi } from 'vitest';
import { WorkerRuntimeEnvironmentEnum } from '../types';
import { clearCompiledWorkerSourceCache, compileWorkerSource } from '../executor/core/compiler/typescript-compiler';

const createFakeTypescriptModule = (transpileModule: (...args: any[]) => unknown) => ({
    transpileModule,
    ScriptTarget: { ES2022: 9 },
    ModuleKind: { ESNext: 99 },
    ModuleResolutionKind: { Bundler: 100 },
    ImportsNotUsedAsValues: { Remove: 0 },
    DiagnosticCategory: { Error: 1 }
});

beforeEach(() => {
    clearCompiledWorkerSourceCache();
});

describe('typescript compiler split', () => {
    it('reuses cached compiled worker source for identical runtime/signature inputs', async () => {
        const transpileModule = vi.fn((source: string) => ({
            outputText: source,
            diagnostics: []
        }));
        const typescriptModuleLoader = async () => createFakeTypescriptModule(transpileModule);
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: [] });`;

        await compileWorkerSource({
            source,
            modelId: 'cached-worker',
            sourceSignature: 'sig-a',
            cacheKey: `worker:${WorkerRuntimeEnvironmentEnum.Node}:cached-worker:sig-a`,
            moduleLoader: typescriptModuleLoader
        });

        await compileWorkerSource({
            source,
            modelId: 'cached-worker',
            sourceSignature: 'sig-a',
            cacheKey: `worker:${WorkerRuntimeEnvironmentEnum.Node}:cached-worker:sig-a`,
            moduleLoader: typescriptModuleLoader
        });

        expect(transpileModule).toHaveBeenCalledTimes(1);
    });
});
