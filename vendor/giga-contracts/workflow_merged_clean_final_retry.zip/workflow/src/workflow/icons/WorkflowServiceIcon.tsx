import React from 'react';
import { resolveWorkflowServiceIconMetadata } from './workflow-service-icon.metadata';

interface WorkflowServiceIconProps {
    serviceIcon?: string | null;
    serviceName?: string | null;
    className?: string;
    size?: number;
    dataTestId?: string;
}

const toInitials = (serviceName: string | null | undefined): string => {
    const normalized = String(serviceName ?? '').trim();
    if (!normalized) {
        return 'AI';
    }
    const segments = normalized.split(/\s+/g).filter(Boolean);
    if (segments.length === 1) {
        return segments[0].slice(0, 2).toUpperCase();
    }
    return segments
        .slice(0, 2)
        .map((segment) => segment.charAt(0).toUpperCase())
        .join('');
};

const hexToRgba = (hex: string, alpha: number): string => {
    const normalized = hex.replace('#', '');
    const value = normalized.length === 3
        ? normalized.split('').map((segment) => segment + segment).join('')
        : normalized;
    if (!/^[0-9a-f]{6}$/i.test(value)) {
        return `rgba(79, 107, 255, ${alpha})`;
    }
    const numeric = Number.parseInt(value, 16);
    const red = (numeric >> 16) & 255;
    const green = (numeric >> 8) & 255;
    const blue = numeric & 255;
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
};

const hashStringToColor = (seed: string): string => {
    let hash = 0;
    for (let index = 0; index < seed.length; index += 1) {
        hash = seed.charCodeAt(index) + ((hash << 5) - hash);
        hash |= 0;
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue} 68% 52%)`;
};

export const WorkflowServiceIcon: React.FC<WorkflowServiceIconProps> = ({ serviceIcon, serviceName, className, size = 16, dataTestId }) => {
    const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);
    const outerClassName = [className, 'cnw-service-icon'].filter(Boolean).join(' ');
    const normalizedLabel = String(serviceName ?? serviceIcon ?? 'service').trim();
    const fallbackColor = resolved.brandColor ?? hashStringToColor(`${serviceIcon ?? ''}:${normalizedLabel}`);
    const sharedStyle = {
        width: size,
        height: size
    } as const;

    if (resolved.asset) {
        return (
            <span
                aria-hidden="true"
                className={outerClassName}
                data-testid={dataTestId}
                data-source={resolved.source}
                data-service-icon={serviceIcon ?? ''}
                data-asset={resolved.source === 'asset' ? serviceIcon ?? '' : undefined}
                data-component={resolved.source === 'component' ? serviceIcon ?? '' : undefined}
                style={sharedStyle}
            >
                <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox={resolved.asset.viewBox} role="presentation">
                    <title>{resolved.asset.title}</title>
                    <g dangerouslySetInnerHTML={{ __html: resolved.asset.markup }} />
                </svg>
            </span>
        );
    }

    return (
        <span
            aria-hidden="true"
            className={outerClassName}
            data-testid={dataTestId}
            data-source={resolved.source}
            data-service-icon={serviceIcon ?? ''}
            style={{
                ...sharedStyle,
                background: hexToRgba(fallbackColor, 0.14),
                color: fallbackColor
            }}
        >
            <span className="cnw-service-icon__fallback">{toInitials(serviceName)}</span>
        </span>
    );
};
