import React from 'react';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';

interface WorkspaceTextareaFieldProps {
    id: string;
    value: string;
    editable: boolean;
    allowVariables: boolean;
    placeholder?: string;
    rows?: number;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: string) => void;
}

export const WorkspaceTextareaField: React.FC<WorkspaceTextareaFieldProps> = ({ id, value, editable, allowVariables, placeholder, rows = 4, variableContext, variableSuggestions, onChange }) => {
    return <VariableTextField id={id} value={value} onChange={onChange} allowVariables={allowVariables} variableContext={variableContext} variableSuggestions={variableSuggestions} disabled={!editable} multiline rows={rows} placeholder={placeholder} />;
};
