/// <reference types="cypress" />
import { assertWorkspaceInspectorShell, openNodeInspector, scrollParametersSectionIntoView } from '../../support/inspector';

describe('output format workspace inspector', () => {
    it('renders the output format workspace sections with bounded panes', () => {
        cy.visit('/?scenario=output-format');
        openNodeInspector('Output Format 1');
        assertWorkspaceInspectorShell('Output Format 1');

        scrollParametersSectionIntoView('AI formatting');
        cy.get('[data-field-id="useAiFormatting"]').should('be.visible');
        cy.get('[data-field-id="failureMitigation"]').should('be.visible');
        cy.get('.cnw-output-panel__scroll').scrollTo('bottom');

        cy.screenshot('workspace-inspector-output-format', { capture: 'viewport' });
    });
});
