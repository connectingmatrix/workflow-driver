import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import UserNodePreviewLogsTab from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewLogsTab';

vi.mock('primereact/button', () => ({
    Button: ({ onClick, 'aria-label': ariaLabel }: { onClick?: () => void; 'aria-label'?: string }) => (
        <button type="button" aria-label={ariaLabel} onClick={onClick}>
            {ariaLabel}
        </button>
    )
}));

vi.mock('primereact/dropdown', () => ({
    Dropdown: ({ value, options, onChange, className }: { value: string; options: Array<{ label: string; value: string }>; onChange?: (event: { value: string }) => void; className?: string }) => (
        <select data-testid="source-filter" value={value} onChange={(event) => onChange?.({ value: event.target.value })} className={className}>
            {options.map((option) => (
                <option key={option.value} value={option.value}>
                    {option.label}
                </option>
            ))}
        </select>
    )
}));

vi.mock('primereact/inputtext', () => ({
    InputText: ({ value, onChange, placeholder, className }: { value: string; onChange?: (event: { target: { value: string } }) => void; placeholder?: string; className?: string }) => (
        <input value={value} placeholder={placeholder} onChange={(event) => onChange?.({ target: { value: event.target.value } })} className={className} />
    )
}));

describe('UserNodePreviewLogsTab', () => {
    afterEach(() => {
        cleanup();
    });

    it('filters logs by search text and source', () => {
        const { container } = render(
            <UserNodePreviewLogsTab
                logs={[
                    { runId: 'run_1', nodeId: 'node_1', source: 'worker', line: 'worker finished', timestamp: '2026-03-26T16:10:00.000Z' },
                    { runId: 'run_1', nodeId: 'node_1', source: 'stderr', line: 'stderr warning', timestamp: '2026-03-26T16:10:01.000Z' }
                ]}
                onClearLogs={() => undefined}
            />
        );

        const logs = container.querySelector('[data-cy="user-node-preview-logs"]') as HTMLPreElement | null;
        expect(logs).not.toBeNull();
        const logsText = logs?.textContent ?? '';
        expect(logsText).toContain('[worker] worker finished');
        expect(logsText).toContain('[stderr] stderr warning');

        fireEvent.change(screen.getByPlaceholderText('Search logs'), {
            target: { value: 'warning' }
        });
        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).toContain('[stderr] stderr warning');
        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).not.toContain('[worker] worker finished');

        fireEvent.change(screen.getByTestId('source-filter'), { target: { value: 'worker' } });
        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).toBe('');
    });

    it('toggles timestamp rendering for log rows', () => {
        const { container } = render(<UserNodePreviewLogsTab logs={[{ runId: 'run_2', nodeId: 'node_1', source: 'runtime', line: 'runtime event', timestamp: '2026-03-26T16:11:00.000Z' }]} onClearLogs={() => undefined} />);

        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).toContain('[runtime] runtime event');
        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).not.toContain('2026-03-26T16:11:00.000Z');

        const toggleButton = container.querySelector('button[aria-label="Show timestamps"]');
        expect(toggleButton).not.toBeNull();
        fireEvent.click(toggleButton as HTMLButtonElement);

        expect((container.querySelector('[data-cy="user-node-preview-logs"]')?.textContent ?? '')).toContain('2026-03-26T16:11:00.000Z [runtime] runtime event');
    });
});
