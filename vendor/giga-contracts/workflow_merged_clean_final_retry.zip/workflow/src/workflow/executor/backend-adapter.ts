import type { WorkflowNodeHandlerContext, WorkflowNodeHandlerResult } from '@workflow/executor';
import { WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID } from '@workflow/nodes/executor/backend-registry';
import type { WorkflowBackendDescriptor } from '@workflow/nodes/executor/backend-registry';

interface WorkflowExecuteBackendDescriptorInput {
    service?: unknown;
    function?: unknown;
    description?: unknown;
}

interface WorkflowExecuteBackendRequestInput {
    context?: unknown;
    descriptor?: unknown;
    payload?: unknown;
    args?: unknown;
}

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const toStringValue = (value: unknown): string => String(value ?? '').trim();

const normalizeDescriptor = (modelId: string, descriptorLike: unknown): WorkflowBackendDescriptor | null => {
    const candidate = toRecord(descriptorLike) as WorkflowExecuteBackendDescriptorInput;
    const service = toStringValue(candidate.service);
    const fn = toStringValue(candidate.function);
    if (!service || !fn) return null;
    return {
        modelId,
        service,
        function: fn,
        description: toStringValue(candidate.description)
    };
};

const normalizeExecuteBackendRequest = (
    request: unknown
): {
    context: WorkflowNodeHandlerContext;
    descriptor: WorkflowBackendDescriptor | null;
    payload: unknown;
    modelId: string;
} => {
    const requestRecord = toRecord(request) as WorkflowExecuteBackendRequestInput;
    const contextRecord = toRecord(requestRecord.context);
    const context = contextRecord as unknown as WorkflowNodeHandlerContext;
    if (!context || typeof context !== 'object' || !context.node || !context.workflow) {
        throw new Error('executeBackend request is missing workflow node context.');
    }
    const args = Array.isArray(requestRecord.args) ? requestRecord.args : [];
    const modelId = toStringValue(context.node.modelId);
    const descriptor = normalizeDescriptor(modelId, requestRecord.descriptor ?? args[0]);
    return {
        context,
        descriptor,
        payload: requestRecord.payload ?? args[1] ?? null,
        modelId
    };
};

const resolveValidatedDescriptor = (modelId: string, descriptor: WorkflowBackendDescriptor | null): WorkflowBackendDescriptor => {
    const expected = WORKFLOW_BACKEND_DESCRIPTOR_BY_MODEL_ID[modelId];
    if (!expected) {
        throw new Error(`executeBackend is not allowed for model "${modelId}".`);
    }

    if (!descriptor) {
        return expected;
    }

    if (descriptor.service !== expected.service || descriptor.function !== expected.function) {
        throw new Error(`executeBackend descriptor mismatch for "${modelId}". Expected ${expected.service}#${expected.function}.`);
    }

    return {
        ...expected,
        description: descriptor.description || expected.description
    };
};

export const executeNodeWorkerBackend = async (request: unknown): Promise<WorkflowNodeHandlerResult> => {
    const normalized = normalizeExecuteBackendRequest(request);
    const modelId = normalized.modelId;
    const descriptor = resolveValidatedDescriptor(modelId, normalized.descriptor);

    throw new Error(`Node "${modelId}" requested backend execution via ${descriptor.service}#${descriptor.function}, but browser runtime cannot invoke backend handlers directly. Run this node in server mode.`);
};
