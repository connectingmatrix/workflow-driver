/// <reference types="cypress" />
import { assertWorkspaceInspectorShell, openNodeInspector, scrollParametersSectionIntoView } from '../../support/inspector';

describe('ai governor workspace inspector', () => {
    it('renders the ai governor selection prompt section', () => {
        cy.visit('/?scenario=ai-governor');
        openNodeInspector('AI Governor 1');
        assertWorkspaceInspectorShell('AI Governor 1');

        cy.contains('.cnw-hero-card__title', 'AI action planner').should('be.visible');
        scrollParametersSectionIntoView('Selection Prompt');
        cy.get('.cnw-parameters-panel__scroll').scrollTo('bottom', { ensureScrollable: false });

        cy.screenshot('workspace-inspector-ai-governor', { capture: 'viewport' });
    });
});
