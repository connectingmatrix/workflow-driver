/** @vitest-environment jsdom */
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import WorkspaceToolbar from '@workflow/ui/workflow/components/toolbar/workspace/WorkspaceToolbar';
import { WorkflowPlayLifecycleEnum, WorkflowPlayModeEnum } from '@workflow/ui/workflow/types';

vi.mock('primereact/menu', () => ({ Menu: React.forwardRef(() => null) }));
vi.mock('primereact/tooltip', () => ({ Tooltip: () => null }));

afterEach(() => cleanup());

const buildProps = () => ({
    metadata: { id: 'wf_1', name: 'Execution Replay' } as any,
    isPlaying: false,
    playMode: WorkflowPlayModeEnum.Local,
    playLifecycle: WorkflowPlayLifecycleEnum.Idle,
    canPlay: true,
    isEditable: false,
    isExecutionMode: true,
    canReplayExecution: true,
    onPlayLocal: vi.fn(),
    onPlayServer: vi.fn(),
    onStop: vi.fn(),
    onExportWorkflowOnly: vi.fn(),
    onExportWithData: vi.fn(),
    onClear: vi.fn(),
    onToggleEditable: vi.fn(),
    onImportJson: vi.fn(),
    onShowMetadata: vi.fn(),
    onShowLogs: vi.fn(),
    onShowSettings: vi.fn(),
    onClose: vi.fn()
});

describe('WorkspaceToolbar execution mode', () => {
    it('shows replay and close actions for completed execution snapshots', () => {
        const props = buildProps();
        render(<WorkspaceToolbar {...props} />);

        expect(screen.getByRole('button', { name: 'View workflow logs' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Workflow settings' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Play snapshot' }).querySelector('i')).not.toBeNull();
        fireEvent.click(screen.getByRole('button', { name: 'Play snapshot' }));

        expect(props.onPlayLocal).toHaveBeenCalledTimes(1);
        expect(screen.getByRole('button', { name: 'Close designer' })).toBeInTheDocument();
    });

    it('keeps logs, settings, and close when replay is not allowed', () => {
        render(<WorkspaceToolbar {...buildProps()} canReplayExecution={false} />);

        expect(screen.queryByRole('button', { name: 'Play snapshot' })).toBeNull();
        expect(screen.getByRole('button', { name: 'View workflow logs' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Workflow settings' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Close designer' })).toBeInTheDocument();
    });

    it('stops the emulation from the same replay button while playing', () => {
        const props = buildProps();
        render(<WorkspaceToolbar {...props} isPlaying playLifecycle={WorkflowPlayLifecycleEnum.Running} />);

        fireEvent.click(screen.getByRole('button', { name: 'Stop emulation' }));

        expect(props.onStop).toHaveBeenCalledTimes(1);
    });
});
