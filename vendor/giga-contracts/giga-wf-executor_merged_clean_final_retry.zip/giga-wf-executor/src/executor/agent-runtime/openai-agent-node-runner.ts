export type StoredAgentNodeRunInput = {
  agentId: string;
  message: string;
  chatId?: string | null;
  sessionId?: string | null;
  executeBackend: (command: { tool: string; input: Record<string, unknown> }) => Promise<unknown>;
};

export async function runStoredAgentNode(input: StoredAgentNodeRunInput): Promise<unknown> {
  if (!input.agentId) throw new Error('agentId is required to run stored agent node.');
  if (!input.message) throw new Error('message is required to run stored agent node.');
  return input.executeBackend({
    tool: 'agent.run',
    input: { agentId: input.agentId, message: input.message, chatId: input.chatId || null, sessionId: input.sessionId || null },
  });
}
