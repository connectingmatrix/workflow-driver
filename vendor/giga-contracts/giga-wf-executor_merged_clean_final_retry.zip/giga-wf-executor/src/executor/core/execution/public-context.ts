import { WorkflowDefinition, WorkflowRuntimeSettings } from '../../../types';

const parseRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const cloneValue = <T>(value: T): T => {
    if (typeof value === 'undefined') return value;
    try {
        return JSON.parse(JSON.stringify(value)) as T;
    } catch {
        return value;
    }
};

const normalizePublicOutput = (value: unknown): Record<string, unknown> => {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
        return cloneValue(value as Record<string, unknown>);
    }
    return {
        output: cloneValue(value)
    };
};

const isControlPortContext = (value: Record<string, unknown>): boolean => Object.prototype.hasOwnProperty.call(value, 'IN') || Object.prototype.hasOwnProperty.call(value, 'STATE');

export const buildExecutionWorkflow = (workflow: WorkflowDefinition, settings: WorkflowRuntimeSettings, workflowInput?: Record<string, unknown>): WorkflowDefinition => ({
    ...workflow,
    input: cloneValue(parseRecord(workflowInput || workflow.input)),
    metadata: {
        ...(workflow.metadata || {}),
        runtime: {
            ...parseRecord(workflow.metadata?.runtime),
            settings: cloneValue(settings)
        }
    }
});

export const buildPublicInputContext = (input: Record<string, Record<string, unknown>>): Record<string, unknown> => {
    const context: Record<string, unknown> = {};
    const inputsByPort: Record<string, Record<string, unknown>> = {};
    const controlByPort: Record<string, unknown> = {};
    Object.entries(input || {}).forEach(([portId, sourceMap]) => {
        const sourceRecord = parseRecord(sourceMap);
        if (isControlPortContext(sourceRecord)) {
            controlByPort[portId] = cloneValue(sourceRecord);
            return;
        }
        const portContext: Record<string, unknown> = {};
        Object.entries(sourceRecord).forEach(([sourceNodeId, sourceValue]) => {
            const output = normalizePublicOutput(sourceValue);
            portContext[sourceNodeId] = output;
            context[sourceNodeId] = output;
        });
        if (Object.keys(portContext).length > 0) inputsByPort[portId] = portContext;
    });
    context.input = inputsByPort.input || inputsByPort;
    context.inputs = inputsByPort;
    if (Object.keys(controlByPort).length > 0) context.control = controlByPort;
    return context;
};

export const buildPublicWorkflowContext = (workflow: WorkflowDefinition, settings?: WorkflowRuntimeSettings): Record<string, unknown> => {
    const metadataRuntime = parseRecord(workflow.metadata?.runtime);
    const runtime = parseRecord(settings || metadataRuntime.settings);
    return {
        runtime: cloneValue(runtime),
        input: cloneValue(parseRecord(workflow.input))
    };
};
