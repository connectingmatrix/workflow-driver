export const WORKFLOW_FAILURE_MITIGATION_STOP = 'stop-workflow';
export const WORKFLOW_FAILURE_MITIGATION_RETRY = 'retry-node';
export const WORKFLOW_FAILURE_MITIGATION_FIELD = 'failureMitigation';
export const WORKFLOW_RETRY_COUNT_FIELD = 'retryCount';
export const WORKFLOW_MIN_RETRY_COUNT = 1;
export const WORKFLOW_MAX_RETRY_COUNT = 6;

export type WorkflowFailureMitigationMode = typeof WORKFLOW_FAILURE_MITIGATION_STOP | typeof WORKFLOW_FAILURE_MITIGATION_RETRY;

export const parseFailureMitigationMode = (value: unknown): WorkflowFailureMitigationMode => {
    return value === WORKFLOW_FAILURE_MITIGATION_RETRY ? WORKFLOW_FAILURE_MITIGATION_RETRY : WORKFLOW_FAILURE_MITIGATION_STOP;
};

export const parseFailureRetryCount = (value: unknown): number => {
    const parsed = Number(String(value ?? '').trim());
    if (!Number.isFinite(parsed)) return WORKFLOW_MIN_RETRY_COUNT;
    const rounded = Math.round(parsed);
    if (rounded < WORKFLOW_MIN_RETRY_COUNT) return WORKFLOW_MIN_RETRY_COUNT;
    if (rounded > WORKFLOW_MAX_RETRY_COUNT) return WORKFLOW_MAX_RETRY_COUNT;
    return rounded;
};
