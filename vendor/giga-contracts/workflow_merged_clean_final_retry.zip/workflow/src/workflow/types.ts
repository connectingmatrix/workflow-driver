import type { ReactNode } from 'react';

export enum WorkflowNodeStatusEnum {
    Passed = 'passed',
    Failed = 'failed',
    Warning = 'warning',
    Running = 'running',
    Stopped = 'stopped'
}

export enum WorkflowNodeKindEnum {
    Process = 'process',
    Output = 'output',
    Error = 'error'
}

export enum WorkflowViewerTypeEnum {
    Json = 'json',
    Markdown = 'markdown',
    Raw = 'raw',
    Table = 'table'
}

export enum WorkflowNodeFieldTypeEnum {
    String = 'string',
    Textarea = 'textarea',
    Markdown = 'markdown',
    Number = 'number',
    Boolean = 'boolean',
    Json = 'json',
    File = 'file',
    Timestamp = 'timestamp',
    Select = 'select',
    Method = 'method',
    Headers = 'headers',
    FileList = 'file-list',
    ObjectArray = 'object-array'
}

export enum WorkflowAuthModeEnum {
    AutoFromCurrentSession = 'auto-from-current-session',
    Manual = 'manual',
    None = 'none'
}

export enum WorkflowLogLevelEnum {
    Info = 'info',
    Warn = 'warn',
    Error = 'error'
}

export enum WorkflowPlayModeEnum {
    Local = 'local',
    Server = 'server'
}

export enum WorkflowPlayLifecycleEnum {
    Idle = 'idle',
    Starting = 'starting',
    Running = 'running',
    Stopping = 'stopping'
}

export enum WorkflowStatusEnum {
    Draft = 'draft',
    Published = 'published'
}

export enum WorkflowDisplayStatusEnum {
    Draft = 'draft',
    Running = 'running',
    Published = 'published',
    UnPublished = 'un-published'
}

export enum WorkflowNodePortSideEnum {
    Left = 'left',
    Right = 'right',
    Top = 'top',
    Bottom = 'bottom'
}

export enum WorkflowRemoteNodeIdEnum {
    AiAgent = 'ai-agent',
    AiGovernor = 'ai-governor',
    SerpSearch = 'serp-search',
    AnalyzeTextWithModel = 'analyze-text-with-model',
    RunChannelAction = 'run-channel-action',
    RunCategoryAction = 'run-category-action',
    RunSubjectAction = 'run-subject-action',
    RunPostAction = 'run-post-action',
    RunUserTreeAction = 'run-user-tree-action',
    RunChatAction = 'run-chat-action',
    CurrentChat = 'current-chat',
    TextAnalysis = 'text-analysis',
    ActionRouter = 'action-router',
    ChatPlanPolicy = 'chat-plan-policy',
    ValidateWorkflowCypher = 'validate-workflow-cypher',
    Workflow = 'workflow',
    ExecuteWorkflow = 'execute-workflow',
    OutputFormat = 'output-format',
    OpenAI = 'openai',
    Claude = 'claude',
    Gemini = 'gemini',
    Groq = 'groq',
    DeepSeek = 'deepseek',
    Perplexity = 'perplexity',
    Mistral = 'mistral'
}

export type WorkflowNodeStatus = 'passed' | 'failed' | 'warning' | 'running' | 'stopped';
export type WorkflowNodeKind = 'process' | 'output' | 'error';
export type WorkflowViewerType = 'json' | 'markdown' | 'raw' | 'table';
export type WorkflowExportMode = 'workflow-only' | 'with-data';
export type WorkflowNodeFieldType = 'string' | 'textarea' | 'markdown' | 'number' | 'boolean' | 'json' | 'file' | 'timestamp' | 'select' | 'method' | 'headers' | 'file-list' | 'object-array';
export type WorkflowInspectorFieldLayoutPreset = 'half' | 'full' | 'mitigation' | 'switch' | 'inline';
export type WorkflowFieldAiWriteMode = 'allow' | 'connected-options-only' | 'deny';
export type WorkflowAuthMode = 'auto-from-current-session' | 'manual' | 'none';
export type WorkflowLogLevel = 'info' | 'warn' | 'error';
export type WorkflowPlayMode = 'local' | 'server';
export type WorkflowPlayLifecycle = 'idle' | 'starting' | 'running' | 'stopping';
export type WorkflowStatus = 'draft' | 'published';
export type WorkflowDisplayStatus = 'draft' | 'running' | 'published' | 'un-published';
export type WorkflowNodePortSide = 'left' | 'right' | 'top' | 'bottom';
export type WorkflowCanvasLayoutEngine = 'legacy' | 'elk';
export type WorkflowCanvasEdgeStyle = 'legacy' | 'bezier' | 'straight' | 'step' | 'smoothstep';
export type WorkflowCatalogScope = 'user' | 'global' | 'organization';
export type WorkflowWebhookRouteType = 'test' | 'published';
export type WorkflowPreviewRuntime = 'auto' | 'browser' | 'node';
export type WorkflowPreviewMode = 'designer';
export type WorkflowPreviewLogSource = 'stdout' | 'stderr' | 'worker' | 'browser' | 'runtime';
export type WorkflowCredentialScope = 'GLOBAL' | 'ORGANIZATION' | 'PERSONAL';
export type WorkflowCredentialScopeTag = 'Global' | 'Org' | 'User';
export type WorkflowExecutableScope = 'user' | 'organization';
export type WorkflowExecutableScopeTag = 'User' | 'Org';
export const WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS = [50, 100, 150, 200, 250, 300] as const;
export type WorkflowMaxExecutionSeconds = (typeof WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS)[number];

export interface WorkflowSourceFiles {
    'worker.ts'?: string;
    'validate.ts'?: string;
}

export interface WorkflowPreviewLogEvent {
    runId: string;
    nodeId: string;
    source: WorkflowPreviewLogSource;
    line: string;
    timestamp: string;
    runtime?: 'browser' | 'node';
    stream?: string | null;
}

export interface WorkflowPreviewStateEvent {
    runId: string;
    nodeId: string;
    state: 'starting' | 'running' | 'passed' | 'failed' | 'stopped' | 'cancelled';
    requestedRuntime?: WorkflowPreviewRuntime;
    runtime?: 'browser' | 'node';
    startedAt?: string | null;
    durationMs?: number | null;
    message?: string | null;
    validation?: {
        ok: boolean;
        warnings?: string[];
        errors?: string[];
        normalizedRuntime?: Record<string, unknown>;
    } | null;
}

export interface WorkflowRunLogEvent {
    timestamp: string;
    level: WorkflowLogLevel;
    event: string;
    workflowId: string;
    runId: string;
    nodeId?: string;
    message?: string;
    data?: unknown;
}

export interface WorkflowRuntimeSettings {
    graphqlUrl: string;
    httpBaseUrl?: string;
    authMode: WorkflowAuthMode | string;
    manualHeaders?: Record<string, string>;
    maxExecutionSeconds?: WorkflowMaxExecutionSeconds | number;
}

export interface WorkflowCredentialOption {
    id: string;
    credentialId: string;
    credentialName: string;
    serviceId: string;
    serviceName: string | null;
    serviceIcon: string | null;
    scope: WorkflowCredentialScope;
    scopeTag: WorkflowCredentialScopeTag;
    status?: string | null;
}

export interface WorkflowExecutableOption {
    workflowId: string;
    workflowName: string;
    scope: WorkflowExecutableScope;
    scopeTag: WorkflowExecutableScopeTag;
    status?: string | null;
}

export interface WorkflowResolvedCredential {
    id: string;
    credentialId: string;
    credentialName: string;
    serviceId: string;
    serviceName: string | null;
    serviceIcon: string | null;
    scope: WorkflowCredentialScope;
    values: Record<string, unknown>;
}

export interface WorkflowCredentialExecutionResultInput {
    credentialId: string;
    success: boolean;
    lastUsedAt?: string | null;
}

export interface WorkflowGovernorActionSummary {
    id: string;
    nodeId: string;
    name: string;
    kind: 'model' | 'tool';
    status: 'passed' | 'failed' | 'skipped';
    reason: string;
    depends_on: string[];
    summary?: string;
    error?: string;
}

export interface WorkflowGovernorTraceOutput {
    result: unknown;
    intent: string;
    finalActionId?: string;
    actionSummary: WorkflowGovernorActionSummary[];
    summaryStatus: WorkflowNodeStatus;
    __activeOutputs: ['output'];
}
export interface WorkflowNodeRenderConfig {
    [key: string]: unknown;
    iconClass?: string;
    iconKey?: string;
    iconMode?: 'prime' | 'svg';
    iconSvg?: string;
    iconSize?: number;
    nodeSize?: number;
    nodeWidth?: number;
    nodeHeight?: number;
    iconColor?: string;
    iconBackground?: string;
    containerClassName?: string;
}
export interface WorkflowNodeInstructionConfig {
    code: boolean;
    markdown: boolean;
}
export interface WorkflowNodeNameProperty {
    type: 'string';
    editable: boolean;
    autoGenerate: boolean;
}
export interface WorkflowNodeFileValue {
    name: string;
    mimeType: string;
    size: number;
    encoding: 'base64';
    contentBase64: string;
    extractedText?: string;
}

export interface WorkflowNodeFieldOption {
    label: string;
    value: string;
    description?: string;
}

export interface WorkflowNodeFieldOptionsRequest {
    modelId: string;
    fieldKey: string;
    optionsSource?: string | null;
    properties: Record<string, unknown>;
    workflowInput: Record<string, unknown>;
    workflowMetadata?: Record<string, unknown> | null;
}

export interface WorkflowNodeFieldDependsOnRange {
    min?: number;
    max?: number;
    step?: number;
}

export interface WorkflowNodeFieldDependsOn {
    field: string;
    map?: Record<string, WorkflowNodeFieldDependsOnRange>;
    fallback?: WorkflowNodeFieldDependsOnRange;
    entityField?: boolean;
}

export interface WorkflowNodeFieldVariableCondition {
    field: string;
    value?: unknown;
}

export interface WorkflowNodeFieldVisibleWhen {
    field: string;
    equals?: string;
    notEquals?: string;
    includes?: string[];
}

export interface WorkflowNodeObjectArraySubFieldDefinition {
    label?: string;
    type?: Exclude<WorkflowNodeFieldType, 'object-array' | 'file' | 'file-list' | 'headers'> | string;
    placeholder?: string;
    required?: boolean;
    defaultValue?: unknown;
    allowVariables?: boolean;
    options?: Array<{
        label: string;
        value: string;
    }>;
    styleCol?: number;
    min?: number;
    max?: number;
    step?: number;
}

export type WorkflowNodeObjectArrayValueMode = 'object-array' | 'record' | 'string-array';

export interface WorkflowNodeFieldDefinition {
    order?: number;
    type?: WorkflowNodeFieldType | string;
    hidden?: boolean;
    auto?: boolean;
    required?: boolean;
    editable?: boolean;
    allowVariables?: boolean;
    defaultValue?: unknown;
    label?: string;
    options?: Array<{
        label: string;
        value: string;
    }>;
    optionsSource?: string;
    placeholder?: string;
    accept?: string;
    multi?: boolean;
    min?: number;
    max?: number;
    step?: number;
    subFields?: Record<string, WorkflowNodeObjectArraySubFieldDefinition>;
    minimum?: number;
    addButtonLabel?: string;
    valueMode?: WorkflowNodeObjectArrayValueMode;
    keyField?: string;
    valueField?: string;
    dependsOn?: WorkflowNodeFieldDependsOn;
    visibleWhen?: WorkflowNodeFieldVisibleWhen;
    resolveVariablesWhen?: WorkflowNodeFieldVariableCondition;
    aiWriteMode?: WorkflowFieldAiWriteMode;
    aiSourcePort?: string;
    styles?: {
        layoutPreset?: WorkflowInspectorFieldLayoutPreset;
        showBooleanState?: boolean;
        showSlider?: boolean;
        floatingLabel?: boolean;
        columns?: number;
        labelCols?: number;
        controlCols?: number;
        companionCols?: number;
        compact?: boolean;
    };
    [key: string]: unknown;
}
export type WorkflowNodeFieldMap = Record<string, WorkflowNodeFieldDefinition>;
export interface WorkflowNodePortProperty {
    allowMultipleArrows?: boolean;
    side?: WorkflowNodePortSide;
    order?: number;
    label?: string;
    portType?: string;
    acceptedSourceGroups?: string[];
    acceptedSourceModelIds?: string[];
    showQuickAdd?: boolean;
    [key: string]: unknown;
}
export interface WorkflowNodeDocumentationField {
    key: string;
    label: string;
    description: string;
    required?: boolean;
}
export interface WorkflowNodeDocumentationExample {
    title: string;
    description?: string;
    setup?: string;
    output?: string;
}
export interface WorkflowNodeDocumentation {
    nodeTypeLabel?: string;
    summary: string;
    usage: string;
    inputs: WorkflowNodeDocumentationField[];
    outputs: WorkflowNodeDocumentationField[];
    examples?: WorkflowNodeDocumentationExample[];
    failureCases?: string[];
    backend?: {
        handler?: string;
        action?: string;
        service?: string;
        notes?: string[];
    };
}
export interface WorkflowNodeSchema {
    id?: string;
    group?: string;
    useCredentials?: string;
    useWorkflows?: WorkflowExecutableScope[];
    iconClass?: string;
    iconColor?: string;
    iconMode?: 'prime' | 'svg';
    iconSvg?: string;
    render?: WorkflowNodeRenderConfig;
    executorKey?: string;
    instruction?: WorkflowNodeInstructionConfig;
    outputViewers?: Array<{
        id: string;
        label: string;
        type: WorkflowViewerType;
    }>;
    name?: WorkflowNodeNameProperty;
    fields?: WorkflowNodeFieldMap;
    inputs?: Record<string, WorkflowNodePortProperty>;
    outputs?: Record<string, WorkflowNodePortProperty>;
    commands?: Record<string, WorkflowNodePortProperty>;
    documentation?: WorkflowNodeDocumentation;
    styles?: {
        inspectorColumns?: number;
    };
    [key: string]: unknown;
}
export interface WorkflowCanvasSettings {
    layoutEngine?: WorkflowCanvasLayoutEngine;
    edgeStyle?: WorkflowCanvasEdgeStyle;
}
export interface WorkflowMetadata {
    id: string;
    name: string;
    description?: string | null;
    workflowRecordId?: string | null;
    workflowScope?: WorkflowCatalogScope | null;
    organizationId?: string | null;
    status?: WorkflowStatus | null;
    displayStatus?: WorkflowDisplayStatus | null;
    publishedAt?: string | null;
    hasDraftChanges?: boolean;
    webhook?: {
        enabled?: boolean;
        method?: 'GET' | 'POST' | null;
        secret?: string | null;
        testUrl?: string | null;
        publishedUrl?: string | null;
        lastInvocation?: string | null;
    };
    ui?: WorkflowMetadataUi;
    createdAt?: string;
    runtime?: {
        settings?: WorkflowRuntimeSettings;
    };
    [key: string]: unknown;
}
export interface WorkflowMetadataUi {
    canvas?: WorkflowCanvasSettings;
    subworkflows?: WorkflowSubworkflowUiModel[];
}

export interface WorkflowNodePorts {
    in: Record<string, Record<string, unknown>>;
    out: Record<string, unknown>;
}

export interface WorkflowNodeModel {
    id: string;
    gigaId: string;
    modelId: string;
    type: string;
    name: string;
    description: string;
    kind: WorkflowNodeKind;
    status: WorkflowNodeStatus;
    position: {
        x: number;
        y: number;
    };
    runtime: Record<string, unknown>;
    ports: WorkflowNodePorts;
    render?: WorkflowNodeRenderConfig;
    // Legacy UI compatibility fields (not part of canonical execution payload).
    input?: Record<string, unknown>;
    output?: unknown;
    properties?: Record<string, unknown>;
    inspector?: {
        title?: string;
        input?: Record<string, unknown>;
        properties?: Record<string, unknown>;
        fields?: WorkflowNodeFieldMap;
        code?: string;
        markdown?: string;
        viewers: Array<{
            id: string;
            label: string;
            type: WorkflowViewerType;
            value: unknown;
        }>;
    };
}
export interface WorkflowSubworkflowUiModel {
    id: string;
    name: string;
    nodeIds: string[];
    collapsed: boolean;
}
export interface WorkflowConnectionModel {
    id: string;
    name: string;
    from: string;
    to: string;
    sourceHandle?: string;
    targetHandle?: string;
    text?: string;
}
export interface WorkflowDefinition {
    metadata: WorkflowMetadata;
    input?: Record<string, unknown>;
    nodeModels?: Record<string, WorkflowNodeSchema>;
    NODE_EXECUTORS?: Record<string, string>;
    NODE_EXECUTOR_SIGNATURES?: Record<string, string>;
    NODE_VALIDATORS?: Record<string, string>;
    NODE_VALIDATOR_SIGNATURES?: Record<string, string>;
    nodes: WorkflowNodeModel[];
    connections: WorkflowConnectionModel[];
}

export interface WorkflowUserNodeDefinition {
    id: string;
    userId: string;
    name: string;
    slug: string;
    description: string | null;
    groupName: string | null;
    nodeSchema: Record<string, unknown>;
    sourceFiles: {
        'worker.ts': string;
        'validate.ts'?: string;
    };
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
    modelId: string;
}

export interface WorkflowCatalogRecord {
    id: string;
    scope: WorkflowCatalogScope;
    organizationId?: string | null;
    name: string;
    description: string;
    workflow: WorkflowDefinition;
    publishedWorkflow: WorkflowDefinition | null;
    status: WorkflowStatus;
    displayStatus: WorkflowDisplayStatus;
    hasDraftChanges: boolean;
    webhookSecret: string;
    updatedAt: string | null;
    publishedAt: string | null;
    isActive: boolean;
}

export interface WorkflowCatalogLists {
    user: WorkflowCatalogRecord[];
    global: WorkflowCatalogRecord[];
    organization: WorkflowCatalogRecord[];
}

export interface WorkflowCatalogRunningStatus {
    workflowId: string;
    isRunning: boolean;
    activeExecutionCount: number;
    queuedExecutionCount: number;
    latestStatus?: string | null;
}

export interface WorkflowDerivedCapabilities {
    isWebhookBased: boolean;
    webhookMethod: 'GET' | 'POST' | null;
}

export interface WorkflowExecutionFilterValues {
    createdFrom?: string | null;
    createdTo?: string | null;
    durationMsMin?: number | null;
    durationMsMax?: number | null;
    status?: string | null;
    workflowVersionId?: string | null;
}

export interface WorkflowExecutionRecord {
    id: string;
    workflowId: string;
    workflowScope: WorkflowCatalogScope;
    organizationId?: string | null;
    workflowVersionId: string | null;
    workflowVersionLabel: string | null;
    status: string;
    triggerType: string | null;
    runId: string | null;
    errorMessage: string | null;
    createdAt: string;
    completedAt: string | null;
    durationMs: number | null;
    requestPayload: unknown;
    responsePayload: unknown;
    logs: unknown[];
    workflowSnapshot: WorkflowDefinition | null;
}

export interface WorkflowVersionRecord {
    id: string;
    workflowId: string;
    workflowScope: WorkflowCatalogScope;
    organizationId?: string | null;
    versionNumber: number;
    label: string;
    isCurrent: boolean;
    publishedAt: string | null;
    createdAt: string;
    executionCount: number;
    referencedByExecutions: boolean;
    workflowSnapshot: WorkflowDefinition | null;
}
export interface WorkflowNodeLibraryItem {
    id: string;
    label: string;
    description: string;
    gigaId: string;
    modelId: string;
    order?: number;
    renderIcon?: (size: number) => unknown;
    iconClass?: string;
    iconKey?: string;
    iconColor?: string;
    iconBackground?: string;
    nodeType: string;
    defaultKind?: WorkflowNodeKind;
    group?: string;
}
export interface WorkflowExportNode {
    id: string;
    gigaId: string;
    modelId: string;
    type: string;
    name: string;
    description: string;
    status: WorkflowNodeStatus;
    kind: WorkflowNodeKind;
    position: {
        x: number;
        y: number;
    };
    runtime: Record<string, unknown>;
    ports: WorkflowNodePorts;
}
export interface WorkflowExportConnection {
    name: string;
    id: string;
    from: string;
    to: string;
    fromId?: string;
    toId?: string;
    sourceHandle?: string;
    targetHandle?: string;
    text?: string;
}
export interface WorkflowExportPayload {
    exportMode: WorkflowExportMode;
    metadata: WorkflowMetadata;
    nodes: Record<string, WorkflowExportNode>;
    connections: Record<string, WorkflowExportConnection>;
    nodeModels?: Record<string, WorkflowNodeSchema>;
    NODE_EXECUTORS?: Record<string, string>;
    NODE_EXECUTOR_SIGNATURES?: Record<string, string>;
}
