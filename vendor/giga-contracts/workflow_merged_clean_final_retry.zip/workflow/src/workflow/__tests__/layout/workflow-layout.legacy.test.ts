import { describe, expect, it } from 'vitest';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { layoutWorkflowGraph } from '@workflow/ui/workflow/layout';

describe('workflow layout legacy engine', () => {
    it('keeps linear flows on one vertical spine', async () => {
        const workflow = createEmptyWorkflow('wf_layout_legacy_linear');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];
        const arranged = await layoutWorkflowGraph(workflow);

        expect(arranged.nodes[0].position.x).toBe(arranged.nodes[1].position.x);
        expect(arranged.nodes[1].position.x).toBe(arranged.nodes[2].position.x);
        expect(arranged.nodes[0].position.y).toBeLessThan(arranged.nodes[1].position.y);
        expect(arranged.nodes[1].position.y).toBeLessThan(arranged.nodes[2].position.y);
    });

    it('fans out branches and recenters merge nodes', async () => {
        const workflow = createEmptyWorkflow('wf_layout_legacy_branch');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const branch = createWorkflowNode(workflow, 'if-else', 'Branch', 2);
        const left = createWorkflowNode(workflow, 'code', 'Left', 3);
        const right = createWorkflowNode(workflow, 'code', 'Right', 4);
        const merge = createWorkflowNode(workflow, 'merge', 'Merge', 5);
        workflow.nodes = [start, branch, left, right, merge];
        workflow.connections = [createConnection('c1', start.id, branch.id), createConnection('c2', branch.id, left.id, 'out:true'), createConnection('c3', branch.id, right.id, 'out:false'), createConnection('c4', left.id, merge.id), createConnection('c5', right.id, merge.id, 'out:output', 'in:input2')];
        const arranged = await layoutWorkflowGraph(workflow);
        const leftNode = arranged.nodes.find((node) => node.id === left.id);
        const rightNode = arranged.nodes.find((node) => node.id === right.id);
        const mergeNode = arranged.nodes.find((node) => node.id === merge.id);

        expect(leftNode?.position.y).toBe(rightNode?.position.y);
        expect(leftNode?.position.x).not.toBe(rightNode?.position.x);
        expect((mergeNode?.position.x || 0) > Math.min(leftNode?.position.x || 0, rightNode?.position.x || 0)).toBe(true);
        expect((mergeNode?.position.x || 0) < Math.max(leftNode?.position.x || 0, rightNode?.position.x || 0)).toBe(true);
    });
});
