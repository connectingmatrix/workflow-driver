import type { Plugin } from 'vite';
import { executeNodeWorkflowPreviewRequest } from './node-preview-runtime';
import { readJsonBody, sendJson } from './node-preview-http.utils';
import type { WorkflowNodePreviewRequest } from '../shared/preview-runtime.types';
import { WORKFLOW_NODE_PREVIEW_ENDPOINT } from '../shared/preview-runtime.constants';

export const workflowNodePreviewPlugin = (): Plugin => ({
    name: 'workflow-node-preview-plugin',
    configureServer(server) {
        server.middlewares.use(WORKFLOW_NODE_PREVIEW_ENDPOINT, async (request, response) => {
            if (request.method !== 'POST') {
                sendJson(response, 405, { ok: false, error: 'Method not allowed.', logs: [], states: [] });
                return;
            }

            try {
                const payload = await readJsonBody<WorkflowNodePreviewRequest>(request);
                const result = await executeNodeWorkflowPreviewRequest(payload);
                sendJson(response, result.ok ? 200 : 500, result);
            } catch (error) {
                sendJson(response, 500, {
                    ok: false,
                    error: error instanceof Error ? error.message : String(error),
                    logs: [],
                    states: []
                });
            }
        });
    }
});

export const workflowNodePreviewEndpoint = WORKFLOW_NODE_PREVIEW_ENDPOINT;
