import { WorkflowAiHiddenContext } from './types';

const RAW_PROMPTS = import.meta.glob('./workflow-ai.prompt.md', {
    eager: true,
    import: 'default',
    query: '?raw'
}) as Record<string, string>;

const WORKFLOW_AI_SYSTEM_PROMPT = RAW_PROMPTS['./workflow-ai.prompt.md'] ?? '';

export const buildWorkflowAiPrompt = (userMessage: string, context: WorkflowAiHiddenContext): string => {
    const normalizedMessage = String(userMessage ?? '').trim();
    const contextJson = JSON.stringify(context, null, 2);

    return [WORKFLOW_AI_SYSTEM_PROMPT.trim(), '', '---', 'HIDDEN_CONTEXT_JSON_START', contextJson, 'HIDDEN_CONTEXT_JSON_END', '---', '', `USER_MESSAGE: ${normalizedMessage}`].join('\n');
};
