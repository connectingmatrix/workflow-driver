export enum WorkflowNodeStatusEnum {
    Passed = 'passed',
    Failed = 'failed',
    Warning = 'warning',
    Running = 'running',
    Stopped = 'stopped'
}

export enum WorkflowNodeKindEnum {
    Process = 'process',
    Output = 'output',
    Error = 'error'
}

export enum WorkflowLogLevelEnum {
    Info = 'info',
    Warn = 'warn',
    Error = 'error'
}

export enum WorkflowExecutorModeEnum {
    Local = 'local',
    Server = 'server'
}

export enum WorkerRuntimeEnvironmentEnum {
    Browser = 'browser',
    Node = 'node'
}

export type WorkflowNodeStatus = `${WorkflowNodeStatusEnum}`;
export type WorkflowNodeKind = `${WorkflowNodeKindEnum}`;
export type WorkflowLogLevel = `${WorkflowLogLevelEnum}`;
export type WorkflowExecutorMode = `${WorkflowExecutorModeEnum}`;
export type WorkerRuntimeEnvironment = `${WorkerRuntimeEnvironmentEnum}`;
export type WorkflowPreviewRuntime = 'auto' | 'browser' | 'node';
export type WorkflowPreviewMode = 'designer';
export type WorkflowPreviewLogSource =
    | 'stdout'
    | 'stderr'
    | 'worker'
    | 'browser'
    | 'runtime';
export type WorkflowCredentialScope = 'GLOBAL' | 'ORGANIZATION' | 'PERSONAL';
export type WorkflowCredentialScopeTag = 'Global' | 'Org' | 'User';
export type WorkflowExecutableScope = 'user' | 'organization';

export interface WorkflowSourceFiles {
    'worker.ts'?: string;
    'validate.ts'?: string;
    [fileName: string]: string | undefined;
}

export interface WorkflowRunLogEvent {
    timestamp: string;
    level: WorkflowLogLevel;
    event: string;
    workflowId: string;
    runId: string;
    nodeId?: string;
    message?: string;
    data?: unknown;
}

export interface WorkflowPreviewLogEvent {
    runId: string;
    nodeId: string;
    source: WorkflowPreviewLogSource;
    line: string;
    timestamp: string;
    runtime?: WorkerRuntimeEnvironment | 'node' | 'browser';
    stream?: string;
}

export interface WorkflowPreviewValidationSummary {
    ok: boolean;
    warnings?: string[];
    errors?: string[];
    normalizedRuntime?: Record<string, unknown>;
}

export interface WorkflowPreviewStateEvent {
    runId: string;
    nodeId: string;
    state:
        | 'starting'
        | 'running'
        | 'passed'
        | 'failed'
        | 'stopped'
        | 'cancelled';
    requestedRuntime?: WorkflowPreviewRuntime;
    runtime?: WorkerRuntimeEnvironment | 'node' | 'browser';
    startedAt?: string;
    durationMs?: number;
    message?: string;
    validation?: WorkflowPreviewValidationSummary;
}

export interface WorkflowRuntimeSettings {
    graphqlUrl: string;
    httpBaseUrl?: string;
    authMode: string;
    manualHeaders?: Record<string, string>;
    maxConcurrentExecutionsPerUser?: number;
    maxExecutionSeconds?: number;
    sharedDrive?: {
        access: 'read' | 'readwrite';
        organizationId: string;
        path: string;
        quotaBytes: number;
        virtualPath: '/drive';
    } | null;
}

export interface WorkflowCredentialOption {
    id: string;
    credentialId: string;
    credentialName: string;
    serviceId: string;
    serviceName: string | null;
    serviceIcon: string | null;
    scope: WorkflowCredentialScope;
    scopeTag: WorkflowCredentialScopeTag;
    status?: string | null;
}

export interface WorkflowResolvedCredential {
    id: string;
    credentialId: string;
    credentialName: string;
    serviceId: string;
    serviceName: string | null;
    serviceIcon: string | null;
    scope: WorkflowCredentialScope;
    values: Record<string, unknown>;
}

export interface WorkflowCredentialExecutionResultInput {
    credentialId: string;
    success: boolean;
    lastUsedAt?: string | null;
}

export interface WorkflowCredentialHostContext {
    fetchCredentialById?: (credentialId: string) => Promise<WorkflowResolvedCredential | null>;
    recordCredentialExecutionResult?: (input: WorkflowCredentialExecutionResultInput) => Promise<void>;
}

export interface WorkflowExecutionReferenceInput {
    workflowId: string;
    parameters: unknown;
    settings?: WorkflowRuntimeSettings;
}

export interface WorkflowExecutionReferenceResult {
    result: unknown;
    runId: string;
    workflowId: string;
    workflowName: string;
    workflowScope: WorkflowExecutableScope;
    stopped: boolean;
    logs: string[];
    editorUrl?: string | null;
}

export interface WorkflowManagedRecord {
    workflowId: string;
    workflowName: string;
    workflowDescription?: string | null;
    workflowScope: WorkflowExecutableScope;
    organizationId?: string | null;
    status?: string | null;
    editorUrl?: string | null;
    workflow?: WorkflowDefinition | null;
    publishedWorkflow?: WorkflowDefinition | null;
    cypher?: string | null;
    publishedAt?: string | null;
}

export interface WorkflowListInput {
    scope?: WorkflowExecutableScope;
    organizationId?: string | null;
}

export interface WorkflowGetInput {
    workflowId: string;
    scope?: WorkflowExecutableScope;
    organizationId?: string | null;
}

export interface WorkflowSaveInput {
    workflowId?: string | null;
    scope: WorkflowExecutableScope;
    organizationId?: string | null;
    name: string;
    description?: string | null;
    workflow: WorkflowDefinition;
    cypher?: string | null;
    publishAfterSave?: boolean;
    executable?: boolean;
}

export interface WorkflowDeleteInput {
    workflowId: string;
    scope?: WorkflowExecutableScope;
    organizationId?: string | null;
}

export interface WorkflowPublishInput {
    workflowId: string;
    scope?: WorkflowExecutableScope;
    organizationId?: string | null;
}

export interface WorkflowManagementHostContext {
    listWorkflowDefinitions?: (input: WorkflowListInput) => Promise<WorkflowManagedRecord[]>;
    getWorkflowDefinition?: (input: WorkflowGetInput) => Promise<WorkflowManagedRecord | null>;
    saveWorkflowDefinition?: (input: WorkflowSaveInput) => Promise<WorkflowManagedRecord>;
    deleteWorkflowDefinition?: (input: WorkflowDeleteInput) => Promise<{ workflowId: string }>;
    publishWorkflowDefinition?: (input: WorkflowPublishInput) => Promise<WorkflowManagedRecord>;
}

export interface WorkflowExecutionHostContext extends WorkflowManagementHostContext {
    executeWorkflowReference?: (input: WorkflowExecutionReferenceInput) => Promise<WorkflowExecutionReferenceResult>;
}

export interface WorkflowNodePorts {
    in: Record<string, Record<string, unknown>>;
    out: Record<string, unknown>;
}

export interface WorkflowNodeModel {
    id: string;
    gigaId: string;
    modelId: string;
    type: string;
    name: string;
    description: string;
    kind: WorkflowNodeKind;
    status: WorkflowNodeStatus;
    position: { x: number; y: number };
    runtime: Record<string, unknown>;
    ports: WorkflowNodePorts;
    properties?: Record<string, unknown>;
}

export interface WorkflowConnectionModel {
    id: string;
    name: string;
    from: string;
    to: string;
    sourceHandle?: string;
    targetHandle?: string;
    text?: string;
}

export interface WorkflowNodeFieldSchema {
    aiWriteMode?: 'allow' | 'connected-options-only' | 'deny';
    aiSourcePort?: string;
    allowVariables?: boolean;
    hidden?: boolean;
    auto?: boolean;
    editable?: boolean;
    type?: string;
    [key: string]: unknown;
}

export interface WorkflowNodePortSchema {
    allowMultipleArrows?: boolean;
    side?: string;
    order?: number;
    label?: string;
    portType?: string;
    acceptedSourceGroups?: string[];
    acceptedSourceModelIds?: string[];
    [key: string]: unknown;
}

export interface WorkflowNodeSchema {
    id?: string;
    useCredentials?: string;
    iconClass?: string;
    iconColor?: string;
    iconMode?: 'prime' | 'svg';
    iconSvg?: string;
    render?: {
        iconClass?: string;
        iconColor?: string;
        iconMode?: 'prime' | 'svg';
        iconSvg?: string;
        [key: string]: unknown;
    };
    fields?: Record<string, WorkflowNodeFieldSchema>;
    inputs?: Record<string, WorkflowNodePortSchema>;
    outputs?: Record<string, WorkflowNodePortSchema>;
    commands?: Record<string, WorkflowNodePortSchema>;
    sandbox?: {
        transport?: 'worker-sandbox' | 'openai-unix-sandbox';
        allowProcessApis?: boolean;
        [key: string]: unknown;
    };
    [key: string]: unknown;
}

export interface WorkflowMetadata {
    id: string;
    name: string;
    createdAt?: string;
    runtime?: {
        settings?: WorkflowRuntimeSettings;
    };
    [key: string]: unknown;
}

export interface WorkflowDefinition {
    metadata: WorkflowMetadata;
    input?: Record<string, unknown>;
    nodeModels?: Record<string, WorkflowNodeSchema>;
    NODE_EXECUTORS?: Record<string, string>;
    NODE_EXECUTOR_SIGNATURES?: Record<string, string>;
    NODE_SOURCE_FILES?: Record<string, string>;
    NODE_VALIDATORS?: Record<string, string>;
    NODE_VALIDATOR_SIGNATURES?: Record<string, string>;
    nodes: WorkflowNodeModel[];
    connections: WorkflowConnectionModel[];
}

export interface WorkflowInvokeConnectedNodeArgs {
    nodeId: string;
    input?: Record<string, Record<string, unknown>>;
    overrides?: WorkflowStepOverrides;
}

export interface WorkflowNodeHandlerContext {
    node: WorkflowNodeModel;
    workflow: WorkflowDefinition;
    settings: WorkflowRuntimeSettings;
    input: Record<string, Record<string, unknown>>;
    signal?: AbortSignal;
    hostContext?: unknown;
    credential?: WorkflowResolvedCredential | null;
    invokeConnectedNode?: (args: WorkflowInvokeConnectedNodeArgs) => Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }>;
}

export interface WorkflowNodeHandlerResult {
    output: unknown;
    status?: WorkflowNodeStatus;
    logs?: string[];
    previewValidation?: WorkflowPreviewValidationSummary | null;
    skipCommandPeerAutoRun?: boolean;
}

export interface WorkflowControlNodePatch {
    properties?: Record<string, unknown>;
    runtime?: Record<string, unknown>;
    code?: string;
    markdown?: string;
    sourceFiles?: WorkflowSourceFiles;
}

export interface WorkflowControlNodeSnapshot {
    nodeId: string;
    name: string;
    modelId: string;
    status: WorkflowNodeStatus;
    properties: Record<string, unknown>;
    runtime: Record<string, unknown>;
    input: Record<string, Record<string, unknown>>;
    output: unknown;
    sourceFiles?: WorkflowSourceFiles;
}

export interface WorkflowControlNodeValidateArgs {
    patch?: WorkflowControlNodePatch;
    input?: Record<string, Record<string, unknown>>;
}

export interface WorkflowControlNodeExecuteArgs {
    patch?: WorkflowControlNodePatch;
    input?: Record<string, Record<string, unknown>>;
}

export interface WorkflowControlNodeExecuteInputsArgs {
    patch?: WorkflowControlNodePatch;
}

export interface WorkflowCommandToolContractField {
    key: string;
    label?: string;
    description?: string;
    required?: boolean;
    options?: { label: string; value: string }[];
    [key: string]: unknown;
}

export interface WorkflowCommandToolMetadata {
    mutating?: boolean;
    workflowOutput?: boolean;
    toolDomain?: string;
    mutatingActions?: string[];
    workflowActions?: string[];
    [key: string]: unknown;
}

export interface WorkflowCommandToolSpec {
    toolName: string;
    toolDescription: string;
    inputContract?: {
        required?: WorkflowCommandToolContractField[];
        optional?: WorkflowCommandToolContractField[];
    };
    outputContract?: WorkflowCommandToolContractField[];
    metadata?: WorkflowCommandToolMetadata;
    executionKind: 'tool';
}

export interface WorkerControlNodeFacade {
    get: () => Promise<WorkflowControlNodeSnapshot>;
    getSchema: () => Promise<WorkflowNodeSchema>;
    set: (patch: WorkflowControlNodePatch) => Promise<WorkflowControlNodeSnapshot>;
    validate: (args?: WorkflowControlNodeValidateArgs) => Promise<WorkerValidateResult>;
    executeInputs: (args?: WorkflowControlNodeExecuteInputsArgs) => Promise<WorkflowControlNodeSnapshot>;
    execute: (args?: WorkflowControlNodeExecuteArgs) => Promise<{ node: WorkflowControlNodeSnapshot; result: WorkflowNodeHandlerResult }>;
    commandToolSpec?: () => Promise<WorkflowCommandToolSpec | null>;
}

export type WorkflowNodeHandler = (context: WorkflowNodeHandlerContext) => Promise<WorkflowNodeHandlerResult>;

/**
 * Descriptor for worker-authored service execution:
 * executeGigaService({ service, function, description }, payload)
 */
export interface WorkflowExecuteGigaServiceDescriptor {
    key?: string;
    service?: string;
    function?: string;
    description?: string;
}

export interface WorkflowExecuteGigaServiceRequest {
    context: WorkflowNodeHandlerContext;
    descriptor?: WorkflowExecuteGigaServiceDescriptor;
    payload?: unknown;
    args: unknown[];
}

export type WorkflowExecuteBackendDescriptor = WorkflowExecuteGigaServiceDescriptor;
export type WorkflowExecuteBackendRequest = WorkflowExecuteGigaServiceRequest;

export interface WorkflowInvokeConnectedNodeRequest {
    context: WorkflowNodeHandlerContext;
    payload?: WorkflowInvokeConnectedNodeArgs;
    args: unknown[];
}

export interface WorkflowResolveNodeSourceFilesRequest {
    context: WorkflowNodeHandlerContext;
    modelId: string;
}

export interface WorkerExecuteHelpers {
    /**
     * This will execute the Giga service path, Giga service function,
     * and description of what that service does:
     * executeGigaService({ service, function, description }, payload)
     */
    executeGigaService?: (request: WorkflowExecuteGigaServiceRequest) => Promise<WorkflowNodeHandlerResult>;
    /**
     * Backward-compatible alias of executeGigaService.
     */
    executeBackend?: (request: WorkflowExecuteBackendRequest) => Promise<WorkflowNodeHandlerResult>;
    compileWorkflowCypher?: (input: {
        cypher: string;
        name?: string;
        description?: string;
        executable?: boolean;
        metadata?: Record<string, unknown>;
    }) => Promise<unknown> | unknown;
    invokeConnectedNode?: (request: WorkflowInvokeConnectedNodeRequest) => Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }>;
    updateNode?: (...args: unknown[]) => Promise<void> | void;
    resolveNodeSourceFiles?: (request: WorkflowResolveNodeSourceFilesRequest) => Promise<WorkflowSourceFiles | null>;
}

export interface WorkflowStepOverrides {
    runtime?: Record<string, unknown>;
    properties?: Record<string, unknown>;
    code?: string;
    markdown?: string;
    sourceFiles?: WorkflowSourceFiles;
    previewRuntime?: WorkflowPreviewRuntime;
    previewInput?: Record<string, unknown>;
    previewMode?: WorkflowPreviewMode;
}

export interface WorkflowLogger {
    push: (event: Omit<WorkflowRunLogEvent, 'timestamp'>) => void;
    entries: WorkflowRunLogEvent[];
}

export interface WorkflowExecutorRemoteNodeResult {
    workflow: WorkflowDefinition;
    node: WorkflowNodeModel;
    result: WorkflowNodeHandlerResult;
    events?: WorkflowRunLogEvent[];
}

export interface WorkflowExecutorAdapters {
    getNodeHandler: (modelId: string | undefined) => WorkflowNodeHandler;
}

export interface ExecuteWorkflowOptions {
    signal?: AbortSignal;
    settings: WorkflowRuntimeSettings;
    workflowInput?: Record<string, unknown>;
    hostContext?: unknown;
    isNodeLocalCapable?: (modelId: string | undefined) => boolean;
    executeNodeRemotely?: (payload: {
        workflow: WorkflowDefinition;
        nodeId: string;
        settings: WorkflowRuntimeSettings;
        overrides?: WorkflowStepOverrides;
        hostContext?: unknown;
    }) => Promise<WorkflowExecutorRemoteNodeResult>;
    onNodeStart?: (nodeId: string) => void;
    onNodeFinish?: (node: WorkflowNodeModel) => void;
    onEvent?: (event: WorkflowRunLogEvent) => void;
    onPreviewLogLine?: (event: WorkflowPreviewLogEvent) => void;
    onPreviewState?: (event: WorkflowPreviewStateEvent) => void;
}

export interface ExecuteNodeStepOptions {
    workflow: WorkflowDefinition;
    nodeId: string;
    settings: WorkflowRuntimeSettings;
    workflowInput?: Record<string, unknown>;
    signal?: AbortSignal;
    hostContext?: unknown;
    overrides?: WorkflowStepOverrides;
    isNodeLocalCapable?: (modelId: string | undefined) => boolean;
    executeNodeRemotely?: ExecuteWorkflowOptions['executeNodeRemotely'];
    onEvent?: (event: WorkflowRunLogEvent) => void;
    onPreviewLogLine?: (event: WorkflowPreviewLogEvent) => void;
    onPreviewState?: (event: WorkflowPreviewStateEvent) => void;
}

export interface WorkflowExecutorResult {
    workflow: WorkflowDefinition;
    stopped: boolean;
    events: WorkflowRunLogEvent[];
}

export interface WorkflowStepExecutorResult {
    workflow: WorkflowDefinition;
    node: WorkflowNodeModel;
    result: WorkflowNodeHandlerResult;
    events: WorkflowRunLogEvent[];
}

export interface WorkflowExecutor {
    mode: WorkflowExecutorMode;
    executeWorkflow: (workflow: WorkflowDefinition, options: ExecuteWorkflowOptions) => Promise<WorkflowExecutorResult>;
    executeNodeStep: (options: ExecuteNodeStepOptions) => Promise<WorkflowStepExecutorResult>;
}

export type WorkerScope = Record<string, unknown>;

export interface WorkerNodeFacade extends WorkflowNodeModel {
    PORTS: Record<string, unknown>;
    PROPERTIES: Record<string, unknown>;
    OUTPUT: unknown;
    CREDENTIAL: WorkflowResolvedCredential | null;
    CONTROL_NODES: Record<string, Record<string, WorkerControlNodeFacade>>;
}

export interface WorkerSelfState {
    status: WorkflowNodeStatus;
    PORTS: WorkflowNodePorts;
    OUTPUT: unknown;
}

export interface WorkerPayload {
    workflow: WorkflowDefinition;
    ENVIRONMENT: WorkerRuntimeEnvironment;
    EXECUTOR: {
        environment: WorkerRuntimeEnvironment;
    };
    HOST_CONTEXT?: unknown;
    NODE_SCOPE: WorkerScope;
    NODE: WorkerNodeFacade;
    self: WorkerSelfState;
}

export interface WorkerValidateResult {
    ok: boolean;
    errors: string[];
    warnings?: string[];
    normalizedRuntime?: Record<string, unknown>;
}

export interface WorkerUpdateResult {
    ok: boolean;
    error?: string | null;
}

export type WorkerExecuteResult = WorkflowNodeHandlerResult;

export interface WorkerModuleExports {
    validate: (payload: WorkerPayload) => Promise<WorkerValidateResult | boolean | void> | WorkerValidateResult | boolean | void;
    init: (payload: WorkerPayload) => Promise<unknown> | unknown;
    onUpdate: (payload: WorkerPayload) => Promise<WorkerUpdateResult | boolean | void> | WorkerUpdateResult | boolean | void;
    execute: (payload: WorkerPayload) => Promise<WorkerExecuteResult | unknown> | WorkerExecuteResult | unknown;
    commandToolSpec?: (payload: WorkerPayload) => Promise<WorkflowCommandToolSpec | null> | WorkflowCommandToolSpec | null;
}
