import type { WorkflowMetadata, WorkflowPlayLifecycleEnum, WorkflowPlayModeEnum } from '@workflow/ui/workflow/types';

export interface ToolbarProps {
    metadata: WorkflowMetadata | null;
    isPlaying: boolean;
    playMode: WorkflowPlayModeEnum;
    playLifecycle: WorkflowPlayLifecycleEnum;
    canPlay: boolean;
    isEditable: boolean;
    isExecutionMode?: boolean;
    canReplayExecution?: boolean;
    onPlayLocal: () => void;
    onPlayServer: () => void;
    onStop: () => void;
    onExportWorkflowOnly: () => void;
    onExportWithData: () => void;
    onClear: () => void;
    onToggleEditable: () => void;
    onImportJson: (rawJson: string) => void;
    onShowMetadata: () => void;
    onShowLogs: () => void;
    onShowSettings: () => void;
    onOpenUserNodeStudio?: () => void;
    onSaveDraft?: () => void;
    saveDraftDisabled?: boolean;
    saveDraftBusy?: boolean;
    onPublish?: () => void;
    publishDisabled?: boolean;
    publishBusy?: boolean;
    onOpenCatalogImport?: () => void;
    catalogImportDisabled?: boolean;
    onOpenAi?: () => void;
    onClose: () => void;
}
