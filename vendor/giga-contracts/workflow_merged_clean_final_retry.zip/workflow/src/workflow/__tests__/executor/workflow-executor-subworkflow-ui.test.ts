import { describe, expect, it } from 'vitest';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WorkflowAuthModeEnum } from '@workflow/ui/workflow/types';

const buildWorkflowWithSubworkflowUi = (collapsed: boolean) => {
    const workflow = createEmptyWorkflow(`wf_subworkflow_ui_${collapsed ? 'collapsed' : 'expanded'}`);
    const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
    const metadataNode = createWorkflowNode(workflow, 'metadata', 'Metadata', 2);
    const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
    endNode.runtime = {
        ...(endNode.runtime ?? {}),
        response: `{{${metadataNode.id}}}`
    };
    workflow.nodes = [startNode, metadataNode, endNode];
    workflow.connections = [createConnection('c_1', startNode.id, metadataNode.id), createConnection('c_2', metadataNode.id, endNode.id)];
    workflow.metadata.ui = {
        subworkflows: [{ id: 'sw_executor', name: 'Executor Group', nodeIds: [metadataNode.id], collapsed }]
    };
    return workflow;
};

describe('workflow executor with subworkflow ui metadata', () => {
    it('executes successfully when subworkflow is expanded', async () => {
        const result = await workflowExecutor.executeWorkflow(buildWorkflowWithSubworkflowUi(false), {
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: WorkflowAuthModeEnum.None,
                manualHeaders: {}
            }
        });

        expect(result.events.some((event) => event.event === 'workflow.validation_failed')).toBe(false);
        const endNode = result.workflow.nodes.find((node) => node.modelId === 'respond-end');
        expect(endNode).toBeTruthy();
        expect((endNode?.ports?.out as Record<string, unknown> | undefined)?.output).toBeTruthy();
    });

    it('executes successfully when subworkflow is collapsed', async () => {
        const result = await workflowExecutor.executeWorkflow(buildWorkflowWithSubworkflowUi(true), {
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: WorkflowAuthModeEnum.None,
                manualHeaders: {}
            }
        });

        expect(result.events.some((event) => event.event === 'workflow.validation_failed')).toBe(false);
        const endNode = result.workflow.nodes.find((node) => node.modelId === 'respond-end');
        expect(endNode).toBeTruthy();
        expect((endNode?.ports?.out as Record<string, unknown> | undefined)?.output).toBeTruthy();
    });
});
