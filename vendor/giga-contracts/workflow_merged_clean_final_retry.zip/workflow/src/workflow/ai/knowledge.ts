export interface WorkflowAiKnowledgeEntry {
    id: string;
    problem: string;
    solutionCypher: string;
    tags: string[];
    notes?: string;
}

const queryCode = 'return { query: "latest Iran security and geopolitical news last 7 days", columns: ["time", "title", "source", "url", "threatLevel", "threatType", "summary", "confidence"] };';
const tableCode = [
    'const request = Object.values(input || {})[0] || {};',
    'const actionInput = (request.action || {}).input || {};',
    'const dependencyResults = request.dependencyResults || {};',
    'const analysis = dependencyResults.analysis || {};',
    'const search = dependencyResults.search || {};',
    'const rows = actionInput.rows || analysis.rows || search.rows || [];',
    'const columns = actionInput.columns || ["time", "title", "source", "url", "threatLevel", "threatType", "summary", "confidence"];',
    'const escapeCell = (value) => String(value || "").replace(/\\|/g, "\\\\|").replace(/\\n/g, " ");',
    'const csv = [columns.join(","), ...rows.map((row) => columns.map((key) => JSON.stringify(row[key] || "")).join(","))].join("\\n");',
    'const markdown = ["|" + columns.join("|") + "|", "|" + columns.map(() => "---").join("|") + "|", ...rows.map((row) => "|" + columns.map((key) => escapeCell(row[key])).join("|") + "|")].join("\\n");',
    'return { csv, markdown, rows, columns };'
].join('\n');

const governorPrompt = [
    'Use the Code input query as the source task.',
    'Run SERP Search for recent Iran news.',
    'Ask the connected model to analyze threat relevance and return rows with the requested columns.',
    'Run the connected Code formatter tool with rows and columns to produce csv and markdown.',
    'Final action must be the formatter tool. Return markdown only as the final user-visible answer.'
].join(' ');

export const WORKFLOW_AI_KNOWLEDGE: WorkflowAiKnowledgeEntry[] = [
    {
        id: 'news-threat-analysis-governor-code-table',
        problem: 'Search recent Iran news, analyze threat relevance, sort into a CSV-like table, and output a markdown table using existing nodes.',
        tags: ['news', 'threat-analysis', 'ai-governor', 'serp-search', 'code-table'],
        notes: 'Output Format remains markdown pass-through; Code tool performs CSV and markdown table conversion.',
        solutionCypher: [
            `(start:start {"name":"Start","runtime":{}})`,
            `(query:code {"name":"Build Query","runtime":{"code":${JSON.stringify(queryCode)}}})`,
            `(governor:ai-governor {"name":"Threat Analysis Governor","runtime":{"selectionPromptMd":${JSON.stringify(governorPrompt)}}})`,
            `(search:serp-search {"name":"Search Iran News","runtime":{"query":"latest Iran security and geopolitical news last 7 days","max_results":12,"location":"United States","language":"en"}})`,
            `(model:openai {"name":"Analyze Threats","runtime":{"model":"gpt-4.1-mini","prompt":"Analyze the SERP results into threat rows. Return JSON with rows only."}})`,
            `(table:code {"name":"CSV Markdown Table","runtime":{"code":${JSON.stringify(tableCode)}}})`,
            `(format:output-format {"name":"Markdown Output","runtime":{"format":"markdown","value":{},"useAiFormatting":false}})`,
            `(end:respond-end {"name":"Respond End","runtime":{}})`,
            `(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(query)`,
            `(query)-[:CONNECT {"source":"out:output","target":"in:input"}]->(governor)`,
            `(search)-[:CONNECT {"source":"cmd:command","target":"cmd:tools"}]->(governor)`,
            `(model)-[:CONNECT {"source":"cmd:command","target":"cmd:llm"}]->(governor)`,
            `(table)-[:CONNECT {"source":"cmd:command","target":"cmd:tools"}]->(governor)`,
            `(governor)-[:CONNECT {"source":"out:output","target":"in:input"}]->(format)`,
            `(format)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)`
        ].join('\n')
    }
];
