// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import WorkspaceCanvasChrome from '@workflow/ui/workflow/components/designer-layout/workspace/WorkspaceCanvasChrome';

describe('WorkspaceCanvasChrome', () => {
    afterEach(() => cleanup());

    it('renders search navigation only for multiple matches and triggers handlers', () => {
        const onNextMatch = vi.fn();
        const onPreviousMatch = vi.fn();
        render(
            <WorkspaceCanvasChrome
                searchValue="code"
                onSearchChange={vi.fn()}
                onSearchKeyDown={vi.fn()}
                matchCount={3}
                activeMatchIndex={1}
                onNextMatch={onNextMatch}
                onPreviousMatch={onPreviousMatch}
                nodeCount={5}
                connectionCount={2}
            />
        );
        expect(screen.getByText('2 of 3')).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Previous search result' }));
        fireEvent.click(screen.getByRole('button', { name: 'Next search result' }));
        expect(onPreviousMatch).toHaveBeenCalledTimes(1);
        expect(onNextMatch).toHaveBeenCalledTimes(1);
    });

    it('hides search navigation when matches are one or none', () => {
        render(
            <WorkspaceCanvasChrome
                searchValue=""
                onSearchChange={vi.fn()}
                onSearchKeyDown={vi.fn()}
                matchCount={1}
                activeMatchIndex={0}
                onNextMatch={vi.fn()}
                onPreviousMatch={vi.fn()}
                nodeCount={0}
                connectionCount={0}
            />
        );
        expect(screen.queryByText(/of/)).not.toBeInTheDocument();
    });
});
