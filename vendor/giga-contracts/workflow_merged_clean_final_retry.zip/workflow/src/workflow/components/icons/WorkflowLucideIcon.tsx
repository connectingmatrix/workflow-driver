import React from 'react';
import type { LucideIcon } from 'lucide-react';
import {
    Box,
    Check,
    Clock3,
    Compass,
    Copy,
    Database,
    Download,
    FileText,
    FolderOpen,
    Grid3X3,
    Hand,
    Info,
    LoaderCircle,
    MessageSquare,
    Monitor,
    MoreHorizontal,
    Move,
    Paperclip,
    Play,
    Plus,
    Power,
    RefreshCw,
    Save,
    Scissors,
    Search,
    Send,
    Server,
    Settings,
    Share2,
    SlidersHorizontal,
    Sparkles,
    Square,
    Table2,
    Trash2,
    Upload,
    Workflow,
    X,
    Zap
} from 'lucide-react';

interface WorkflowLucideIconProps {
    icon?: string;
    className?: string;
    size?: number;
}

const ICONS: Record<string, LucideIcon> = {
    bolt: Zap,
    box: Box,
    check: Check,
    clock: Clock3,
    clone: Copy,
    code: Box,
    comments: MessageSquare,
    compass: Compass,
    copy: Copy,
    database: Database,
    desktop: Monitor,
    download: Download,
    ellipsis: MoreHorizontal,
    file: FileText,
    folder: FolderOpen,
    hand: Hand,
    info: Info,
    move: Move,
    paperclip: Paperclip,
    play: Play,
    plus: Plus,
    power: Power,
    refresh: RefreshCw,
    save: Save,
    scissors: Scissors,
    search: Search,
    send: Send,
    server: Server,
    settings: Settings,
    share: Share2,
    sitemap: Workflow,
    sliders: SlidersHorizontal,
    sparkles: Sparkles,
    spinner: LoaderCircle,
    stop: Square,
    table: Table2,
    th: Grid3X3,
    times: X,
    trash: Trash2,
    upload: Upload,
    x: X
};

const resolveIconKey = (icon?: string): string => {
    const token = (icon || '').toLowerCase();
    if (token.includes('spinner') || token.includes('spin')) return 'spinner';
    if (token.includes('th-large')) return 'th';
    if (token.includes('arrows-alt')) return 'move';
    if (token.includes('folder-open')) return 'folder';
    if (token.includes('power-off')) return 'power';
    if (token.includes('info-circle')) return 'info';
    if (token.includes('share-alt')) return 'share';
    if (token.includes('stop-circle')) return 'stop';
    if (token.includes('sliders-h')) return 'sliders';
    if (token.includes('pi pi-')) return token.replace('pi pi-', '').split(/\s+/)[0] || 'box';
    return token || 'box';
};

export const WorkflowLucideIcon: React.FC<WorkflowLucideIconProps> = ({ icon, className, size = 16 }) => {
    const IconComponent = ICONS[resolveIconKey(icon)] || Box;
    return <IconComponent className={className} size={size} strokeWidth={2} aria-hidden="true" />;
};
