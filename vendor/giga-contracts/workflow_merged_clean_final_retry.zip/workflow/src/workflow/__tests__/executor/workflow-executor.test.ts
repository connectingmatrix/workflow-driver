import { beforeEach, describe, expect, it } from 'vitest';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import { WorkflowAuthModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: WorkflowAuthModeEnum.None,
    manualHeaders: {}
};

describe('executeWorkflow', () => {
    beforeEach(() => {
        delete (globalThis as Record<string, unknown>).__workflowRetryAttempt;
    });

    it('logs validation failure when start node is missing', async () => {
        const workflow = createEmptyWorkflow('wf_missing_start');
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 1);
        workflow.nodes = [endNode];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });

        expect(result.stopped).toBe(false);
        expect(result.workflow.nodes).toHaveLength(1);
        expect(result.events.some((entry) => entry.event === 'workflow.validation_failed')).toBe(true);
    });

    it('logs validation failure when respond/end node is missing', async () => {
        const workflow = createEmptyWorkflow('wf_missing_end');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        workflow.nodes = [startNode];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });

        expect(result.stopped).toBe(false);
        expect(result.events.some((entry) => entry.event === 'workflow.validation_failed')).toBe(true);
    });

    it('routes to true branch and keeps respond/end output as terminal payload', async () => {
        const workflow = createEmptyWorkflow('wf_if_else_true');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const ifElseNode = createWorkflowNode(workflow, 'if-else', 'If Else', 2);
        const trueNode = createWorkflowNode(workflow, 'metadata', 'True Branch', 3);
        const falseNode = createWorkflowNode(workflow, 'metadata', 'False Branch', 4);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 5);

        ifElseNode.runtime = {
            ...(ifElseNode.runtime ?? {}),
            value: { route: true },
            leftPath: 'route',
            operator: 'truthy'
        };
        endNode.runtime = {
            ...(endNode.runtime ?? {}),
            response: `{{${trueNode.id}}}`
        };

        workflow.nodes = [startNode, ifElseNode, trueNode, falseNode, endNode];
        workflow.connections = [
            createConnection('c1', startNode.id, ifElseNode.id, 'out:output', 'in:input'),
            createConnection('c2', ifElseNode.id, trueNode.id, 'out:true', 'in:input'),
            createConnection('c3', ifElseNode.id, falseNode.id, 'out:false', 'in:input'),
            createConnection('c4', trueNode.id, endNode.id, 'out:output', 'in:input')
        ];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });

        const ifNodeAfter = result.workflow.nodes.find((node) => node.id === ifElseNode.id);
        const trueNodeAfter = result.workflow.nodes.find((node) => node.id === trueNode.id);
        const falseNodeAfter = result.workflow.nodes.find((node) => node.id === falseNode.id);
        const endNodeAfter = result.workflow.nodes.find((node) => node.id === endNode.id);

        expect(ifNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((ifNodeAfter?.ports.out.output as { selectedBranch?: string })?.selectedBranch).toBe('true');
        expect((ifNodeAfter?.ports.out.output as { trueBranch?: { active?: boolean } })?.trueBranch?.active).toBe(true);
        expect((ifNodeAfter?.ports.out.output as { falseBranch?: { active?: boolean } })?.falseBranch?.active).toBe(false);
        expect(trueNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(falseNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect(endNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(endNodeAfter?.ports.out.output).toEqual(trueNodeAfter?.ports.out.output);
        expect((endNodeAfter?.ports.out.output as { __workflow?: unknown }).__workflow).toBeUndefined();
    }, 15000);

    it('retries failed node execution based on failure mitigation settings', async () => {
        const workflow = createEmptyWorkflow('wf_retry_node');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        codeNode.runtime = {
            ...(codeNode.runtime ?? {}),
            code: `
const attemptKey = '__workflowRetryAttempt';
globalThis[attemptKey] = Number(globalThis[attemptKey] ?? 0) + 1;
console.log('attempt', globalThis[attemptKey]);
if (globalThis[attemptKey] < 2) {
    throw new Error('boom');
}
return { recovered: true, attempts: globalThis[attemptKey] };
`,
            failureMitigation: 'retry-node',
            retryCount: '2'
        };

        workflow.nodes = [startNode, codeNode, endNode];
        workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });

        const codeNodeAfter = result.workflow.nodes.find((node) => node.id === codeNode.id);
        expect(codeNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(codeNodeAfter?.ports.out.output).toEqual({ recovered: true, attempts: 2 });
        expect(result.events.some((event) => event.event === 'node.log' && String(event.message ?? '').includes('Retrying'))).toBe(true);
    });

    it('does not retry when failure mitigation is stop workflow', async () => {
        const workflow = createEmptyWorkflow('wf_stop_on_failure');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        codeNode.runtime = {
            ...(codeNode.runtime ?? {}),
            code: 'throw new Error("hard failure");',
            failureMitigation: 'stop-workflow',
            retryCount: '6'
        };

        workflow.nodes = [startNode, codeNode, endNode];
        workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });

        const codeNodeAfter = result.workflow.nodes.find((node) => node.id === codeNode.id);
        expect(codeNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
    });

    it('fails validation before execution and does not call node handler', async () => {
        const workflow = createEmptyWorkflow('wf_validation_before_execute');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        codeNode.id = '';

        codeNode.runtime = {
            ...(codeNode.runtime ?? {}),
            failureMitigation: 'retry-node',
            retryCount: '99'
        };

        workflow.nodes = [startNode, codeNode, endNode];
        workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];

        const result = await workflowExecutor.executeWorkflow(workflow, { settings });
        const codeNodeAfter = result.workflow.nodes.find((node) => node.modelId === codeNode.modelId);

        expect(codeNodeAfter?.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.events.some((event) => event.event === 'node.failed' && event.nodeId === codeNode.id)).toBe(true);
    });
});
