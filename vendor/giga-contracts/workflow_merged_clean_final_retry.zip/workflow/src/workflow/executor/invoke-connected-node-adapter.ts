import type { WorkflowNodeHandlerContext } from '@workflow/executor';

interface WorkflowInvokeConnectedNodeRequestInput {
    context?: unknown;
    args?: unknown;
    payload?: unknown;
}

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const normalizeRequest = (request: unknown): { context: WorkflowNodeHandlerContext; payload: unknown } => {
    const requestRecord = toRecord(request) as WorkflowInvokeConnectedNodeRequestInput;
    const context = toRecord(requestRecord.context) as unknown as WorkflowNodeHandlerContext;
    if (!context || typeof context !== 'object' || typeof context.invokeConnectedNode !== 'function') {
        throw new Error('invokeConnectedNode request is missing workflow node context.');
    }
    const args = Array.isArray(requestRecord.args) ? requestRecord.args : [];
    return {
        context,
        payload: requestRecord.payload ?? args[0] ?? null
    };
};

export const invokeNodeWorkerConnection = async (request: unknown): Promise<unknown> => {
    const normalized = normalizeRequest(request);
    return normalized.context.invokeConnectedNode?.(normalized.payload as Parameters<NonNullable<WorkflowNodeHandlerContext['invokeConnectedNode']>>[0]);
};
