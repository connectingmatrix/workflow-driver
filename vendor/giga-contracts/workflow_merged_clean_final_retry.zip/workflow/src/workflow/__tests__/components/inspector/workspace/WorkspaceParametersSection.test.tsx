// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { WorkspaceParametersSection } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceParametersSection';
import type { WorkspaceFieldModel, WorkspaceParameterSectionModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';

vi.mock('@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceFieldHost', () => ({
    WorkspaceFieldHost: ({ field }: { field: WorkspaceFieldModel }) => <div data-testid={`workspace-field-${field.key}`}>{field.key}</div>
}));

const buildField = (key: string): WorkspaceFieldModel => ({
    id: key,
    key,
    value: '',
    definition: {
        type: WorkflowNodeFieldTypeEnum.String,
        editable: true
    }
});

const renderSection = (section: WorkspaceParameterSectionModel) =>
    render(
        <WorkspaceParametersSection
            section={section}
            allFields={section.fields}
            propertiesEditorState={{}}
            onFieldChange={vi.fn()}
        />
    );

afterEach(() => {
    cleanup();
});

describe('WorkspaceParametersSection', () => {
    it('stretches single-card sections to a single full-width column', () => {
        renderSection({
            id: 'execution',
            title: 'Execution',
            variant: 'execution-grid',
            fields: [buildField('failureMitigation')]
        });

        const field = screen.getByTestId('workspace-field-failureMitigation');
        expect(field.parentElement).toHaveClass('cnw-fields-grid--single');
        expect(field.parentElement).toHaveClass('cnw-fields-grid--execution');
    });

    it('keeps multi-card execution sections in the shared two-column grid', () => {
        renderSection({
            id: 'execution',
            title: 'Execution',
            variant: 'execution-grid',
            fields: [buildField('failureMitigation'), buildField('forwardSessionLogs')]
        });

        const field = screen.getByTestId('workspace-field-failureMitigation');
        expect(field.parentElement).toHaveClass('cnw-fields-grid--execution');
        expect(field.parentElement).not.toHaveClass('cnw-fields-grid--single');
    });
});
