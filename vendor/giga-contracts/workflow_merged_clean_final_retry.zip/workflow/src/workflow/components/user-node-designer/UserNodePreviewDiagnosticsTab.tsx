import React from 'react';
import { UserNodePreviewState } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';

interface UserNodePreviewDiagnosticsTabProps {
    state: UserNodePreviewState;
}

const UserNodePreviewDiagnosticsTab: React.FC<UserNodePreviewDiagnosticsTabProps> = ({ state }) => {
    const diagnostics = {
        runtimeError: state.runtimeError,
        diagnostics: state.diagnostics,
        validation: state.validation ?? null
    };

    return (
        <div data-cy="user-node-preview-diagnostics">
            {state.runtimeError ? <div className="text-xs text-red-400 mb-2">{state.runtimeError}</div> : null}
            <pre className="text-xs overflow-auto wf-user-node-preview-scroll">
                {JSON.stringify(diagnostics, null, 2)}
            </pre>
        </div>
    );
};

export default UserNodePreviewDiagnosticsTab;
