import React from 'react';
import { Handle, NodeProps, Position } from '@xyflow/react';

export interface SubworkflowCollapsedNodeData {
    title: string;
    onExpand?: () => void;
}

const SubworkflowCollapsedNodeComponent: React.FC<NodeProps> = ({ data, selected }) => {
    const nodeData = data as unknown as SubworkflowCollapsedNodeData;
    return (
        <div className={`wf-subworkflow wf-subworkflow--collapsed ${selected ? 'wf-subworkflow--selected' : ''}`}>
            <Handle id="in:input" type="target" position={Position.Left} isConnectable={false} className="base-node__handle base-node__handle--left" />
            <Handle id="out:output" type="source" position={Position.Right} isConnectable={false} className="base-node__handle base-node__handle--right" />
            <div className="wf-subworkflow__title">{nodeData.title}</div>
            <button
                type="button"
                className="wf-subworkflow__action-btn"
                onClick={(event) => {
                    event.stopPropagation();
                    nodeData.onExpand?.();
                }}
            >
                Expand
            </button>
        </div>
    );
};

const areSubworkflowCollapsedNodePropsEqual = (previous: NodeProps, next: NodeProps): boolean => {
    const previousData = previous.data as unknown as SubworkflowCollapsedNodeData;
    const nextData = next.data as unknown as SubworkflowCollapsedNodeData;
    return previous.selected === next.selected && previousData.title === nextData.title;
};

const SubworkflowCollapsedNode = React.memo(SubworkflowCollapsedNodeComponent, areSubworkflowCollapsedNodePropsEqual);

export default SubworkflowCollapsedNode;
