import primeThemeCss from 'primereact/resources/themes/lara-light-blue/theme.css?inline';
import primeReactCss from 'primereact/resources/primereact.min.css?inline';
import primeIconsCss from 'primeicons/primeicons.css?inline';

const PRIME_STYLE_ATTRIBUTE = 'data-wf-prime-style';
const PRIME_THEME_KEY = 'theme';
const PRIME_REACT_KEY = 'core';
const PRIME_ICONS_KEY = 'icons';

let activeStyleConsumers = 0;

const ensureStyleTag = (key: string, cssText: string): HTMLStyleElement => {
    const existing = document.querySelector<HTMLStyleElement>(`style[${PRIME_STYLE_ATTRIBUTE}="${key}"]`);
    if (existing) {
        return existing;
    }
    const styleTag = document.createElement('style');
    styleTag.setAttribute(PRIME_STYLE_ATTRIBUTE, key);
    styleTag.textContent = cssText;
    document.head.appendChild(styleTag);
    return styleTag;
};

const removeStyleTag = (key: string): void => {
    document.querySelector<HTMLStyleElement>(`style[${PRIME_STYLE_ATTRIBUTE}="${key}"]`)?.remove();
};

export const mountWorkflowPrimeStyles = (): void => {
    if (typeof document === 'undefined') {
        return;
    }
    if (activeStyleConsumers === 0) {
        ensureStyleTag(PRIME_THEME_KEY, primeThemeCss);
        ensureStyleTag(PRIME_REACT_KEY, primeReactCss);
        ensureStyleTag(PRIME_ICONS_KEY, primeIconsCss);
    }
    activeStyleConsumers += 1;
};

export const unmountWorkflowPrimeStyles = (): void => {
    if (typeof document === 'undefined' || activeStyleConsumers === 0) {
        return;
    }
    activeStyleConsumers -= 1;
    if (activeStyleConsumers > 0) {
        return;
    }
    removeStyleTag(PRIME_THEME_KEY);
    removeStyleTag(PRIME_REACT_KEY);
    removeStyleTag(PRIME_ICONS_KEY);
};
