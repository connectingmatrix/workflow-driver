import type { CSSProperties, ReactNode } from 'react';
import type { WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowCredentialOption, WorkflowExecutableOption, WorkflowNodeDocumentation, WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';

export type WorkspaceIconName =
    | 'bolt'
    | 'braces'
    | 'desktop'
    | 'download'
    | 'database'
    | 'document'
    | 'ellipsis'
    | 'eye'
    | 'folder'
    | 'inspect'
    | 'info'
    | 'json'
    | 'node'
    | 'save'
    | 'send'
    | 'server'
    | 'settings'
    | 'share'
    | 'play'
    | 'spinner'
    | 'refresh'
    | 'sitemap'
    | 'sparkles'
    | 'stop'
    | 'trash'
    | 'upload'
    | 'terminal'
    | 'x';

export type WorkspaceActionTone = 'primary' | 'secondary' | 'ghost' | 'icon' | 'danger';
export type WorkspaceStatusTone = 'default' | 'success' | 'info' | 'warning' | 'danger';

export interface WorkspaceSegmentedTabItem {
    id: string;
    label: string;
    badge?: string | number;
    disabled?: boolean;
}

export interface WorkspaceAction {
    id: string;
    label: string;
    icon?: WorkspaceIconName;
    tone?: WorkspaceActionTone;
    visible?: boolean;
    disabled?: boolean;
    busy?: boolean;
    iconOnly?: boolean;
}

export interface WorkspaceHeaderModel {
    breadcrumb?: string;
    title: string;
    subtitle?: string;
    iconClass?: string;
    iconColor?: string;
    iconSvg?: string;
    previewAction?: WorkspaceAction;
    primaryAction?: WorkspaceAction;
    utilityActions?: WorkspaceAction[];
}

export interface WorkspaceFeatureItem {
    id: string;
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
}

export interface WorkspacePanelEmptyState {
    icon?: WorkspaceIconName;
    title: string;
    description?: string;
    action?: WorkspaceAction;
}

export interface WorkspaceInputTableRow {
    key: string;
    value: string;
}

export interface WorkspaceInputPanelModel {
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
    tabs: WorkspaceSegmentedTabItem[];
    activeTab: string;
    emptyState: WorkspacePanelEmptyState;
    acceptedFormats?: string[];
    featureItems?: WorkspaceFeatureItem[];
    tableRows: WorkspaceInputTableRow[];
    jsonValue: Record<string, unknown>;
    documentation?: WorkflowNodeDocumentation;
    nodeTypeLabel: string;
    controlNodes?: Record<string, unknown> | null;
}

export interface WorkspaceHeroCard {
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
    chip?: string;
}

export interface WorkspaceHintItem {
    id: string;
    title: string;
    description?: string;
}

export interface WorkspaceFieldModel {
    id: string;
    key: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    presentation?: WorkspaceFieldPresentation;
    badge?: string;
    helperText?: string;
}

export type WorkspaceFieldPresentation = 'default' | 'execution-select' | 'execution-toggle';
export type WorkspaceParameterSectionVariant = 'default' | 'execution-grid';

export interface WorkspaceParameterSectionModel {
    id: string;
    title: string;
    description?: string;
    fields: WorkspaceFieldModel[];
    variant?: WorkspaceParameterSectionVariant;
}

export interface WorkspaceInstructionPanelModel {
    tabs: WorkspaceSegmentedTabItem[];
    activeTab: string;
}

export type WorkspaceAsyncSelectorState = 'loading' | 'ready' | 'empty' | 'error';
export type WorkspaceCredentialSelectorState = WorkspaceAsyncSelectorState;

export interface WorkspaceCredentialSelectorModel {
    title: string;
    description?: string;
    serviceId: string;
    selectedCredentialId: string | null;
    options: WorkflowCredentialOption[];
    state: WorkspaceCredentialSelectorState;
    message?: string;
}

export interface WorkspaceWorkflowSelectorModel {
    title: string;
    description?: string;
    selectedWorkflowId: string | null;
    options: WorkflowExecutableOption[];
    state: WorkspaceAsyncSelectorState;
    message?: string;
}

export interface WorkspaceParametersPanelModel {
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
    tabs: WorkspaceSegmentedTabItem[];
    activeTab: string;
    headerAction?: WorkspaceAction;
    heroCard?: WorkspaceHeroCard;
    credentialSelector?: WorkspaceCredentialSelectorModel;
    workflowSelector?: WorkspaceWorkflowSelectorModel;
    sections: WorkspaceParameterSectionModel[];
    hints?: WorkspaceHintItem[];
    footerAction?: WorkspaceAction;
    instructionPanel?: WorkspaceInstructionPanelModel;
}

export interface WorkspaceOutputStatus {
    label: string;
    tone?: WorkspaceStatusTone;
    meta?: string;
}

export interface WorkspaceOutputSummary {
    title: string;
    description?: string;
    tip?: string;
}

export interface WorkspaceOutputActivityItem {
    id: string;
    title: string;
    description?: string;
    tone?: WorkspaceStatusTone;
}

export interface WorkspaceOutputEditorConfig {
    height?: number | string;
    theme?: 'light' | 'vs-dark';
    language?: string;
    options?: Record<string, unknown>;
}

export interface WorkspaceOutputPanelModel {
    title: string;
    description?: string;
    icon?: WorkspaceIconName;
    tabs: WorkspaceSegmentedTabItem[];
    activeTab: string;
    copyAction?: WorkspaceAction;
    status?: WorkspaceOutputStatus;
    summary?: WorkspaceOutputSummary;
    activities?: WorkspaceOutputActivityItem[];
    editor?: WorkspaceOutputEditorConfig;
    activeViewer: WorkflowInspectorViewer | null;
    renderedMarkdown: string;
}

export interface WorkspaceInspectorModel {
    header: WorkspaceHeaderModel;
    input: WorkspaceInputPanelModel;
    parameters: WorkspaceParametersPanelModel;
    output: WorkspaceOutputPanelModel;
}

export interface WorkspaceInspectorFlags {
    showHeader: boolean;
    showAcceptedFormats: boolean;
    showInputFeatures: boolean;
    showParametersHero: boolean;
    showBestPracticeHints: boolean;
    showOutputSummary: boolean;
    showRecentActivity: boolean;
    showFooterAction: boolean;
}

export interface WorkspaceInspectorTheme {
    accent: string;
    accentSoft: string;
    accentStrong: string;
    surface: string;
    surfaceAlt: string;
    border: string;
    text: string;
    muted: string;
    success: string;
    warning: string;
    danger: string;
    shadow: string;
    shellBackground: string;
}

export interface WorkspaceInspectorActionContext {
    focusPanel: (panelId: 'input' | 'parameters' | 'output') => void;
    focusParametersTab: (tabId: string) => void;
    copyOutput: () => void;
    refreshView: () => void;
    runNode: () => void;
    saveChanges: () => void;
    closeInspector: () => void;
}

export interface WorkspaceInspectorProps {
    model: WorkspaceInspectorModel;
    flags: WorkspaceInspectorFlags;
    theme: WorkspaceInspectorTheme;
    className?: string;
    style?: CSSProperties;
    onInputTabChange: (tabId: string) => void;
    onParametersTabChange: (tabId: string) => void;
    onInstructionTabChange: (tabId: string) => void;
    onOutputTabChange: (tabId: string) => void;
    onFieldChange: (fieldKey: string, value: unknown) => void;
    onCodeChange: (nextCode: string) => void;
    onMarkdownChange: (nextMarkdown: string) => void;
    onAction: (actionId: string) => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: Array<{ path: string; token: string; label: string; preview?: string }>;
    code: string;
    markdown: string;
    inspectorColumns?: number;
    isExecuting: boolean;
    renderOutputContent: () => ReactNode;
}
