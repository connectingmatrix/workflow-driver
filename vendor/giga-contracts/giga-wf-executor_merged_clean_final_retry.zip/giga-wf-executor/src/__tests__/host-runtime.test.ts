import { describe, expect, it } from 'vitest';
import { createNodeExecutorSignature } from '../executor/worker-runtime';
import { createBrowserWorkerNodeHandler } from '../executor/browser/browser-runtime';
import { createNodeWorkerNodeHandler } from '../executor/node/node-runtime';
import { WorkflowDefinition, WorkflowNodeHandlerContext, WorkflowNodeStatusEnum } from '../types';

const textEncoder = new TextEncoder();

const toBase64 = (source: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(source, 'utf8').toString('base64');
    }

    const bytes = textEncoder.encode(source);
    let binary = '';
    bytes.forEach((byte) => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
};

const createWorkflow = (modelId: string, source: string): WorkflowDefinition => ({
    metadata: {
        id: 'wf_runtime_hosts',
        name: 'Runtime Hosts Test'
    },
    nodes: [
        {
            id: 'node_1',
            gigaId: 'node_1',
            modelId,
            type: 'workflowStep',
            name: 'Node 1',
            description: '',
            kind: 'process',
            status: WorkflowNodeStatusEnum.Stopped,
            position: { x: 0, y: 0 },
            runtime: {
                marker: 'host-runtime'
            },
            ports: {
                in: {},
                out: {}
            }
        }
    ],
    connections: [],
    NODE_EXECUTORS: {
        [modelId]: toBase64(source)
    },
    NODE_EXECUTOR_SIGNATURES: {
        [modelId]: createNodeExecutorSignature(modelId, source)
    }
});

const createContext = (workflow: WorkflowDefinition): WorkflowNodeHandlerContext => ({
    node: workflow.nodes[0],
    workflow,
    settings: {
        graphqlUrl: 'http://localhost/graphql',
        authMode: 'none'
    },
    input: {}
});

const workerSource = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({
  output: {
    environment: payload.ENVIRONMENT,
    marker: payload.NODE?.PROPERTIES?.marker ?? null
  },
  status: 'passed',
  logs: ['host-runtime-ok']
});`;

describe('host runtime handlers', () => {
    it('creates a browser worker handler path', async () => {
        const workflow = createWorkflow('browser-runtime-model', workerSource);
        const result = await createBrowserWorkerNodeHandler({ modelId: 'browser-runtime-model' })(createContext(workflow));

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).environment).toBe('browser');
        expect((result.output as Record<string, unknown>).marker).toBe('host-runtime');
    }, 15000);

    it('creates a node worker handler path', async () => {
        const workflow = createWorkflow('node-runtime-model', workerSource);
        const result = await createNodeWorkerNodeHandler({ modelId: 'node-runtime-model' })(createContext(workflow));

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).environment).toBe('node');
        expect((result.output as Record<string, unknown>).marker).toBe('host-runtime');
    }, 15000);
});
