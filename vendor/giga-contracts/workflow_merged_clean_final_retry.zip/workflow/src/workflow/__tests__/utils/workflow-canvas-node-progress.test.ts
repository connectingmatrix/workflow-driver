import { describe, expect, it } from 'vitest';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { buildCanvasNodes } from '@workflow/ui/workflow/utils/workflow-canvas-node.utils';
import { WorkflowPlayModeEnum } from '@workflow/ui/workflow/types';

describe('workflow canvas node progress indicators', () => {
    it('marks active local run node with local progress indicator', () => {
        const workflow = createEmptyWorkflow('wf_canvas_progress_local');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];

        const nodes = buildCanvasNodes(
            workflow,
            workflow.nodes.map((node) => node.id),
            1,
            true,
            WorkflowPlayModeEnum.Local
        );
        const codeNode = nodes.find((node) => node.id === code.id);
        const startNode = nodes.find((node) => node.id === start.id);

        expect(codeNode?.data.progressIndicatorMode).toBe('local');
        expect(startNode?.data.progressIndicatorMode).toBeNull();
    });

    it('marks active server run node with server progress indicator', () => {
        const workflow = createEmptyWorkflow('wf_canvas_progress_server');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];

        const nodes = buildCanvasNodes(
            workflow,
            workflow.nodes.map((node) => node.id),
            2,
            true,
            WorkflowPlayModeEnum.Server
        );
        const endNode = nodes.find((node) => node.id === end.id);
        const codeNode = nodes.find((node) => node.id === code.id);

        expect(endNode?.data.progressIndicatorMode).toBe('server');
        expect(codeNode?.data.progressIndicatorMode).toBeNull();
    });

    it('resolves active progress indicator from execution order ids instead of canvas index order', () => {
        const workflow = createEmptyWorkflow('wf_canvas_progress_order');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];

        const orderedIds = [start.id, end.id, code.id];
        const nodes = buildCanvasNodes(workflow, orderedIds, 2, true, WorkflowPlayModeEnum.Local);
        const codeNode = nodes.find((node) => node.id === code.id);
        const endNode = nodes.find((node) => node.id === end.id);

        expect(codeNode?.data.progressIndicatorMode).toBe('local');
        expect(endNode?.data.progressIndicatorMode).toBeNull();
    });
});
