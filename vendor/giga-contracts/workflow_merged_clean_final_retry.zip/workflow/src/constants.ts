export type WorkflowNodeLibraryCategory = 'all' | 'flow' | 'logic' | 'mcp' | 'data' | 'other';

export const WORKSPACE_NODE_LIBRARY_CATEGORY_ORDER: WorkflowNodeLibraryCategory[] = ['all', 'flow', 'logic', 'mcp', 'data', 'other'];
export const WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER = ['Flow Nodes', 'Output Nodes', 'Giga Data Nodes', 'Giga AI Nodes', 'MCP Group', 'User Nodes'] as const;
export const WORKFLOW_CANVAS_SEARCH_FOCUS_ZOOM = 1.08;
