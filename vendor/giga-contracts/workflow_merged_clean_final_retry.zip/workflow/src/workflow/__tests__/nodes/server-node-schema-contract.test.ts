import { describe, expect, it } from 'vitest';
import { getAllNodeSchemas } from '@workflow/nodes/node-utils';

const EXPECTED_FIELDS_BY_MODEL: Record<string, string[]> = {
    'ai-agent': ['selectionPromptMd', 'executionMode', 'confirmationPolicy', 'modelActionPolicy', 'workflowToolAllowlist', 'description'],
    'current-chat': ['mode', 'pendingAction', 'limit', 'offset', 'description'],
    'text-analysis': ['analysisKinds', 'description'],
    'action-router': ['toolName', 'toolDescription', 'broadcastModelId', 'allowedActions', 'strictConnectionCheck', 'description'],
    'chat-plan-policy': ['confirmationPolicy', 'mutatingActions', 'workflowOutputActions', 'validationPolicy', 'emptyPlanBehavior', 'confirmedWithoutPendingBehavior', 'description'],
    'validate-workflow-cypher': ['cypherSource', 'cypher', 'workflowTitle', 'emptySourceBehavior', 'executable', 'description'],
    'workflow': ['operation', 'saveMode', 'definitionSource', 'publishAfterSave', 'workflowIdSource', 'scope', 'organizationId', 'workflowId', 'workflowName', 'workflowDescription', 'workflowPrompt', 'cypher', 'executable', 'description'],
    'execute-workflow': ['executionSource', 'workflowId', 'parameters', 'description'],
    'serp-search': ['query', 'max_results', 'location', 'language', 'description'],
    'run-channel-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'run-category-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'run-subject-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'run-post-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'run-user-tree-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'run-chat-action': ['action', 'reason', 'chatId', 'message', 'topK', 'subjectIds', 'postIds', 'tagSlugs', 'parameters', 'description'],
    'mcp-runtime': [
        'capabilityQuery',
        'outputContract',
        'forwardNonMcpWork',
        'loopNonMcpWork',
        'maxLoopPasses',
        'description'
    ],
    'mcp-capabilities': [
        'description'
    ]
};
const LOCAL_DOC_NODES = new Set(['ai-agent', 'text-analysis', 'action-router', 'chat-plan-policy', 'validate-workflow-cypher', 'workflow', 'execute-workflow']);

describe('server node schema contracts', () => {
    it('exposes explicit parameter fields, keeps instruction tabs disabled, and includes documentation metadata', () => {
        const schemas = getAllNodeSchemas();

        Object.entries(EXPECTED_FIELDS_BY_MODEL).forEach(([modelId, expectedFields]) => {
            const schema = schemas[modelId];
            expect(schema).toBeTruthy();

            const fieldKeys = Object.keys(schema.fields ?? {});
            expect(fieldKeys).toEqual(expect.arrayContaining(expectedFields));
            expect(fieldKeys).not.toContain('payload');

            expect(schema.instruction?.code).toBe(false);
            expect(schema.instruction?.markdown).toBe(false);

            expect(schema.documentation?.summary).toBeTruthy();
            expect(schema.documentation?.usage).toBeTruthy();
            expect(schema.documentation?.inputs?.length).toBeGreaterThan(0);
            expect(schema.documentation?.outputs?.length).toBeGreaterThan(0);
            if (LOCAL_DOC_NODES.has(modelId)) expect(schema.documentation?.backend).toBeUndefined();
            else expect(schema.documentation?.backend?.handler).toBeTruthy();

            if (modelId === 'ai-agent') {
                expect(schema.commands?.workflow?.acceptedSourceModelIds).toEqual(['workflow', 'execute-workflow']);
                expect(schema.commands?.workflow?.portType).toBe('bi-directional');
            }
            if (modelId !== 'mcp-capabilities' && modelId !== 'mcp-runtime') return;
            expect(schema.useCredentials).toBe('mcp');
            expect(Object.keys(schema.fields ?? {})).not.toEqual(expect.arrayContaining(['serverKey', 'serverUrl', 'transport', 'stdioCommand', 'includeServerMetadata']));
            expect(schema.documentation?.failureCases?.join(' ')).not.toContain('stdio');
        });
    });
});
