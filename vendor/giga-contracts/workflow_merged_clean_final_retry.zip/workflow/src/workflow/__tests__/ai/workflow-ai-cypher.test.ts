import { describe, expect, it } from 'vitest';
import { getNodeLibraryItems } from '@workflow/nodes/node-utils';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WORKFLOW_AI_KNOWLEDGE } from '@workflow/ui/workflow/ai/knowledge';
import { workflowAsCypher } from '@workflow/ui/workflow/ai/cypher-export';
import { workflowFromCypher } from '@workflow/ui/workflow/ai/cypher-workflow';

describe('workflow-ai cypher', () => {
    it('builds the Iran-news knowledge workflow from compact cypher', async () => {
        const workflow = createEmptyWorkflow('wf_ai_cypher_iran');
        const knowledge = WORKFLOW_AI_KNOWLEDGE[0];
        const result = await workflowFromCypher({
            cypher: knowledge.solutionCypher,
            baseWorkflow: workflow,
            nodeLibraryItems: getNodeLibraryItems()
        });

        expect(result.workflow.nodes.some((node) => node.modelId === 'ai-governor')).toBe(true);
        expect(result.workflow.nodes.some((node) => node.name === 'CSV Markdown Table')).toBe(true);
        expect(result.workflow.connections.some((edge) => edge.sourceHandle === 'cmd:command' && edge.targetHandle === 'cmd:tools')).toBe(true);
        expect(result.workflow.connections.some((edge) => edge.targetHandle === 'cmd:llm')).toBe(true);
    });

    it('rejects incompatible cypher connections', async () => {
        const workflow = createEmptyWorkflow('wf_ai_cypher_invalid');
        const cypher = [
            '(start:start {"name":"Start","runtime":{}})',
            '(governor:ai-governor {"name":"Governor","runtime":{"selectionPromptMd":"Plan"}})',
            '(code:code {"name":"Code","runtime":{"code":"return {};"} })',
            '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(governor)',
            '(code)-[:CONNECT {"source":"out:output","target":"cmd:llm"}]->(governor)'
        ].join('\n');

        await expect(() =>
            workflowFromCypher({
                cypher,
                baseWorkflow: workflow,
                nodeLibraryItems: getNodeLibraryItems()
            })
        ).rejects.toThrow(/Invalid workflow cypher connection/);
    });

    it('exports compact cypher without execution artifacts', async () => {
        const workflow = (
            await workflowFromCypher({
            cypher: WORKFLOW_AI_KNOWLEDGE[0].solutionCypher,
            baseWorkflow: createEmptyWorkflow('wf_ai_cypher_export'),
            nodeLibraryItems: getNodeLibraryItems()
            })
        ).workflow;
        workflow.nodes[0].ports.out.output = { stale: true };
        workflow.NODE_EXECUTORS = { code: 'executor' };

        const cypher = workflowAsCypher(workflow);

        expect(cypher).toContain('CONNECT');
        expect(cypher).not.toContain('NODE_EXECUTORS');
        expect(cypher).not.toContain('stale');
    });

    it('arranges split and merge cypher into a branched graph', async () => {
        const workflow = createEmptyWorkflow('wf_ai_cypher_branch');
        const cypher = [
            '(start:start {"name":"Start","runtime":{}})',
            '(branch:if-else {"name":"Branch","runtime":{"leftPath":"ok","operator":"truthy"}})',
            '(left:code {"name":"Left","runtime":{"code":"return input;"}})',
            '(right:code {"name":"Right","runtime":{"code":"return input;"}})',
            '(merge:merge {"name":"Merge","runtime":{}})',
            '(end:respond-end {"name":"End","runtime":{}})',
            '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(branch)',
            '(branch)-[:CONNECT {"source":"out:true","target":"in:input"}]->(left)',
            '(branch)-[:CONNECT {"source":"out:false","target":"in:input"}]->(right)',
            '(left)-[:CONNECT {"source":"out:output","target":"in:input1"}]->(merge)',
            '(right)-[:CONNECT {"source":"out:output","target":"in:input2"}]->(merge)',
            '(merge)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)'
        ].join('\n');
        const result = await workflowFromCypher({ cypher, baseWorkflow: workflow, nodeLibraryItems: getNodeLibraryItems() });
        const left = result.workflow.nodes.find((node) => node.name === 'Left');
        const right = result.workflow.nodes.find((node) => node.name === 'Right');
        const merge = result.workflow.nodes.find((node) => node.name === 'Merge');

        expect(left?.position.y).toBe(right?.position.y);
        expect(left?.position.x).not.toBe(right?.position.x);
        expect((merge?.position.y || 0) > (left?.position.y || 0)).toBe(true);
    });
});
