import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';

const WORKFLOW_ROOT = '/Users/abeer/dev/giga/workflow';
const BACKEND_ENV_PATH = '/Users/abeer/dev/giga/giga-ai-backend/.env';
const DEFAULT_REFERENCE_PATH = '/Users/abeer/Downloads/redesigned_code_node_ui.png';
const SCREENSHOT_ROOT = path.join(WORKFLOW_ROOT, 'playground/cypress/screenshots');
const REPORT_DIR = path.join(WORKFLOW_ROOT, 'playground/cypress/reports');
const API_URL = 'https://api.openai.com/v1/responses';
const MODEL = process.env.OPENAI_VISUAL_REVIEW_MODEL || 'gpt-4.1-mini';
const MAX_IMAGE_WIDTH = Number(process.env.OPENAI_VISUAL_REVIEW_MAX_WIDTH || 1400);

const parseEnvFile = (filePath) => {
    if (!fs.existsSync(filePath)) {
        return {};
    }
    return Object.fromEntries(
        fs
            .readFileSync(filePath, 'utf8')
            .split(/\r?\n/)
            .map((line) => line.trim())
            .filter((line) => line && !line.startsWith('#') && line.includes('='))
            .map((line) => {
                const idx = line.indexOf('=');
                const key = line.slice(0, idx).trim();
                const value = line.slice(idx + 1).trim().replace(/^['\"]|['\"]$/g, '');
                return [key, value];
            })
    );
};

const toDataUrl = (filePath) => {
    const extension = path.extname(filePath).toLowerCase();
    const mimeType = extension === '.jpg' || extension === '.jpeg' ? 'image/jpeg' : 'image/png';
    const base64 = fs.readFileSync(filePath).toString('base64');
    return `data:${mimeType};base64,${base64}`;
};

const resizeImageForReview = (sourcePath) => {
    const tempPath = path.join(os.tmpdir(), `workspace-review-${path.basename(sourcePath)}`);
    execFileSync('sips', ['-Z', String(MAX_IMAGE_WIDTH), sourcePath, '--out', tempPath], {
        stdio: 'ignore'
    });
    return tempPath;
};

const collectPngFiles = (rootDir) => {
    if (!fs.existsSync(rootDir)) {
        return [];
    }
    const results = [];
    const visit = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const fullPath = path.join(dir, entry.name);
            if (entry.isDirectory()) {
                visit(fullPath);
                continue;
            }
            if (/\.(png|jpg|jpeg)$/i.test(entry.name)) {
                results.push(fullPath);
            }
        }
    };
    visit(rootDir);
    return results.sort();
};

const buildPrompt = (referencePath, candidatePath, exactMatch) => {
    const mode = exactMatch ? 'strict literal comparison' : 'shared design-system comparison';
    return [
        `You are reviewing workflow inspector UI screenshots in ${mode} mode.`,
        'The first image is the golden reference. The second image is the current implementation screenshot.',
        exactMatch
            ? 'Judge the current implementation against the reference as strictly as possible for layout, spacing, hierarchy, controls, scroll containment, panel sizing, input-field styling, and overall polish.'
            : 'Judge the current implementation against the same design system and identify where it diverges from the reference language, even if the content differs.',
        'Return compact JSON with keys: screenshot, exactMatch, score, verdict, matches, mismatches, actionItems.',
        `reference: ${referencePath}`,
        `candidate: ${candidatePath}`
    ].join('\n');
};

const extractText = (payload) => {
    if (typeof payload.output_text === 'string' && payload.output_text.trim()) {
        return payload.output_text.trim();
    }

    const texts = [];
    for (const output of payload.output || []) {
        for (const content of output.content || []) {
            if (content.type === 'output_text' && typeof content.text === 'string') {
                texts.push(content.text);
            }
        }
    }
    return texts.join('\n').trim();
};

const main = async () => {
    const env = { ...parseEnvFile(BACKEND_ENV_PATH), ...process.env };
    const apiKey = env.OPENAI_API_KEY;
    if (!apiKey) {
        throw new Error(`OPENAI_API_KEY is missing. Checked ${BACKEND_ENV_PATH} and process env.`);
    }

    const referencePath = process.argv[2] || DEFAULT_REFERENCE_PATH;
    if (!fs.existsSync(referencePath)) {
        throw new Error(`Reference image not found: ${referencePath}`);
    }

    const screenshots = collectPngFiles(SCREENSHOT_ROOT);
    if (screenshots.length === 0) {
        throw new Error(`No screenshots found under ${SCREENSHOT_ROOT}`);
    }

    fs.mkdirSync(REPORT_DIR, { recursive: true });
    const tempFiles = [];
    const resizedReferencePath = resizeImageForReview(referencePath);
    tempFiles.push(resizedReferencePath);
    const referenceDataUrl = toDataUrl(resizedReferencePath);
    const report = [];

    try {
        for (const screenshotPath of screenshots) {
        const exactMatch = /code-node/i.test(path.basename(screenshotPath));
        const resizedScreenshotPath = resizeImageForReview(screenshotPath);
        tempFiles.push(resizedScreenshotPath);
        console.log(`Reviewing ${path.basename(screenshotPath)} (${exactMatch ? 'strict' : 'design-system'})`);
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: MODEL,
                input: [
                    {
                        role: 'user',
                        content: [
                            { type: 'input_text', text: buildPrompt(referencePath, screenshotPath, exactMatch) },
                            { type: 'input_image', image_url: referenceDataUrl },
                            { type: 'input_image', image_url: toDataUrl(resizedScreenshotPath) }
                        ]
                    }
                ]
            })
        });

        if (!response.ok) {
            const text = await response.text();
            throw new Error(`OpenAI visual review failed for ${screenshotPath}: ${response.status} ${text}`);
        }

        const payload = await response.json();
        const text = extractText(payload);
        let parsed;
        try {
            parsed = JSON.parse(text);
        } catch {
            parsed = {
                screenshot: screenshotPath,
                exactMatch,
                raw: text
            };
        }
        report.push(parsed);
    }

        const jsonPath = path.join(REPORT_DIR, 'workspace-visual-review.json');
        const markdownPath = path.join(REPORT_DIR, 'workspace-visual-review.md');
        fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2));
        fs.writeFileSync(
            markdownPath,
            report
                .map((entry) => {
                    const matches = Array.isArray(entry.matches) ? entry.matches.map((item) => `- ${item}`).join('\n') : '- None';
                    const mismatches = Array.isArray(entry.mismatches) ? entry.mismatches.map((item) => `- ${item}`).join('\n') : '- None';
                    const actionItems = Array.isArray(entry.actionItems) ? entry.actionItems.map((item) => `- ${item}`).join('\n') : '- None';
                    return `## ${entry.screenshot || 'screenshot'}\n- Verdict: ${entry.verdict || 'n/a'}\n- Score: ${entry.score || 'n/a'}\n- Exact match: ${String(entry.exactMatch)}\n\n### Matches\n${matches}\n\n### Mismatches\n${mismatches}\n\n### Action Items\n${actionItems}`;
                })
                .join('\n\n')
        );

        console.log(`Wrote visual review report to ${jsonPath}`);
    } finally {
        tempFiles.forEach((filePath) => {
            try {
                if (fs.existsSync(filePath)) {
                    fs.unlinkSync(filePath);
                }
            } catch {
                // Ignore cleanup failures for review temp files.
            }
        });
    }
};

main().catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
});
