import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkspaceHeaderModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WORKSPACE_ACTION_IDS } from '@workflow/ui/workflow/components/inspector/workspace/constants';

const createRefreshAction = () => ({
    id: WORKSPACE_ACTION_IDS.RefreshNode,
    label: 'Refresh',
    icon: 'refresh' as const,
    tone: 'icon' as const,
    iconOnly: true
});

const createCloseAction = () => ({
    id: WORKSPACE_ACTION_IDS.CloseNode,
    label: 'Close',
    icon: 'x' as const,
    tone: 'danger' as const,
    iconOnly: true
});

export const buildWorkspaceHeaderModel = (config: WorkflowInspectorConfig, isExecuting: boolean, readOnly = false, editableTitle = ''): WorkspaceHeaderModel => ({
    title: editableTitle || config.title || config.name,
    subtitle: config.nodeTypeLabel,
    iconClass: config.render?.iconClass,
    iconColor: config.render?.iconColor,
    iconSvg: config.renderIcon ? config.renderIcon(64) : config.render?.iconSvg,
    previewAction: undefined,
    primaryAction: readOnly
        ? undefined
        : {
              id: WORKSPACE_ACTION_IDS.RunNode,
              label: isExecuting ? 'Running...' : 'Run Node',
              icon: 'play',
              tone: 'primary',
              disabled: isExecuting,
              busy: isExecuting
          },
    utilityActions: [
        ...(readOnly ? [] : [createRefreshAction()]),
        createCloseAction()
    ]
});
