import type { WorkflowAuthModeEnum, WorkflowCanvasLayoutEngine, WorkflowCanvasSettings, WorkflowRuntimeSettings, WorkflowCanvasEdgeStyle } from '@workflow/ui/workflow/types';

export interface WorkflowSettingsDialogSavePayload {
    settings: WorkflowRuntimeSettings;
    canvasSettings: WorkflowCanvasSettings;
    workflowName: string;
    workflowDescription: string;
}

export interface SettingsDialogProps {
    visible: boolean;
    readOnly?: boolean;
    settings: WorkflowRuntimeSettings;
    canvasSettings: WorkflowCanvasSettings;
    workflowName: string;
    workflowDescription?: string | null;
    workflowId?: string | null;
    onHide: () => void;
    onSave: (payload: WorkflowSettingsDialogSavePayload) => void;
    onResetLayout?: (canvasSettings: WorkflowCanvasSettings) => void;
}

export interface ManualHeaderRow {
    id: string;
    header: string;
    value: string;
}

export interface WorkflowSettingsFormState {
    workflowNameInput: string;
    workflowDescriptionInput: string;
    graphqlUrl: string;
    httpBaseUrl: string;
    authMode: WorkflowRuntimeSettings['authMode'] | WorkflowAuthModeEnum | string;
    manualHeaderRows: ManualHeaderRow[];
    maxExecutionSeconds: number;
    layoutEngine: WorkflowCanvasLayoutEngine;
    edgeStyle: WorkflowCanvasEdgeStyle;
}
