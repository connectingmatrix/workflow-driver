import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, normalize } from 'node:path';

export type AgentNodePackageFile = {
  path: string;
  content: string;
};

export type AgentNodePackage = {
  manifest: {
    id: string;
    name: string;
    version: string;
    kind: string;
    description: string;
    backendCommands: string[];
    dependencies: Array<{ name: string; version: string; reason: string }>;
  };
  files: AgentNodePackageFile[];
};

const forbidden = [/child_process/, /new\s+Function/, /\beval\s*\(/, /process\.env/, /@supabase/, /neo4j|neogma/i, /\bfs\b/, /\bnet\b|\btls\b/, /npm\s+install|yarn\s+add|pnpm\s+add|bun\s+add/];

export const validateAgentNodePackage = (pkg: AgentNodePackage) => {
  const errors: string[] = [];
  if (!pkg.manifest?.id) errors.push('manifest.id is required.');
  if (!pkg.files.some((file) => file.path === 'manifest.json')) errors.push('manifest.json is required.');
  if (!pkg.files.some((file) => file.path === 'schema.json')) errors.push('schema.json is required.');
  if (!pkg.files.some((file) => file.path.endsWith('node.ts'))) errors.push('node.ts is required.');
  if (!pkg.files.some((file) => file.path.endsWith('worker.ts'))) errors.push('worker.ts is required.');
  if (!pkg.files.some((file) => file.path === 'README.md')) errors.push('README.md is required.');
  for (const file of pkg.files) {
    const path = normalize(file.path);
    if (path.startsWith('..') || path.includes('/../')) errors.push(`Unsafe path: ${file.path}`);
    if (/\.tsx?$/.test(path)) for (const pattern of forbidden) if (pattern.test(file.content)) errors.push(`Forbidden source pattern ${pattern} in ${file.path}`);
  }
  return { ok: errors.length === 0, errors };
};

export const writeAgentNodePackage = async (pkg: AgentNodePackage, targetDir: string) => {
  const validation = validateAgentNodePackage(pkg);
  if (!validation.ok) throw new Error(validation.errors.join('\n'));
  await mkdir(targetDir, { recursive: true });
  for (const file of pkg.files) {
    const target = join(targetDir, file.path);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, file.content, 'utf8');
  }
  const checksums: Record<string, string> = {};
  for (const file of pkg.files) checksums[file.path] = createHash('sha256').update(file.content).digest('hex');
  await writeFile(join(targetDir, 'checksums.json'), JSON.stringify(checksums, null, 2), 'utf8');
  return { targetDir, checksums };
};

export const readAgentNodePackage = async (targetDir: string): Promise<AgentNodePackage> => {
  const manifest = JSON.parse(await readFile(join(targetDir, 'manifest.json'), 'utf8'));
  return { manifest, files: [{ path: 'manifest.json', content: JSON.stringify(manifest) }] };
};
