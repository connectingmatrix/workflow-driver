import React from 'react';
import type { WorkflowNodeLibraryCategory } from '@workflow/ui/constants';
import { getWorkspaceNodeLibraryCount, resolveWorkspaceNodeLibraryCategoryLabel } from '@workflow/ui/workflow/components/node-library/workspace/workspace-node-library.utils';
import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

interface WorkspaceNodeLibraryTabsProps {
    categories: WorkflowNodeLibraryCategory[];
    activeCategory: WorkflowNodeLibraryCategory;
    items: WorkflowNodeLibraryItem[];
    onChange: (category: WorkflowNodeLibraryCategory) => void;
}

export const WorkspaceNodeLibraryTabs: React.FC<WorkspaceNodeLibraryTabsProps> = ({ categories, activeCategory, items, onChange }) => {
    return (
        <div className="wf-workspace-node-library__tabs">
            {categories.map((category) => (
                <button
                    key={category}
                    type="button"
                    className={`wf-workspace-node-library__tab${activeCategory === category ? ' wf-workspace-node-library__tab--active' : ''}`}
                    onClick={() => onChange(category)}
                >
                    {resolveWorkspaceNodeLibraryCategoryLabel(category)}
                    <span>{getWorkspaceNodeLibraryCount(items, category)}</span>
                </button>
            ))}
        </div>
    );
};
