import { getAllNodeSchemas, resolveNodeSchema } from '@workflow/nodes/node-utils';
import type { WorkflowDefinition, WorkflowNodeModel, WorkflowNodePortProperty, WorkflowNodePortSide, WorkflowNodeSchema } from '@workflow/ui/workflow/types';
import { getNormalizedCommandPorts, getSortedCommandPortIds } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';
import { WORKFLOW_LAYOUT_NODE_HEIGHT, WORKFLOW_LAYOUT_NODE_WIDTH } from '@workflow/ui/workflow/layout/layout-constants';

const resolveSide = (side: WorkflowNodePortSide | undefined, fallback: WorkflowNodePortSide): WorkflowNodePortSide => side || fallback;
const resolvePorts = (schema: WorkflowNodeSchema, direction: 'inputs' | 'outputs', fallback: WorkflowNodePortSide): Array<[string, WorkflowNodePortProperty]> => {
    const commands = getNormalizedCommandPorts(schema);
    return Object.entries(schema[direction] || {})
        .filter(([portId, rules]) => rules.portType !== 'bi-directional' && !commands[portId])
        .sort((left, right) => Number(left[1].order || 0) - Number(right[1].order || 0) || left[0].localeCompare(right[0]))
        .map(([portId, rules]) => [portId, { ...rules, side: resolveSide(rules.side, fallback) }]);
};

export const buildElkNode = (workflow: WorkflowDefinition, node: WorkflowNodeModel): { id: string; width: number; height: number; layoutOptions: Record<string, string>; ports: Array<{ id: string; layoutOptions: Record<string, string> }> } => {
    const schemas = workflow.nodeModels || getAllNodeSchemas();
    const schema = resolveNodeSchema(node.modelId, schemas);
    const { width, height } = resolveElkNodeSize(schema);
    const normalizedCommandPorts = getNormalizedCommandPorts(schema);
    const commandPorts = getSortedCommandPortIds(schema).map((portId) => [portId, normalizedCommandPorts[portId]] as [string, WorkflowNodePortProperty]);
    const ports = [
        ...resolvePorts(schema, 'inputs', 'left').map(([portId, rules]) => ({ id: `in:${portId}`, layoutOptions: { 'elk.port.side': String(resolveSide(rules.side, 'left')).toUpperCase() } })),
        ...resolvePorts(schema, 'outputs', 'right').map(([portId, rules]) => ({ id: `out:${portId}`, layoutOptions: { 'elk.port.side': String(resolveSide(rules.side, 'right')).toUpperCase() } })),
        ...commandPorts.map(([portId, rules]) => ({ id: `cmd:${portId}`, layoutOptions: { 'elk.port.side': String(resolveSide(rules.side, 'left')).toUpperCase() } }))
    ];

    return { id: node.id, width, height, layoutOptions: { 'org.eclipse.elk.portConstraints': 'FIXED_ORDER' }, ports };
};

export const resolveElkNodeSize = (schema: WorkflowNodeSchema): { width: number; height: number } => {
    const nodeWidth = Number(schema.render?.nodeWidth || schema.render?.nodeSize || 200);
    const nodeHeight = Number(schema.render?.nodeHeight || schema.render?.nodeSize || 200);
    return { width: Math.max(nodeWidth + 36, WORKFLOW_LAYOUT_NODE_WIDTH), height: Math.max(nodeHeight + 48, WORKFLOW_LAYOUT_NODE_HEIGHT) };
};
