import { describe, expect, it } from 'vitest';
import { isRespondEndWorkflowModel, isStartWorkflowModel, normalizeWorkflowModelId } from '@workflow/ui/workflow/utils/workflow-model-id.utils';

describe('workflow model id normalization', () => {
    it('normalizes explicit string aliases', () => {
        expect(normalizeWorkflowModelId('start-node')).toBe('start');
        expect(normalizeWorkflowModelId('respond-end-node')).toBe('respond-end');
    });

    it('normalizes start/end from node fallback fields', () => {
        expect(
            normalizeWorkflowModelId({
                modelId: '',
                gigaId: 'StartNode'
            })
        ).toBe('start');

        expect(
            normalizeWorkflowModelId({
                modelId: '',
                runtime: {
                    nodeLibraryId: 'respond-end-node'
                }
            })
        ).toBe('respond-end');
    });

    it('detects node objects directly in type checks', () => {
        expect(
            isStartWorkflowModel({
                modelId: '',
                gigaId: 'StartNode'
            })
        ).toBe(true);
        expect(
            isRespondEndWorkflowModel({
                modelId: '',
                properties: {
                    nodeLibraryId: 'respond-end-node'
                }
            })
        ).toBe(true);
    });
});
