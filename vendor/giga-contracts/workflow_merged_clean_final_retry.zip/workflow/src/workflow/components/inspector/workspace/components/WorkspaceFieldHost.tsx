import React from 'react';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import type { WorkspaceFieldModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceFieldShell } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceFieldShell';
import { WorkspaceTextField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceTextField';
import { WorkspaceTextareaField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceTextareaField';
import { WorkspaceSelectField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceSelectField';
import { WorkspaceBooleanField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceBooleanField';
import { WorkspaceNumberField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceNumberField';
import { WorkspaceJsonField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceJsonField';
import { WorkspaceMarkdownField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceMarkdownField';
import { WorkspaceObjectArrayField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceObjectArrayField';
import { WorkspaceDependingField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceDependingField';
import { WorkspaceFileField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceFileField';
import { WorkspaceFileListField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceFileListField';
import { WorkspaceReadonlyField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceReadonlyField';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { clampDependingFieldNumberValue, resolveDependingFieldDefinition } from '@workflow/ui/workflow/components/form/depending-field';
import { containsVariableToken } from '@workflow/ui/workflow/utils/workflow-variables.utils';
import {
    isWorkspaceFieldEditable,
    parseWorkspaceFieldNumber,
    parseWorkspaceFieldString,
    resolveWorkspaceFieldLabel,
    shouldWorkspaceFieldSpanFullWidth
} from '@workflow/ui/workflow/components/inspector/workspace/components/fields/workspace-field.utils';

interface CompanionField {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    visible?: boolean;
}

interface WorkspaceFieldHostProps {
    field: WorkspaceFieldModel;
    readOnly?: boolean;
    propertiesEditorState: Record<string, unknown>;
    onChange: (fieldKey: string, value: unknown) => void;
    inspectorColumns?: number;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    companionField?: CompanionField;
    dependingField?: CompanionField;
}

const buildMethodDefinition = (): WorkflowNodeFieldDefinition => ({
    type: WorkflowNodeFieldTypeEnum.Select,
    editable: true,
    options: [
        { label: 'GET', value: 'GET' },
        { label: 'POST', value: 'POST' },
        { label: 'OPTIONS', value: 'OPTIONS' }
    ]
});

const renderFieldControl = ({
    fieldKey,
    definition,
    value,
    editable,
    variableContext,
    variableSuggestions,
    onChange,
    compactBoolean = false,
    variableMode = false
}: {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    editable: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (fieldKey: string, value: unknown) => void;
    compactBoolean?: boolean;
    variableMode?: boolean;
}): React.ReactNode => {
    const fieldId = `wf-workspace-field-${fieldKey}`;
    const allowVariables = definition.allowVariables !== false;

    switch (definition.type) {
        case WorkflowNodeFieldTypeEnum.Textarea:
            return (
                <WorkspaceTextareaField
                    id={fieldId}
                    value={parseWorkspaceFieldString(value)}
                    editable={editable}
                    allowVariables={allowVariables}
                    placeholder={definition.placeholder}
                    rows={4}
                    variableContext={variableContext}
                    variableSuggestions={variableSuggestions}
                    onChange={(nextValue) => onChange(fieldKey, nextValue)}
                />
            );
        case WorkflowNodeFieldTypeEnum.Markdown:
            return <WorkspaceMarkdownField id={fieldId} value={parseWorkspaceFieldString(value)} editable={editable} variableSuggestions={variableSuggestions} onChange={(nextValue) => onChange(fieldKey, nextValue)} />;
        case WorkflowNodeFieldTypeEnum.Boolean:
            return <WorkspaceBooleanField id={fieldId} checked={value === true || String(value).trim().toLowerCase() === 'true'} editable={editable} compact={compactBoolean} allowVariables={allowVariables} variableMode={Boolean(variableMode)} value={value} variableContext={variableContext} variableSuggestions={variableSuggestions} onChange={(nextValue) => onChange(fieldKey, nextValue)} />;
        case WorkflowNodeFieldTypeEnum.Number:
            return <WorkspaceNumberField id={fieldId} value={parseWorkspaceFieldNumber(value)} editable={editable} min={definition.min} max={definition.max} step={definition.step} onChange={(nextValue) => onChange(fieldKey, nextValue)} />;
        case WorkflowNodeFieldTypeEnum.Json:
        case WorkflowNodeFieldTypeEnum.Headers:
            return (
                <WorkspaceJsonField
                    value={parseWorkspaceFieldString(value)}
                    editable={editable}
                    allowVariables={allowVariables}
                    variableContext={variableContext}
                    variableSuggestions={variableSuggestions}
                    onChange={(nextValue) => onChange(fieldKey, nextValue)}
                />
            );
        case WorkflowNodeFieldTypeEnum.Method:
            return <WorkspaceSelectField id={fieldId} value={value} editable={editable} definition={buildMethodDefinition()} allowVariables={allowVariables} variableMode={Boolean(variableMode)} variableContext={variableContext} variableSuggestions={variableSuggestions} onChange={(nextValue) => onChange(fieldKey, nextValue)} />;
        case WorkflowNodeFieldTypeEnum.Select:
            return <WorkspaceSelectField id={fieldId} value={value} editable={editable} definition={definition} allowVariables={allowVariables} variableMode={Boolean(variableMode)} variableContext={variableContext} variableSuggestions={variableSuggestions} onChange={(nextValue) => onChange(fieldKey, nextValue)} />;
        case WorkflowNodeFieldTypeEnum.ObjectArray:
            return <WorkspaceObjectArrayField fieldKey={fieldKey} definition={definition} value={value} variableContext={variableContext} variableSuggestions={variableSuggestions} onChange={onChange} />;
        case WorkflowNodeFieldTypeEnum.File:
            return <WorkspaceFileField fieldKey={fieldKey} value={value} editable={editable} accept={definition.accept} onChange={onChange} />;
        case WorkflowNodeFieldTypeEnum.FileList:
            return <WorkspaceFileListField fieldKey={fieldKey} value={value} editable={editable} accept={definition.accept} onChange={onChange} />;
        case WorkflowNodeFieldTypeEnum.Timestamp:
            return <WorkspaceReadonlyField value={parseWorkspaceFieldString(value)} />;
        case WorkflowNodeFieldTypeEnum.String:
        default:
            return (
                <WorkspaceTextField
                    id={fieldId}
                    value={parseWorkspaceFieldString(value)}
                    editable={editable}
                    allowVariables={allowVariables}
                    placeholder={definition.placeholder}
                    variableContext={variableContext}
                    variableSuggestions={variableSuggestions}
                    onChange={(nextValue) => onChange(fieldKey, nextValue)}
                />
            );
    }
};

export const WorkspaceFieldHost: React.FC<WorkspaceFieldHostProps> = ({ field, readOnly = false, propertiesEditorState, onChange, variableContext, variableSuggestions, companionField, dependingField }) => {
    const resolvedDefinition = React.useMemo(() => resolveDependingFieldDefinition(field.definition, propertiesEditorState), [field.definition, propertiesEditorState]);
    const label = resolveWorkspaceFieldLabel({ ...field, definition: resolvedDefinition });
    const editable = !readOnly && field.key !== 'name' && isWorkspaceFieldEditable(resolvedDefinition);
    const description = field.presentation === 'default' ? undefined : field.helperText;
    const helperText = field.presentation === 'default' ? field.helperText : undefined;
    const supportsVariableMode =
        resolvedDefinition.allowVariables !== false &&
        (resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Select || resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Method || resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Boolean);
    const [variableMode, setVariableMode] = React.useState<boolean>(() => supportsVariableMode && containsVariableToken(parseWorkspaceFieldString(field.value)));
    const companionSupportsVariableMode =
        Boolean(companionField) &&
        (companionField?.definition.allowVariables !== false) &&
        (companionField?.definition.type === WorkflowNodeFieldTypeEnum.Select || companionField?.definition.type === WorkflowNodeFieldTypeEnum.Method || companionField?.definition.type === WorkflowNodeFieldTypeEnum.Boolean);
    const [companionVariableMode, setCompanionVariableMode] = React.useState<boolean>(() => Boolean(companionSupportsVariableMode && companionField && containsVariableToken(parseWorkspaceFieldString(companionField.value))));
    const dependingResolvedDefinition = React.useMemo(
        () => (dependingField ? resolveDependingFieldDefinition(dependingField.definition, propertiesEditorState) : undefined),
        [dependingField, propertiesEditorState]
    );

    React.useEffect(() => {
        if (resolvedDefinition.type !== WorkflowNodeFieldTypeEnum.Number) {
            return;
        }

        const parsedValue = parseWorkspaceFieldNumber(field.value);
        if (parsedValue === null) {
            return;
        }

        const nextValue = clampDependingFieldNumberValue(parsedValue, resolvedDefinition);
        if (nextValue !== parsedValue) {
            onChange(field.key, nextValue);
        }
    }, [field.key, field.value, onChange, resolvedDefinition]);

    const labelAction = supportsVariableMode ? (
        <button
            type="button"
            className={`cnw-field__label-action-button${variableMode ? ' is-active' : ''}`}
            disabled={!editable}
            aria-label={variableMode ? 'Disable variable mode' : 'Enable variable mode'}
            onClick={() => setVariableMode((current) => !current)}
        >
            <WorkspaceGlyph name="braces" className="cnw-field__label-action-icon" />
        </button>
    ) : undefined;
    const companionLabelAction = companionSupportsVariableMode ? (
        <button
            type="button"
            className={`cnw-field__label-action-button${companionVariableMode ? ' is-active' : ''}`}
            disabled={Boolean(readOnly) || !isWorkspaceFieldEditable(companionField?.definition ?? field.definition)}
            aria-label={companionVariableMode ? `Disable ${companionField?.definition.label ?? companionField?.fieldKey ?? 'field'} variable mode` : `Enable ${companionField?.definition.label ?? companionField?.fieldKey ?? 'field'} variable mode`}
            onClick={() => setCompanionVariableMode((current) => !current)}
        >
            <WorkspaceGlyph name="braces" className="cnw-field__label-action-icon" />
        </button>
    ) : undefined;

    if (dependingField && dependingResolvedDefinition) {
        const dependingLabel = dependingResolvedDefinition.label ?? dependingField.fieldKey;
        return (
            <div className={`cnw-field-shell${shouldWorkspaceFieldSpanFullWidth(field) ? ' cnw-field-shell--span-2' : ''}`} data-field-id={field.id}>
                <WorkspaceFieldShell label={label} badge={field.badge} helperText={helperText} description={description} presentation={field.presentation} labelAction={labelAction}>
                    <WorkspaceDependingField
                        primary={renderFieldControl({
                            fieldKey: field.key,
                            definition: resolvedDefinition,
                            value: field.value,
                            editable,
                            variableContext,
                            variableSuggestions,
                            onChange,
                            compactBoolean: field.presentation === 'execution-toggle',
                            variableMode
                        })}
                        dependentLabel={dependingLabel}
                        dependent={renderFieldControl({
                            fieldKey: dependingField.fieldKey,
                            definition: dependingResolvedDefinition,
                            value: dependingField.value,
                            editable: !readOnly && isWorkspaceFieldEditable(dependingResolvedDefinition),
                            variableContext,
                            variableSuggestions,
                            onChange
                        })}
                    />
                </WorkspaceFieldShell>
            </div>
        );
    }

    return (
        <div className={`cnw-field-shell${shouldWorkspaceFieldSpanFullWidth(field) ? ' cnw-field-shell--span-2' : ''}`} data-field-id={field.id}>
            <WorkspaceFieldShell label={label} badge={field.badge} helperText={helperText} description={description} presentation={field.presentation} labelAction={labelAction}>
                {renderFieldControl({
                    fieldKey: field.key,
                    definition: resolvedDefinition,
                    value: field.value,
                    editable,
                    variableContext,
                    variableSuggestions,
                    onChange,
                    compactBoolean: field.presentation === 'execution-toggle',
                    variableMode
                })}
                {companionField?.visible ? (
                    <div className="cnw-field__companion">
                        <div className="cnw-field__companion-label-row">
                            <label className="cnw-field__companion-label">{companionField.definition.label ?? companionField.fieldKey}</label>
                            {companionLabelAction ? <div className="cnw-field__label-action">{companionLabelAction}</div> : null}
                        </div>
                        {renderFieldControl({
                            fieldKey: companionField.fieldKey,
                            definition: companionField.definition,
                            value: companionField.value,
                            editable: !readOnly && isWorkspaceFieldEditable(companionField.definition),
                            variableContext,
                            variableSuggestions,
                            onChange,
                            variableMode: companionVariableMode
                        })}
                    </div>
                ) : null}
            </WorkspaceFieldShell>
        </div>
    );
};
