import { WorkflowFlowNode } from '@workflow/ui/workflow/components/canvas/workflow-flow.types';

const preserveNodeDimensions = (node: WorkflowFlowNode, previousNode: WorkflowFlowNode | undefined): WorkflowFlowNode => {
    if (!previousNode) {
        return node;
    }

    const measuredWidth = node.measured?.width ?? previousNode.measured?.width;
    const measuredHeight = node.measured?.height ?? previousNode.measured?.height;
    const measured = measuredWidth !== undefined || measuredHeight !== undefined ? { ...(node.measured ?? {}), ...(measuredWidth !== undefined ? { width: measuredWidth } : {}), ...(measuredHeight !== undefined ? { height: measuredHeight } : {}) } : node.measured;
    const width = node.width ?? previousNode.width;
    const height = node.height ?? previousNode.height;

    return {
        ...node,
        ...(measured ? { measured } : {}),
        ...(width !== undefined ? { width } : {}),
        ...(height !== undefined ? { height } : {})
    };
};

export const mergeCanvasNodes = (previous: WorkflowFlowNode[], next: WorkflowFlowNode[], workflowNodeCount: number, isInteracting: boolean): WorkflowFlowNode[] => {
    if (previous.length > 0 && next.length === 0 && workflowNodeCount > 0) {
        return previous;
    }

    const previousById = new Map(previous.map((node) => [node.id, node]));
    const nextWithDimensions = next.map((node) => preserveNodeDimensions(node, previousById.get(node.id)));

    if (!isInteracting) {
        return nextWithDimensions;
    }

    return nextWithDimensions.map((node) => {
        const prevNode = previousById.get(node.id);
        if (!prevNode) return node;
        return {
            ...node,
            position: prevNode.position,
            selected: prevNode.selected,
            dragging: prevNode.dragging
        };
    });
};
