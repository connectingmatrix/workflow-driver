import { describe, expect, it } from 'vitest';
import { buildChatWorkflowDefinition } from '@/modules/workflow-driver/chat-workflow';
import { ChatDebugRequestTimeline } from '@/types/chat';

const buildRequest = (): ChatDebugRequestTimeline => ({
    requestId: 'req_1',
    chatId: null,
    lastSentMessage: 'hello',
    isCompleted: false,
    hasFailed: false,
    startedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    events: [
        {
            id: 'evt_1',
            request_id: 'req_1',
            chat_id: null,
            stage: 'client.send',
            status: 'started',
            message: 'Sending',
            timestamp: new Date().toISOString(),
            source: 'client',
            meta: {
                subject_ids: ['subject_a'],
                post_ids: ['post_a'],
                scope: {
                    subjectIds: ['subject_b'],
                    postId: 'post_b'
                }
            }
        }
    ]
});

describe('chat workflow builder', () => {
    it('hydrates workflow input context from route fallback and timeline meta', () => {
        const workflow = buildChatWorkflowDefinition(buildRequest(), {
            routePathname: '/chat/chat_123/workflow/req_1'
        });
        expect(workflow.input?.chatId).toBe('chat_123');
        expect(workflow.input?.subjectIds).toEqual(expect.arrayContaining(['subject_a', 'subject_b']));
        expect(workflow.input?.postIds).toEqual(expect.arrayContaining(['post_a', 'post_b']));
    });
});
