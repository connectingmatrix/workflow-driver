export interface PreviewLogBuffer {
    flush: () => void;
    push: (chunk: unknown) => void;
}

const toText = (chunk: unknown): string => {
    if (typeof chunk === 'string') return chunk;
    if (chunk instanceof Uint8Array) {
        return new TextDecoder().decode(chunk);
    }
    if (chunk === null || typeof chunk === 'undefined') return '';
    return String(chunk);
};

export const createPreviewLogBuffer = (emitLine: (line: string) => void): PreviewLogBuffer => {
    let pending = '';

    const emitBufferedLines = (): void => {
        let nextBreak = pending.indexOf('\n');
        while (nextBreak >= 0) {
            const line = pending.slice(0, nextBreak).replace(/\r$/, '');
            if (line.trim().length > 0) {
                emitLine(line);
            }
            pending = pending.slice(nextBreak + 1);
            nextBreak = pending.indexOf('\n');
        }
    };

    return {
        push: (chunk: unknown) => {
            const text = toText(chunk);
            if (!text) return;
            pending += text;
            emitBufferedLines();
        },
        flush: () => {
            const lastLine = pending.replace(/\r$/, '');
            if (lastLine.trim().length > 0) {
                emitLine(lastLine);
            }
            pending = '';
        }
    };
};
