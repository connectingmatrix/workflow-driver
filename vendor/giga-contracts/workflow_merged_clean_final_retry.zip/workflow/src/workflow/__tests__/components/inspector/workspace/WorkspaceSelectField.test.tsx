// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React, { useState } from 'react';
import { cleanup, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it } from 'vitest';
import { WorkspaceSelectField } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/WorkspaceSelectField';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';

const definition = {
    type: 'select',
    editable: true,
    options: [{ label: 'One', value: 'one' }]
} as WorkflowNodeFieldDefinition;

const StatefulField = () => {
    const [value, setValue] = useState('one');
    return <WorkspaceSelectField id="wf-select-variable-test" value={value} editable definition={definition} allowVariables variableMode={false} variableContext={{ node_1: { title: 'Hello' } }} variableSuggestions={[]} onChange={setValue} />;
};

afterEach(() => {
    cleanup();
});

describe('WorkspaceSelectField', () => {
    it('renders select and variable modes from the host state', () => {
        const { rerender } = render(<StatefulField />);

        expect(screen.getByRole('button', { name: 'Select an option' })).toBeInTheDocument();

        rerender(
            <WorkspaceSelectField
                id="wf-select-variable-test"
                value="{{node_1.title}}"
                editable
                definition={definition}
                allowVariables
                variableMode
                variableContext={{ node_1: { title: 'Hello' } }}
                variableSuggestions={[]}
                onChange={() => undefined}
            />
        );

        expect(screen.getByRole('textbox')).toBeInTheDocument();
    });
});
