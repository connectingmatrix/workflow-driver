import { describe, expect, it } from 'vitest';
import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';
import {
    buildWorkspaceNodeLibraryGroups,
    filterWorkspaceNodeLibraryItems,
    resolveWorkspaceNodeLibraryCategory,
    resolveWorkspaceNodeLibraryGroupLabel
} from '@workflow/ui/workflow/components/node-library/workspace/workspace-node-library.utils';

const createItem = (overrides: Partial<WorkflowNodeLibraryItem>): WorkflowNodeLibraryItem =>
    ({
        id: overrides.id ?? overrides.modelId ?? 'node',
        modelId: overrides.modelId ?? 'node',
        gigaId: overrides.gigaId ?? overrides.modelId ?? 'node',
        label: overrides.label ?? 'Node',
        description: overrides.description ?? 'Node description',
        nodeType: overrides.nodeType ?? 'workflow',
        group: overrides.group ?? 'Other',
        ...overrides
    }) as WorkflowNodeLibraryItem;

describe('workspace node library utils', () => {
    it('maps exact workflow groups to the intended workspace categories', () => {
        expect(resolveWorkspaceNodeLibraryCategory(createItem({ group: 'Flow Nodes' }))).toBe('flow');
        expect(resolveWorkspaceNodeLibraryCategory(createItem({ group: 'Output Nodes' }))).toBe('data');
        expect(resolveWorkspaceNodeLibraryCategory(createItem({ group: 'Giga Data Nodes' }))).toBe('data');
        expect(resolveWorkspaceNodeLibraryCategory(createItem({ group: 'Giga AI Nodes' }))).toBe('logic');
        expect(resolveWorkspaceNodeLibraryCategory(createItem({ group: 'MCP Group' }))).toBe('mcp');
    });

    it('preserves exact group labels and priority ordering in grouped output', () => {
        const groups = buildWorkspaceNodeLibraryGroups([
            createItem({ id: 'ai-governor', modelId: 'ai-governor', group: 'Giga AI Nodes' }),
            createItem({ id: 'start', modelId: 'start', group: 'Flow Nodes' }),
            createItem({ id: 'output-format', modelId: 'output-format', group: 'Output Nodes' })
        ]);

        expect(groups.map((group) => group.groupName)).toEqual(['Flow Nodes', 'Output Nodes', 'Giga AI Nodes']);
        expect(resolveWorkspaceNodeLibraryGroupLabel(createItem({ group: 'MCP Group' }))).toBe('MCP Group');
    });

    it('filters by coarse category while keeping exact group labels for the cards', () => {
        const items = [
            createItem({ id: 'start', modelId: 'start', group: 'Flow Nodes' }),
            createItem({ id: 'output-format', modelId: 'output-format', group: 'Output Nodes' }),
            createItem({ id: 'mcp-runtime', modelId: 'mcp-runtime', group: 'MCP Group' })
        ];

        expect(filterWorkspaceNodeLibraryItems(items, '', 'flow').map((item) => item.id)).toEqual(['start']);
        expect(filterWorkspaceNodeLibraryItems(items, '', 'data').map((item) => item.id)).toEqual(['output-format']);
        expect(filterWorkspaceNodeLibraryItems(items, '', 'mcp').map((item) => item.id)).toEqual(['mcp-runtime']);
    });
});
