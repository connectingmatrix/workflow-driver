import { describe, expect, it } from 'vitest';
import { createWorkerNodeHandler, WorkflowNodeStatusEnum } from '@workflow/executor';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { withNodeExecutors } from '@workflow/ui/workflow/utils/workflow-node-executors.utils';

type BackendMock = (request: any, plan: Record<string, unknown>) => Promise<any> | any;

const outputError = (output: unknown): string => {
    const record = output as Record<string, any>;
    return String(record.result?.error ?? record.result?.message ?? record.error ?? record.message ?? '');
};

const executeValidation = async (workflow: any, nodeId: string, plannerPlan?: Record<string, unknown>, backendMock?: BackendMock, input: Record<string, Record<string, unknown>> = {}) => {
    const sourceValue = input.input ?? input;
    if (Object.keys(sourceValue).length) {
        workflow.nodes = workflow.nodes.map((entry: any) => (entry.id === nodeId ? { ...entry, runtime: { ...(entry.runtime ?? {}), sourceValue } } : entry));
    }
    const governorNode = workflow.nodes.find((entry: any) => entry.id === nodeId && entry.modelId === 'ai-governor');
    const plannerNode = workflow.nodes.find((entry: any) => entry.modelId === 'openai');
    if (governorNode && plannerNode && !workflow.connections.some((entry: any) => entry.from === plannerNode.id && entry.to === governorNode.id && entry.targetHandle === 'cmd:models')) {
        workflow.connections = [
            ...(workflow.connections ?? []),
            {
                id: `c_models_${plannerNode.id}_${governorNode.id}`,
                name: 'openai->governor:models',
                from: plannerNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:models'
            }
        ];
    }
    const executableWorkflow = withNodeExecutors(workflow);
    const node = executableWorkflow.nodes.find((entry: any) => entry.id === nodeId);
    if (!node) throw new Error(`Node ${nodeId} not found.`);
    const executablePlannerNode = executableWorkflow.nodes.find((entry: any) => entry.modelId === 'openai');

    const plan = plannerPlan ?? {
        intent: 'Return a compact answer.',
        actions: [
            {
                id: 'a1',
                nodeId: executablePlannerNode?.id,
                kind: 'model',
                reason: 'Use the connected model as final formatter.',
                input: { prompt: 'Return ok.' },
                depends_on: []
            }
        ],
        final_action_id: 'a1'
    };

    const handler = createWorkerNodeHandler({
        modelId: node.modelId,
        runtimeEnvironment: 'node',
        executeHelpers: {
            executeBackend: async (request: any) =>
                backendMock
                    ? backendMock(request, plan)
                    : {
                          output: {
                              text: JSON.stringify(plan)
                          },
                          status: WorkflowNodeStatusEnum.Passed,
                          logs: []
                      }
        }
    });

    return handler({
        node,
        workflow: executableWorkflow,
        settings: {
            graphqlUrl: 'http://localhost/graphql',
            authMode: 'none'
        },
        input
    } as any);
};

describe('ai-governor validate', { timeout: 30000 }, () => {
    it('fails when selection prompt is missing', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_missing_prompt');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = {
            ...(governorNode.runtime ?? {}),
            selectionPromptMd: ''
        };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const result = await executeValidation(workflow, governorNode.id);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('Selection Prompt');
    });

    it('fails when no llm planner is connected', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_disconnected');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        governorNode.runtime = {
            ...(governorNode.runtime ?? {}),
            selectionPromptMd: 'Plan a response.'
        };
        workflow.nodes = [governorNode];

        const result = await executeValidation(workflow, governorNode.id);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('LLM');
    });

    it('passes when selection prompt and connected planner llm are present', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_connected');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = {
            ...(governorNode.runtime ?? {}),
            selectionPromptMd: 'Plan a response.'
        };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const result = await executeValidation(workflow, governorNode.id);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).actionSummary).toHaveLength(1);
        expect((result.output as Record<string, unknown>).iterations).toBeUndefined();
        expect((result.output as Record<string, unknown>).finalMergedPayload).toBeUndefined();
    });

    it('keeps command control buckets out of planner governor input', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_clean_input');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Use the code query.' };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const plan = {
            intent: 'Format.',
            actions: [
                {
                    id: 'a1',
                    nodeId: openAiNode.id,
                    kind: 'model',
                    reason: 'Use the connected model.',
                    input: { prompt: 'Return markdown.' },
                    depends_on: []
                }
            ],
            final_action_id: 'a1'
        };
        let openAiCalls = 0;
        let plannerPrompt = '';
        const result = await executeValidation(
            workflow,
            governorNode.id,
            plan,
            async (request: any) => {
                openAiCalls += 1;
                if (openAiCalls === 1) {
                    plannerPrompt = String(request.context.node.runtime.prompt ?? '');
                    return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
                }
                return { output: { text: '| title | threat |' }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            },
            {
                input: { code_5: { query: 'latest Iran threat news' } },
                llm: { IN: { [openAiNode.id]: { text: 'planner' } }, STATE: { [openAiNode.id]: { status: 'stopped' } } }
            }
        );

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(plannerPrompt).toContain('Current Governor input: {"code_5":{"query":"latest Iran threat news"}}');
        expect(plannerPrompt).not.toContain('"IN"');
        expect(plannerPrompt).not.toContain('"STATE"');
    });

    it('fails when planner response is not valid JSON', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_invalid_json');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Plan a response.' };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const result = await executeValidation(workflow, governorNode.id, undefined, async () => ({
            output: { text: 'not json' },
            status: WorkflowNodeStatusEnum.Passed,
            logs: []
        }));

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('Unexpected token');
        expect((result.output as Record<string, unknown>).error).toBeUndefined();
    });

    it('fails when planner dependencies reference unknown actions', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_bad_dependency');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Plan a response.' };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const result = await executeValidation(workflow, governorNode.id, {
            intent: 'Use bad dependency.',
            actions: [
                {
                    id: 'a1',
                    nodeId: openAiNode.id,
                    kind: 'model',
                    reason: 'Invalid dependency.',
                    input: { prompt: 'No-op' },
                    depends_on: ['missing_action']
                }
            ],
            final_action_id: 'a1'
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('unknown action');
    });

    it('fails when planner returns too many actions', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_too_many_actions');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Plan a response.' };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const actions = Array.from({ length: 9 }, (_, index) => ({
            id: `a${index + 1}`,
            nodeId: openAiNode.id,
            kind: 'model',
            reason: 'Over limit.',
            input: { prompt: 'No-op' },
            depends_on: []
        }));
        const result = await executeValidation(workflow, governorNode.id, {
            intent: 'Too many.',
            actions,
            final_action_id: 'a1'
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('maximum is 8');
    });

    it('applies generated action input as ephemeral tool runtime', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_tool_input');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Search for Giga AI.' };
        workflow.nodes = [governorNode, openAiNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            },
            {
                id: 'c_2',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const plan = {
            intent: 'Search web.',
            actions: [
                {
                    id: 'a1',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'Search current web data.',
                    input: { query: 'giga ai workflow', max_results: 2 },
                    depends_on: []
                }
            ],
            final_action_id: 'a1'
        };
        let seenQuery = '';
        let seenMaxResults = 0;
        let plannerPrompt = '';
        const result = await executeValidation(workflow, governorNode.id, plan, async (request: any) => {
            const modelId = request.context.node.modelId;
            if (modelId === 'openai') {
                plannerPrompt = String(request.context.node.runtime.prompt ?? '');
                return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            }
            seenQuery = String(request.context.node.runtime.query ?? '');
            seenMaxResults = Number(request.context.node.runtime.max_results ?? 0);
            return {
                output: { query: seenQuery, max_results: seenMaxResults, items: [] },
                status: WorkflowNodeStatusEnum.Passed,
                logs: []
            };
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(plannerPrompt).toContain('"query"');
        expect(plannerPrompt).toContain('"items"');
        expect(plannerPrompt.trim().endsWith('Selection Prompt: Search for Giga AI.')).toBe(true);
        expect(seenQuery).toBe('giga ai workflow');
        expect(seenMaxResults).toBe(2);
        expect((result.output as Record<string, any>).result.query).toBe('giga ai workflow');
    });

    it('returns plan-only output without executing selected tools', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_plan_only');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        governorNode.runtime = {
            ...(governorNode.runtime ?? {}),
            selectionPromptMd: 'Plan a web search.',
            executionMode: 'plan-only'
        };
        workflow.nodes = [governorNode, openAiNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            },
            {
                id: 'c_2',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const plan = {
            intent: 'Search web.',
            actions: [
                {
                    id: 'a1',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'Search current web data.',
                    input: { query: 'giga ai workflow' },
                    depends_on: []
                }
            ],
            final_action_id: 'a1'
        };
        const calledModels: string[] = [];
        const result = await executeValidation(workflow, governorNode.id, plan, async (request: any) => {
            calledModels.push(request.context.node.modelId);
            if (request.context.node.modelId !== 'openai') throw new Error('Plan-only mode must not execute tools.');
            return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(calledModels).toEqual(['openai']);
        expect((result.output as Record<string, any>).plan.actions[0].nodeId).toBe(serpNode.id);
        expect((result.output as Record<string, any>).result).toBeUndefined();
    });

    it('hydrates missing required tool input from governor input data', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_tool_input_from_upstream');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Use the code node query to search.' };
        workflow.nodes = [governorNode, openAiNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            },
            {
                id: 'c_2',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const plan = {
            intent: 'Search web.',
            actions: [
                {
                    id: 'a1',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'Search with upstream query.',
                    input: {},
                    depends_on: []
                }
            ],
            final_action_id: 'a1'
        };
        let seenQuery = '';
        const result = await executeValidation(
            workflow,
            governorNode.id,
            plan,
            async (request: any) => {
                if (request.context.node.modelId === 'openai') return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
                seenQuery = String(request.context.node.runtime.query ?? '');
                return { output: { query: seenQuery, items: [] }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            },
            { input: { code_5: { query: 'latest Iran threat news' } } }
        );

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(seenQuery).toBe('latest Iran threat news');
        expect((result.output as Record<string, any>).result.query).toBe('latest Iran threat news');
    });

    it('allows repeated tool execution only as separate planned action ids', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_repeated_tool');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Run two searches.' };
        workflow.nodes = [governorNode, openAiNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            },
            {
                id: 'c_2',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const plan = {
            intent: 'Run repeated tool actions.',
            actions: [
                {
                    id: 'a1',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'First search.',
                    input: { query: 'first query' },
                    depends_on: []
                },
                {
                    id: 'a2',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'Second search.',
                    input: { query: 'second query' },
                    depends_on: []
                }
            ],
            final_action_id: 'a2'
        };
        const seenQueries: string[] = [];
        const result = await executeValidation(workflow, governorNode.id, plan, async (request: any) => {
            if (request.context.node.modelId === 'openai') return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            const query = String(request.context.node.runtime.query ?? '');
            seenQueries.push(query);
            return { output: { query }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(seenQueries).toEqual(['first query', 'second query']);
        expect((result.output as Record<string, any>).result.query).toBe('second query');
    });

    it('passes dependency results into dependent model actions', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_dependency_input');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 3);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), selectionPromptMd: 'Search then format.' };
        workflow.nodes = [governorNode, openAiNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            },
            {
                id: 'c_2',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const plan = {
            intent: 'Search then summarize.',
            actions: [
                {
                    id: 'a1',
                    nodeId: serpNode.id,
                    kind: 'tool',
                    reason: 'Collect references.',
                    input: { query: 'giga ai', max_results: 1 },
                    depends_on: []
                },
                {
                    id: 'a2',
                    nodeId: openAiNode.id,
                    kind: 'model',
                    reason: 'Format final response.',
                    input: { prompt: 'Summarize {{a1.output}}.' },
                    depends_on: ['a1']
                }
            ],
            final_action_id: 'a2'
        };
        let openAiCalls = 0;
        let finalOpenAiInput: Record<string, any> = {};
        let finalOpenAiPrompt = '';
        const result = await executeValidation(workflow, governorNode.id, plan, async (request: any) => {
            const modelId = request.context.node.modelId;
            if (modelId === 'openai') {
                openAiCalls += 1;
                if (openAiCalls === 1) return { output: { text: JSON.stringify(plan) }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
                finalOpenAiInput = request.context.input;
                finalOpenAiPrompt = String(request.context.node.runtime.prompt ?? '');
                return { output: { text: 'Final summary.' }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            }
            return {
                output: { query: 'giga ai', items: [{ title: 'Giga AI' }] },
                status: WorkflowNodeStatusEnum.Passed,
                logs: []
            };
        });

        const dependencyResults = finalOpenAiInput.input?.[governorNode.id]?.dependencyResults as Record<string, any>;
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(openAiCalls).toBe(2);
        expect(dependencyResults.a1.items[0].title).toBe('Giga AI');
        expect(finalOpenAiPrompt).toContain('Giga AI');
        expect(finalOpenAiPrompt).not.toContain('{{a1.output}}');
        expect((result.output as Record<string, any>).result.text).toBe('Final summary.');
    });

    it('fails when planner selects a disconnected node', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_unknown_node');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 2);
        governorNode.runtime = {
            ...(governorNode.runtime ?? {}),
            selectionPromptMd: 'Plan a response.'
        };
        workflow.nodes = [governorNode, openAiNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'openai->governor:model',
                from: openAiNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            }
        ];

        const result = await executeValidation(workflow, governorNode.id, {
            intent: 'Use missing node.',
            actions: [
                {
                    id: 'a1',
                    nodeId: 'missing_node',
                    kind: 'model',
                    reason: 'Invalid selection.',
                    input: { prompt: 'No-op' },
                    depends_on: []
                }
            ],
            final_action_id: 'a1'
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(outputError(result.output)).toContain('disconnected node');
    });

    it('executes an approved plan directly in execute-plan mode', async () => {
        const workflow = createEmptyWorkflow('wf_validate_ai_governor_execute_plan');
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const serpNode = createWorkflowNode(workflow, 'serp-search', 'SERP Search', 2);
        governorNode.runtime = { ...(governorNode.runtime ?? {}), executionMode: 'execute-plan' };
        workflow.nodes = [governorNode, serpNode];
        workflow.connections = [
            {
                id: 'c_1',
                name: 'serp->governor:tools',
                from: serpNode.id,
                to: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:tools'
            }
        ];

        const result = await executeValidation(
            workflow,
            governorNode.id,
            undefined,
            async (request: any) => {
                expect(request.context.node.modelId).toBe('serp-search');
                expect(request.context.node.runtime.query).toBe('giga ai workflow');
                return { output: { items: [{ title: 'Giga AI Workflow' }] }, status: WorkflowNodeStatusEnum.Passed, logs: [] };
            },
            {
                input: {
                    plan: {
                        intent: 'Search now.',
                        actions: [{ id: 'a1', nodeId: serpNode.id, kind: 'tool', reason: 'Run search.', input: { query: 'giga ai workflow' }, depends_on: [] }],
                        final_action_id: 'a1'
                    }
                }
            }
        );

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, any>).action_results[0].data.items[0].title).toBe('Giga AI Workflow');
    });
});
