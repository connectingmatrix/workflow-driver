import React, { useMemo, useState } from 'react';
import ReactDOM from 'react-dom/client';
import { PrimeReactProvider } from 'primereact/api';
import { Button } from 'primereact/button';
import { createGigaNodeCatalog } from '@workflow/nodes';
import { DesignerDialog, type WorkflowDefinition } from '@workflow/ui';
import { createSampleWorkflow } from './sample-workflow';
import { createStubWorkflowDriver } from './stub-driver';
import './playground.scss';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import 'primeflex/primeflex.css';

const nodeCatalog = createGigaNodeCatalog();
const searchParams = typeof window === 'undefined' ? new URLSearchParams() : new URLSearchParams(window.location.search);
const scenario = searchParams.get('scenario')?.trim() || 'code';
const preview = searchParams.get('preview')?.trim() || 'designer';

const App: React.FC = () => {
    const [visible, setVisible] = useState<boolean>(preview === 'designer');
    const [workflow, setWorkflow] = useState<WorkflowDefinition>(() => createSampleWorkflow(nodeCatalog, scenario));
    const driver = useMemo(() => createStubWorkflowDriver(), []);

    return (
        <div className="wf-playground">
            <header className="wf-playground__header">
                <div className="wf-playground__header-copy">
                    <h1>Workflow UI Playground</h1>
                    <p>Stubbed realtime/server driver + full local designer runtime for Play Local regression checks.</p>
                </div>
                <div className="wf-playground__actions">
                    <Button
                        label="Reset Sample Workflow"
                        icon="pi pi-refresh"
                        text
                        onClick={() => {
                            setWorkflow(createSampleWorkflow(nodeCatalog, scenario));
                            setVisible(true);
                        }}
                    />
                    <Button
                        label={visible ? 'Hide Designer' : 'Open Designer'}
                        icon={visible ? 'pi pi-eye-slash' : 'pi pi-eye'}
                        outlined
                        onClick={() => setVisible((previous) => !previous)}
                    />
                </div>
            </header>

            <DesignerDialog visible={visible} workflow={workflow} onHide={() => setVisible(false)} onWorkflowChange={setWorkflow} driver={driver} nodeCatalog={nodeCatalog} initialEditable />
        </div>
    );
};

ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
        <PrimeReactProvider>
            <App />
        </PrimeReactProvider>
    </React.StrictMode>
);
