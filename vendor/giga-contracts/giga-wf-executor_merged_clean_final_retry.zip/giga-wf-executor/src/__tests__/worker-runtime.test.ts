import { describe, expect, it, vi } from 'vitest';
import { createNodeExecutorSignature, createWorkerNodeHandler } from '../executor/worker-runtime';
import { WorkflowDefinition, WorkflowNodeHandlerContext, WorkflowNodeStatusEnum } from '../types';

const textEncoder = new TextEncoder();

const toBase64 = (source: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(source, 'utf8').toString('base64');
    }

    const bytes = textEncoder.encode(source);
    let binary = '';
    bytes.forEach((byte) => {
        binary += String.fromCharCode(byte);
    });
    return btoa(binary);
};

const createWorkflow = (modelId: string, source: string, signature?: string): WorkflowDefinition => ({
    metadata: {
        id: 'wf_worker_runtime',
        name: 'Worker Runtime Test'
    },
    nodes: [
        {
            id: 'node_1',
            gigaId: 'node_1',
            modelId,
            type: 'workflowStep',
            name: 'Node 1',
            description: '',
            kind: 'process',
            status: WorkflowNodeStatusEnum.Stopped,
            position: { x: 0, y: 0 },
            runtime: {
                flag: true
            },
            ports: {
                in: {},
                out: {}
            }
        }
    ],
    connections: [],
    NODE_EXECUTORS: {
        [modelId]: toBase64(source)
    },
    NODE_EXECUTOR_SIGNATURES: {
        [modelId]: signature ?? createNodeExecutorSignature(modelId, source)
    }
});

const createContext = (workflow: WorkflowDefinition, overrides: Partial<WorkflowNodeHandlerContext> = {}): WorkflowNodeHandlerContext => ({
    node: workflow.nodes[0],
    workflow,
    settings: {
        graphqlUrl: 'http://localhost/graphql',
        authMode: 'none'
    },
    input: {},
    ...overrides
});

describe('worker runtime compilation and loading', () => {
    it('prefers resolved sourceFiles worker.ts over persisted NODE_EXECUTORS source', async () => {
        const modelId = 'worker-source-override';
        const persistedSource = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { source: 'persisted' }, status: 'passed', logs: ['persisted-source'] });`;
        const unsavedSource = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { source: 'unsaved' }, status: 'passed', logs: ['unsaved-source'] });`;

        const workflow = createWorkflow(modelId, persistedSource);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            executeHelpers: {
                resolveNodeSourceFiles: async () => ({
                    'worker.ts': unsavedSource
                })
            }
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).source).toBe('unsaved');
        expect(result.logs).toContain('unsaved-source');
        expect(result.logs).not.toContain('persisted-source');
        expect(result.previewValidation?.ok).toBe(true);
    }, 15000);

    it('falls back to persisted NODE_EXECUTORS source when resolveNodeSourceFiles returns null', async () => {
        const modelId = 'worker-source-null-fallback';
        const persistedSource = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { source: 'persisted' }, status: 'passed', logs: ['persisted-source'] });`;

        const workflow = createWorkflow(modelId, persistedSource);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            executeHelpers: {
                resolveNodeSourceFiles: async () => null
            }
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).source).toBe('persisted');
        expect(result.logs).toContain('persisted-source');
    });

    it('runs resolved validate.ts before execute and blocks worker on validation failure', async () => {
        const modelId = 'worker-preview-validate';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['worker-executed'] });`;
        const validateSource = `
export const validate = async () => ({
  ok: false,
  errors: ['validate-ts blocked execution'],
  warnings: ['validate-ts warning']
});`;
        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            executeHelpers: {
                resolveNodeSourceFiles: async () => ({
                    'validate.ts': validateSource
                })
            }
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('validate-ts blocked execution');
        expect(result.logs).toContain('validate-ts warning');
        expect(result.logs).not.toContain('worker-executed');
        expect(result.previewValidation?.ok).toBe(false);
        expect(result.previewValidation?.errors).toContain('validate-ts blocked execution');
    });

    it('forwards executeBackend descriptor and payload args with context metadata', async () => {
        const modelId = 'worker-execute-backend-args';
        const source = `
import { executeBackend } from '@workflow/execute';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  return executeBackend(
    {
      key: 'executeWorkerBackendArgsNode',
      description: 'Tests descriptor argument forwarding.'
    },
    { fromWorker: true, value: 42 }
  );
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        let receivedRequest: Record<string, unknown> | null = null;
        const handler = createWorkerNodeHandler({
            modelId,
            executeHelpers: {
                executeBackend: async (request) => {
                    receivedRequest = request as unknown as Record<string, unknown>;
                    return {
                        output: {
                            ok: true
                        },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['execute-backend-forwarded']
                    };
                }
            }
        });

        const result = await handler(context);
        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('execute-backend-forwarded');
        expect(receivedRequest).toBeTruthy();
        const backendRequest = receivedRequest as unknown as Record<string, unknown>;
        expect((backendRequest.descriptor as Record<string, unknown>)?.key).toBe('executeWorkerBackendArgsNode');
        expect((backendRequest.payload as Record<string, unknown>)?.fromWorker).toBe(true);
        expect(((backendRequest.context as Record<string, unknown>)?.node as Record<string, unknown>)?.id).toBe('node_1');
    }, 15000);


    it('injects workflow graph metadata and runtime settings into worker payload', async () => {
        const modelId = 'worker-context-payload';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({
  output: {
    workflowName: payload.workflow?.metadata?.name ?? null,
    nodeCount: Array.isArray(payload.workflow?.nodes) ? payload.workflow.nodes.length : 0,
    connectionCount: Array.isArray(payload.workflow?.connections) ? payload.workflow.connections.length : 0,
    graphqlUrl: payload.workflow?.metadata?.runtime?.settings?.graphqlUrl ?? null
  },
  status: 'passed',
  logs: ['worker-context']
});`;

        const workflow = createWorkflow(modelId, source);
        workflow.nodes.push({
            ...workflow.nodes[0],
            id: 'node_2',
            gigaId: 'node_2',
            name: 'Node 2'
        });
        workflow.connections = [
            {
                id: 'c1',
                name: 'node_1->node_2',
                from: 'node_1',
                to: 'node_2'
            }
        ];

        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).workflowName).toBe('Worker Runtime Test');
        expect((result.output as Record<string, unknown>).nodeCount).toBe(2);
        expect((result.output as Record<string, unknown>).connectionCount).toBe(1);
        expect((result.output as Record<string, unknown>).graphqlUrl).toBe('http://localhost/graphql');
        expect(result.logs).toContain('worker-context');
    });

    it('normalizes nested TypeScript module shapes and does not crash on missing ES2022 enum path', async () => {

        const modelId = 'nested-ts-shape';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['nested-ts'] });`;

        const transpileModule = (input: string) => ({
            outputText: input,
            diagnostics: []
        });

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            typescriptModuleLoader: async () => ({
                default: {
                    default: {
                        transpileModule,
                        flattenDiagnosticMessageText: (message: unknown) => String(message),
                        DiagnosticCategory: { Error: 1 }
                    }
                }
            })
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('nested-ts');
    });

    it('supports function-wrapped TypeScript module shapes', async () => {
        const modelId = 'function-ts-shape';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['function-ts'] });`;

        const transpileModule = (input: string) => ({
            outputText: input,
            diagnostics: []
        });

        const functionWrapper = (() => undefined) as unknown as Record<string, unknown>;
        Object.defineProperty(functionWrapper, 'transpileModule', {
            value: transpileModule,
            enumerable: false
        });
        Object.defineProperty(functionWrapper, 'flattenDiagnosticMessageText', {
            value: (message: unknown) => String(message),
            enumerable: false
        });
        Object.defineProperty(functionWrapper, 'DiagnosticCategory', {
            value: { Error: 1 },
            enumerable: false
        });

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            typescriptModuleLoader: async () => ({
                default: functionWrapper
            })
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('function-ts');
    });

    it('falls back to bundled TypeScript imports when a custom loader returns an invalid shape', async () => {
        const modelId = 'fallback-ts-loader';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['fallback-ts-loader'] });`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            typescriptModuleLoader: async () => ({
                default: {
                    notTypescriptApi: true
                }
            })
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('fallback-ts-loader');
    });

    it('compiles TypeScript worker source and executes with @workflow/executor imports', async () => {
        const modelId = 'worker-model';
        const source = `
import type { WorkerPayload, WorkerValidateResult } from '@workflow/executor';
import { toNode, toRecord, normalizeResult } from '@workflow/executor';

export const validate = async (payload: WorkerPayload): Promise<WorkerValidateResult> => {
  const node = toNode(payload);
  const hasId = String(node.id ?? '').trim().length > 0;
  return { ok: hasId, errors: hasId ? [] : ['NODE.id is required'], warnings: [] };
};

export const init = async (_payload: WorkerPayload) => true;

export const onUpdate = async (_payload: WorkerPayload) => ({ ok: true });

export const execute = async (payload: WorkerPayload) => {
  const node = toNode(payload);
  const properties = toRecord(node.PROPERTIES);
  return normalizeResult({
    output: {
      id: node.id,
      flag: properties.flag ?? null
    },
    status: 'passed',
    logs: ['compiled-worker']
  });
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).id).toBe('node_1');
        expect(result.logs).toContain('compiled-worker');
    });

    it('preserves worker command-peer auto-run suppression', async () => {
        const modelId = 'skip-command-peers-model';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { ok: true },
  status: 'passed',
  logs: ['skip-command-peers'],
  skipCommandPeerAutoRun: true
});`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('skip-command-peers');
        expect(result.skipCommandPeerAutoRun).toBe(true);
    });

    it('stubs node built-in imports in browser runtime', async () => {
        const modelId = 'browser-node-builtins';
        const source = `
import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { hasReadFileSync: typeof fs.readFileSync === 'function' },
  status: 'passed',
  logs: ['browser-stubbed']
});`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'browser'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).hasReadFileSync).toBe(true);
        expect(result.logs).toContain('browser-stubbed');
    });

    it('keeps unresolved non-builtin imports as explicit runtime failures in browser mode', async () => {
        const modelId = 'browser-unresolved-import';
        const source = `
import unknownModule from 'not-a-real-runtime-module';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { unknownModule },
  status: 'passed',
  logs: []
});`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'browser'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('Unable to load worker module');
    });

    it('executes node built-in imports normally in node runtime', async () => {
        const modelId = 'node-builtins';
        const source = `
import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { hasReadFileSync: typeof fs.readFileSync === 'function' },
  status: 'passed',
  logs: ['node-builtin']
});`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'node'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).hasReadFileSync).toBe(true);
        expect(result.logs).toContain('node-builtin');
    });

    it('keeps sync fs builtin methods sync in sandboxed node runtime', async () => {
        const modelId = 'node-fs-sync-bridge';
        const source = `
import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { ok: fs.readdirSync('.') },
  status: 'passed',
  logs: ['user-node executed']
});`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'node'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(Array.isArray((result.output as Record<string, unknown>).ok)).toBe(true);
        expect((result.output as Record<string, unknown>).ok).toContain('worker.ts');
        expect(result.logs).toContain('user-node executed');
    });

    it('supports default-import host module access for sync fs writes in sandboxed node runtime', async () => {
        const modelId = 'node-fs-write-sync-bridge';
        const source = `
import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  fs.writefileSync('abeer.txt', 'Hello World');
  return {
    output: { ok: fs.readdirSync('.') },
    status: 'passed',
    logs: ['user-node executed']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'node'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(Array.isArray((result.output as Record<string, unknown>).ok)).toBe(true);
        expect((result.output as Record<string, unknown>).ok).toContain('abeer.txt');
        expect(result.logs).toContain('user-node executed');
    });

    it('bridges timer globals into sandboxed node runtime workers', async () => {
        const modelId = 'node-timer-bridge';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  await new Promise((resolve) => globalThis.setTimeout(resolve, 5));
  return {
    output: { ok: true },
    status: 'passed',
    logs: ['timer-bridge']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'node'
        });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).ok).toBe(true);
        expect(result.logs).toContain('timer-bridge');
    });

    it('bridges fetch globals into sandboxed node runtime workers', async () => {
        const modelId = 'node-fetch-bridge';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  const response = await fetch('data:application/json,%7B%22source%22%3A%22sandbox%22%7D');
  const body = await response.json();
  return {
    output: { ok: response.ok, status: response.status, source: body.source, headerCount: Array.from(response.headers.entries()).length },
    status: 'passed',
    logs: ['fetch-bridge']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId, runtimeEnvironment: 'node' });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).ok).toBe(true);
        expect((result.output as Record<string, unknown>).status).toBe(200);
        expect((result.output as Record<string, unknown>).source).toBe('sandbox');
        expect(Number((result.output as Record<string, unknown>).headerCount)).toBeGreaterThan(0);
        expect(result.logs).toContain('fetch-bridge');
    });

    it('loads @workflow/charts inside sandboxed node runtime workers', async () => {
        const modelId = 'node-workflow-charts-module';
        const source = `
import { createWorkflowChart, serializeWorkflowChartMarkdown } from '@workflow/charts';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  const chart = createWorkflowChart({ prompt: 'Create a bar chart', libraryId: 'recharts' });
  return {
    output: { template: chart.chartTemplateId, markdown: serializeWorkflowChartMarkdown(chart) },
    status: 'passed',
    logs: ['workflow-charts-loaded']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId, runtimeEnvironment: 'node' });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(String((result.output as Record<string, unknown>).markdown)).toContain('[chart]');
        expect(String((result.output as Record<string, unknown>).markdown)).toContain('[/chart]');
        expect(result.logs).toContain('workflow-charts-loaded');
    }, 15000);

    it('fails with explicit diagnostics when worker TypeScript compile fails', async () => {
        const modelId = 'compile-fail';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  const broken: = 123;
  return { output: { ok: true }, status: 'passed', logs: [] };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('compile failed');
    });

    it('fails when worker has unresolved runtime imports', async () => {
        const modelId = 'resolve-fail';
        const source = `
import missingThing from 'not-a-real-runtime-module';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { missingThing }, status: 'passed', logs: [] });`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('Unable to load worker module');
    });

    it('fails when worker signature does not match source', async () => {
        const modelId = 'signature-fail';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: [] });`;

        const workflow = createWorkflow(modelId, source, 'wf-sign-v1-invalid');
        const context = createContext(workflow);
        const handler = createWorkerNodeHandler({ modelId });
        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('signature mismatch');
    });

    it('forwards invokeConnectedNode args with worker context', async () => {
        const modelId = 'worker-invoke-connected-node';
        const source = `
import { invokeConnectedNode } from '@workflow/execute';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  const invoked = await invokeConnectedNode({
    nodeId: 'node_connected',
    input: { input: { node_1: { hello: 'world' } } },
    overrides: { runtime: { prompt: 'format me' } }
  });
  return {
    output: {
      status: invoked.result.status,
      nodeId: invoked.node.id,
      prompt: invoked.result.output.prompt
    },
    status: 'passed',
    logs: ['invoke-connected-forwarded']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const context = createContext(workflow);
        let receivedRequest: Record<string, unknown> | null = null;
        const handler = createWorkerNodeHandler({
            modelId,
            executeHelpers: {
                invokeConnectedNode: async (request) => {
                    receivedRequest = request as unknown as Record<string, unknown>;
                    return {
                        node: { ...context.node, id: 'node_connected' },
                        result: {
                            output: { prompt: 'format me' },
                            status: WorkflowNodeStatusEnum.Passed,
                            logs: ['connected-node']
                        }
                    };
                }
            }
        });

        const result = await handler(context);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('invoke-connected-forwarded');
        expect(receivedRequest).toBeTruthy();
        const invokeRequest = receivedRequest as unknown as Record<string, unknown>;
        expect((invokeRequest.payload as Record<string, unknown>)?.nodeId).toBe('node_connected');
        expect((((invokeRequest.payload as Record<string, unknown>)?.overrides as Record<string, unknown>)?.runtime as Record<string, unknown>)?.prompt).toBe('format me');
        expect((((invokeRequest.context as Record<string, unknown>)?.node as Record<string, unknown>)?.id)).toBe('node_1');
        expect((result.output as Record<string, unknown>).prompt).toBe('format me');
    });

    it('falls back to context invokeConnectedNode when no explicit execute helper is provided', async () => {
        const modelId = 'worker-invoke-connected-node-context';
        const source = `
import { invokeConnectedNode } from '@workflow/execute';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => {
  const invoked = await invokeConnectedNode({
    nodeId: 'node_connected',
    input: { input: { node_1: { hello: 'world' } } },
    overrides: { runtime: { prompt: 'context fallback' } }
  });
  return {
    output: {
      status: invoked.result.status,
      nodeId: invoked.node.id,
      prompt: invoked.result.output.prompt
    },
    status: 'passed',
    logs: ['invoke-connected-context']
  };
};`;

        const workflow = createWorkflow(modelId, source);
        const baseContext = createContext(workflow);
        let receivedArgs: Record<string, unknown> | null = null;
        const handler = createWorkerNodeHandler({ modelId });

        const result = await handler({
            ...baseContext,
            invokeConnectedNode: async (args) => {
                receivedArgs = args as unknown as Record<string, unknown>;
                return {
                    node: { ...baseContext.node, id: 'node_connected' },
                    result: {
                        output: { prompt: 'context fallback' },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['connected-node-context']
                    }
                };
            }
        });

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.logs).toContain('invoke-connected-context');
        expect(receivedArgs).toBeTruthy();
        const invokeArgs = receivedArgs as unknown as Record<string, unknown>;
        expect(invokeArgs.nodeId).toBe('node_connected');
        expect(((invokeArgs.overrides as Record<string, unknown>)?.runtime as Record<string, unknown>)?.prompt).toBe('context fallback');
        expect((result.output as Record<string, unknown>).prompt).toBe('context fallback');
    });

    it('resolves a selected credential, injects it into NODE.CREDENTIAL, and reports success telemetry', async () => {
        const modelId = 'worker-credential-success';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async (payload) => ({
  output: {
    credentialId: payload.NODE.CREDENTIAL?.credentialId ?? null,
    apiKey: payload.NODE.CREDENTIAL?.values?.api_key ?? null
  },
  status: 'passed',
  logs: ['credential-success']
});`;

        const workflow = createWorkflow(modelId, source);
        workflow.nodeModels = {
            [modelId]: {
                useCredentials: 'openai'
            }
        } as Record<string, any>;
        workflow.nodes[0].properties = {
            credentialId: 'cred_openai_1'
        };

        const fetchCredentialById = vi.fn(async () => ({
            id: 'cred_openai_1',
            credentialId: 'cred_openai_1',
            credentialName: 'Primary OpenAI',
            serviceId: 'openai',
            serviceName: 'OpenAI',
            serviceIcon: 'simple-icons:openai',
            scope: 'PERSONAL',
            values: {
                api_key: 'sk-test'
            }
        }));
        const recordCredentialExecutionResult = vi.fn(async () => undefined);

        const result = await createWorkerNodeHandler({ modelId })(createContext(workflow, { hostContext: { fetchCredentialById, recordCredentialExecutionResult } }));

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).credentialId).toBe('cred_openai_1');
        expect((result.output as Record<string, unknown>).apiKey).toBe('sk-test');
        expect(fetchCredentialById).toHaveBeenCalledWith('cred_openai_1');
        expect(recordCredentialExecutionResult).toHaveBeenCalledWith({
            credentialId: 'cred_openai_1',
            success: true
        });
    });

    it('fails deterministically when a selected credential cannot be resolved and reports failure telemetry', async () => {
        const modelId = 'worker-credential-missing';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { ok: true }, status: 'passed', logs: ['should-not-run'] });`;

        const workflow = createWorkflow(modelId, source);
        workflow.nodeModels = {
            [modelId]: {
                useCredentials: 'openai'
            }
        } as Record<string, any>;
        workflow.nodes[0].properties = {
            credentialId: 'cred_missing'
        };

        const fetchCredentialById = vi.fn(async () => null);
        const recordCredentialExecutionResult = vi.fn(async () => undefined);

        const result = await createWorkerNodeHandler({ modelId })(createContext(workflow, { hostContext: { fetchCredentialById, recordCredentialExecutionResult } }));

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String((result.output as Record<string, unknown>).error ?? '')).toContain('cred_missing');
        expect(recordCredentialExecutionResult).toHaveBeenCalledWith({
            credentialId: 'cred_missing',
            success: false
        });
    });

    it('reports credential failure telemetry when the worker returns a failed result', async () => {
        const modelId = 'worker-credential-failed-result';
        const source = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { error: 'provider failed' }, status: 'failed', logs: ['credential-failed'] });`;

        const workflow = createWorkflow(modelId, source);
        workflow.nodeModels = {
            [modelId]: {
                useCredentials: 'openai'
            }
        } as Record<string, any>;
        workflow.nodes[0].properties = {
            credentialId: 'cred_openai_failed'
        };

        const recordCredentialExecutionResult = vi.fn(async () => undefined);

        const result = await createWorkerNodeHandler({ modelId })(
            createContext(workflow, {
                hostContext: {
                    fetchCredentialById: async () => ({
                        id: 'cred_openai_failed',
                        credentialId: 'cred_openai_failed',
                        credentialName: 'Broken OpenAI',
                        serviceId: 'openai',
                        serviceName: 'OpenAI',
                        serviceIcon: 'simple-icons:openai',
                        scope: 'PERSONAL',
                        values: { api_key: 'sk-bad' }
                    }),
                    recordCredentialExecutionResult
                }
            })
        );

        expect(result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(recordCredentialExecutionResult).toHaveBeenCalledWith({
            credentialId: 'cred_openai_failed',
            success: false
        });
    });
});
