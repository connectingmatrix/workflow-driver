import React from 'react';
import { Handle } from '@xyflow/react';
import { WorkflowNodePortProperty, WorkflowNodePortSideEnum } from '@workflow/ui/workflow/types';
import { buildPortHandleStyle, isBottomPortSide, resolvePortPosition } from '@workflow/ui/workflow/nodes/base-node-port-layout.utils';

interface BaseNodeDataPortProps {
    direction: 'input' | 'output';
    nodeId: string;
    port: { id: string; name: string; rules: WorkflowNodePortProperty };
    side: WorkflowNodePortSideEnum;
    index: number;
    total: number;
    outputConnections?: number;
    onQuickAddFromPort?: (payload: { nodeId: string; outputPortId: string; anchor: HTMLElement }) => void;
}

const BaseNodeDataPortComponent: React.FC<BaseNodeDataPortProps> = ({ direction, nodeId, port, side, index, total, outputConnections = 0, onQuickAddFromPort }) => {
    const style = buildPortHandleStyle(side, index, total);
    const isInput = direction === 'input';
    const label = port.rules.label ?? port.name;
    const showQuickAdd = !isInput && (port.rules.showQuickAdd ?? true) && outputConnections === 0;
    const branchClass = isBottomPortSide(side)
        ? `base-node__bottom-branch base-node__bottom-branch--${direction}`
        : `${isInput ? 'base-node__input-branch' : 'base-node__output-branch'} ${isInput ? 'base-node__input-branch' : 'base-node__output-branch'}--${side}`;

    return (
        <>
            <Handle id={`${isInput ? 'in' : 'out'}:${port.id}`} type={isInput ? 'target' : 'source'} position={resolvePortPosition(side)} className={`base-node__handle base-node__handle--${isInput ? 'input' : 'output'} base-node__handle--${side}`} style={style} />
            <div className={branchClass} style={style}>
                <span className={isBottomPortSide(side) ? 'base-node__bottom-branch-line' : 'base-node__output-branch-line'} />
                <span className={isBottomPortSide(side) ? 'base-node__bottom-branch-label' : 'base-node__output-branch-label'}>{label}</span>
                {showQuickAdd ? (
                    <button
                        type="button"
                        className="base-node__branch-add-btn"
                        title={`Add node from ${label}`}
                        onClick={(event) => {
                            event.stopPropagation();
                            onQuickAddFromPort?.({
                                nodeId,
                                outputPortId: port.id,
                                anchor: event.currentTarget
                            });
                        }}
                    >
                        <i className="pi pi-plus" />
                    </button>
                ) : null}
            </div>
        </>
    );
};

const BaseNodeDataPort = React.memo(BaseNodeDataPortComponent);

export default BaseNodeDataPort;
