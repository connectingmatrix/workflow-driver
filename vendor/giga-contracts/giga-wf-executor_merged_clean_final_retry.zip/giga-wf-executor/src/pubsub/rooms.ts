export const workflowCatalogRoom = (broadcastId: string, channelName: string) => `${String(broadcastId || '').trim()}-${String(channelName || '').trim()}`;
export const workflowExecutionRoom = (broadcastId: string, workflowId: string) => `${String(broadcastId || '').trim()}-${String(workflowId || '').trim()}`;
export const workflowLogsRoom = (userId: string, runId: string) => `workflow:user:${String(userId || '').trim()}:run:${String(runId || '').trim()}`;
export const workflowUserRoom = (userId: string) => `workflow:user:${String(userId || '').trim()}`;

export const canListenWorkflowRoom = (userId: string, roomName: string) => {
  const normalizedUserId = String(userId || '').trim();
  const normalizedRoomName = String(roomName || '').trim();
  if (!normalizedUserId || !normalizedRoomName) return false;
  return normalizedRoomName === workflowUserRoom(normalizedUserId) || normalizedRoomName.startsWith(`${normalizedUserId}-`) || normalizedRoomName.startsWith(`workflow:user:${normalizedUserId}:run:`);
};
