import type { WorkflowCredentialOption } from '@workflow/ui/workflow/types';
import type { WorkspaceCredentialSelectorModel, WorkspaceCredentialSelectorState } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface BuildWorkspaceCredentialSelectorModelArgs {
    serviceId: string | null;
    selectedCredentialId: string | null;
    options: WorkflowCredentialOption[];
    state: WorkspaceCredentialSelectorState;
    message?: string;
}

const humanizeServiceId = (serviceId: string): string =>
    serviceId.toLowerCase() === 'mcp'
        ? 'MCP'
        :
    serviceId
        .split(/[-_]/g)
        .filter(Boolean)
        .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
        .join(' ');

export const buildWorkspaceCredentialSelectorModel = ({ serviceId, selectedCredentialId, options, state, message }: BuildWorkspaceCredentialSelectorModelArgs): WorkspaceCredentialSelectorModel | null => {
    const normalizedServiceId = typeof serviceId === 'string' ? serviceId.trim() : '';
    if (!normalizedServiceId) {
        return null;
    }

    const selectedOption = options.find((option) => option.credentialId === selectedCredentialId) ?? null;
    const serviceName = selectedOption?.serviceName ?? options[0]?.serviceName ?? humanizeServiceId(normalizedServiceId);

    return {
        title: 'Credential',
        description: `Select the ${serviceName} credential this node should use at runtime.`,
        serviceId: normalizedServiceId,
        selectedCredentialId,
        options,
        state,
        message
    };
};
