import { WorkflowDefinition, WorkflowNodeLibraryItem, WorkflowNodeSchema, WorkflowRunLogEvent } from '@workflow/ui/workflow/types';
import { workflowToExportPayload } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { WorkflowAiHiddenContext, WorkflowAiScope } from './types';
import { WORKFLOW_AI_KNOWLEDGE } from './knowledge';
import { workflowAsCypher } from './cypher-export';
import { buildWorkflowGraphHealth } from './graph-health';
import { buildWorkflowNodeContract } from './field-contracts';

interface BuildWorkflowAiHiddenContextInput {
    workflow: WorkflowDefinition;
    scope: WorkflowAiScope;
    recentLogs: WorkflowRunLogEvent[];
    nodeLibraryItems: WorkflowNodeLibraryItem[];
    capabilities: string[];
    resolveNodeSchema: (modelId: string | undefined, nodeModels: Record<string, WorkflowNodeSchema>) => WorkflowNodeSchema;
}

const toNodeCatalogItem = (item: WorkflowNodeLibraryItem): WorkflowAiHiddenContext['nodeCatalog'][number] => ({
    modelId: item.modelId,
    label: item.label,
    description: item.description,
    group: item.group
});

const toNodeContract = (
    workflow: WorkflowDefinition,
    item: WorkflowNodeLibraryItem,
    resolveNodeSchema: (modelId: string | undefined, nodeModels: Record<string, WorkflowNodeSchema>) => WorkflowNodeSchema
): NonNullable<WorkflowAiHiddenContext['nodeContracts']>[number] => {
    const schema = resolveNodeSchema(item.modelId, workflow.nodeModels ?? {});
    return buildWorkflowNodeContract(item, schema);
};

const toLogRecord = (entry: WorkflowRunLogEvent): Record<string, unknown> => ({
    timestamp: entry.timestamp,
    level: entry.level,
    event: entry.event,
    workflowId: entry.workflowId,
    runId: entry.runId,
    nodeId: entry.nodeId,
    message: entry.message,
    data: entry.data
});

export const buildWorkflowAiHiddenContext = (input: BuildWorkflowAiHiddenContextInput): WorkflowAiHiddenContext => ({
    workflowId: input.workflow.metadata.id,
    workflowName: input.workflow.metadata.name,
    scope: input.scope,
    workflowExportWithData: workflowToExportPayload(input.workflow, 'with-data'),
    workflowCypher: workflowAsCypher(input.workflow),
    graphHealth: buildWorkflowGraphHealth(input.workflow),
    knowledge: WORKFLOW_AI_KNOWLEDGE,
    recentLogs: input.recentLogs.map(toLogRecord),
    capabilities: input.capabilities,
    nodeCatalog: input.nodeLibraryItems.map(toNodeCatalogItem),
    nodeContracts: input.nodeLibraryItems.map((item) => toNodeContract(input.workflow, item, input.resolveNodeSchema))
});
