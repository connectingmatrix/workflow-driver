# Workflow Interconnections

Workflows connect Chat, Nodes, AI Agents, Process Monitor, and output previews.

```mermaid
graph TD
  A[Chat Workflow mode] --> B[Workflow attachment]
  B --> C[Workflow run]
  C --> D[Node loop]
  D --> E{Node kind}
  E -->|AI Agent node| F[Run selected AI Agent]
  E -->|Standard node| G[Run node runtime]
  F --> H[Agent output contract]
  G --> I[Node output]
  H --> J[Workflow result]
  I --> J
  J --> K[Chat/UI preview]
```

Rules:

- Workflow mode requires a workflow attachment.
- AI Agent nodes inherit workflow parent scope.
- Workflow outputs preserve `[charts]`, `[excel]`, `[file]`, and `[mermaid]` markers.
- Stop/kill from Process Monitor should propagate to active child nodes when possible.
