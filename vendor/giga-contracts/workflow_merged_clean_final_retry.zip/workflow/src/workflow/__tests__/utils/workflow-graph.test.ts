import fs from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { buildCanvasEdges, canAttachConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';
import { WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

describe('workflow graph edge rendering contract', () => {
    it('uses base + 0.4px stroke width for active and failed edges only', () => {
        const workflow = createEmptyWorkflow('wf_graph_edges');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];

        const activeEdges = buildCanvasEdges(
            workflow,
            workflow.nodes.map((node) => node.id),
            1,
            true
        );
        const activeEdgeStyle = activeEdges.find((edge) => edge.id === 'c1')?.style as { strokeWidth?: number };
        const inactiveEdgeStyle = activeEdges.find((edge) => edge.id === 'c2')?.style as { strokeWidth?: number };
        expect(activeEdgeStyle.strokeWidth).toBe(2.9);
        expect(inactiveEdgeStyle.strokeWidth).toBe(2.5);

        workflow.nodes = workflow.nodes.map((node) => (node.id === start.id ? { ...node, status: WorkflowNodeStatusEnum.Failed } : node));
        const failedEdges = buildCanvasEdges(
            workflow,
            workflow.nodes.map((node) => node.id),
            -1,
            false
        );
        const failedEdgeStyle = failedEdges.find((edge) => edge.id === 'c1')?.style as { strokeWidth?: number };
        expect(failedEdgeStyle.strokeWidth).toBe(2.9);
    });

    it('adds sibling lane offsets for multi-edge handles', () => {
        const workflow = createEmptyWorkflow('wf_graph_lanes');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const left = createWorkflowNode(workflow, 'code', 'Left', 2);
        const right = createWorkflowNode(workflow, 'code', 'Right', 3);
        workflow.nodes = [start, left, right];
        workflow.connections = [createConnection('c1', start.id, left.id), createConnection('c2', start.id, right.id)];

        const edges = buildCanvasEdges(workflow, workflow.nodes.map((node) => node.id), -1, false);
        const firstData = edges.find((edge) => edge.id === 'c1')?.data as { sourceLaneOffset?: number };
        const secondData = edges.find((edge) => edge.id === 'c2')?.data as { sourceLaneOffset?: number };

        expect(firstData.sourceLaneOffset).toBe(-9);
        expect(secondData.sourceLaneOffset).toBe(9);
    });

    it('scopes edge state selectors to react-flow edge path and keeps hit area neutral', () => {
        const edgeStylesheet = fs.readFileSync(path.resolve(process.cwd(), 'src/workflow/components/canvas/wf-edge.scss'), 'utf8');
        expect(edgeStylesheet.includes('.wf-edge--active path')).toBe(false);
        expect(edgeStylesheet.includes('.wf-edge--active .react-flow__edge-path')).toBe(true);
        expect(edgeStylesheet.includes('.wf-edge__hit-area')).toBe(true);
        expect(edgeStylesheet.includes('stroke: transparent')).toBe(true);
    });

    it('enforces AI Governor LLM port compatibility rules', () => {
        const workflow = createEmptyWorkflow('wf_graph_llm_port_contract');
        const openaiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 3);
        workflow.nodes = [openaiNode, codeNode, governorNode];
        workflow.connections = [];

        expect(
            canAttachConnection(workflow, {
                source: openaiNode.id,
                target: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            })
        ).toBe(true);

        expect(
            canAttachConnection(workflow, {
                source: codeNode.id,
                target: governorNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:llm'
            })
        ).toBe(false);

        expect(
            canAttachConnection(workflow, {
                source: openaiNode.id,
                target: governorNode.id,
                sourceHandle: 'out:output',
                targetHandle: 'cmd:llm'
            })
        ).toBe(false);
    });

    it('enforces AI Agent workflow port compatibility rules', () => {
        const workflow = createEmptyWorkflow('wf_graph_workflow_port_contract');
        const workflowNode = createWorkflowNode(workflow, 'workflow', 'Workflow', 1);
        const executeWorkflowNode = createWorkflowNode(workflow, 'execute-workflow', 'Execute Workflow', 2);
        const routerNode = createWorkflowNode(workflow, 'action-router', 'Router', 3);
        const agentNode = createWorkflowNode(workflow, 'ai-agent', 'AI Agent', 4);
        workflow.nodes = [workflowNode, executeWorkflowNode, routerNode, agentNode];
        workflow.connections = [];

        expect(
            canAttachConnection(workflow, {
                source: workflowNode.id,
                target: agentNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:workflow'
            })
        ).toBe(true);

        expect(
            canAttachConnection(workflow, {
                source: executeWorkflowNode.id,
                target: agentNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:workflow'
            })
        ).toBe(true);

        expect(
            canAttachConnection(workflow, {
                source: routerNode.id,
                target: agentNode.id,
                sourceHandle: 'cmd:command',
                targetHandle: 'cmd:workflow'
            })
        ).toBe(false);
    });

    it('styles the command handle connection indicator with the shared light-grey size override', () => {
        const stylesheet = fs.readFileSync(path.resolve(process.cwd(), 'src/workflow/nodes/base-node.scss'), 'utf8');
        expect(stylesheet.includes('.react-flow__handle.connectionindicator')).toBe(true);
        expect(stylesheet.includes('width: 15px')).toBe(true);
        expect(stylesheet.includes('height: 15px')).toBe(true);
        expect(stylesheet.includes('var(--surface-300, #d1d5db)')).toBe(true);
    });
});
