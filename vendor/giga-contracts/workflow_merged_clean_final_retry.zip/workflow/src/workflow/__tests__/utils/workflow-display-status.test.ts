import { describe, expect, test } from 'vitest';
import { WorkflowDisplayStatusEnum, WorkflowStatusEnum } from '@workflow/ui/workflow/types';
import {
    readWorkflowDisplayStatusLabel,
    resolveWorkflowDisplayStatus
} from '@workflow/ui/workflow/utils/workflow-display-status';

describe('workflow display status', () => {
    test('keeps draft for brand new drafts', () => {
        expect(resolveWorkflowDisplayStatus({ status: WorkflowStatusEnum.Draft })).toBe(WorkflowDisplayStatusEnum.Draft);
    });

    test('keeps published for published records with draft changes', () => {
        expect(resolveWorkflowDisplayStatus({ status: WorkflowStatusEnum.Published, publishedAt: '2026-04-05T00:00:00.000Z' })).toBe(WorkflowDisplayStatusEnum.Published);
    });

    test('promotes running overlay above persisted state', () => {
        expect(resolveWorkflowDisplayStatus({ isRunning: true, status: WorkflowStatusEnum.Published })).toBe(WorkflowDisplayStatusEnum.Running);
    });

    test('marks previously published drafts as un-published', () => {
        expect(resolveWorkflowDisplayStatus({ status: WorkflowStatusEnum.Draft, publishedAt: '2026-04-05T00:00:00.000Z' })).toBe(WorkflowDisplayStatusEnum.UnPublished);
        expect(readWorkflowDisplayStatusLabel(WorkflowDisplayStatusEnum.UnPublished)).toBe('Un-Published');
    });
});
