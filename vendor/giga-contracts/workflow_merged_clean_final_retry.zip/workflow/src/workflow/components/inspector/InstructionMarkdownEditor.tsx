import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import TurndownService from 'turndown';
import { marked } from 'marked';
import { FloatingFieldShell, RichEditorField } from '@workflow/ui/workflow/components/form/index';
import VariableSuggestionsPopover, { useWorkflowVariableSuggestionController } from '@workflow/ui/workflow/components/inspector/VariableSuggestionsPopover';
import { WorkflowVariableSuggestion, buildVariableToken, filterVariableSuggestions, restoreWorkflowVariableTokenEscapes } from '@workflow/ui/workflow/utils/workflow-variables.utils';

interface InstructionMarkdownEditorProps {
    id?: string;
    value: string;
    readOnly?: boolean;
    onChange: (nextMarkdown: string) => void;
    allowVariables?: boolean;
    variableSuggestions?: WorkflowVariableSuggestion[];
    label?: string;
}

interface VariableQueryState {
    open: boolean;
    query: string;
    tokenStart: number;
    tokenEnd: number;
}

interface QuillSelection {
    index: number;
    length: number;
}

interface QuillLikeEditor {
    root: HTMLElement;
    getSelection: () => QuillSelection | null;
    setSelection: (index: number, length?: number) => void;
    getText: (start?: number, length?: number) => string;
    getLength: () => number;
    insertText: (index: number, insertText: string, source?: string) => void;
    deleteText: (index: number, length: number, source?: string) => void;
}

const EMPTY_QUERY_STATE: VariableQueryState = {
    open: false,
    query: '',
    tokenStart: -1,
    tokenEnd: -1
};

const resolveQueryState = (sourcePrefix: string, cursorIndex: number): VariableQueryState => {
    const openIndex = sourcePrefix.lastIndexOf('{{');
    if (openIndex < 0) return EMPTY_QUERY_STATE;
    const closeIndex = sourcePrefix.lastIndexOf('}}');
    if (closeIndex > openIndex) return EMPTY_QUERY_STATE;
    const query = sourcePrefix.slice(openIndex + 2);
    if (/[\r\n{}]/.test(query)) return EMPTY_QUERY_STATE;
    return { open: true, query, tokenStart: openIndex, tokenEnd: cursorIndex };
};

const getDropToken = (event: React.DragEvent<HTMLDivElement>): string => {
    const path = event.dataTransfer.getData('application/x-workflow-variable-path').trim();
    if (path) return buildVariableToken(path);
    return event.dataTransfer.getData('text/plain').trim();
};

const markdownToHtml = (markdownValue: string): string => {
    const rendered = marked.parse(markdownValue ?? '', { async: false });
    return typeof rendered === 'string' ? rendered : '';
};

const InstructionMarkdownEditor: React.FC<InstructionMarkdownEditorProps> = ({ id, value, readOnly = false, onChange, allowVariables = true, variableSuggestions = [], label }) => {
    const editorId = id ?? 'workflow-instruction-markdown';
    const turndownRef = useRef<TurndownService | null>(null);
    const quillRef = useRef<QuillLikeEditor | null>(null);
    const selectionRef = useRef<QuillSelection | null>(null);
    const [isFocused, setIsFocused] = useState<boolean>(false);
    const [queryState, setQueryState] = useState<VariableQueryState>(EMPTY_QUERY_STATE);

    const htmlValue = useMemo(() => markdownToHtml(value), [value]);
    const filteredSuggestions = useMemo(() => filterVariableSuggestions(variableSuggestions, queryState.query), [queryState.query, variableSuggestions]);
    const suggestionsOpen = allowVariables && queryState.open && filteredSuggestions.length > 0;
    const hasValue = value.trim().length > 0;

    const resetQueryState = useCallback(() => setQueryState(EMPTY_QUERY_STATE), []);

    const convertHtmlToMarkdown = (htmlValue: string): string => {
        if (!turndownRef.current) {
            turndownRef.current = new TurndownService();
        }
        return restoreWorkflowVariableTokenEscapes(turndownRef.current.turndown(htmlValue ?? ''));
    };

    const syncQueryFromQuill = useCallback((): void => {
        if (!allowVariables || !quillRef.current) {
            resetQueryState();
            return;
        }
        const quill = quillRef.current;
        const selection = quill.getSelection();
        if (!selection || typeof selection.index !== 'number') {
            resetQueryState();
            return;
        }
        selectionRef.current = {
            index: selection.index,
            length: typeof selection.length === 'number' ? selection.length : 0
        };
        const sourcePrefix = quill.getText(0, selection.index);
        setQueryState(resolveQueryState(sourcePrefix, selection.index));
    }, [allowVariables, resetQueryState]);

    const applySuggestion = useCallback(
        (path: string): void => {
            const token = buildVariableToken(path);

            if (quillRef.current) {
                const quill = quillRef.current;
                const selection = selectionRef.current ?? quill.getSelection() ?? { index: Math.max(quill.getLength() - 1, 0), length: 0 };
                const selectionIndex = typeof selection.index === 'number' ? selection.index : 0;

                if (queryState.open && queryState.tokenStart >= 0 && queryState.tokenEnd >= queryState.tokenStart) {
                    quill.deleteText(queryState.tokenStart, queryState.tokenEnd - queryState.tokenStart, 'user');
                    quill.insertText(queryState.tokenStart, token, 'user');
                    quill.setSelection(queryState.tokenStart + token.length, 0);
                } else {
                    quill.insertText(selectionIndex, token, 'user');
                    quill.setSelection(selectionIndex + token.length, 0);
                }

                resetQueryState();
                syncQueryFromQuill();
                return;
            }

            if (!queryState.open || queryState.tokenStart < 0) {
                onChange(value.trim() ? `${value}\n${token}` : token);
                resetQueryState();
                return;
            }

            const nextValue = `${value.slice(0, queryState.tokenStart)}${token}${value.slice(queryState.tokenEnd)}`;
            onChange(nextValue);
            resetQueryState();
        },
        [onChange, queryState.open, queryState.tokenEnd, queryState.tokenStart, resetQueryState, syncQueryFromQuill, value]
    );

    const { activeIndex, setActiveIndex, handleKeyDown } = useWorkflowVariableSuggestionController({
        open: suggestionsOpen,
        suggestions: filteredSuggestions,
        onSelect: (suggestion) => applySuggestion(suggestion.path),
        onClose: resetQueryState
    });

    useEffect(() => {
        const quill = quillRef.current;
        const rootElement = quill?.root;
        if (!rootElement) return;
        const onKeyDown = (event: KeyboardEvent): void => {
            handleKeyDown(event);
        };
        rootElement.addEventListener('keydown', onKeyDown);
        return () => {
            rootElement.removeEventListener('keydown', onKeyDown);
        };
    }, [handleKeyDown]);

    const editorBody = (
        <div
            className="wf-markdown-editor"
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
                event.preventDefault();
                const token = getDropToken(event);
                if (!token) {
                    return;
                }

                if (quillRef.current) {
                    const quill = quillRef.current;
                    const selection = quill.getSelection() ?? { index: Math.max(quill.getLength() - 1, 0), length: 0 };
                    const index = typeof selection.index === 'number' ? selection.index : 0;
                    quill.insertText(index, token, 'user');
                    quill.setSelection(index + token.length, 0);
                    syncQueryFromQuill();
                    return;
                }

                const nextMarkdown = value.trim() ? `${value}\n${token}` : token;
                onChange(nextMarkdown);
            }}
        >
                <RichEditorField
                    id={editorId}
                    value={htmlValue}
                    readOnly={readOnly}
                    onChange={(nextHtml) => {
                    const nextMarkdown = convertHtmlToMarkdown(nextHtml);
                    onChange(nextMarkdown);
                    if (!allowVariables) {
                        resetQueryState();
                        return;
                    }
                    if (quillRef.current) {
                        syncQueryFromQuill();
                    } else {
                        const fallbackQuery = resolveQueryState(nextMarkdown, nextMarkdown.length);
                        setQueryState(fallbackQuery);
                    }
                }}
                onSelectionChange={(selection) => {
                    setIsFocused(Boolean(selection));
                    if (!allowVariables) {
                        resetQueryState();
                        return;
                    }
                    selectionRef.current = selection;
                    syncQueryFromQuill();
                }}
                onEditorLoad={(quill) => {
                    quillRef.current = quill as QuillLikeEditor;
                    syncQueryFromQuill();
                }}
                label=""
                placeholder="Write instruction markdown..."
                fieldClassName="wf-markdown-editor-field"
            />
            {suggestionsOpen && (
                <VariableSuggestionsPopover
                    suggestions={filteredSuggestions}
                    activeIndex={activeIndex}
                    onActiveIndexChange={setActiveIndex}
                    onSelect={(suggestion) => applySuggestion(suggestion.path)}
                    className="wf-variable-field__suggestions--markdown"
                />
            )}
        </div>
    );

    if (!label) return editorBody;

    return (
        <FloatingFieldShell id={editorId} label={label} active={isFocused || hasValue || suggestionsOpen} multiline className="wf-float-field--markdown">
            {editorBody}
        </FloatingFieldShell>
    );
};

export default InstructionMarkdownEditor;
