import React from 'react';

interface WorkspaceReadonlyFieldProps {
    value: string;
}

export const WorkspaceReadonlyField: React.FC<WorkspaceReadonlyFieldProps> = ({ value }) => {
    return <div className="cnw-readonly-field">{value || '—'}</div>;
};
