import { WorkflowAiChatMessage } from './types';

const STORAGE_PREFIX = 'wf-ai-chat';

const canUseSessionStorage = (): boolean => typeof window !== 'undefined' && typeof window.sessionStorage !== 'undefined';

const toKey = (workflowId: string): string => `${STORAGE_PREFIX}:${workflowId || 'default'}`;

export const loadWorkflowAiSessionMessages = (workflowId: string): WorkflowAiChatMessage[] => {
    if (!canUseSessionStorage()) return [];
    try {
        const raw = window.sessionStorage.getItem(toKey(workflowId));
        if (!raw) return [];
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return [];
        return parsed
            .map((entry) => {
                if (!entry || typeof entry !== 'object') return null;
                const record = entry as Record<string, unknown>;
                const id = String(record.id ?? '').trim();
                const role = String(record.role ?? '').trim();
                const text = String(record.text ?? '').trim();
                const createdAt = String(record.createdAt ?? '').trim();
                if (!id || (role !== 'user' && role !== 'assistant') || !text || !createdAt) return null;
                return {
                    id,
                    role: role as 'user' | 'assistant',
                    text,
                    createdAt
                };
            })
            .filter((entry): entry is WorkflowAiChatMessage => Boolean(entry));
    } catch {
        return [];
    }
};

export const saveWorkflowAiSessionMessages = (workflowId: string, messages: WorkflowAiChatMessage[]): void => {
    if (!canUseSessionStorage()) return;
    try {
        window.sessionStorage.setItem(toKey(workflowId), JSON.stringify(messages));
    } catch {
        // Ignore session-storage quota/private-mode issues.
    }
};

export const clearWorkflowAiSessionMessages = (workflowId: string): void => {
    if (!canUseSessionStorage()) return;
    try {
        window.sessionStorage.removeItem(toKey(workflowId));
    } catch {
        // Ignore session-storage errors.
    }
};
