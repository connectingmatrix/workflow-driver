import type { WorkflowDefinition, WorkflowNodeSchema } from '../types';

export type WorkflowCypherNodeSpec = {
  alias: string;
  modelId: string;
  name?: string;
  runtime: Record<string, unknown>;
};

export type WorkflowCypherEdgeSpec = {
  from: string;
  to: string;
  source: string;
  target: string;
};

export type WorkflowCypherGraph = {
  nodes: WorkflowCypherNodeSpec[];
  edges: WorkflowCypherEdgeSpec[];
};

export type WorkflowNodeSource = {
  id: string;
  schema: WorkflowNodeSchema;
  schemaText: string;
  readme: string;
  worker: string;
  sourceFiles: Record<string, string>;
  directory: string;
};

export type WorkflowCypherCompileResult = {
  workflow: WorkflowDefinition;
  graph: WorkflowCypherGraph;
  warnings: string[];
  validation: {
    ok: boolean;
    errors: string[];
    warnings: string[];
    node_ids: string[];
    connection_count: number;
    terminal_node_ids: string[];
  };
};
