import { getAllNodeSchemas, getNodeModuleById } from '@workflow/nodes/node-utils';
import { WorkflowDefinition, WorkflowNodeFieldMap, WorkflowNodeModel, WorkflowNodeSchema } from '@workflow/ui/workflow/types';
import { normalizeWorkflowModelId } from '@workflow/ui/workflow/utils/workflow-model-id.utils';
const isFinitePosition = (value: unknown): value is { x: number; y: number } => {
    if (!value || typeof value !== 'object') return false;
    const x = Number((value as { x?: unknown }).x);
    const y = Number((value as { y?: unknown }).y);
    return Number.isFinite(x) && Number.isFinite(y);
};

const mergeFieldSchemas = (workflowFields: WorkflowNodeFieldMap, localFields: WorkflowNodeFieldMap): WorkflowNodeFieldMap => {
    const fieldIds = new Set<string>([...Object.keys(localFields), ...Object.keys(workflowFields)]);
    return Array.from(fieldIds).reduce<WorkflowNodeFieldMap>((acc, fieldId) => {
        acc[fieldId] = {
            ...(localFields[fieldId] ?? {}),
            ...(workflowFields[fieldId] ?? {})
        };
        return acc;
    }, {});
};

const mergeNodeSchemaByModel = (modelId: string, workflowSchemas: Record<string, WorkflowNodeSchema>, localSchemas: Record<string, WorkflowNodeSchema>): WorkflowNodeSchema => {
    const workflowSchema = workflowSchemas[modelId];
    const localSchema = localSchemas[modelId];
    if (!workflowSchema && localSchema) return localSchema;
    if (!workflowSchema && !localSchema) {
        return {
            id: modelId,
            iconClass: 'pi pi-box',
            executorKey: modelId,
            instruction: { code: false, markdown: false },
            outputViewers: [{ id: 'json', label: 'JSON', type: 'json' }],
            name: { type: 'string', editable: true, autoGenerate: true },
            fields: {},
            inputs: { input: { allowMultipleArrows: true, side: 'left', order: 1 } },
            outputs: { output: { allowMultipleArrows: true, side: 'right', order: 1 } }
        };
    }
    return {
        ...(localSchema ?? {}),
        ...workflowSchema,
        render: {
            ...(localSchema?.render ?? {}),
            ...(workflowSchema?.render ?? {})
        },
        fields: mergeFieldSchemas(workflowSchema?.fields ?? {}, localSchema?.fields ?? {}),
        inputs: {
            ...(localSchema?.inputs ?? {}),
            ...(workflowSchema?.inputs ?? {})
        },
        outputs: {
            ...(localSchema?.outputs ?? {}),
            ...(workflowSchema?.outputs ?? {})
        }
    };
};
const hydrateNode = (node: WorkflowNodeModel, nodeModels: Record<string, WorkflowNodeSchema>): WorkflowNodeModel => {
    const normalizedModelId = normalizeWorkflowModelId(node);
    const modelId = normalizedModelId || node.modelId;
    const schema = nodeModels[modelId];
    const localModule = getNodeModuleById(modelId);
    const runtime = node.runtime && typeof node.runtime === 'object' && !Array.isArray(node.runtime) ? { ...node.runtime } : { ...(node.properties ?? {}) };
    const portsIn = node.ports?.in && typeof node.ports.in === 'object' ? { ...node.ports.in } : { input: (node.input ?? {}) as Record<string, unknown> };
    const portsOut = node.ports?.out && typeof node.ports.out === 'object' ? { ...node.ports.out } : { output: node.output };
    const output = Object.prototype.hasOwnProperty.call(portsOut, 'output') ? portsOut.output : portsOut;
    const render = {
        ...(localModule?.schema.render ?? {}),
        ...(schema?.render ?? {}),
        ...(node.render ?? {})
    };
    return {
        ...node,
        modelId,
        type: node.type || 'workflowStep',
        position: isFinitePosition(node.position) ? node.position : { x: 0, y: 0 },
        runtime,
        ports: {
            in: portsIn as WorkflowNodeModel['ports']['in'],
            out: portsOut
        },
        input: (portsIn as Record<string, Record<string, unknown>>).input ?? {},
        output,
        properties: runtime,
        inspector: node.inspector
            ? {
                  ...node.inspector,
                  input: node.inspector.input ?? ((portsIn as Record<string, unknown>).input as Record<string, unknown>) ?? {},
                  properties: node.inspector.properties ?? runtime,
                  code: node.inspector.code ?? (typeof runtime.code === 'string' ? runtime.code : ''),
                  markdown: node.inspector.markdown ?? (typeof runtime.markdown === 'string' ? runtime.markdown : '')
              }
            : node.inspector,
        render
    };
};
export const hydrateWorkflowDefinition = (workflow: WorkflowDefinition): WorkflowDefinition => {
    const localSchemas = getAllNodeSchemas();
    const normalizedNodeModelIds = workflow.nodes.map((node) => normalizeWorkflowModelId(node.modelId) || node.modelId);
    const modelIds = new Set<string>([...Object.keys(localSchemas), ...Object.keys(workflow.nodeModels ?? {}), ...normalizedNodeModelIds]);
    const nodeModels = Array.from(modelIds).reduce<Record<string, WorkflowNodeSchema>>((acc, modelId) => {
        if (!modelId) return acc;
        acc[modelId] = mergeNodeSchemaByModel(modelId, workflow.nodeModels ?? {}, localSchemas);
        return acc;
    }, {});
    const nodes = workflow.nodes.map((node) => hydrateNode(node, nodeModels));
    return {
        ...workflow,
        nodeModels,
        nodes
    };
};
const mergeNodeRuntimeState = (currentNode: WorkflowNodeModel, nextNode: WorkflowNodeModel): WorkflowNodeModel => {
    const nextPortsOut = nextNode.ports?.out && typeof nextNode.ports.out === 'object' ? (nextNode.ports.out as Record<string, unknown>) : null;
    const outputFromPorts = nextPortsOut && Object.prototype.hasOwnProperty.call(nextPortsOut, 'output') ? nextPortsOut.output : undefined;
    return {
        ...currentNode,
        runtime: nextNode.runtime,
        ports: nextNode.ports,
        input: nextNode.input ?? currentNode.input,
        output: nextNode.output ?? outputFromPorts ?? currentNode.output,
        status: nextNode.status,
        properties: nextNode.properties ?? nextNode.runtime,
        inspector: nextNode.inspector
            ? {
                  ...(currentNode.inspector ?? {}),
                  ...nextNode.inspector,
                  properties: nextNode.inspector.properties ?? nextNode.runtime
              }
            : currentNode.inspector,
        render: {
            ...(currentNode.render ?? {}),
            ...(nextNode.render ?? {})
        }
    };
};
export const mergeWorkflowRuntimeStateWithUpsert = (current: WorkflowDefinition, next: WorkflowDefinition): WorkflowDefinition => {
    const hydratedNext = hydrateWorkflowDefinition(next);
    const nextNodesById = new Map(hydratedNext.nodes.map((node) => [node.id, node]));
    const mergedNodes = current.nodes.map((node) => {
        const runtimeNode = nextNodesById.get(node.id);
        if (!runtimeNode) return node;
        nextNodesById.delete(node.id);
        return mergeNodeRuntimeState(node, runtimeNode);
    });
    nextNodesById.forEach((node) => mergedNodes.push(node));
    const mergedConnections = new Map(current.connections.map((connection) => [connection.id, connection]));
    hydratedNext.connections.forEach((connection) => mergedConnections.set(connection.id, connection));
    return hydrateWorkflowDefinition({
        ...current,
        metadata: {
            ...current.metadata,
            ...hydratedNext.metadata,
            runtime: {
                ...(current.metadata.runtime ?? {}),
                ...(hydratedNext.metadata.runtime ?? {})
            }
        },
        nodeModels: { ...(current.nodeModels ?? {}), ...(hydratedNext.nodeModels ?? {}) },
        NODE_EXECUTORS: hydratedNext.NODE_EXECUTORS ?? current.NODE_EXECUTORS,
        NODE_EXECUTOR_SIGNATURES: hydratedNext.NODE_EXECUTOR_SIGNATURES ?? current.NODE_EXECUTOR_SIGNATURES,
        nodes: mergedNodes,
        connections: Array.from(mergedConnections.values())
    });
};
