import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { applyEdgeChanges, applyNodeChanges, Connection, EdgeChange, NodeChange, NodeMouseHandler, OnSelectionChangeParams } from '@xyflow/react';
import { Dialog } from 'primereact/dialog';
import { Toast } from 'primereact/toast';
import { OverlayPanel } from 'primereact/overlaypanel';
import { InputText } from 'primereact/inputtext';
import { ContextMenu } from 'primereact/contextmenu';
import { MenuItem } from 'primereact/menuitem';
import { WORKFLOW_CANVAS_SEARCH_FOCUS_ZOOM } from '@workflow/ui/constants';
import JsonlLogsDialog from '@workflow/ui/workflow/components/logs/JsonlLogsDialog';
import Canvas from '@workflow/ui/workflow/components/canvas/Canvas';
import { CanvasInteractionMode } from '@workflow/ui/workflow/components/canvas/CanvasInteractionControls';
import WorkspaceCanvasChrome from '@workflow/ui/workflow/components/designer-layout/workspace/WorkspaceCanvasChrome';
import MetadataDialog from '@workflow/ui/workflow/components/dialogs/MetadataDialog';
import NodeInspector from '@workflow/ui/workflow/components/inspector/NodeInspector';
import { parsePropertiesInput } from '@workflow/ui/workflow/components/inspector/executor';
import NodeLibrary from '@workflow/ui/workflow/components/node-library/NodeLibrary';
import SettingsDialog from '@workflow/ui/workflow/components/dialogs/SettingsDialog';
import Toolbar from '@workflow/ui/workflow/components/toolbar/Toolbar';
import UserNodeDesignerDialog from '@workflow/ui/workflow/components/user-node-designer/UserNodeDesignerDialog';
import { WorkflowFlowEdge, WorkflowFlowInstance, WorkflowFlowNode } from '@workflow/ui/workflow/components/canvas/workflow-flow.types';
import { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import { workflowExecutor, workflowExecutorHostContext } from '@workflow/ui/workflow/executor/runtime';
import { canAttachConnection, buildCanvasEdges } from '@workflow/ui/workflow/utils/workflow-graph.utils';
import { getNormalizedCommandPorts, resolveCommandPortIdFromHandle } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';
import { parseNodeProperties } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';
import { buildCanvasNodes, buildInspectorInputContext, DESIGNER_NODE_HEIGHT, DESIGNER_NODE_WIDTH } from '@workflow/ui/workflow/utils/workflow-canvas-node.utils';
import { mergeCanvasNodes } from '@workflow/ui/workflow/utils/workflow-canvas-merge.utils';
import { hydrateWorkflowDefinition, mergeWorkflowRuntimeStateWithUpsert } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { buildFailureResultFromStatus, clearNodeExecutionArtifacts, isWorkflowNodeModel, patchNodeRuntimeState, toErrorMessage } from '@workflow/ui/workflow/utils/workflow-designer-runtime.utils';
import { buildJsonlOutput, CompatWorkflowLogger, createCompatWorkflowLogger, parseRunLogEvent, resolveLegacyExecutionEvents } from '@workflow/ui/workflow/utils/workflow-log.utils';
import {
    addDroppedNode,
    applyConnection,
    applyEdgeRemovals,
    insertNodeAfterOutputPort,
    insertNodeOnEdge,
    removeNodeFromWorkflow,
    renameNodeInWorkflow,
    toggleNodeEnabled,
    updateNodeInspectorInWorkflow,
    updateNodePosition
} from '@workflow/ui/workflow/utils/workflow-state-updates.utils';
import {
    buildSubworkflowLayout,
    createOrExtendSubworkflow,
    extractSubworkflowIdFromNodeId,
    findExpandedSubworkflowIdAtPosition,
    getCollapsedSubworkflowPosition,
    getExpandedSubworkflowPosition,
    moveSubworkflowNodes,
    SUBWORKFLOW_BOX_PREFIX,
    SUBWORKFLOW_COLLAPSED_PREFIX,
    ungroupSubworkflow,
    toggleSubworkflowCollapsed
} from '@workflow/ui/workflow/utils/workflow-subworkflow.utils';
import { downloadWorkflowJson, exportPayloadToWorkflow } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { runNodeWorkerInit, withNodeExecutors } from '@workflow/nodes/utils/workflow-node-executors.utils';
import { getMissingPlayValidationNodes } from '@workflow/ui/workflow/utils/workflow-validation.utils';
import { copyWorkflowSelection, pasteWorkflowSelection, readWorkflowClipboard } from '@workflow/ui/workflow/utils/workflow-clipboard.utils';
import { isWorkflowClipboardShortcutBlocked } from '@workflow/ui/workflow/utils/workflow-shortcut-guard.utils';
import {
    AiPanel,
    applyWorkflowAiActions,
    buildWorkflowAiHiddenContext,
    buildWorkflowAiPrompt,
    clearWorkflowAiSessionMessages,
    loadWorkflowAiSessionMessages,
    saveWorkflowAiSessionMessages,
    WORKFLOW_AI_CAPABILITIES
} from '@workflow/ui/workflow/ai';
import { WorkflowAiChatMessage, WorkflowAiScope } from '@workflow/ui/workflow/ai/types';
import { prewarmJavascriptRuntimeFrame } from '@workflow/ui/workflow/browser-runtime/js-runtime-iframe';
import { mergeWorkflowUserNodeSchemas, toUserNodeLibraryItem, workflowNeedsUserNodeSchemaSync } from '@workflow/ui/workflow/components/user-node-designer/user-node-designer.utils';
import { parseRecordValue } from '@workflow/ui/workflow/utils/value-utils';
import { findWorkflowCanvasSearchMatches } from '@workflow/ui/workflow/utils/workflow-canvas-search.utils';
import { isRespondEndWorkflowModel } from '@workflow/ui/workflow/utils/workflow-model-id.utils';
import { arrangeWorkflowState } from '@workflow/ui/workflow/utils/workflow-arrange.utils';
import { resolveWorkflowCanvasSettings } from '@workflow/ui/workflow/utils/workflow-canvas-settings.utils';
import { applyWorkflowSettingsChange } from '@workflow/ui/workflow/utils/workflow-settings.utils';
import { buildPublicWorkflowContext } from '@workflow/ui/workflow/utils/workflow-public-context.utils';
import { createWorkflowExecutionTimeoutController } from '@workflow/executor/execution-timeout';
import { WorkflowExecutionModeEnum, WorkflowNodeCatalog, WorkflowRealtimeClient, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import {
    WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS,
    WorkflowAuthModeEnum,
    WorkflowCanvasSettings,
    WorkflowDefinition,
    WorkflowLogLevelEnum,
    WorkflowNodeLibraryItem,
    WorkflowNodeStatus,
    WorkflowNodeStatusEnum,
    WorkflowPlayModeEnum,
    WorkflowPlayLifecycleEnum,
    WorkflowRunLogEvent,
    WorkflowRuntimeSettings,
    WorkflowUserNodeDefinition,
    WorkflowViewerTypeEnum
} from '@workflow/ui/workflow/types';
import '@workflow/ui/workflow/components/canvas/wf-layout.scss';
import '@workflow/ui/workflow/components/canvas/wf-edge.scss';
import '@workflow/ui/workflow/components/node-library/wf-node-library.scss';
import '@workflow/ui/workflow/components/toolbar/wf-toolbar.scss';
import '@workflow/ui/workflow/components/dialogs/wf-dialogs.scss';
import '@xyflow/react/dist/style.css';

interface DesignerDialogProps {
    driver: WorkflowUiDriver;
    nodeCatalog: WorkflowNodeCatalog;
    visible: boolean;
    workflow: WorkflowDefinition | null;
    mode?: 'design' | 'execution';
    broadcastId?: string | null;
    executionWorkflowId?: string | null;
    executionRunId?: string | null;
    executionLive?: boolean;
    executionRequestPayload?: unknown;
    executionLogs?: WorkflowRunLogEvent[];
    allowUserNodeStudio?: boolean;
    allowWorkflowAi?: boolean;
    onHide: () => void;
    onWorkflowChange?: (workflow: WorkflowDefinition) => void;
    nodeLibraryItems?: WorkflowNodeLibraryItem[];
    initialEditable?: boolean;
    onSaveDraft?: () => void;
    saveDraftDisabled?: boolean;
    saveDraftBusy?: boolean;
    onPublish?: () => void;
    publishDisabled?: boolean;
    publishBusy?: boolean;
    onOpenCatalogImport?: () => void;
    catalogImportDisabled?: boolean;
}

type QuickInsertContext =
    | {
          type: 'port';
          nodeId: string;
          outputPortId: string;
      }
    | {
          type: 'edge';
          edgeId: string;
      };

type ExecuteWorkflowOptionsCompat = Parameters<typeof workflowExecutor.executeWorkflow>[1] & {
    logger: CompatWorkflowLogger;
};

type ExecuteNodeStepOptionsCompat = Parameters<typeof workflowExecutor.executeNodeStep>[0] & {
    logger: CompatWorkflowLogger;
};

type LocalWorkflowExecutionResult = {
    workflow: WorkflowDefinition;
    output: unknown;
    logs: WorkflowRunLogEvent[];
    error?: string;
};

const EMPTY_EXECUTION_LOGS: WorkflowRunLogEvent[] = [];

const resolveDialogWorkflow = (workflow: WorkflowDefinition | null, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    if (workflow) {
        return hydrateWorkflowDefinition(workflow);
    }
    return {
        metadata: {
            id: 'workflow_empty',
            name: 'Workflow Designer'
        },
        nodeModels: nodeCatalog.getAllNodeSchemas(),
        nodes: [],
        connections: []
    };
};

const isMissingGraphqlAuthTokenError = (error: unknown): boolean => {
    if (!(error instanceof Error)) return false;
    return /missing authentication token/i.test(error.message);
};

const getDefaultRuntimeSettings = (driver: WorkflowUiDriver): WorkflowRuntimeSettings => {
    const fromDriver = driver.getDefaultRuntimeSettings();
    return {
        graphqlUrl: typeof fromDriver?.graphqlUrl === 'string' ? fromDriver.graphqlUrl : '',
        httpBaseUrl: typeof fromDriver?.httpBaseUrl === 'string' ? fromDriver.httpBaseUrl : undefined,
        authMode: fromDriver?.authMode ?? WorkflowAuthModeEnum.AutoFromCurrentSession,
        manualHeaders: fromDriver?.manualHeaders ?? {},
        maxExecutionSeconds: fromDriver?.maxExecutionSeconds ?? 300
    };
};

const resolveRuntimeSettings = (workflowDefinition: WorkflowDefinition | null | undefined, fallback: WorkflowRuntimeSettings): WorkflowRuntimeSettings => {
    const settings = workflowDefinition?.metadata.runtime?.settings as WorkflowRuntimeSettings | undefined;
    const normalizedTimeout = Number(settings?.maxExecutionSeconds);

    return {
        ...fallback,
        ...(settings ?? {}),
        maxExecutionSeconds: WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS.includes(normalizedTimeout as (typeof WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS)[number]) ? normalizedTimeout : fallback.maxExecutionSeconds
    };
};

const isSubworkflowSyntheticNodeId = (nodeId: string): boolean => nodeId.startsWith(SUBWORKFLOW_COLLAPSED_PREFIX) || nodeId.startsWith(SUBWORKFLOW_BOX_PREFIX);

const resolveNodeTypeLabel = (modelId: string, fallbackName: string, nodeCatalog: WorkflowNodeCatalog): string => {
    const localSchema = nodeCatalog.resolveNodeSchema(modelId, nodeCatalog.getAllNodeSchemas());
    if (localSchema.documentation?.nodeTypeLabel?.trim()) return localSchema.documentation.nodeTypeLabel.trim();
    const fallback = fallbackName.trim();
    if (fallback) return fallback;
    return modelId
        .replace(/[-_]+/g, ' ')
        .split(/\s+/)
        .filter(Boolean)
        .map((part) => `${part.charAt(0).toUpperCase()}${part.slice(1)}`)
        .join(' ');
};

const parseHandlePortName = (handleId: string | undefined, fallbackPort: string): string => {
    if (!handleId) return fallbackPort;
    const [, parsedPort] = handleId.split(':');
    return parsedPort?.trim() ? parsedPort : fallbackPort;
};

const remapEdgeForCollapsedSubworkflow = (edge: WorkflowFlowEdge, nodeToSubworkflow: Map<string, string>): { source: string; target: string; sourceHandle: string | null | undefined; targetHandle: string | null | undefined } | null => {
    if (!edge.source || !edge.target) return null;
    const sourceSubworkflowId = nodeToSubworkflow.get(edge.source);
    const targetSubworkflowId = nodeToSubworkflow.get(edge.target);
    const source = sourceSubworkflowId ? `${SUBWORKFLOW_COLLAPSED_PREFIX}${sourceSubworkflowId}` : edge.source;
    const target = targetSubworkflowId ? `${SUBWORKFLOW_COLLAPSED_PREFIX}${targetSubworkflowId}` : edge.target;
    if (source === target) return null;
    return {
        source,
        target,
        sourceHandle: sourceSubworkflowId ? 'out:output' : edge.sourceHandle,
        targetHandle: targetSubworkflowId ? 'in:input' : edge.targetHandle
    };
};

const createWorkflowAiMessage = (role: WorkflowAiChatMessage['role'], text: string): WorkflowAiChatMessage => ({
    id: `wfai_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
    role,
    text,
    createdAt: new Date().toISOString()
});

const areUserNodeDefinitionsEqual = (left: WorkflowUserNodeDefinition[], right: WorkflowUserNodeDefinition[]): boolean => {
    if (left === right) return true;
    if (left.length !== right.length) return false;
    for (let index = 0; index < left.length; index += 1) {
        const leftNode = left[index];
        const rightNode = right[index];
        if (!leftNode || !rightNode) return false;
        if (leftNode.id !== rightNode.id) return false;
        if ((leftNode.updatedAt || '') !== (rightNode.updatedAt || '')) return false;
    }
    return true;
};

const extractTerminalWorkflowPayload = (workflow: WorkflowDefinition | null): unknown => {
    const endNodes = (workflow?.nodes || []).filter((node) => isRespondEndWorkflowModel(node));
    const endNode = endNodes[endNodes.length - 1];
    const output = endNode?.ports?.out && Object.prototype.hasOwnProperty.call(endNode.ports.out, 'output') ? endNode.ports.out.output : endNode?.output;

    if (output && typeof output === 'object' && !Array.isArray(output)) {
        const record = output as Record<string, unknown>;
        const payloadKeys = Object.keys(record).filter((key) => key !== '__workflow');
        if (payloadKeys.length === 1 && payloadKeys[0] === 'input') {
            return record.input;
        }
    }

    return output;
};

const DesignerDialog: React.FC<DesignerDialogProps> = ({
    driver,
    nodeCatalog,
    visible,
    workflow,
    mode = 'design',
    broadcastId = null,
    executionWorkflowId = null,
    executionRunId = null,
    executionLive = false,
    executionRequestPayload = null,
    executionLogs = EMPTY_EXECUTION_LOGS,
    allowUserNodeStudio = true,
    allowWorkflowAi = true,
    onHide,
    onWorkflowChange,
    nodeLibraryItems,
    initialEditable = false,
    onSaveDraft,
    saveDraftDisabled = false,
    saveDraftBusy = false,
    onPublish,
    publishDisabled = false,
    publishBusy = false,
    onOpenCatalogImport,
    catalogImportDisabled = false
}) => {
    const setDesignerModeActive = useCallback((_active: boolean): void => undefined, []);
    const isExecutionMode = mode === 'execution';
    const defaultRuntimeSettings = useMemo(() => getDefaultRuntimeSettings(driver), [driver]);
    const baseNodeLibraryItems = useMemo(() => (nodeLibraryItems || nodeCatalog.getNodeLibraryItems()).filter((item) => item.modelId !== 'ai-governor'), [nodeCatalog, nodeLibraryItems]);
    const [workflowState, setWorkflowState] = useState<WorkflowDefinition | null>(null);
    const [userNodeDefinitions, setUserNodeDefinitions] = useState<WorkflowUserNodeDefinition[]>([]);
    const [isUserNodeStudioVisible, setIsUserNodeStudioVisible] = useState<boolean>(false);
    const [canvasNodes, setCanvasNodes] = useState<WorkflowFlowNode[]>([]);
    const [canvasEdges, setCanvasEdges] = useState<WorkflowFlowEdge[]>([]);
    const [flowInstance, setFlowInstance] = useState<WorkflowFlowInstance | null>(null);
    const [fitViewTick, setFitViewTick] = useState<number>(0);
    const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
    const [inspectorNodeId, setInspectorNodeId] = useState<string | null>(null);
    const [playLifecycle, setPlayLifecycle] = useState<WorkflowPlayLifecycleEnum>(WorkflowPlayLifecycleEnum.Idle);
    const [activeIndex, setActiveIndex] = useState<number>(-1);
    const [isEditable, setIsEditable] = useState<boolean>(false);
    const [isNodeLibraryVisible, setIsNodeLibraryVisible] = useState<boolean>(initialEditable);
    const [isCanvasInteractive, setIsCanvasInteractive] = useState<boolean>(initialEditable);
    const [canvasInteractionMode, setCanvasInteractionMode] = useState<CanvasInteractionMode>('select');
    const [showMetadata, setShowMetadata] = useState<boolean>(false);
    const [showLogs, setShowLogs] = useState<boolean>(false);
    const [showSettings, setShowSettings] = useState<boolean>(false);
    const [quickInsertContext, setQuickInsertContext] = useState<QuickInsertContext | null>(null);
    const [quickInsertSearch, setQuickInsertSearch] = useState<string>('');
    const [canvasSearch, setCanvasSearch] = useState<string>('');
    const [activeSearchMatchIndex, setActiveSearchMatchIndex] = useState<number>(0);
    const [runtimeSettings, setRuntimeSettings] = useState<WorkflowRuntimeSettings>(defaultRuntimeSettings);
    const [executionRunLogs, setExecutionRunLogs] = useState<WorkflowRunLogEvent[]>([]);
    const [sessionLogs, setSessionLogs] = useState<WorkflowRunLogEvent[]>([]);
    const [playMode, setPlayMode] = useState<WorkflowPlayModeEnum>(WorkflowPlayModeEnum.Local);
    const [contextMenuSelectionIds, setContextMenuSelectionIds] = useState<string[]>([]);
    const [contextMenuSubworkflowId, setContextMenuSubworkflowId] = useState<string | null>(null);
    const [isAiPanelVisible, setIsAiPanelVisible] = useState<boolean>(false);
    const [isAiRequestInFlight, setIsAiRequestInFlight] = useState<boolean>(false);
    const [aiScope, setAiScope] = useState<WorkflowAiScope>({ mode: 'workflow' });
    const [aiMessages, setAiMessages] = useState<WorkflowAiChatMessage[]>([]);
    const abortControllerRef = useRef<AbortController | null>(null);
    const toastRef = useRef<Toast>(null);
    const quickInsertPanelRef = useRef<OverlayPanel>(null);
    const subworkflowContextMenuRef = useRef<ContextMenu>(null);
    const openedWorkflowIdRef = useRef<string>('');
    const silentWorkflowStateRef = useRef<WorkflowDefinition | null>(null);
    const workflowStateRef = useRef<WorkflowDefinition | null>(workflowState);
    const inspectorDraftRef = useRef<Record<string, { propertiesEditorState: Record<string, unknown>; code: string; markdown: string }>>({});
    const onWorkflowChangeRef = useRef<DesignerDialogProps['onWorkflowChange']>(onWorkflowChange);
    const onExecuteStepFromNodeRef = useRef<(nodeId: string) => void>(() => undefined);
    const runNodeStepRef = useRef<(payload: { nodeId: string; properties: Record<string, unknown>; code: string; markdown: string }) => Promise<{ output: unknown; logs: string[]; error: string | null }>>(async () => ({
        output: null,
        logs: [],
        error: 'Node step runner is not ready yet.'
    }));
    const isInteractingRef = useRef<boolean>(false);
    const workflowSocketClientRef = useRef<WorkflowRealtimeClient | null>(null);
    const workflowSocketLogUnsubscribeRef = useRef<(() => void) | null>(null);
    const selectedCanvasNodeIdsRef = useRef<string[]>([]);
    const subworkflowDragOriginByNodeIdRef = useRef<Record<string, { x: number; y: number }>>({});
    const initialResizeDispatchedRef = useRef<boolean>(false);
    const subworkflowContextSnapshotRef = useRef<{ selectionIds: string[]; subworkflowId: string | null }>({ selectionIds: [], subworkflowId: null });
    const subworkflowContextMenuOpenRef = useRef<boolean>(false);
    const sessionLogsRef = useRef<WorkflowRunLogEvent[]>([]);
    const playSessionIdRef = useRef<number>(0);
    const serverRealtimePatchedNodeIdsRef = useRef<Set<string>>(new Set());
    const serverFailedNodeIdsRef = useRef<Set<string>>(new Set());
    const userNodeLibraryItems = useMemo(() => userNodeDefinitions.map(toUserNodeLibraryItem), [userNodeDefinitions]);
    const executionReplayInput = useMemo(() => parseRecordValue(executionRequestPayload), [executionRequestPayload]);
    const persistedExecutionLogs = useMemo(() => (Array.isArray(executionLogs) ? executionLogs : []).map((entry) => parseRunLogEvent(entry)).filter((entry): entry is WorkflowRunLogEvent => Boolean(entry)), [executionLogs]);
    const resolvedNodeLibraryItems = useMemo(() => {
        const dedupedByModelId = new Map<string, WorkflowNodeLibraryItem>();
        [...baseNodeLibraryItems, ...userNodeLibraryItems].forEach((item) => {
            dedupedByModelId.set(item.modelId, item);
        });
        return Array.from(dedupedByModelId.values());
    }, [baseNodeLibraryItems, userNodeLibraryItems]);
    const orderedNodeIds = useMemo(() => workflowState?.nodes.map((node) => node.id) ?? [], [workflowState?.nodes]);
    const aiSessionWorkflowId = workflowState?.metadata.id ?? '__workflow_ai_default__';
    const executionLogEvents = isExecutionMode && !executionLive ? executionRunLogs : sessionLogs;
    const executionLogsJsonl = useMemo(() => buildJsonlOutput(executionLogEvents), [executionLogEvents]);
    const isPlaying = playLifecycle !== WorkflowPlayLifecycleEnum.Idle;
    const executionSessionKey = isExecutionMode
        ? `${workflow?.metadata?.id ?? '__empty_workflow__'}:${executionRunId ?? ''}:${executionLive ? 'live' : 'static'}`
        : workflow?.metadata?.id ?? '__empty_workflow__';
    const inspectedNode = useMemo(() => workflowState?.nodes.find((node) => node.id === inspectorNodeId) ?? null, [inspectorNodeId, workflowState?.nodes]);
    const subworkflowLayout = useMemo(() => (workflowState ? buildSubworkflowLayout(workflowState) : null), [workflowState]);
    const canvasSettings = useMemo<Required<WorkflowCanvasSettings>>(() => resolveWorkflowCanvasSettings(workflowState), [workflowState]);
    const onExecuteStepFromNode = useCallback((nodeId: string): void => {
        onExecuteStepFromNodeRef.current(nodeId);
    }, [defaultRuntimeSettings]);
    const updateWorkflow = useCallback((updater: (current: WorkflowDefinition) => WorkflowDefinition): void => {
        setWorkflowState((previous) => {
            if (!previous) return previous;
            const next = updater(previous);
            workflowStateRef.current = next;
            return next;
        });
    }, []);
    const setWorkflowStateSilently = useCallback((updater: (current: WorkflowDefinition) => WorkflowDefinition): void => {
        setWorkflowState((previous) => {
            if (!previous) return previous;
            const next = updater(previous);
            if (next === previous) return previous;
            silentWorkflowStateRef.current = next;
            workflowStateRef.current = next;
            return next;
        });
    }, []);
    const replaceWorkflowStateSilently = useCallback((nextWorkflow: WorkflowDefinition): void => {
        silentWorkflowStateRef.current = nextWorkflow;
        workflowStateRef.current = nextWorkflow;
        setWorkflowState(nextWorkflow);
    }, []);
    const replaceWorkflowState = useCallback(
        (nextWorkflow: WorkflowDefinition, options?: { fitView?: boolean }) => {
            const hydrated = mergeWorkflowUserNodeSchemas(hydrateWorkflowDefinition(nextWorkflow), userNodeDefinitions);
            workflowStateRef.current = hydrated;
            setWorkflowState(hydrated);
            setRuntimeSettings(resolveRuntimeSettings(hydrated, defaultRuntimeSettings));
            if (options?.fitView) {
                setFitViewTick((previous) => previous + 1);
            }
        },
        [defaultRuntimeSettings, userNodeDefinitions]
    );
    const arrangeWorkflow = useCallback(
        async (snapshot?: WorkflowDefinition, options?: { fitView?: boolean }) => {
            const activeWorkflow = snapshot || workflowStateRef.current;
            if (!activeWorkflow) return;
            const arranged = await arrangeWorkflowState(activeWorkflow);
            if (workflowStateRef.current !== activeWorkflow) return;
            replaceWorkflowState(arranged, options);
        },
        [replaceWorkflowState]
    );
    const resetAiScopeToWorkflow = useCallback(() => {
        setAiScope({ mode: 'workflow' });
    }, []);
    const getWorkflowSocketClient = useCallback((): WorkflowRealtimeClient => {
        if (!workflowSocketClientRef.current) {
            workflowSocketClientRef.current = driver.createRealtimeClient();
        }
        return workflowSocketClientRef.current;
    }, [driver]);
    const resetSubworkflowContextState = useCallback(() => {
        subworkflowContextMenuOpenRef.current = false;
        subworkflowContextSnapshotRef.current = { selectionIds: [], subworkflowId: null };
        setContextMenuSelectionIds([]);
        setContextMenuSubworkflowId(null);
    }, []);
    const closePrimeContextMenu = useCallback(() => {
        subworkflowContextMenuRef.current?.hide({
            preventDefault: () => undefined,
            stopPropagation: () => undefined
        } as unknown as React.SyntheticEvent);
    }, []);
    const hideSubworkflowContextMenu = useCallback(() => {
        closePrimeContextMenu();
        resetSubworkflowContextState();
    }, [closePrimeContextMenu, resetSubworkflowContextState]);
    const appendSessionLogEvents = useCallback((nextEntries: unknown): void => {
        const normalizedEntries = Array.isArray(nextEntries)
            ? nextEntries.map((entry) => parseRunLogEvent(entry)).filter((entry): entry is WorkflowRunLogEvent => Boolean(entry))
            : [parseRunLogEvent(nextEntries)].filter((entry): entry is WorkflowRunLogEvent => Boolean(entry));
        if (!normalizedEntries.length) return;
        setSessionLogs((previous) => [...(Array.isArray(previous) ? previous : []), ...normalizedEntries]);
    }, []);
    const reportExecutionFailure = useCallback(
        (scope: 'local' | 'server' | 'step', error: unknown, workflowId: string): void => {
            const message = error instanceof Error ? error.message : `Workflow ${scope} execution failed.`;
            const stack = error instanceof Error ? error.stack : undefined;
            console.error(`[WorkflowDesigner:${scope}] ${message}`, error);
            appendSessionLogEvents({
                timestamp: new Date().toISOString(),
                level: WorkflowLogLevelEnum.Error,
                event: `workflow.${scope}.error`,
                workflowId,
                runId: `designer_${scope}_${Date.now().toString(36)}`,
                message,
                data: stack ? { stack } : undefined
            });
        },
        [appendSessionLogEvents]
    );
    const applyServerWorkflowEvent = useCallback(
        (entry: WorkflowRunLogEvent, orderedIds: string[]): void => {
            appendSessionLogEvents(entry);
            if (entry.event === 'node.started' && entry.nodeId) {
                const index = orderedIds.indexOf(entry.nodeId);
                if (index >= 0) {
                    setActiveIndex(index);
                }
                updateWorkflow((previous) => ({
                    ...previous,
                    nodes: previous.nodes.map((node) => (node.id === entry.nodeId ? clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Running) : node))
                }));
                return;
            }
            if (entry.event === 'node.finished' && entry.nodeId) {
                const status = (entry.data as { status?: WorkflowNodeStatusEnum } | undefined)?.status ?? WorkflowNodeStatusEnum.Passed;
                updateWorkflow((previous) => ({
                    ...previous,
                    nodes: previous.nodes.map((node) => {
                        if (node.id !== entry.nodeId) return node;
                        if (serverFailedNodeIdsRef.current.has(entry.nodeId as string)) {
                            return { ...node, status: WorkflowNodeStatusEnum.Failed };
                        }
                        return { ...node, status };
                    })
                }));
                return;
            }
            if (entry.event === 'node.failed' && entry.nodeId) {
                serverFailedNodeIdsRef.current.add(entry.nodeId);
                updateWorkflow((previous) => ({
                    ...previous,
                    nodes: previous.nodes.map((node) => (node.id === entry.nodeId ? { ...node, status: WorkflowNodeStatusEnum.Failed } : node))
                }));
                return;
            }
            if (entry.event === 'node.delta' && entry.nodeId) {
                const deltaNode = isWorkflowNodeModel((entry.data as { node?: unknown } | undefined)?.node) ? (entry.data as { node: WorkflowDefinition['nodes'][number] }).node : null;
                if (!deltaNode) return;
                serverRealtimePatchedNodeIdsRef.current.add(entry.nodeId);
                updateWorkflow((previous) => ({
                    ...previous,
                    nodes: previous.nodes.map((node) => (node.id === entry.nodeId ? patchNodeRuntimeState(node, deltaNode) : node))
                }));
            }
        },
        [appendSessionLogEvents, updateWorkflow]
    );
    const resolveEffectiveSelectionIds = useCallback((): string[] => {
        if (selectedCanvasNodeIdsRef.current.length) return selectedCanvasNodeIdsRef.current;
        return selectedNodeId ? [selectedNodeId] : [];
    }, [selectedNodeId]);
    const resolveClipboardSelectionIds = useCallback((): string[] => resolveEffectiveSelectionIds().filter((nodeId) => !isSubworkflowSyntheticNodeId(nodeId)), [resolveEffectiveSelectionIds]);
    const openSubworkflowContextMenu = useCallback(
        (event: MouseEvent | React.MouseEvent, selectionIdsOverride?: string[]): boolean => {
            const selectionIds = selectionIdsOverride?.length ? selectionIdsOverride : resolveEffectiveSelectionIds();
            event.preventDefault?.();
            event.stopPropagation?.();
            const selectedSubworkflowId = selectionIds.map((nodeId) => extractSubworkflowIdFromNodeId(nodeId)).find((value): value is string => Boolean(value)) ?? null;
            subworkflowContextMenuOpenRef.current = true;
            subworkflowContextSnapshotRef.current = {
                selectionIds: [...selectionIds],
                subworkflowId: selectedSubworkflowId
            };
            setContextMenuSelectionIds(selectionIds);
            setContextMenuSubworkflowId(selectedSubworkflowId);
            subworkflowContextMenuRef.current?.show(event as unknown as React.MouseEvent<HTMLElement>);
            return true;
        },
        [resolveEffectiveSelectionIds]
    );
    useEffect(() => {
        workflowStateRef.current = workflowState;
    }, [workflowState]);
    useEffect(() => {
        if (!visible || !allowUserNodeStudio) {
            setUserNodeDefinitions([]);
            return;
        }
        let cancelled = false;
        driver
            .listWorkflowUserNodes(false)
            .then((nextNodes) => {
                if (cancelled) return;
                setUserNodeDefinitions(nextNodes);
            })
            .catch((error) => {
                if (isMissingGraphqlAuthTokenError(error)) {
                    return;
                }
                console.error('[WorkflowDesigner] Could not load user nodes.', error);
            });
        return () => {
            cancelled = true;
        };
    }, [allowUserNodeStudio, driver, visible]);
    useEffect(() => {
        if (allowWorkflowAi) return;
        setIsAiPanelVisible(false);
        setIsAiRequestInFlight(false);
    }, [allowWorkflowAi]);
    useEffect(() => {
        if (!workflowState || !userNodeDefinitions.length) return;
        if (!workflowNeedsUserNodeSchemaSync(workflowState, userNodeDefinitions)) return;
        setWorkflowStateSilently((previous) => mergeWorkflowUserNodeSchemas(previous, userNodeDefinitions));
    }, [setWorkflowStateSilently, userNodeDefinitions, workflowState]);
    useEffect(() => {
        if (!visible) {
            return;
        }

        setDesignerModeActive(true);
        return () => {
            setDesignerModeActive(false);
        };
    }, [setDesignerModeActive, visible]);
    useEffect(() => {
        sessionLogsRef.current = sessionLogs;
    }, [sessionLogs]);
    useEffect(() => {
        onWorkflowChangeRef.current = onWorkflowChange;
    }, [onWorkflowChange]);
    useEffect(() => {
        return () => {
            workflowSocketLogUnsubscribeRef.current?.();
            workflowSocketLogUnsubscribeRef.current = null;
            workflowSocketClientRef.current = null;
        };
    }, []);
    useEffect(() => {
        if (!visible) {
            abortControllerRef.current?.abort();
            abortControllerRef.current = null;
            playSessionIdRef.current += 1;
            serverRealtimePatchedNodeIdsRef.current.clear();
            serverFailedNodeIdsRef.current.clear();
            openedWorkflowIdRef.current = '';
            silentWorkflowStateRef.current = null;
            workflowSocketLogUnsubscribeRef.current?.();
            workflowSocketLogUnsubscribeRef.current = null;
            quickInsertPanelRef.current?.hide();
            closePrimeContextMenu();
            setQuickInsertContext(null);
            setQuickInsertSearch('');
            setSelectedNodeId(null);
            setInspectorNodeId(null);
            selectedCanvasNodeIdsRef.current = [];
            resetSubworkflowContextState();
            setPlayLifecycle(WorkflowPlayLifecycleEnum.Idle);
            setActiveIndex(-1);
            setPlayMode(WorkflowPlayModeEnum.Local);
            setIsUserNodeStudioVisible(false);
            setIsAiPanelVisible(false);
            setIsAiRequestInFlight(false);
            resetAiScopeToWorkflow();
            return;
        }
        if (openedWorkflowIdRef.current === executionSessionKey) {
            return;
        }
        openedWorkflowIdRef.current = executionSessionKey;
        const hydrated = mergeWorkflowUserNodeSchemas(resolveDialogWorkflow(workflow, nodeCatalog), userNodeDefinitions);
        replaceWorkflowStateSilently(hydrated);
        setRuntimeSettings(resolveRuntimeSettings(hydrated, defaultRuntimeSettings));
        setExecutionRunLogs(isExecutionMode ? persistedExecutionLogs : []);
        setSessionLogs(isExecutionMode ? persistedExecutionLogs : []);
        setSelectedNodeId(null);
        setInspectorNodeId(null);
        selectedCanvasNodeIdsRef.current = [];
        closePrimeContextMenu();
        resetSubworkflowContextState();
        setPlayLifecycle(isExecutionMode && executionLive ? WorkflowPlayLifecycleEnum.Running : WorkflowPlayLifecycleEnum.Idle);
        setActiveIndex(-1);
        setPlayMode(isExecutionMode && executionLive ? WorkflowPlayModeEnum.Server : WorkflowPlayModeEnum.Local);
        setIsEditable(isExecutionMode ? false : initialEditable);
        setIsNodeLibraryVisible(isExecutionMode ? false : initialEditable);
        setIsCanvasInteractive(isExecutionMode ? false : initialEditable);
        setCanvasInteractionMode('select');
        setFitViewTick((previous) => previous + 1);
        resetAiScopeToWorkflow();
    }, [closePrimeContextMenu, defaultRuntimeSettings, executionLive, executionLogs, executionSessionKey, initialEditable, isExecutionMode, nodeCatalog, persistedExecutionLogs, replaceWorkflowStateSilently, resetAiScopeToWorkflow, resetSubworkflowContextState, userNodeDefinitions, visible, workflow]);
    useEffect(() => {
        if (!visible) return;
        void prewarmJavascriptRuntimeFrame().catch((error) => {
            console.warn('Workflow runtime iframe prewarm failed.', error);
        });
    }, [visible]);
    useEffect(() => {
        setWorkflowStateSilently((previous) => {
            if (!previous) return previous;
            const currentSettings = previous.metadata.runtime?.settings as WorkflowRuntimeSettings | undefined;
            if (
                currentSettings?.graphqlUrl === runtimeSettings.graphqlUrl &&
                currentSettings?.httpBaseUrl === runtimeSettings.httpBaseUrl &&
                currentSettings?.authMode === runtimeSettings.authMode &&
                currentSettings?.maxExecutionSeconds === runtimeSettings.maxExecutionSeconds &&
                JSON.stringify(currentSettings?.manualHeaders || {}) === JSON.stringify(runtimeSettings.manualHeaders || {})
            ) {
                return previous;
            }
            return {
                ...previous,
                metadata: {
                    ...previous.metadata,
                    runtime: {
                        ...(previous.metadata.runtime ?? {}),
                        settings: runtimeSettings
                    }
                }
            };
        });
    }, [runtimeSettings, setWorkflowStateSilently]);
    useEffect(() => {
        if (!workflowState) return;
        if (silentWorkflowStateRef.current === workflowState) {
            silentWorkflowStateRef.current = null;
            return;
        }
        onWorkflowChangeRef.current?.(workflowState);
    }, [workflowState]);
    useEffect(() => {
        const workflowId = workflowState?.metadata?.id;
        if (!workflowId) return;
        const { testUrl, publishedUrl } = driver.buildWorkflowWebhookUrls(workflowId);
        setWorkflowStateSilently((previous) => {
            if (!previous) return previous;
            let changed = false;
            const nextNodes = previous.nodes.map((node) => {
                if (node.modelId !== 'start') {
                    return node;
                }
                const runtime = parseRecordValue(node.runtime);
                if (runtime.webhookTestUrl === testUrl && runtime.webhookPublishedUrl === publishedUrl) {
                    return node;
                }
                changed = true;
                const nextRuntime = {
                    ...runtime,
                    webhookTestUrl: testUrl,
                    webhookPublishedUrl: publishedUrl
                };
                return {
                    ...node,
                    runtime: nextRuntime,
                    properties: {
                        ...(parseRecordValue(node.properties) || {}),
                        webhookTestUrl: testUrl,
                        webhookPublishedUrl: publishedUrl
                    },
                    inspector: node.inspector
                        ? {
                              ...node.inspector,
                              properties: {
                                  ...(parseRecordValue(node.inspector.properties) || {}),
                                  webhookTestUrl: testUrl,
                                  webhookPublishedUrl: publishedUrl
                              }
                          }
                        : node.inspector
                };
            });
            if (!changed) {
                return previous;
            }
            return {
                ...previous,
                metadata: {
                    ...previous.metadata,
                    webhook: {
                        ...(parseRecordValue(previous.metadata.webhook) || {}),
                        testUrl,
                        publishedUrl
                    }
                },
                nodes: nextNodes
            };
        });
    }, [driver, setWorkflowStateSilently, workflowState?.metadata?.id]);
    useEffect(() => {
        if (!visible) return;
        setAiMessages(loadWorkflowAiSessionMessages(aiSessionWorkflowId));
    }, [aiSessionWorkflowId, visible]);
    useEffect(() => {
        saveWorkflowAiSessionMessages(aiSessionWorkflowId, aiMessages);
    }, [aiMessages, aiSessionWorkflowId]);
    useEffect(() => {
        if (!visible || !flowInstance) return;
        const frame = window.requestAnimationFrame(() => {
            flowInstance.fitView({ padding: 0.2, duration: 320 });
        });
        return () => window.cancelAnimationFrame(frame);
    }, [fitViewTick, flowInstance, visible]);
    useEffect(() => {
        if (!visible || !flowInstance || initialResizeDispatchedRef.current) return;
        initialResizeDispatchedRef.current = true;
        const frame = window.requestAnimationFrame(() => {
            window.dispatchEvent(new Event('resize'));
        });
        return () => window.cancelAnimationFrame(frame);
    }, [flowInstance, visible, workflowState?.metadata?.id]);
    useEffect(() => {
        if (visible) return;
        initialResizeDispatchedRef.current = false;
    }, [visible]);
    useEffect(() => {
        const workflowId = workflowState?.metadata?.id;
        if (!visible || !workflowId) {
            return;
        }

        const socketClient = getWorkflowSocketClient();
        if (typeof socketClient.openEditorSession !== 'function' || typeof socketClient.heartbeatEditorSession !== 'function') {
            return;
        }
        let cancelled = false;
        let heartbeatInterval: number | null = null;

        void socketClient
            .openEditorSession({
                workflowId,
                editable: isEditable
            })
            .then(() => {
                if (cancelled) {
                    socketClient.closeEditorSession({ workflowId });
                    return;
                }
                heartbeatInterval = window.setInterval(() => {
                    void socketClient.heartbeatEditorSession({
                        workflowId,
                        editable: isEditable
                    });
                }, 15_000);
            })
            .catch((error) => {
                toastRef.current?.show({
                    severity: 'warn',
                    summary: 'Workflow editor sync',
                    detail: error instanceof Error ? error.message : 'Could not register the workflow editor session.',
                    life: 4200
                });
            });

        return () => {
            cancelled = true;
            if (heartbeatInterval !== null) {
                window.clearInterval(heartbeatInterval);
            }
            if (typeof socketClient.closeEditorSession === 'function') {
                socketClient.closeEditorSession({ workflowId });
            }
        };
    }, [getWorkflowSocketClient, isEditable, visible, workflowState?.metadata?.id]);
    useEffect(() => {
        if (!flowInstance || activeIndex < 0 || !orderedNodeIds[activeIndex]) return;
        const node = workflowState?.nodes.find((item) => item.id === orderedNodeIds[activeIndex]);
        if (!node) return;
        flowInstance.setCenter(node.position.x + DESIGNER_NODE_WIDTH / 2, node.position.y + DESIGNER_NODE_HEIGHT / 2, { zoom: WORKFLOW_CANVAS_SEARCH_FOCUS_ZOOM, duration: 700 });
    }, [activeIndex, flowInstance, orderedNodeIds, workflowState?.nodes]);
    const canvasSearchMatchNodeIds = useMemo(() => findWorkflowCanvasSearchMatches(workflowState, canvasSearch, nodeCatalog), [canvasSearch, nodeCatalog, workflowState]);
    const activeSearchMatchNodeId = canvasSearchMatchNodeIds[activeSearchMatchIndex] ?? null;
    const goToNextSearchMatch = useCallback(() => {
        if (canvasSearchMatchNodeIds.length < 2) return;
        setActiveSearchMatchIndex((previous) => (previous + 1) % canvasSearchMatchNodeIds.length);
    }, [canvasSearchMatchNodeIds]);
    const goToPreviousSearchMatch = useCallback(() => {
        if (canvasSearchMatchNodeIds.length < 2) return;
        setActiveSearchMatchIndex((previous) => (previous - 1 + canvasSearchMatchNodeIds.length) % canvasSearchMatchNodeIds.length);
    }, [canvasSearchMatchNodeIds]);
    const onCanvasSearchKeyDown = useCallback(
        (event: React.KeyboardEvent<HTMLInputElement>) => {
            if (event.key !== 'Enter' || canvasSearchMatchNodeIds.length < 2) return;
            event.preventDefault();
            if (event.shiftKey) {
                goToPreviousSearchMatch();
                return;
            }
            goToNextSearchMatch();
        },
        [canvasSearchMatchNodeIds.length, goToNextSearchMatch, goToPreviousSearchMatch]
    );
    useEffect(() => {
        if (!canvasSearch.trim()) {
            setActiveSearchMatchIndex(0);
            return;
        }
        if (!canvasSearchMatchNodeIds.length) {
            setActiveSearchMatchIndex(0);
            return;
        }
        setActiveSearchMatchIndex((previous) => (previous >= canvasSearchMatchNodeIds.length ? 0 : previous));
    }, [canvasSearch, canvasSearchMatchNodeIds]);
    useEffect(() => {
        if (!flowInstance || !activeSearchMatchNodeId) return;
        const node = workflowState?.nodes.find((item) => item.id === activeSearchMatchNodeId);
        if (!node) return;
        setSelectedNodeId(node.id);
        flowInstance.setCenter(node.position.x + DESIGNER_NODE_WIDTH / 2, node.position.y + DESIGNER_NODE_HEIGHT / 2, {
            zoom: WORKFLOW_CANVAS_SEARCH_FOCUS_ZOOM,
            duration: 480
        });
    }, [activeSearchMatchNodeId, flowInstance, workflowState?.nodes]);
    useEffect(() => {
        if (!inspectorNodeId) return;
        if (inspectedNode) return;
        setInspectorNodeId(null);
    }, [inspectedNode, inspectorNodeId]);
    useEffect(() => {
        if (aiScope.mode !== 'node' || !aiScope.nodeId) return;
        const exists = workflowState?.nodes.some((node) => node.id === aiScope.nodeId);
        if (exists) return;
        setAiScope({ mode: 'workflow' });
    }, [aiScope.mode, aiScope.nodeId, workflowState?.nodes]);
    const selectedNodeInspector = useMemo<WorkflowInspectorConfig | null>(() => {
        if (!inspectedNode) return null;
        const upstream = buildInspectorInputContext(workflowState, inspectedNode.id, (inspectedNode.ports?.in?.input as Record<string, unknown>) ?? inspectedNode.input ?? {});
        const nodeModel = workflowState ? nodeCatalog.resolveNodeSchema(inspectedNode.modelId, workflowState.nodeModels ?? nodeCatalog.getAllNodeSchemas()) : nodeCatalog.resolveNodeSchema(inspectedNode.modelId, nodeCatalog.getAllNodeSchemas());
        const nodeModule = nodeCatalog.getNodeModuleById(inspectedNode.modelId);
        const nodeTypeLabel = nodeModel.documentation?.nodeTypeLabel ?? resolveNodeTypeLabel(inspectedNode.modelId, inspectedNode.name, nodeCatalog);
        const fields =
            nodeModule?.resolveInspectorFields && workflowState
                ? nodeModule.resolveInspectorFields({
                      workflow: workflowState,
                      node: inspectedNode,
                      fields: { ...(nodeModel.fields ?? {}) }
                  })
                : { ...(nodeModel.fields ?? {}) };
        const nodeUiInspector = nodeModule?.ui?.inspector;
        const hiddenFieldKeys = nodeUiInspector?.hiddenFieldKeys ?? [];
        const instructionOnly = nodeUiInspector?.instructionOnly ?? false;
        const showGraphqlQuerySection = nodeUiInspector?.showGraphqlQuerySection ?? false;
        const codeAllowVariables = nodeUiInspector?.codeAllowVariables ?? true;
        const inspectorColumns = nodeModel.styles?.inspectorColumns;
        const commandPorts = getNormalizedCommandPorts(nodeModel);
        const controlNodes = workflowState
            ? workflowState.connections.reduce<Record<string, Record<string, unknown>>>((acc, connection) => {
                  const isSource = connection.from === inspectedNode.id;
                  const isTarget = connection.to === inspectedNode.id;
                  if (!isSource && !isTarget) return acc;
                  const peerNodeId = isSource ? connection.to : connection.from;
                  const peerNode = workflowState.nodes.find((node) => node.id === peerNodeId);
                  if (!peerNode) return acc;
                  const portName = resolveCommandPortIdFromHandle(
                      nodeModel,
                      isSource ? connection.sourceHandle : connection.targetHandle,
                      isSource ? 'outputs' : 'inputs'
                  );
                  if (!portName || !commandPorts[portName]) return acc;
                  const peerOut = peerNode.ports?.out && typeof peerNode.ports.out === 'object' ? (peerNode.ports.out as Record<string, unknown>) : {};
                  const peerRuntime = peerNode.runtime && typeof peerNode.runtime === 'object' && !Array.isArray(peerNode.runtime) ? peerNode.runtime : {};
                  if (!acc[portName]) acc[portName] = {};
                  acc[portName][peerNode.id] = {
                      name: peerNode.name,
                      modelId: peerNode.modelId,
                      status: peerNode.status,
                      connectedVia: connection.id,
                      port: portName,
                      state: peerOut[portName] ?? peerOut.output ?? null,
                      runtime: peerRuntime
                  };
                  return acc;
              }, {})
            : {};
        const runtimeValues = inspectedNode.runtime && typeof inspectedNode.runtime === 'object' && !Array.isArray(inspectedNode.runtime) ? inspectedNode.runtime : {};
        const properties = parseNodeProperties(fields, {
            ...(inspectedNode.inspector?.properties ?? inspectedNode.properties ?? runtimeValues),
            name: inspectedNode.name,
            description: inspectedNode.description
        });
        const portsOut = inspectedNode.ports?.out && typeof inspectedNode.ports.out === 'object' ? (inspectedNode.ports.out as Record<string, unknown>) : {};
        const currentOutput = Object.prototype.hasOwnProperty.call(portsOut, 'output') ? portsOut.output : inspectedNode.output;
        const viewerTemplates = (inspectedNode.inspector?.viewers?.length ? inspectedNode.inspector.viewers : nodeModel.outputViewers ?? [{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json }]) as Array<{
            id: string;
            label: string;
            type: WorkflowViewerTypeEnum;
            value?: unknown;
        }>;
        const modelViewers = viewerTemplates.map((viewer) => ({
            ...viewer,
            value: viewer.type === WorkflowViewerTypeEnum.Table ? (currentOutput as { rows?: unknown[] })?.rows ?? [] : currentOutput
        }));
        const instruction = nodeModel.instruction ?? { code: false, markdown: false };
        const workflowInspectorData = workflowState
            ? {
                  metadata: workflowState.metadata,
                  nodes: workflowState.nodes,
                  connections: workflowState.connections
              }
            : {};
        const workflowVariableContext = buildPublicWorkflowContext(workflowState);
        return inspectedNode.inspector
            ? {
                  ...inspectedNode.inspector,
                  nodeId: inspectedNode.id,
                  modelId: inspectedNode.modelId,
                  nodeTypeLabel,
                  executorKey: nodeModel.executorKey,
                  useCredentials: nodeModel.useCredentials ?? null,
                  useWorkflows: nodeModel.useWorkflows ?? null,
                  render: { ...(nodeModel.render || {}), ...(inspectedNode.render || {}) },
                  renderIcon: nodeModule?.renderIcon,
                  instruction,
                  name: inspectedNode.name,
                  title: inspectedNode.inspector.title ?? inspectedNode.name,
                  input: upstream,
                  workflow: workflowInspectorData,
                  workflowVariableContext,
                  controlNodes: Object.keys(controlNodes).length > 0 ? controlNodes : null,
                  properties,
                  fields,
                  hiddenFieldKeys,
                  instructionOnly,
                  showGraphqlQuerySection,
                  inspectorColumns,
                  codeAllowVariables,
                  documentation: nodeModel.documentation,
                  code: instruction.code ? inspectedNode.inspector.code ?? String(runtimeValues.code ?? 'return input;') : '',
                  markdown: instruction.markdown ? inspectedNode.inspector.markdown ?? String(runtimeValues.markdown ?? '') : '',
                  viewers: modelViewers
              }
            : {
                  nodeId: inspectedNode.id,
                  modelId: inspectedNode.modelId,
                  nodeTypeLabel,
                  executorKey: nodeModel.executorKey,
                  useCredentials: nodeModel.useCredentials ?? null,
                  useWorkflows: nodeModel.useWorkflows ?? null,
                  render: { ...(nodeModel.render || {}), ...(inspectedNode.render || {}) },
                  renderIcon: nodeModule?.renderIcon,
                  instruction,
                  name: inspectedNode.name,
                  title: inspectedNode.name,
                  input: upstream,
                  workflow: workflowInspectorData,
                  workflowVariableContext,
                  controlNodes: Object.keys(controlNodes).length > 0 ? controlNodes : null,
                  properties,
                  fields,
                  hiddenFieldKeys,
                  instructionOnly,
                  showGraphqlQuerySection,
                  inspectorColumns,
                  codeAllowVariables,
                  documentation: nodeModel.documentation,
                  code: instruction.code ? 'return input;' : '',
                  markdown: instruction.markdown ? '' : '',
                  viewers: modelViewers
              };
    }, [inspectedNode, nodeCatalog, workflowState]);
    const onRenameNode = useCallback(
        (nodeId: string, nextName: string): void => {
            updateWorkflow((previous) => renameNodeInWorkflow(previous, nodeId, nextName));
        },
        [updateWorkflow]
    );
    const onOpenInspectorFromNode = useCallback((nodeId: string): void => {
        if (isSubworkflowSyntheticNodeId(nodeId)) return;
        setSelectedNodeId(nodeId);
        setInspectorNodeId(nodeId);
    }, []);
    const onOpenAiForWorkflow = useCallback((): void => {
        if (!allowWorkflowAi) return;
        setIsAiPanelVisible(true);
        setAiScope({ mode: 'workflow' });
    }, [allowWorkflowAi]);
    const onOpenAiForNode = useCallback((nodeId: string): void => {
        if (!allowWorkflowAi) return;
        if (isSubworkflowSyntheticNodeId(nodeId)) return;
        const workflowSnapshot = workflowStateRef.current;
        const node = workflowSnapshot?.nodes.find((entry) => entry.id === nodeId);
        if (!node) return;
        setSelectedNodeId(nodeId);
        setAiScope({
            mode: 'node',
            nodeId,
            nodeName: node.name,
            nodeType: resolveNodeTypeLabel(node.modelId, node.name, nodeCatalog)
        });
        setIsAiPanelVisible(true);
    }, [allowWorkflowAi, nodeCatalog]);
    const onDeleteNode = useCallback(
        (nodeId: string): void => {
            updateWorkflow((previous) => removeNodeFromWorkflow(previous, nodeId));
            setSelectedNodeId((previous) => (previous === nodeId ? null : previous));
            setInspectorNodeId((previous) => (previous === nodeId ? null : previous));
        },
        [updateWorkflow]
    );
    const deleteSelectedNodes = useCallback((): void => {
        const selectionIds = resolveClipboardSelectionIds();
        if (!selectionIds.length) {
            return;
        }
        updateWorkflow((previous) => selectionIds.reduce((nextWorkflow, nodeId) => removeNodeFromWorkflow(nextWorkflow, nodeId), previous));
        setSelectedNodeId(null);
        setInspectorNodeId((previous) => (previous && selectionIds.includes(previous) ? null : previous));
        selectedCanvasNodeIdsRef.current = [];
        hideSubworkflowContextMenu();
    }, [hideSubworkflowContextMenu, resolveClipboardSelectionIds, updateWorkflow]);
    const copySelectedNodes = useCallback(async (): Promise<boolean> => {
        const selectionIds = resolveClipboardSelectionIds();
        const currentWorkflow = workflowStateRef.current;
        if (!currentWorkflow || !selectionIds.length) {
            return false;
        }
        return copyWorkflowSelection(currentWorkflow, selectionIds);
    }, [resolveClipboardSelectionIds]);
    const cutSelectedNodes = useCallback(async (): Promise<void> => {
        const didCopy = await copySelectedNodes();
        if (didCopy) {
            deleteSelectedNodes();
        }
    }, [copySelectedNodes, deleteSelectedNodes]);
    const pasteNodesFromClipboard = useCallback(async (): Promise<void> => {
        const currentWorkflow = workflowStateRef.current;
        if (!currentWorkflow || !flowInstance) {
            return;
        }
        const payload = await readWorkflowClipboard();
        if (!payload) {
            return;
        }
        const anchor = flowInstance.screenToFlowPosition({
            x: window.innerWidth / 2,
            y: window.innerHeight / 2
        });
        const pasted = pasteWorkflowSelection(currentWorkflow, payload, anchor);
        replaceWorkflowState(pasted.workflow);
        selectedCanvasNodeIdsRef.current = pasted.insertedNodeIds;
        setSelectedNodeId(pasted.insertedNodeIds[0] ?? null);
    }, [flowInstance, replaceWorkflowState]);
    const onToggleNodeEnabled = useCallback(
        (nodeId: string, nextEnabled: boolean): void => {
            updateWorkflow((previous) => toggleNodeEnabled(previous, nodeId, nextEnabled));
        },
        [updateWorkflow]
    );
    const openQuickInsertPanel = useCallback((anchor: HTMLElement): void => {
        setQuickInsertSearch('');
        quickInsertPanelRef.current?.show(
            {
                currentTarget: anchor,
                target: anchor
            } as unknown as React.SyntheticEvent,
            anchor
        );
    }, []);
    const onQuickInsertFromPort = useCallback(
        (payload: { nodeId: string; outputPortId: string; anchor: HTMLElement }): void => {
            setQuickInsertContext({
                type: 'port',
                nodeId: payload.nodeId,
                outputPortId: payload.outputPortId
            });
            openQuickInsertPanel(payload.anchor);
        },
        [openQuickInsertPanel]
    );
    const onQuickInsertFromEdge = useCallback(
        (payload: { edgeId: string; anchor: HTMLElement }): void => {
            setQuickInsertContext({
                type: 'edge',
                edgeId: payload.edgeId
            });
            openQuickInsertPanel(payload.anchor);
        },
        [openQuickInsertPanel]
    );
    const quickInsertItems = useMemo(() => {
        const normalizedSearch = quickInsertSearch.trim().toLowerCase();
        if (!normalizedSearch) return resolvedNodeLibraryItems;
        return resolvedNodeLibraryItems.filter((item) => {
            return item.label.toLowerCase().includes(normalizedSearch) || item.description.toLowerCase().includes(normalizedSearch) || item.modelId.toLowerCase().includes(normalizedSearch);
        });
    }, [quickInsertSearch, resolvedNodeLibraryItems]);
    const onSelectQuickInsertItem = useCallback(
        (item: WorkflowNodeLibraryItem): void => {
            if (!quickInsertContext) return;
            if (quickInsertContext.type === 'port') {
                updateWorkflow((previous) => insertNodeAfterOutputPort(previous, quickInsertContext.nodeId, quickInsertContext.outputPortId, item));
            }
            if (quickInsertContext.type === 'edge') {
                updateWorkflow((previous) => insertNodeOnEdge(previous, quickInsertContext.edgeId, item));
            }
            setQuickInsertContext(null);
            setQuickInsertSearch('');
            quickInsertPanelRef.current?.hide();
        },
        [quickInsertContext, updateWorkflow]
    );
    const executeStepFromNode = useCallback(async (nodeId: string): Promise<void> => {
        const workflowSnapshot = workflowStateRef.current;
        if (!workflowSnapshot) return;
        const targetNode = workflowSnapshot.nodes.find((node) => node.id === nodeId);
        if (!targetNode) return;
        const draft = inspectorDraftRef.current[nodeId];
        const nodeSchema = nodeCatalog.resolveNodeSchema(targetNode.modelId, workflowSnapshot.nodeModels ?? nodeCatalog.getAllNodeSchemas());
        try {
            const result = await runNodeStepRef.current({
                nodeId: targetNode.id,
                properties: draft ? parsePropertiesInput(draft.propertiesEditorState, nodeSchema.fields ?? {}) : (targetNode.inspector?.properties as Record<string, unknown>) ?? targetNode.properties ?? targetNode.runtime ?? {},
                code: draft?.code ?? targetNode.inspector?.code ?? String(targetNode.runtime?.code ?? ''),
                markdown: draft?.markdown ?? targetNode.inspector?.markdown ?? String(targetNode.runtime?.markdown ?? '')
            });
            if (!result.error) return;
            toastRef.current?.show({
                severity: 'error',
                summary: 'Node execution failed',
                detail: result.error,
                life: 4200
            });
        } catch (error) {
            toastRef.current?.show({
                severity: 'error',
                summary: 'Node execution failed',
                detail: error instanceof Error ? error.message : 'Unable to execute node step.',
                life: 4200
            });
        }
    }, []);
    useEffect(() => {
        onExecuteStepFromNodeRef.current = (nodeId: string) => {
            void executeStepFromNode(nodeId);
        };
    }, [executeStepFromNode]);
    const onToggleSubworkflowState = useCallback(
        (subworkflowId: string, collapsed: boolean) => {
            updateWorkflow((previous) => toggleSubworkflowCollapsed(previous, subworkflowId, collapsed));
        },
        [updateWorkflow]
    );
    const computedNodes = useMemo(() => {
        const baseNodes = buildCanvasNodes(workflowState, orderedNodeIds, activeIndex, isPlaying, playMode, {
            readOnly: isExecutionMode,
            onRenameNode,
            onOpenInspector: onOpenInspectorFromNode,
            onOpenAi: isExecutionMode ? undefined : allowWorkflowAi ? onOpenAiForNode : undefined,
            onExecuteStep: onExecuteStepFromNode,
            onToggleEnabled: onToggleNodeEnabled,
            onDeleteNode,
            onQuickAddFromPort: onQuickInsertFromPort
        });
        if (!subworkflowLayout) return baseNodes;
        const visibleNodes = baseNodes.filter((node) => !subworkflowLayout.hiddenNodeIds.has(node.id));
        const collapsedNodes = subworkflowLayout.collapsedNodes.map(
            (item): WorkflowFlowNode => ({
                id: item.id,
                type: 'subworkflowCollapsed',
                position: getCollapsedSubworkflowPosition(item.bounds),
                draggable: !isExecutionMode,
                selectable: true,
                zIndex: 3,
                data: {
                    title: item.name,
                    onExpand: () => onToggleSubworkflowState(item.id.slice(SUBWORKFLOW_COLLAPSED_PREFIX.length), false)
                }
            })
        );
        const expandedBoxes = subworkflowLayout.expandedBoxes.map(
            (item): WorkflowFlowNode => ({
                id: item.id,
                type: 'subworkflowBox',
                position: getExpandedSubworkflowPosition(item.bounds),
                draggable: !isExecutionMode,
                selectable: true,
                dragHandle: isExecutionMode ? undefined : '.wf-subworkflow__box-header',
                zIndex: 0,
                style: { width: item.bounds.width, height: item.bounds.height },
                data: {
                    title: item.name,
                    onCollapse: () => onToggleSubworkflowState(item.id.slice(SUBWORKFLOW_BOX_PREFIX.length), true)
                }
            })
        );
        return [...expandedBoxes, ...visibleNodes, ...collapsedNodes];
    }, [
        activeIndex,
        allowWorkflowAi,
        isExecutionMode,
        isPlaying,
        onDeleteNode,
        onExecuteStepFromNode,
        onOpenAiForNode,
        onOpenInspectorFromNode,
        onQuickInsertFromPort,
        onRenameNode,
        onToggleNodeEnabled,
        onToggleSubworkflowState,
        orderedNodeIds,
        playMode,
        subworkflowLayout,
        workflowState
    ]);
    const onNodeClick: NodeMouseHandler = (_, node) => {
        hideSubworkflowContextMenu();
        if (isSubworkflowSyntheticNodeId(node.id)) {
            setSelectedNodeId(null);
            return;
        }
        setSelectedNodeId(node.id);
        if (isExecutionMode) {
            setInspectorNodeId(node.id);
        }
    };
    const onNodeDoubleClick: NodeMouseHandler = useCallback(
        (event, node) => {
            hideSubworkflowContextMenu();
            if (isSubworkflowSyntheticNodeId(node.id)) {
                setSelectedNodeId(null);
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            setSelectedNodeId(node.id);
            setInspectorNodeId(node.id);
        },
        [hideSubworkflowContextMenu]
    );
    const onNodeContextMenu: NodeMouseHandler = useCallback(
        (event, node) => {
            if (isExecutionMode) {
                return;
            }
            selectedCanvasNodeIdsRef.current = [node.id];
            setSelectedNodeId(isSubworkflowSyntheticNodeId(node.id) ? null : node.id);
            openSubworkflowContextMenu(event, [node.id]);
        },
        [isExecutionMode, openSubworkflowContextMenu]
    );
    const onCanvasInit = useCallback((instance: WorkflowFlowInstance): void => {
        setFlowInstance(instance);
    }, []);
    const onConnect = useCallback(
        (connection: Connection): void => {
            if (isExecutionMode) return;
            if (!connection.source || !connection.target) return;
            updateWorkflow((previous) => {
                if (!canAttachConnection(previous, connection)) return previous;
                return applyConnection(previous, connection.source as string, connection.target as string, connection.sourceHandle, connection.targetHandle);
            });
        },
        [isExecutionMode, updateWorkflow]
    );
    const onEdgesChange = useCallback(
        (changes: EdgeChange<WorkflowFlowEdge>[]): void => {
            if (isExecutionMode) return;
            setCanvasEdges((previous) => applyEdgeChanges(changes, previous));
            updateWorkflow((previous) => applyEdgeRemovals(previous, changes));
        },
        [isExecutionMode, updateWorkflow]
    );
    const onNodesChange = useCallback((changes: NodeChange<WorkflowFlowNode>[]): void => {
        if (isExecutionMode) {
            return;
        }
        const safeChanges = changes.filter((change) => change.type !== 'remove');
        if (!safeChanges.length) {
            return;
        }
        const hasDraggingPositionChange = safeChanges.some((change) => change.type === 'position' && Boolean(change.dragging));
        if (hasDraggingPositionChange) {
            isInteractingRef.current = true;
        }
        setCanvasNodes((previous) => {
            const next = applyNodeChanges(safeChanges, previous).map((node) => {
                const x = Number(node.position.x);
                const y = Number(node.position.y);
                if (!Number.isFinite(x) || !Number.isFinite(y)) {
                    const fallback = previous.find((previousNode) => previousNode.id === node.id);
                    return fallback ?? node;
                }
                return node;
            });
            if (previous.length > 0 && next.length === 0 && (workflowStateRef.current?.nodes.length ?? 0) > 0) {
                return previous;
            }
            return next;
        });
    }, [isExecutionMode]);
    const onNodeDragStart: NodeMouseHandler = useCallback((_event, node) => {
        if (!isSubworkflowSyntheticNodeId(node.id)) return;
        subworkflowDragOriginByNodeIdRef.current[node.id] = { x: node.position.x, y: node.position.y };
    }, []);
    const onNodeDragStop: NodeMouseHandler = useCallback(
        (_event, node) => {
            if (isExecutionMode) {
                return;
            }
            isInteractingRef.current = false;
            if (isSubworkflowSyntheticNodeId(node.id)) {
                const subworkflowId = extractSubworkflowIdFromNodeId(node.id);
                const dragOrigin = subworkflowDragOriginByNodeIdRef.current[node.id];
                delete subworkflowDragOriginByNodeIdRef.current[node.id];
                if (!subworkflowId || !dragOrigin) return;
                const delta = {
                    x: Number(node.position.x) - Number(dragOrigin.x),
                    y: Number(node.position.y) - Number(dragOrigin.y)
                };
                if (!Number.isFinite(delta.x) || !Number.isFinite(delta.y)) return;
                updateWorkflow((previous) => moveSubworkflowNodes(previous, subworkflowId, delta));
                return;
            }
            updateWorkflow((previous) => updateNodePosition(previous, node.id, node.position));
        },
        [isExecutionMode, updateWorkflow]
    );
    const onDeleteEdge = useCallback(
        (edgeId: string): void => {
            if (isExecutionMode) return;
            setCanvasEdges((previous) => previous.filter((edge) => edge.id !== edgeId));
            updateWorkflow((previous) => {
                return {
                    ...previous,
                    connections: previous.connections.filter((connection) => connection.id !== edgeId)
                };
            });
        },
        [isExecutionMode, updateWorkflow]
    );
    const onSelectionChange = useCallback(
        (selection: OnSelectionChangeParams): void => {
            const selectedIds = (selection.nodes ?? []).map((node) => node.id);
            selectedCanvasNodeIdsRef.current = selectedIds;
            if (!selectedIds.length) {
                if (subworkflowContextMenuOpenRef.current) return;
                resetSubworkflowContextState();
            }
        },
        [resetSubworkflowContextState]
    );
    const onSelectionContextMenu = useCallback(
        (event: React.MouseEvent<Element, MouseEvent>, nodes: WorkflowFlowNode[]): void => {
            const selectedIds = Array.isArray(nodes) ? nodes.map((node) => node.id) : [];
            if (selectedIds.length) {
                selectedCanvasNodeIdsRef.current = selectedIds;
            }
            openSubworkflowContextMenu(event, selectedIds);
        },
        [openSubworkflowContextMenu]
    );
    const onPaneContextMenu = useCallback(
        (event: MouseEvent | React.MouseEvent): void => {
            event.preventDefault?.();
            openSubworkflowContextMenu(event);
        },
        [openSubworkflowContextMenu]
    );
    const onPaneClick = useCallback(
        (event: MouseEvent | React.MouseEvent): void => {
            if ('button' in event && event.button !== 0) return;
            hideSubworkflowContextMenu();
        },
        [hideSubworkflowContextMenu]
    );
    useEffect(() => {
        if (!visible || !isEditable) {
            return;
        }

        const onKeyDown = (event: KeyboardEvent): void => {
            const isMetaKey = event.metaKey || event.ctrlKey;
            if (isMetaKey && isWorkflowClipboardShortcutBlocked(event.target)) {
                return;
            }
            if (isMetaKey && event.key.toLowerCase() === 'c') {
                event.preventDefault();
                void copySelectedNodes();
                return;
            }
            if (isMetaKey && event.key.toLowerCase() === 'x') {
                event.preventDefault();
                void cutSelectedNodes();
                return;
            }
            if (isMetaKey && event.key.toLowerCase() === 'v') {
                event.preventDefault();
                void pasteNodesFromClipboard();
                return;
            }
            if (event.key === 'Delete' || event.key === 'Backspace') {
                if (isWorkflowClipboardShortcutBlocked(event.target)) {
                    return;
                }
                if (!resolveClipboardSelectionIds().length) {
                    return;
                }
                event.preventDefault();
                deleteSelectedNodes();
            }
        };

        window.addEventListener('keydown', onKeyDown);
        return () => window.removeEventListener('keydown', onKeyDown);
    }, [copySelectedNodes, cutSelectedNodes, deleteSelectedNodes, isEditable, pasteNodesFromClipboard, resolveClipboardSelectionIds, visible]);
    const onCreateSubworkflow = useCallback(() => {
        const snapshotSelectionIds = subworkflowContextSnapshotRef.current.selectionIds;
        if (!snapshotSelectionIds.length) return;
        updateWorkflow((previous) => createOrExtendSubworkflow(previous, snapshotSelectionIds));
        hideSubworkflowContextMenu();
    }, [hideSubworkflowContextMenu, updateWorkflow]);
    const onUngroupSelectedSubworkflow = useCallback(() => {
        const snapshotSubworkflowId = subworkflowContextSnapshotRef.current.subworkflowId;
        if (!snapshotSubworkflowId) return;
        updateWorkflow((previous) => ungroupSubworkflow(previous, snapshotSubworkflowId));
        hideSubworkflowContextMenu();
    }, [hideSubworkflowContextMenu, updateWorkflow]);
    const computedEdges = useMemo(() => {
        const baseEdges = buildCanvasEdges(workflowState, orderedNodeIds, activeIndex, isPlaying, {
            onDeleteEdge,
            onInsertNodeOnEdge: onQuickInsertFromEdge
        }, canvasSettings.edgeStyle);
        if (!subworkflowLayout) return baseEdges;
        const remappedEdges: WorkflowFlowEdge[] = [];
        baseEdges.forEach((edge) => {
            const remapped = remapEdgeForCollapsedSubworkflow(edge, subworkflowLayout.collapsedSubworkflowByNodeId);
            if (!remapped) return;
            remappedEdges.push({
                ...edge,
                source: remapped.source,
                target: remapped.target,
                sourceHandle: remapped.sourceHandle ?? null,
                targetHandle: remapped.targetHandle ?? null
            });
        });
        return remappedEdges;
    }, [activeIndex, canvasSettings.edgeStyle, isPlaying, onDeleteEdge, onQuickInsertFromEdge, orderedNodeIds, subworkflowLayout, workflowState]);
    useEffect(() => {
        setCanvasNodes((previous) => {
            return mergeCanvasNodes(previous, computedNodes, workflowState?.nodes.length ?? 0, isInteractingRef.current);
        });
    }, [computedNodes, workflowState?.nodes.length]);
    useEffect(() => {
        setCanvasEdges((previous) => {
            if (previous.length > 0 && computedEdges.length === 0 && (workflowState?.connections.length ?? 0) > 0) {
                return previous;
            }
            return computedEdges;
        });
    }, [computedEdges, workflowState?.connections.length]);
    const insertNodeLibraryItemAtPosition = useCallback(
        (item: WorkflowNodeLibraryItem, nextPosition: { x: number; y: number }) => {
            let droppedWorkflow: WorkflowDefinition | null = null;
            let droppedNodeId: string | null = null;
            updateWorkflow((previous) => {
                const withDroppedNode = addDroppedNode(previous, item, nextPosition);
                droppedNodeId = withDroppedNode.nodes[withDroppedNode.nodes.length - 1]?.id ?? null;
                const containingSubworkflowId = findExpandedSubworkflowIdAtPosition(previous, nextPosition);
                if (!droppedNodeId || !containingSubworkflowId) {
                    droppedWorkflow = withDroppedNode;
                    return withDroppedNode;
                }
                const withSubworkflow = createOrExtendSubworkflow(withDroppedNode, [droppedNodeId], containingSubworkflowId);
                droppedWorkflow = withSubworkflow;
                return withSubworkflow;
            });
            if (droppedWorkflow && droppedNodeId) {
                void runNodeWorkerInit({
                    workflow: droppedWorkflow,
                    modelId: item.modelId,
                    nodeId: droppedNodeId
                });
                setIsCanvasInteractive(true);
                setCanvasInteractionMode('select');
            }
        },
        [updateWorkflow]
    );
    const insertNodeLibraryItemAtViewportCenter = useCallback(
        (item: WorkflowNodeLibraryItem) => {
            if (!flowInstance) return;
            const canvasElement = document.querySelector('.wf-designer__canvas');
            const bounds = canvasElement instanceof HTMLElement ? canvasElement.getBoundingClientRect() : null;
            const x = bounds ? bounds.left + bounds.width * 0.42 : window.innerWidth * 0.42;
            const y = bounds ? bounds.top + bounds.height * 0.5 : window.innerHeight * 0.5;
            insertNodeLibraryItemAtPosition(item, flowInstance.screenToFlowPosition({ x, y }));
        },
        [flowInstance, insertNodeLibraryItemAtPosition]
    );
    const onImportJson = useCallback((raw: string): void => {
        try {
            const parsed = JSON.parse(raw);
            const imported = hydrateWorkflowDefinition(exportPayloadToWorkflow(parsed));
            setWorkflowState(imported);
            workflowStateRef.current = imported;
            setRuntimeSettings(resolveRuntimeSettings(imported, defaultRuntimeSettings));
            setSessionLogs([]);
            setFitViewTick((previous) => previous + 1);
        } catch {
            window.alert('Invalid workflow JSON.');
        }
    }, []);
    const previewHostContext = useMemo(
        () => ({
            ...workflowExecutorHostContext,
            fetchCredentialById: driver.fetchCredentialById
        }),
        [driver.fetchCredentialById]
    );

    const prepareWorkflowForExecution = useCallback((workflow: WorkflowDefinition): WorkflowDefinition => {
        const hydrated = hydrateWorkflowDefinition(workflow);
        return {
            ...hydrated,
            nodes: hydrated.nodes.map((node) => clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Stopped))
        };
    }, []);

    const runWorkflowLocal = useCallback(async (workflowInput?: Record<string, unknown>): Promise<LocalWorkflowExecutionResult | null> => {
        const currentWorkflow = workflowStateRef.current;
        if (!currentWorkflow || isPlaying) return null;
        const validationIssues = getMissingPlayValidationNodes(currentWorkflow);
        if (validationIssues.length > 0) {
            toastRef.current?.show({
                severity: 'error',
                summary: 'Workflow validation failed',
                detail: validationIssues.join(' '),
                life: 4500
            });
            return null;
        }

        setPlayMode(WorkflowPlayModeEnum.Local);
        const controller = new AbortController();
        const playSessionId = playSessionIdRef.current + 1;
        playSessionIdRef.current = playSessionId;
        abortControllerRef.current = controller;
        const timeoutController = createWorkflowExecutionTimeoutController({
            settings: runtimeSettings,
            signal: controller.signal,
            label: 'Workflow execution'
        });
        const preparedWorkflow = prepareWorkflowForExecution(currentWorkflow);
        const executionWorkflow = withNodeExecutors(preparedWorkflow);
        const orderedIds = (Array.isArray(executionWorkflow.nodes) ? executionWorkflow.nodes : []).map((node) => node.id);
        const compatLogger = createCompatWorkflowLogger();
        let receivedOnEvent = false;
        let failedByNodeEvent = false;
        let failureMessage: string | null = null;
        setPlayLifecycle(WorkflowPlayLifecycleEnum.Starting);
        setActiveIndex(-1);
        setSessionLogs([]);
        updateWorkflow(() => preparedWorkflow);
        try {
            if (playSessionIdRef.current !== playSessionId) return null;
                setPlayLifecycle(WorkflowPlayLifecycleEnum.Running);
            const result = await workflowExecutor.executeWorkflow(executionWorkflow, {
                signal: timeoutController.signal,
                settings: runtimeSettings,
                workflowInput,
                hostContext: previewHostContext,
                isNodeLocalCapable: nodeCatalog.isLocalCapableNodeModel,
                executeNodeRemotely: async ({ workflow, nodeId, settings, overrides }) => {
                    const socketClient = getWorkflowSocketClient();
                    const remoteResult = await socketClient.executeStep({
                        workflow: workflow as unknown as WorkflowDefinition,
                        nodeId,
                        settings: settings as WorkflowRuntimeSettings,
                        overrides
                    });
                    return {
                        workflow: remoteResult.workflow,
                        node: remoteResult.node,
                        result: remoteResult.result
                    };
                },
                onNodeStart: (nodeId) => {
                    if (playSessionIdRef.current !== playSessionId) return;
                    const index = orderedIds.indexOf(nodeId);
                    if (index >= 0) {
                        setActiveIndex(index);
                    }
                    updateWorkflow((previous) => ({
                        ...previous,
                        nodes: previous.nodes.map((item) => (item.id === nodeId ? clearNodeExecutionArtifacts(item, WorkflowNodeStatusEnum.Running) : item))
                    }));
                },
                onNodeFinish: (node) => {
                    if (playSessionIdRef.current !== playSessionId) return;
                    updateWorkflow((previous) => ({
                        ...previous,
                        nodes: previous.nodes.map((item) => (item.id === node.id ? patchNodeRuntimeState(item, node as unknown as WorkflowDefinition['nodes'][number]) : item))
                    }));
                    if (node.status !== WorkflowNodeStatusEnum.Failed) return;
                    failedByNodeEvent = true;
                    const nodeOutputRecord = parseRecordValue((node.ports?.out as Record<string, unknown> | undefined)?.output);
                    failureMessage = toErrorMessage(nodeOutputRecord.error ?? nodeOutputRecord.message, 'Workflow execution failed.');
                    if (!controller.signal.aborted) {
                        controller.abort();
                    }
                },
                onEvent: (event) => {
                    compatLogger.push(event);
                    receivedOnEvent = true;
                    if (playSessionIdRef.current !== playSessionId) return;
                    appendSessionLogEvents(event);
                    if (event.event !== 'node.failed' || !event.nodeId) return;
                    failedByNodeEvent = true;
                    const eventData = parseRecordValue(event.data);
                    const outputValue = eventData.output ?? eventData.result ?? eventData;
                    const outputRecord = parseRecordValue(outputValue);
                    const parsedError = toErrorMessage(outputRecord.error ?? outputRecord.message ?? event.message, 'Workflow execution failed.');
                    failureMessage = parsedError;
                    updateWorkflow((previous) => ({
                        ...previous,
                        nodes: previous.nodes.map((node) => {
                            if (node.id !== event.nodeId) return node;
                            const nextRuntime = { ...(node.runtime ?? {}), lastError: parsedError };
                            const nextOutput = Object.keys(outputRecord).length > 0 ? outputRecord : { error: parsedError };
                            return {
                                ...node,
                                status: WorkflowNodeStatusEnum.Failed,
                                runtime: nextRuntime,
                                properties: nextRuntime,
                                output: nextOutput,
                                ports: {
                                    ...(node.ports ?? { in: {}, out: {} }),
                                    out: {
                                        ...((node.ports?.out as Record<string, unknown>) ?? {}),
                                        output: nextOutput
                                    }
                                }
                            };
                        })
                    }));
                    if (!controller.signal.aborted) {
                        controller.abort();
                    }
                },
                logger: compatLogger
            } as ExecuteWorkflowOptionsCompat);
            if (playSessionIdRef.current !== playSessionId) return null;
            const executionLogs = compatLogger.entries.length > 0 ? compatLogger.entries : resolveLegacyExecutionEvents(result);
            if (!receivedOnEvent) {
                appendSessionLogEvents(executionLogs);
            }
            if (failedByNodeEvent) {
                throw new Error(failureMessage ?? 'Workflow execution stopped after node failure.');
            }
            const finalizedWorkflow = mergeWorkflowRuntimeStateWithUpsert(preparedWorkflow, result.workflow as unknown as WorkflowDefinition);
            updateWorkflow(() => finalizedWorkflow);
            return {
                workflow: finalizedWorkflow,
                output: extractTerminalWorkflowPayload(finalizedWorkflow),
                logs: executionLogs
            };
        } catch (error) {
            if (playSessionIdRef.current !== playSessionId) return null;
            const executionLogs = compatLogger.entries.length > 0 ? compatLogger.entries : [];
            const detail = timeoutController.didTimeout()
                ? timeoutController.signal.reason instanceof Error
                    ? timeoutController.signal.reason.message
                    : 'Workflow execution timed out.'
                : failedByNodeEvent
                ? failureMessage ?? 'Execution stopped because a node failed.'
                : error instanceof Error
                ? error.message
                : 'Unable to run workflow locally.';
            reportExecutionFailure('local', error, currentWorkflow.metadata.id ?? 'workflow_unknown');
            toastRef.current?.show({
                severity: 'error',
                summary: 'Local execution failed',
                detail,
                life: 4500
            });
            return {
                workflow: workflowStateRef.current ?? preparedWorkflow,
                output: { error: detail },
                logs: executionLogs,
                error: detail
            };
        } finally {
            timeoutController.cleanup();
            if (playSessionIdRef.current === playSessionId) {
                setPlayLifecycle(WorkflowPlayLifecycleEnum.Idle);
                setActiveIndex(-1);
                abortControllerRef.current = null;
            }
        }
    }, [appendSessionLogEvents, getWorkflowSocketClient, isPlaying, nodeCatalog, prepareWorkflowForExecution, reportExecutionFailure, runtimeSettings, updateWorkflow]);
    useEffect(() => {
        if (!visible) {
            return;
        }

        const socketClient = getWorkflowSocketClient();
        if (typeof socketClient.addWebhookTestInvokeHandler !== 'function' || typeof socketClient.emitWebhookTestResult !== 'function' || typeof socketClient.emitWebhookTestError !== 'function') {
            return;
        }
        return socketClient.addWebhookTestInvokeHandler((payload) => {
            const activeWorkflow = workflowStateRef.current;
            const workflowId = typeof activeWorkflow?.metadata?.id === 'string' ? activeWorkflow.metadata.id.trim() : '';
            if (!workflowId || payload.workflow_id !== workflowId) {
                return;
            }
            if (isPlaying) {
                socketClient.emitWebhookTestError({
                    requestId: payload.request_id,
                    workflowId,
                    error: 'Workflow is already executing in the designer.'
                });
                return;
            }

            const requestPayload = parseRecordValue(payload.request);
            const timestamp = new Date().toISOString();
            const preparedWorkflow: WorkflowDefinition = {
                ...activeWorkflow,
                metadata: {
                    ...activeWorkflow.metadata,
                    webhook: {
                        ...(parseRecordValue(activeWorkflow.metadata.webhook) || {}),
                        lastInvocation: timestamp
                    }
                }
            };

            replaceWorkflowState(preparedWorkflow);
            void runWorkflowLocal(requestPayload)
                .then((executionResult) => {
                    if (!executionResult) {
                        socketClient.emitWebhookTestError({
                            requestId: payload.request_id,
                            workflowId,
                            error: 'Workflow execution finished without a result.',
                            logs: []
                        });
                        return;
                    }
                    if (executionResult.error) {
                        socketClient.emitWebhookTestError({
                            requestId: payload.request_id,
                            workflowId,
                            error: executionResult.error,
                            output: executionResult.output,
                            logs: executionResult.logs
                        });
                        return;
                    }
                    socketClient.emitWebhookTestResult({
                        requestId: payload.request_id,
                        workflowId,
                        output: executionResult.output,
                        logs: executionResult.logs
                    });
                })
                .catch((error) => {
                    socketClient.emitWebhookTestError({
                        requestId: payload.request_id,
                        workflowId,
                        error: error instanceof Error ? error.message : 'Workflow execution failed.',
                        logs: sessionLogs.slice(-120)
                    });
                });
        });
    }, [getWorkflowSocketClient, isPlaying, replaceWorkflowState, runWorkflowLocal, sessionLogs, visible]);

    const runWorkflowServer = useCallback(async (): Promise<void> => {
        const currentWorkflow = workflowStateRef.current;
        if (!currentWorkflow || isPlaying) return;
        const validationIssues = getMissingPlayValidationNodes(currentWorkflow);
        if (validationIssues.length > 0) {
            toastRef.current?.show({
                severity: 'error',
                summary: 'Workflow validation failed',
                detail: validationIssues.join(' '),
                life: 4500
            });
            return;
        }

        const runRequestId = driver.createRequestId();
        const playSessionId = playSessionIdRef.current + 1;
        playSessionIdRef.current = playSessionId;
        serverRealtimePatchedNodeIdsRef.current.clear();
        serverFailedNodeIdsRef.current.clear();
        setPlayMode(WorkflowPlayModeEnum.Server);
        setPlayLifecycle(WorkflowPlayLifecycleEnum.Starting);
        setActiveIndex(-1);
        setSessionLogs([]);
        const preparedWorkflow = prepareWorkflowForExecution(currentWorkflow);
        updateWorkflow(() => preparedWorkflow);

        const executionWorkflow = withNodeExecutors(preparedWorkflow);
        const orderedIds = (Array.isArray(executionWorkflow.nodes) ? executionWorkflow.nodes : []).map((node) => node.id);
        const workflowId = String(executionWorkflow.metadata?.id || '').trim();
        if (!broadcastId || !workflowId) {
            throw new Error('Workflow execution broadcast is not configured.');
        }
        const socketClient = getWorkflowSocketClient();
        try {
            await socketClient.connect();
            if (playSessionIdRef.current !== playSessionId) return;
            await socketClient.subscribeWorkflowExecution({
                broadcastId,
                workflowId
            });
            if (playSessionIdRef.current !== playSessionId) return;

            setPlayLifecycle(WorkflowPlayLifecycleEnum.Running);
            workflowSocketLogUnsubscribeRef.current?.();
            workflowSocketLogUnsubscribeRef.current = socketClient.addEventHandler((entry) => {
                if (playSessionIdRef.current !== playSessionId) return;
                if (entry.runId !== runRequestId) return;
                applyServerWorkflowEvent(entry, orderedIds);
            });

            const response = await driver.executeWorkflowOnServer({
                workflow: executionWorkflow,
                settings: runtimeSettings,
                mode: WorkflowExecutionModeEnum.Wait,
                requestId: runRequestId
            });
            if (playSessionIdRef.current !== playSessionId) return;
            const realtimeNodeIds = new Set(serverRealtimePatchedNodeIdsRef.current);
            updateWorkflow((previous) => {
                const merged = mergeWorkflowRuntimeStateWithUpsert(previous, response.workflow);
                const failedNodeIds = new Set(serverFailedNodeIdsRef.current);
                if (!realtimeNodeIds.size && !failedNodeIds.size) return merged;
                const previousNodesById = new Map(previous.nodes.map((node) => [node.id, node]));
                return {
                    ...merged,
                    nodes: merged.nodes.map((node) => {
                        if (failedNodeIds.has(node.id)) {
                            const previousNode = previousNodesById.get(node.id);
                            if (previousNode) {
                                return {
                                    ...patchNodeRuntimeState(node, previousNode),
                                    status: WorkflowNodeStatusEnum.Failed
                                };
                            }
                            return { ...node, status: WorkflowNodeStatusEnum.Failed };
                        }
                        if (!realtimeNodeIds.has(node.id)) return node;
                        const previousNode = previousNodesById.get(node.id);
                        if (!previousNode) return node;
                        return patchNodeRuntimeState(node, previousNode);
                    })
                };
            });
            if (serverFailedNodeIdsRef.current.size > 0) {
                const failedNodeIds = new Set(serverFailedNodeIdsRef.current);
                updateWorkflow((previous) => ({
                    ...previous,
                    nodes: previous.nodes.map((node) => (failedNodeIds.has(node.id) ? { ...node, status: WorkflowNodeStatusEnum.Failed } : node))
                }));
            }
            if (serverFailedNodeIdsRef.current.size > 0 || response.workflow.nodes.some((node) => node.status === WorkflowNodeStatusEnum.Failed)) {
                appendSessionLogEvents({
                    timestamp: new Date().toISOString(),
                    level: WorkflowLogLevelEnum.Error,
                    event: 'workflow.server.failed',
                    workflowId: currentWorkflow.metadata.id ?? 'workflow_unknown',
                    runId: runRequestId,
                    message: 'Server workflow run reported one or more failed nodes.'
                });
                toastRef.current?.show({
                    severity: 'warn',
                    summary: 'Workflow completed with failures',
                    detail: 'One or more nodes failed during server execution.',
                    life: 4200
                });
            }
        } catch (error) {
            if (playSessionIdRef.current !== playSessionId) return;
            reportExecutionFailure('server', error, currentWorkflow.metadata.id ?? 'workflow_unknown');
            toastRef.current?.show({
                severity: 'error',
                summary: 'Server execution failed',
                detail: error instanceof Error ? error.message : 'Unable to run workflow on server.',
                life: 4500
            });
        } finally {
            if (broadcastId && workflowId) {
                socketClient.unsubscribeWorkflowExecution({
                    broadcastId,
                    workflowId
                });
            }
            workflowSocketLogUnsubscribeRef.current?.();
            workflowSocketLogUnsubscribeRef.current = null;
            serverRealtimePatchedNodeIdsRef.current.clear();
            serverFailedNodeIdsRef.current.clear();
            if (playSessionIdRef.current === playSessionId) {
                setPlayLifecycle(WorkflowPlayLifecycleEnum.Idle);
                setActiveIndex(-1);
            }
        }
    }, [appendSessionLogEvents, applyServerWorkflowEvent, broadcastId, driver, getWorkflowSocketClient, isPlaying, prepareWorkflowForExecution, reportExecutionFailure, runtimeSettings, updateWorkflow]);

    useEffect(() => {
        if (!visible || !isExecutionMode || !executionLive) {
            return;
        }
        const workflowId = String(executionWorkflowId || '').trim();
        const runId = String(executionRunId || '').trim();
        if (!broadcastId || !workflowId || !runId) {
            return;
        }
        const socketClient = getWorkflowSocketClient();
        let active = true;
        serverRealtimePatchedNodeIdsRef.current.clear();
        serverFailedNodeIdsRef.current.clear();
        setPlayMode(WorkflowPlayModeEnum.Server);
        setPlayLifecycle(WorkflowPlayLifecycleEnum.Running);
        void socketClient
            .connect()
            .then(async () => {
                if (!active) return;
                await socketClient.subscribeWorkflowExecution({ broadcastId, workflowId });
                if (!active) return;
                workflowSocketLogUnsubscribeRef.current?.();
                workflowSocketLogUnsubscribeRef.current = socketClient.addEventHandler((entry) => {
                    if (!active || entry.runId !== runId) {
                        return;
                    }
                    applyServerWorkflowEvent(entry, orderedNodeIds);
                });
            })
            .catch((error) => {
                if (!active) {
                    return;
                }
                reportExecutionFailure('server', error, workflowId);
            });
        return () => {
            active = false;
            workflowSocketLogUnsubscribeRef.current?.();
            workflowSocketLogUnsubscribeRef.current = null;
            socketClient.unsubscribeWorkflowExecution({ broadcastId, workflowId });
            serverRealtimePatchedNodeIdsRef.current.clear();
            serverFailedNodeIdsRef.current.clear();
            setActiveIndex(-1);
            setPlayLifecycle(WorkflowPlayLifecycleEnum.Idle);
        };
    }, [applyServerWorkflowEvent, broadcastId, executionLive, executionRunId, executionWorkflowId, getWorkflowSocketClient, isExecutionMode, orderedNodeIds, reportExecutionFailure, visible]);

    const stopWorkflow = useCallback(() => {
        playSessionIdRef.current += 1;
        serverRealtimePatchedNodeIdsRef.current.clear();
        serverFailedNodeIdsRef.current.clear();
        setPlayLifecycle(WorkflowPlayLifecycleEnum.Stopping);
        abortControllerRef.current?.abort();
        abortControllerRef.current = null;
        workflowSocketLogUnsubscribeRef.current?.();
        workflowSocketLogUnsubscribeRef.current = null;
        setPlayLifecycle(WorkflowPlayLifecycleEnum.Idle);
        setActiveIndex(-1);
    }, []);
    const onClearAiSession = useCallback(() => {
        clearWorkflowAiSessionMessages(aiSessionWorkflowId);
        setAiMessages([]);
    }, [aiSessionWorkflowId]);
    const onSendAiMessage = useCallback(
        async (message: string): Promise<void> => {
            if (!allowWorkflowAi) return;
            const currentWorkflow = workflowStateRef.current;
            if (!currentWorkflow) return;
            const nextUserMessage = createWorkflowAiMessage('user', message);
            setAiMessages((previous) => [...previous, nextUserMessage]);
            setIsAiRequestInFlight(true);
            try {
                const hiddenContext = buildWorkflowAiHiddenContext({
                    workflow: currentWorkflow,
                    scope: aiScope,
                    recentLogs: sessionLogs.slice(-120),
                    nodeLibraryItems: resolvedNodeLibraryItems,
                    capabilities: WORKFLOW_AI_CAPABILITIES,
                    resolveNodeSchema: nodeCatalog.resolveNodeSchema
                });
                const prompt = buildWorkflowAiPrompt(message, hiddenContext);
                const aiResponse = await driver.requestWorkflowAi(prompt);
                const actionRunResult = await applyWorkflowAiActions({
                    actions: aiResponse.actions,
                    workflow: workflowStateRef.current,
                    nodeLibraryItems: resolvedNodeLibraryItems,
                    replaceWorkflow: (nextWorkflow) => replaceWorkflowState(nextWorkflow),
                    runNodeStep: executeStepFromNode,
                    runWorkflowLocal: async () => {
                        await runWorkflowLocal();
                    },
                    runWorkflowServer,
                    openInspector: (nodeId: string) => {
                        setSelectedNodeId(nodeId);
                        setInspectorNodeId(nodeId);
                    },
                    showLogs: () => setShowLogs(true),
                    exportWorkflowOnly: () => {
                        const snapshot = workflowStateRef.current;
                        if (!snapshot) return;
                        downloadWorkflowJson(snapshot, 'workflow-only');
                    },
                    exportWorkflowWithData: () => {
                        const snapshot = workflowStateRef.current;
                        if (!snapshot) return;
                        downloadWorkflowJson(snapshot, 'with-data');
                    }
                });
                const notes: string[] = [];
                if (actionRunResult.applied.length > 0) {
                    notes.push(`Applied: ${actionRunResult.applied.join(' | ')}`);
                }
                if (actionRunResult.warnings.length > 0) {
                    notes.push(`Warnings: ${actionRunResult.warnings.join(' | ')}`);
                }
                if (aiResponse.diagnostics) {
                    const diagnosticsSummary = [aiResponse.diagnostics.summary, aiResponse.diagnostics.likelyCause, aiResponse.diagnostics.recommendedFix]
                        .filter((entry): entry is string => typeof entry === 'string' && entry.trim().length > 0)
                        .join(' | ');
                    if (diagnosticsSummary) {
                        notes.push(`Diagnostics: ${diagnosticsSummary}`);
                    }
                }
                const assistantText = [aiResponse.reply, ...notes].filter(Boolean).join('\n\n');
                setAiMessages((previous) => [...previous, createWorkflowAiMessage('assistant', assistantText || 'Done.')]);
            } catch (error) {
                const messageText = error instanceof Error ? error.message : 'Workflow AI request failed.';
                setAiMessages((previous) => [...previous, createWorkflowAiMessage('assistant', `I could not process that request: ${messageText}`)]);
            } finally {
                setIsAiRequestInFlight(false);
            }
        },
        [aiScope, allowWorkflowAi, driver, executeStepFromNode, replaceWorkflowState, resolvedNodeLibraryItems, runWorkflowLocal, runWorkflowServer, sessionLogs]
    );
    const runNodeStep = useCallback(
        async (payload: { nodeId: string; properties: Record<string, unknown>; code: string; markdown: string }) => {
            const currentWorkflow = workflowStateRef.current;
            if (!currentWorkflow) return { output: null, logs: ['Workflow is not available.'], error: 'Workflow is not available.' };
            const targetNode = currentWorkflow.nodes.find((node) => node.id === payload.nodeId);
            if (!targetNode) {
                return { output: null, logs: ['Node not found.'], error: 'Node not found.' };
            }
            const appendStepEvent = (level: WorkflowLogLevelEnum, event: string, message: string, data?: Record<string, unknown>): void => {
                appendSessionLogEvents({
                    timestamp: new Date().toISOString(),
                    level,
                    event,
                    workflowId: currentWorkflow.metadata.id ?? 'workflow_unknown',
                    runId: `designer_step_${Date.now().toString(36)}`,
                    nodeId: payload.nodeId,
                    message,
                    data
                });
            };
            const resolveStepEventMeta = (status: WorkflowNodeStatus | undefined, error: string | null): { level: WorkflowLogLevelEnum; event: string; message: string } => {
                if (status === WorkflowNodeStatusEnum.Failed || error) {
                    return {
                        level: WorkflowLogLevelEnum.Error,
                        event: 'node.step.failed',
                        message: `Node ${payload.nodeId} step failed.`
                    };
                }
                if (status === WorkflowNodeStatusEnum.Warning) {
                    return {
                        level: WorkflowLogLevelEnum.Warn,
                        event: 'node.step.warning',
                        message: `Node ${payload.nodeId} step completed with warning status.`
                    };
                }
                return {
                    level: WorkflowLogLevelEnum.Info,
                    event: 'node.step.succeeded',
                    message: `Node ${payload.nodeId} step succeeded.`
                };
            };
            appendStepEvent(WorkflowLogLevelEnum.Info, 'node.step.started', `Executing step for node ${payload.nodeId}.`);
            updateWorkflow((previous) => ({
                ...previous,
                nodes: previous.nodes.map((node) => (node.id === payload.nodeId ? clearNodeExecutionArtifacts(node, WorkflowNodeStatusEnum.Running) : node))
            }));
            try {
                const executionWorkflow = withNodeExecutors(currentWorkflow);
                const stepProperties = {
                    ...payload.properties,
                    code: payload.code,
                    markdown: payload.markdown
                };
                const shouldRunLocally = playMode === WorkflowPlayModeEnum.Local && nodeCatalog.isLocalCapableNodeModel(targetNode.modelId);
                if (!shouldRunLocally) {
                    const socketClient = getWorkflowSocketClient();
                    const remoteResult = await socketClient.executeStep({
                        workflow: executionWorkflow,
                        nodeId: payload.nodeId,
                        settings: runtimeSettings,
                        overrides: {
                            properties: stepProperties,
                            code: payload.code,
                            markdown: payload.markdown
                        }
                    });
                    updateWorkflow((previous) => mergeWorkflowRuntimeStateWithUpsert(previous, remoteResult.workflow));
                    appendSessionLogEvents(remoteResult.logs ?? []);
                    const normalizedRemote = buildFailureResultFromStatus(remoteResult.result.status, remoteResult.result.output, remoteResult.result.logs ?? [], 'Step execution failed.');
                    const eventMeta = resolveStepEventMeta(remoteResult.result.status, normalizedRemote.error);
                    appendStepEvent(eventMeta.level, eventMeta.event, eventMeta.message, {
                        status: remoteResult.result.status,
                        output: remoteResult.result.output,
                        error: normalizedRemote.error,
                        logs: normalizedRemote.logs
                    });
                    return {
                        output: remoteResult.result.output,
                        logs: normalizedRemote.logs,
                        error: normalizedRemote.error
                    };
                }

                const compatLogger = createCompatWorkflowLogger();
                let receivedOnEvent = false;
                const result = await workflowExecutor.executeNodeStep({
                    workflow: executionWorkflow,
                    nodeId: payload.nodeId,
                    settings: runtimeSettings,
                    hostContext: previewHostContext,
                    isNodeLocalCapable: nodeCatalog.isLocalCapableNodeModel,
                    executeNodeRemotely: async ({ workflow, nodeId, settings, overrides }) => {
                        const socketClient = getWorkflowSocketClient();
                        const remoteResult = await socketClient.executeStep({
                            workflow: workflow as unknown as WorkflowDefinition,
                            nodeId,
                            settings: settings as WorkflowRuntimeSettings,
                            overrides
                        });
                        appendSessionLogEvents(remoteResult.logs ?? []);
                        return {
                            workflow: remoteResult.workflow,
                            node: remoteResult.node,
                            result: remoteResult.result
                        };
                    },
                    overrides: {
                        properties: stepProperties,
                        code: payload.code,
                        markdown: payload.markdown
                    },
                    onEvent: (event) => {
                        compatLogger.push(event);
                        receivedOnEvent = true;
                        appendSessionLogEvents(event);
                    },
                    logger: compatLogger
                } as ExecuteNodeStepOptionsCompat);
                if (!receivedOnEvent) {
                    const fallbackEvents = compatLogger.entries.length > 0 ? compatLogger.entries : resolveLegacyExecutionEvents(result);
                    appendSessionLogEvents(fallbackEvents);
                }
                updateWorkflow((previous) => mergeWorkflowRuntimeStateWithUpsert(previous, result.workflow as unknown as WorkflowDefinition));
                const normalizedResult = buildFailureResultFromStatus(result.result.status, result.result.output, result.result.logs ?? [], 'Step execution failed.');
                const eventMeta = resolveStepEventMeta(result.result.status, normalizedResult.error);
                appendStepEvent(eventMeta.level, eventMeta.event, eventMeta.message, {
                    status: result.result.status,
                    output: result.result.output,
                    error: normalizedResult.error,
                    logs: normalizedResult.logs
                });
                return {
                    output: result.result.output,
                    logs: normalizedResult.logs,
                    error: normalizedResult.error
                };
            } catch (error) {
                reportExecutionFailure('step', error, currentWorkflow.metadata.id ?? 'workflow_unknown');
                const message = error instanceof Error ? error.message : 'Step execution failed.';
                const stack = error instanceof Error ? error.stack : undefined;
                appendStepEvent(WorkflowLogLevelEnum.Error, 'node.step.failed', `Node ${payload.nodeId} step failed.`, {
                    error: message,
                    stack
                });
                return {
                    output: null,
                    logs: stack ? [message, stack] : [message],
                    error: message
                };
            }
        },
        [appendSessionLogEvents, getWorkflowSocketClient, nodeCatalog, playMode, reportExecutionFailure, runtimeSettings, updateWorkflow]
    );
    const contextMenuClipboardSelectionIds = useMemo(() => contextMenuSelectionIds.filter((nodeId) => !isSubworkflowSyntheticNodeId(nodeId)), [contextMenuSelectionIds]);
    const subworkflowContextActions = useMemo<MenuItem[]>(
        () => [
            {
                label: 'Copy Nodes',
                icon: 'pi pi-copy',
                disabled: contextMenuClipboardSelectionIds.length === 0,
                command: () => {
                    const currentWorkflow = workflowStateRef.current;
                    if (currentWorkflow && contextMenuClipboardSelectionIds.length > 0) {
                        void copyWorkflowSelection(currentWorkflow, contextMenuClipboardSelectionIds);
                    }
                    hideSubworkflowContextMenu();
                }
            },
            {
                label: 'Cut Nodes',
                icon: 'pi pi-scissors',
                disabled: contextMenuClipboardSelectionIds.length === 0,
                command: () => {
                    const currentWorkflow = workflowStateRef.current;
                    if (currentWorkflow && contextMenuClipboardSelectionIds.length > 0) {
                        void copyWorkflowSelection(currentWorkflow, contextMenuClipboardSelectionIds).then((didCopy) => {
                            if (!didCopy) {
                                hideSubworkflowContextMenu();
                                return;
                            }
                            updateWorkflow((previous) => contextMenuClipboardSelectionIds.reduce((nextWorkflow, nodeId) => removeNodeFromWorkflow(nextWorkflow, nodeId), previous));
                            setSelectedNodeId(null);
                            setInspectorNodeId((previous) => (previous && contextMenuClipboardSelectionIds.includes(previous) ? null : previous));
                            selectedCanvasNodeIdsRef.current = [];
                            hideSubworkflowContextMenu();
                        });
                        return;
                    }
                    hideSubworkflowContextMenu();
                }
            },
            {
                label: 'Paste Nodes',
                icon: 'pi pi-clone',
                command: () => {
                    void pasteNodesFromClipboard();
                    hideSubworkflowContextMenu();
                }
            },
            {
                label: 'Delete Selected',
                icon: 'pi pi-trash',
                disabled: contextMenuClipboardSelectionIds.length === 0,
                command: () => {
                    if (!contextMenuClipboardSelectionIds.length) {
                        hideSubworkflowContextMenu();
                        return;
                    }
                    updateWorkflow((previous) => contextMenuClipboardSelectionIds.reduce((nextWorkflow, nodeId) => removeNodeFromWorkflow(nextWorkflow, nodeId), previous));
                    setSelectedNodeId(null);
                    setInspectorNodeId((previous) => (previous && contextMenuClipboardSelectionIds.includes(previous) ? null : previous));
                    selectedCanvasNodeIdsRef.current = [];
                    hideSubworkflowContextMenu();
                }
            },
            {
                label: 'Create Subworkflow',
                command: onCreateSubworkflow,
                visible: !contextMenuSubworkflowId && contextMenuClipboardSelectionIds.length > 0
            },
            {
                label: 'Ungroup Subworkflow',
                command: onUngroupSelectedSubworkflow,
                visible: Boolean(contextMenuSubworkflowId)
            }
        ],
        [contextMenuClipboardSelectionIds, contextMenuSubworkflowId, hideSubworkflowContextMenu, onCreateSubworkflow, onUngroupSelectedSubworkflow, pasteNodesFromClipboard, updateWorkflow]
    );
    useEffect(() => {
        runNodeStepRef.current = runNodeStep;
    }, [runNodeStep]);
    const handleUserNodesChanged = useCallback((nextNodes: WorkflowUserNodeDefinition[]) => {
        setUserNodeDefinitions((previous) => (areUserNodeDefinitionsEqual(previous, nextNodes) ? previous : nextNodes));
        setWorkflowStateSilently((previous) => {
            if (!previous) return previous;
            if (!workflowNeedsUserNodeSchemaSync(previous, nextNodes)) {
                return previous;
            }
            const merged = mergeWorkflowUserNodeSchemas(previous, nextNodes);
            return merged;
        });
    }, [setWorkflowStateSilently]);
    return (
        <Dialog visible={visible} onHide={onHide} showHeader={false} className="wf-designer-dialog" contentClassName="wf-designer-dialog__content" modal blockScroll style={{ width: '100vw', height: '100vh', maxHeight: '100vh' }}>
            <Toast ref={toastRef} position="top-left" />
            <div className="wf-designer">
                <Toolbar
                    metadata={workflowState?.metadata ?? null}
                    isPlaying={isPlaying}
                    playMode={playMode}
                    playLifecycle={playLifecycle}
                    canPlay={Boolean(workflowState)}
                    isEditable={isNodeLibraryVisible}
                    isExecutionMode={isExecutionMode}
                    canReplayExecution={isExecutionMode && !executionLive}
                    onPlayLocal={() => {
                        if (isExecutionMode) {
                            void runWorkflowLocal(executionReplayInput);
                            return;
                        }
                        void runWorkflowLocal();
                    }}
                    onPlayServer={runWorkflowServer}
                    onStop={stopWorkflow}
                    onExportWorkflowOnly={() => workflowState && downloadWorkflowJson(hydrateWorkflowDefinition(workflowState), 'workflow-only')}
                    onExportWithData={() => workflowState && downloadWorkflowJson(withNodeExecutors(hydrateWorkflowDefinition(workflowState)), 'with-data')}
                    onClear={() => {
                        updateWorkflow((previous) => ({ ...previous, nodes: [], connections: [] }));
                        setFitViewTick((previous) => previous + 1);
                    }}
                    onToggleEditable={() => {
                        setIsNodeLibraryVisible((previous) => {
                            const next = !previous;
                            if (next) {
                                setIsEditable(true);
                                setIsCanvasInteractive(true);
                                setCanvasInteractionMode('select');
                            }
                            return next;
                        });
                    }}
                    onImportJson={onImportJson}
                    onShowMetadata={() => setShowMetadata(true)}
                    onShowLogs={() => setShowLogs(true)}
                    onShowSettings={() => setShowSettings(true)}
                    onOpenUserNodeStudio={allowUserNodeStudio ? () => setIsUserNodeStudioVisible(true) : undefined}
                    onSaveDraft={onSaveDraft}
                    saveDraftDisabled={saveDraftDisabled}
                    saveDraftBusy={saveDraftBusy}
                    onPublish={onPublish}
                    publishDisabled={publishDisabled}
                    publishBusy={publishBusy}
                    onOpenCatalogImport={onOpenCatalogImport}
                    catalogImportDisabled={catalogImportDisabled}
                    onOpenAi={allowWorkflowAi ? onOpenAiForWorkflow : undefined}
                    onClose={onHide}
                />
                <div className="wf-designer__body wf-designer__body--workspace">
                    <Canvas
                        nodes={canvasNodes}
                        edges={canvasEdges}
                        edgeStyle={canvasSettings.edgeStyle}
                        isEditable={isEditable}
                        isInteractive={isCanvasInteractive}
                        interactionMode={canvasInteractionMode}
                        nodeLibraryItems={resolvedNodeLibraryItems}
                        onNodeClick={onNodeClick}
                        onNodeDoubleClick={onNodeDoubleClick}
                        onNodeContextMenu={isExecutionMode ? undefined : onNodeContextMenu}
                        onInit={onCanvasInit}
                        onConnect={onConnect}
                        onNodesChange={onNodesChange}
                        onEdgesChange={onEdgesChange}
                        onNodeDragStart={onNodeDragStart}
                        onNodeDragStop={onNodeDragStop}
                        onInteractiveChange={setIsCanvasInteractive}
                        onInteractionModeChange={setCanvasInteractionMode}
                        onSelectionChange={onSelectionChange}
                        onSelectionContextMenu={isExecutionMode ? undefined : onSelectionContextMenu}
                        onPaneContextMenu={isExecutionMode ? undefined : onPaneContextMenu}
                        onPaneClick={onPaneClick}
                        onDropNode={(item, x, y) => {
                            if (!flowInstance) return;
                            insertNodeLibraryItemAtPosition(item, flowInstance.screenToFlowPosition({ x, y }));
                        }}
                    >
                        <WorkspaceCanvasChrome
                            searchValue={canvasSearch}
                            onSearchChange={setCanvasSearch}
                            onSearchKeyDown={onCanvasSearchKeyDown}
                            matchCount={canvasSearchMatchNodeIds.length}
                            activeMatchIndex={activeSearchMatchIndex}
                            onNextMatch={goToNextSearchMatch}
                            onPreviousMatch={goToPreviousSearchMatch}
                            nodeCount={workflowState?.nodes.length ?? 0}
                            connectionCount={workflowState?.connections.length ?? 0}
                        />
                        <NodeLibrary visible={!isExecutionMode && isNodeLibraryVisible} items={resolvedNodeLibraryItems} onInsertItem={insertNodeLibraryItemAtViewportCenter} onClose={() => setIsNodeLibraryVisible(false)} />
                    </Canvas>
                    <ContextMenu model={subworkflowContextActions} ref={subworkflowContextMenuRef} onHide={resetSubworkflowContextState} />
                    <AiPanel
                        visible={allowWorkflowAi && isAiPanelVisible}
                        scope={aiScope}
                        isLoading={isAiRequestInFlight}
                        messages={aiMessages}
                        onClose={() => setIsAiPanelVisible(false)}
                        onSwitchToWorkflowScope={resetAiScopeToWorkflow}
                        onSend={onSendAiMessage}
                        onClearSession={onClearAiSession}
                    />
                </div>
            </div>
            <OverlayPanel
                ref={quickInsertPanelRef}
                className="wf-quick-insert"
                showCloseIcon={false}
                onHide={() => {
                    setQuickInsertContext(null);
                    setQuickInsertSearch('');
                }}
            >
                <div className="wf-quick-insert__content">
                    <div className="wf-quick-insert__title">Insert Node</div>
                    <InputText value={quickInsertSearch} onChange={(event) => setQuickInsertSearch(event.target.value)} placeholder="Search nodes..." className="w-full" />
                    <div className="wf-quick-insert__list">
                        {quickInsertItems.map((item) => {
                            const renderedIcon = item.renderIcon ? item.renderIcon(16) : null;
                            const reactIcon = React.isValidElement(renderedIcon) ? renderedIcon : null;
                            return (
                                <button key={`${item.id}-${item.modelId}`} type="button" className="wf-quick-insert__item" onClick={() => onSelectQuickInsertItem(item)}>
                                    <span className="wf-quick-insert__item-icon" style={{ color: item.iconColor ?? '#475569', background: item.iconBackground ?? '#eef2ff' }}>
                                        {typeof renderedIcon === 'string' ? <span className="wf-quick-insert__item-icon-svg" dangerouslySetInnerHTML={{ __html: renderedIcon }} /> : reactIcon}
                                        {!renderedIcon ? <i className={item.iconClass ?? 'pi pi-box'} /> : null}
                                    </span>
                                    <span className="wf-quick-insert__item-label">{item.label}</span>
                                </button>
                            );
                        })}
                        {quickInsertItems.length === 0 ? <div className="wf-quick-insert__empty">No nodes found.</div> : null}
                    </div>
                </div>
            </OverlayPanel>
            <MetadataDialog visible={showMetadata} metadata={workflowState?.metadata ?? null} onHide={() => setShowMetadata(false)} />
            <JsonlLogsDialog
                visible={showLogs}
                jsonl={executionLogsJsonl}
                events={executionLogEvents}
                header={isExecutionMode ? 'Execution Logs (JSONL)' : 'Workflow Logs (JSONL)'}
                fileNamePrefix={executionRunId ? `workflow-run-${executionRunId}` : 'workflow-logs'}
                onHide={() => setShowLogs(false)}
            />
            <SettingsDialog
                visible={showSettings}
                readOnly={isExecutionMode}
                settings={runtimeSettings}
                canvasSettings={canvasSettings}
                workflowName={workflowState?.metadata?.name ?? ''}
                workflowDescription={workflowState?.metadata?.description ?? ''}
                workflowId={workflowState?.metadata?.id ?? null}
                onHide={() => setShowSettings(false)}
                onResetLayout={(nextCanvasSettings) => {
                    const currentWorkflow = workflowStateRef.current;
                    if (!currentWorkflow) return;
                    const nextWorkflow = applyWorkflowSettingsChange(currentWorkflow, {
                        workflowName: currentWorkflow.metadata.name,
                        workflowDescription: currentWorkflow.metadata.description ?? '',
                        settings: runtimeSettings,
                        canvasSettings: nextCanvasSettings
                    });
                    replaceWorkflowState(nextWorkflow);
                    void arrangeWorkflow(workflowStateRef.current || nextWorkflow, { fitView: true });
                }}
                onSave={({ settings: nextRuntimeSettings, workflowName, workflowDescription, canvasSettings: nextCanvasSettings }) => {
                    const currentWorkflow = workflowStateRef.current;
                    if (!currentWorkflow) return;
                    const nextWorkflow = applyWorkflowSettingsChange(currentWorkflow, {
                        workflowName,
                        workflowDescription,
                        settings: nextRuntimeSettings,
                        canvasSettings: nextCanvasSettings
                    });
                    const previousCanvasSettings = resolveWorkflowCanvasSettings(currentWorkflow);
                    replaceWorkflowState(nextWorkflow);
                    if (previousCanvasSettings.layoutEngine !== nextCanvasSettings.layoutEngine) {
                        void arrangeWorkflow(workflowStateRef.current || nextWorkflow, { fitView: true });
                    }
                }}
            />
            <UserNodeDesignerDialog
                driver={driver}
                visible={isUserNodeStudioVisible}
                onHide={() => setIsUserNodeStudioVisible(false)}
                upstreamInputContext={selectedNodeInspector?.input as Record<string, unknown> | null}
                onNodesChanged={handleUserNodesChanged}
            />
            <NodeInspector
                visible={Boolean(selectedNodeInspector)}
                readOnly={isExecutionMode}
                config={selectedNodeInspector}
        fetchCredentials={driver.fetchCredentials}
        openCredentialManager={driver.openCredentialManager}
        fetchExecutableWorkflows={driver.fetchExecutableWorkflows}
        fetchNodeFieldOptions={driver.fetchNodeFieldOptions}
        onHide={() => {
                    if (inspectorNodeId) {
                        delete inspectorDraftRef.current[inspectorNodeId];
                    }
                    isInteractingRef.current = false;
                    if (typeof window !== 'undefined') {
                        if (typeof PointerEvent === 'function') {
                            window.dispatchEvent(new PointerEvent('pointerup', { bubbles: true }));
                        }
                        window.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
                    }
                    if (document.activeElement instanceof HTMLElement) {
                        document.activeElement.blur();
                    }
                    setInspectorNodeId(null);
                }}
                onExecuteStep={runNodeStep}
                onDraftChange={({ nodeId, propertiesEditorState, code, markdown }) => {
                    inspectorDraftRef.current[nodeId] = {
                        propertiesEditorState,
                        code,
                        markdown
                    };
                }}
                onSave={(next) => {
                    if (!inspectorNodeId) return;
                    delete inspectorDraftRef.current[inspectorNodeId];
                    updateWorkflow((previous) => updateNodeInspectorInWorkflow(previous, inspectorNodeId, next, next.properties));
                }}
            />
        </Dialog>
    );
};

export default DesignerDialog;
