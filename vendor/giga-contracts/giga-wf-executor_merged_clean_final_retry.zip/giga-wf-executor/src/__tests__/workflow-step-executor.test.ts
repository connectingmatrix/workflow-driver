import { describe, expect, it } from 'vitest';
import { createWorkflowExecutor } from '../executor/create-workflow-executor';
import { WorkflowExecutorModeEnum, WorkflowNodeStatusEnum } from '../types';
import { createAdapters, createCodeNode, createConnection, createMetadataNode, createStartNode, createWorkflow } from './fixtures';

describe('shared workflow step executor', () => {
    it('emits preview state/log callbacks and injects preview overrides into execution context', async () => {
        const workflow = createWorkflow();
        const code = createCodeNode(2);
        workflow.nodes = [code];
        const captured = {
            input: null as Record<string, Record<string, unknown>> | null,
            hostContext: null as unknown
        };
        const previewStates: string[] = [];
        const previewLogs: Array<{ source: string; line: string }> = [];
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Server,
            adapters: {
                getNodeHandler: () => async (context) => {
                    captured.input = context.input;
                    captured.hostContext = context.hostContext;
                    return {
                        output: { ok: true },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['worker-line']
                    };
                }
            }
        });

        const result = await executor.executeNodeStep({
            workflow,
            nodeId: code.id,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            hostContext: { requestId: 'preview_1' },
            overrides: {
                previewMode: 'designer',
                previewRuntime: 'node',
                previewInput: { hello: 'preview' },
                sourceFiles: {
                    'worker.ts': 'export const preview = true;'
                }
            },
            onPreviewState: (event) => {
                previewStates.push(event.state);
            },
            onPreviewLogLine: (event) => {
                previewLogs.push({ source: event.source, line: event.line });
            }
        });

        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(captured.input?.input?.preview_input).toEqual({ hello: 'preview' });
        const hostContextRecord = captured.hostContext as Record<string, unknown>;
        const previewRecord = hostContextRecord.__workflowPreview as Record<string, unknown>;
        expect((previewRecord.sourceFiles as Record<string, unknown>)['worker.ts']).toContain('preview');
        expect(previewStates).toEqual(expect.arrayContaining(['starting', 'running', 'passed']));
        expect(previewLogs.some((entry) => entry.source === 'runtime' && entry.line.includes('Preview started'))).toBe(true);
        expect(previewLogs.some((entry) => entry.source === 'worker' && entry.line === 'worker-line')).toBe(true);
    });

    it('streams node preview stdout/stderr lines and preserves ordering before worker logs', async () => {
        const workflow = createWorkflow();
        const code = createCodeNode(2);
        workflow.nodes = [code];
        const previewLogs: Array<{ source: string; line: string }> = [];
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Server,
            adapters: {
                getNodeHandler: () => async () => {
                    process.stdout.write('preview-stdout-line\n');
                    process.stderr.write('preview-stderr-line\n');
                    return {
                        output: { ok: true },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['preview-worker-line']
                    };
                }
            }
        });

        await executor.executeNodeStep({
            workflow,
            nodeId: code.id,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            overrides: {
                previewMode: 'designer',
                previewRuntime: 'node'
            },
            onPreviewLogLine: (event) => {
                previewLogs.push({ source: event.source, line: event.line });
            }
        });

        const stdoutIndex = previewLogs.findIndex((entry) => entry.source === 'stdout' && entry.line.includes('preview-stdout-line'));
        const stderrIndex = previewLogs.findIndex((entry) => entry.source === 'stderr' && entry.line.includes('preview-stderr-line'));
        const workerIndex = previewLogs.findIndex((entry) => entry.source === 'worker' && entry.line.includes('preview-worker-line'));
        expect(stdoutIndex).toBeGreaterThan(-1);
        expect(stderrIndex).toBeGreaterThan(-1);
        expect(workerIndex).toBeGreaterThan(-1);
        expect(workerIndex).toBeGreaterThan(stderrIndex);
    });

    it('emits preview validation diagnostics on failed preview states', async () => {
        const workflow = createWorkflow();
        const code = createCodeNode(2);
        workflow.nodes = [code];
        const previewStates: Array<{ state: string; validationErrors: string[] }> = [];
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Server,
            adapters: {
                getNodeHandler: () => async () => ({
                    output: { error: 'Validation blocked.' },
                    status: WorkflowNodeStatusEnum.Failed,
                    logs: ['Validation blocked.'],
                    previewValidation: {
                        ok: false,
                        warnings: ['warning-line'],
                        errors: ['validation-error-line']
                    }
                })
            }
        });

        await executor.executeNodeStep({
            workflow,
            nodeId: code.id,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            overrides: {
                previewMode: 'designer',
                previewRuntime: 'node'
            },
            onPreviewState: (event) => {
                previewStates.push({
                    state: event.state,
                    validationErrors: event.validation?.errors ?? []
                });
            }
        });

        expect(previewStates.some((entry) => entry.state === 'failed' && entry.validationErrors.includes('validation-error-line'))).toBe(true);
    });

    it('executes only target node in step mode', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const code = createCodeNode(2);
        const metadata = createMetadataNode(3);
        workflow.nodes = [start, code, metadata];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, metadata.id)];

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async () => ({ output: { ok: true }, status: WorkflowNodeStatusEnum.Passed, logs: ['step ok'] })
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.node.ports.out.output).toEqual({ ok: true });
        const untouched = result.workflow.nodes.find((item) => item.id === metadata.id);
        expect(untouched?.status).toBe(WorkflowNodeStatusEnum.Stopped);
    });

    it('retries step execution until success when mitigation is retry-node', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const code = createCodeNode(2);
        code.runtime = { failureMitigation: 'retry-node', retryCount: 3 };
        start.status = WorkflowNodeStatusEnum.Passed;
        start.ports.out = { output: { message: 'Hi' } };
        workflow.nodes = [start, code];
        workflow.connections = [createConnection('c1', start.id, code.id)];

        let attempts = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async () => {
                    attempts += 1;
                    if (attempts < 3) return { output: { error: 'transient' }, status: WorkflowNodeStatusEnum.Failed, logs: [`failed ${attempts}`] };
                    return { output: { ok: true }, status: WorkflowNodeStatusEnum.Passed, logs: ['succeeded'] };
                }
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        const retryLines = result.events.filter((event) => event.nodeId === code.id && event.event === 'node.log').map((event) => String(event.message ?? ''));

        expect(attempts).toBe(3);
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(result.result.logs).toEqual(expect.arrayContaining(['failed 1', 'failed 2', 'succeeded']));
        expect(retryLines.some((line) => line.includes('Retrying (1/3)'))).toBe(true);
        expect(retryLines.some((line) => line.includes('Retrying (2/3)'))).toBe(true);
    });

    it('fails step execution after retry exhaustion', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        const code = createCodeNode(2);
        code.runtime = { failureMitigation: 'retry-node', retryCount: 2 };
        workflow.nodes = [start, code];
        workflow.connections = [createConnection('c1', start.id, code.id)];

        let attempts = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async () => {
                    attempts += 1;
                    return { output: { error: 'fatal' }, status: WorkflowNodeStatusEnum.Failed, logs: [`failed ${attempts}`] };
                }
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(attempts).toBe(3);
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.logs).toEqual(expect.arrayContaining(['failed 1', 'failed 2', 'failed 3']));
    });

    it('stop-workflow mitigation fails step immediately without retries', async () => {
        const workflow = createWorkflow();
        const code = createCodeNode(2);
        code.runtime = { failureMitigation: 'stop-workflow' };
        workflow.nodes = [code];

        let attempts = 0;
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async () => {
                    attempts += 1;
                    return { output: { error: 'halt now' }, status: WorkflowNodeStatusEnum.Failed, logs: ['halt now'] };
                }
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(attempts).toBe(1);
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.logs).toContain('halt now');
    });

    it('fails step execution when connection compatibility rules are violated', async () => {
        const workflow = createWorkflow();
        const nonModelNode = createMetadataNode(1, 'Non Model');
        const governorNode = createMetadataNode(2, 'AI Governor');
        governorNode.modelId = 'ai-governor';
        workflow.nodes = [nonModelNode, governorNode];
        workflow.connections = [createConnection('c1', nonModelNode.id, governorNode.id, 'out:output', 'in:modelIn')];
        workflow.nodeModels = {
            metadata: {
                id: 'metadata',
                group: 'Data',
                inputs: { input: { allowMultipleArrows: true } },
                outputs: { output: { allowMultipleArrows: true } }
            },
            'ai-governor': {
                id: 'ai-governor',
                inputs: {
                    modelIn: {
                        allowMultipleArrows: true,
                        acceptedSourceGroups: ['AI Models']
                    },
                    input: { allowMultipleArrows: true }
                },
                outputs: { output: { allowMultipleArrows: true } }
            }
        };

        const executor = createWorkflowExecutor({ mode: WorkflowExecutorModeEnum.Local, adapters: createAdapters({}) });
        const result = await executor.executeNodeStep({ workflow, nodeId: governorNode.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(String(result.result.logs?.[0] ?? '')).toContain('incompatible connection');
    });
});

describe('step variable resolution', () => {
    it('resolves runtime variable tokens in step execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        start.status = WorkflowNodeStatusEnum.Passed;
        start.ports.out = { output: { message: 'Hi' } };
        const code = createCodeNode(2);
        code.runtime = { prompt: 'Summary {{node_start_1.message}}' };
        workflow.nodes = [start, code];
        workflow.connections = [createConnection('c1', start.id, code.id)];
        workflow.nodeModels = {
            code: {
                id: 'code',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async (node) => {
                    seenPrompt = String(node.runtime.prompt ?? '');
                    return { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed };
                }
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(seenPrompt).toBe('Summary Hi');
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('resolves workflow runtime and workflow input in step variable tokens', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        start.status = WorkflowNodeStatusEnum.Passed;
        start.ports.out = { output: { message: 'Hi' } };
        const code = createCodeNode(2);
        code.runtime = {
            prompt: 'Ctx {{workflow.input.chatId}} / {{workflow.runtime.graphqlUrl}} / {{workflow.runtime.authMode}}'
        };
        workflow.nodes = [start, code];
        workflow.connections = [createConnection('c1', start.id, code.id)];
        workflow.nodeModels = {
            code: {
                id: 'code',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async (node) => {
                    seenPrompt = String(node.runtime.prompt ?? '');
                    return { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed };
                }
            })
        });

        const result = await executor.executeNodeStep({
            workflow,
            nodeId: code.id,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            workflowInput: { chatId: 'chat_1' }
        });
        expect(seenPrompt).toBe('Ctx chat_1 / http://localhost/graphql / none');
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('passes resolved runtime to remote step execution', async () => {
        const workflow = createWorkflow();
        const start = createStartNode(1);
        start.status = WorkflowNodeStatusEnum.Passed;
        start.ports.out = { output: { message: 'Hi' } };
        const code = createCodeNode(2);
        code.runtime = { prompt: 'Ctx {{workflow.input.chatId}} / {{workflow.runtime.graphqlUrl}}' };
        workflow.nodes = [start, code];
        workflow.connections = [createConnection('c1', start.id, code.id)];
        workflow.nodeModels = {
            code: {
                id: 'code',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        let seenPrompt = '';
        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Server,
            adapters: createAdapters({})
        });

        const result = await executor.executeNodeStep({
            workflow,
            nodeId: code.id,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            workflowInput: { chatId: 'chat_1' },
            isNodeLocalCapable: (modelId) => modelId !== 'code',
            executeNodeRemotely: async ({ workflow: remoteWorkflow, nodeId }) => {
                const remoteNode = remoteWorkflow.nodes.find((item) => item.id === nodeId);
                seenPrompt = String(remoteNode?.runtime?.prompt ?? '');
                return {
                    workflow: remoteWorkflow,
                    node: {
                        ...(remoteNode || code),
                        status: WorkflowNodeStatusEnum.Passed,
                        ports: { ...(remoteNode?.ports || code.ports), out: { output: { prompt: seenPrompt } } }
                    },
                    result: { output: { prompt: seenPrompt }, status: WorkflowNodeStatusEnum.Passed, logs: [] }
                };
            }
        });

        expect(seenPrompt).toBe('Ctx chat_1 / http://localhost/graphql');
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Passed);
    });

    it('fails step execution when variable token is unresolved', async () => {

        const workflow = createWorkflow();
        const code = createCodeNode(2);
        code.runtime = { prompt: 'Summary {{input.node_start_1.output.message}}' };
        workflow.nodes = [code];
        workflow.nodeModels = {
            code: {
                id: 'code',
                fields: {
                    prompt: {
                        type: 'textarea',
                        allowVariables: true
                    }
                }
            }
        };

        const executor = createWorkflowExecutor({
            mode: WorkflowExecutorModeEnum.Local,
            adapters: createAdapters({
                code: async () => ({ output: { ok: true }, status: WorkflowNodeStatusEnum.Passed })
            })
        });

        const result = await executor.executeNodeStep({ workflow, nodeId: code.id, settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' } });
        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.status).toBe(WorkflowNodeStatusEnum.Failed);
    });
});
