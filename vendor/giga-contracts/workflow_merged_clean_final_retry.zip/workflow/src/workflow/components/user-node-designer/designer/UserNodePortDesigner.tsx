import React, { useMemo, useState } from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { OrderList } from 'primereact/orderlist';
import UserNodePortCard from './UserNodePortCard';
import { UserNodePortDraft, UserNodePortDraftKind, createPortDraft } from './user-node-schema-draft.utils';

const PORT_TYPES: Array<{ label: string; value: UserNodePortDraftKind }> = [
    { label: 'Input', value: 'input' },
    { label: 'Output', value: 'output' },
    { label: 'Command', value: 'command' }
];

interface UserNodePortDesignerProps {
    ports: UserNodePortDraft[];
    onChange: (ports: UserNodePortDraft[]) => void;
}

const UserNodePortDesigner: React.FC<UserNodePortDesignerProps> = ({ ports, onChange }) => {
    const [nextPortKind, setNextPortKind] = useState<UserNodePortDraftKind>('input');

    const normalizedPorts = useMemo(() => ports.map((port, index) => ({ ...port, order: index + 1 })), [ports]);

    const updatePort = (portId: string, nextPort: UserNodePortDraft) => {
        onChange(normalizedPorts.map((port) => (port.id === portId ? nextPort : port)).map((port, index) => ({ ...port, order: index + 1 })));
    };

    const removePort = (portId: string) => {
        onChange(normalizedPorts.filter((port) => port.id !== portId).map((port, index) => ({ ...port, order: index + 1 })));
    };

    const addPort = () => {
        onChange([...normalizedPorts, createPortDraft(nextPortKind, normalizedPorts.length + 1)].map((port, index) => ({ ...port, order: index + 1 })));
    };

    return (
        <div className="wf-user-node-designer__section">
            <div className="wf-user-node-designer__section-header">
                <div>
                    <h4>Ports</h4>
                    <p>Add a port, choose whether it is Input, Output, or Command, then order the rendered ports.</p>
                </div>
                <div className="wf-user-node-designer__section-actions">
                    <Dropdown value={nextPortKind} options={PORT_TYPES} onChange={(event) => setNextPortKind(String(event.value) as UserNodePortDraftKind)} className="wf-user-node-designer__add-port-kind" />
                    <Button label="Add Port" icon="pi pi-plus" size="small" onClick={addPort} />
                </div>
            </div>
            <OrderList
                value={normalizedPorts}
                onChange={(event) => onChange((event.value as UserNodePortDraft[]).map((port, index) => ({ ...port, order: index + 1 })))}
                itemTemplate={(port: UserNodePortDraft) => <UserNodePortCard port={port} onChange={(nextPort) => updatePort(port.id, nextPort)} onRemove={() => removePort(port.id)} />}
                dataKey="id"
                dragdrop
                className="wf-user-node-designer__order-list"
            />
        </div>
    );
};

export default UserNodePortDesigner;
