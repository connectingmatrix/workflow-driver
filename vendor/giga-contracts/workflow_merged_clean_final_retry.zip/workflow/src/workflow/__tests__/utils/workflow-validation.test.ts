import { describe, expect, it } from 'vitest';
import { getMissingPlayValidationNodes } from '@workflow/ui/workflow/utils/workflow-validation.utils';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('getMissingPlayValidationNodes', () => {
    it('returns missing start and end node requirements', () => {
        const workflow = createEmptyWorkflow('wf_validate_missing_all');
        expect(getMissingPlayValidationNodes(workflow)).toEqual(['Exactly one Start node is required before playing the workflow.', 'Exactly one Respond/End node is required before playing the workflow.']);
    });

    it('returns empty array when exactly one start and one end node are present', () => {
        const workflow = createEmptyWorkflow('wf_validate_ok');
        workflow.nodes = [createWorkflowNode(workflow, 'start', 'Start', 1), createWorkflowNode(workflow, 'respond-end', 'End', 2)];
        expect(getMissingPlayValidationNodes(workflow)).toEqual([]);
    });

    it('accepts legacy start/end model-id aliases', () => {
        const workflow = createEmptyWorkflow('wf_validate_alias_models');
        const start = { ...createWorkflowNode(workflow, 'start', 'Start', 1), modelId: 'start_node' };
        const end = { ...createWorkflowNode(workflow, 'respond-end', 'End', 2), modelId: 'respond-end-node' };
        workflow.nodes = [start, end];
        expect(getMissingPlayValidationNodes(workflow)).toEqual([]);
    });

    it('returns duplicate node validation errors', () => {
        const workflow = createEmptyWorkflow('wf_validate_duplicates');
        workflow.nodes = [createWorkflowNode(workflow, 'start', 'Start 1', 1), createWorkflowNode(workflow, 'start', 'Start 2', 2), createWorkflowNode(workflow, 'respond-end', 'End 1', 3), createWorkflowNode(workflow, 'respond-end', 'End 2', 4)];

        expect(getMissingPlayValidationNodes(workflow)).toEqual(['Only one Start node is allowed per workflow.', 'Only one Respond/End node is allowed per workflow.']);
    });

    it('returns validation error when respond/end has multiple incoming connections', () => {
        const workflow = createEmptyWorkflow('wf_validate_end_inputs');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeA = createWorkflowNode(workflow, 'code', 'Code A', 2);
        const codeB = createWorkflowNode(workflow, 'code', 'Code B', 3);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 4);

        workflow.nodes = [start, codeA, codeB, end];
        workflow.connections = [createConnection('c_1', start.id, codeA.id), createConnection('c_2', start.id, codeB.id), createConnection('c_3', codeA.id, end.id), createConnection('c_4', codeB.id, end.id)];

        expect(getMissingPlayValidationNodes(workflow)).toEqual(['Respond/End node can have only one incoming connection.']);
    });
});
