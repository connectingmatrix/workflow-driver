import React from 'react';
import type { WorkflowLogsFilter } from '@workflow/ui/workflow/components/logs/logs-dialog.types';

interface WorkflowLogsFiltersProps {
    search: string;
    filter: WorkflowLogsFilter;
    prettyPrint: boolean;
    onSearchChange: (value: string) => void;
    onFilterChange: (value: WorkflowLogsFilter) => void;
    onPrettyPrintChange: (value: boolean) => void;
}

const FILTERS: Array<{ id: WorkflowLogsFilter; label: string }> = [
    { id: 'all', label: 'All' },
    { id: 'info', label: 'Info' },
    { id: 'warn', label: 'Warnings' },
    { id: 'error', label: 'Errors' }
];

export const WorkflowLogsFilters: React.FC<WorkflowLogsFiltersProps> = ({ search, filter, prettyPrint, onSearchChange, onFilterChange, onPrettyPrintChange }) => (
    <div className="wf-workspace-logs__filters-row">
        <div className="wf-workspace-logs__search-shell">
            <i className="pi pi-search" aria-hidden />
            <input value={search} onChange={(event) => onSearchChange(event.target.value)} placeholder="Search node, event, level, or run field…" className="wf-workspace-logs__search-input" />
        </div>
        <div className="wf-workspace-logs__filter-pills">
            {FILTERS.map((item) => (
                <button key={item.id} type="button" className={`wf-workspace-logs__filter-pill${filter === item.id ? ' wf-workspace-logs__filter-pill--active' : ''}`} onClick={() => onFilterChange(item.id)}>
                    {item.label}
                </button>
            ))}
        </div>
        <label className="wf-workspace-logs__toggle-shell">
            <span>Pretty print</span>
            <span className={`wf-workspace-logs__toggle${prettyPrint ? ' wf-workspace-logs__toggle--active' : ''}`}>
                <input type="checkbox" checked={prettyPrint} onChange={(event) => onPrettyPrintChange(event.target.checked)} />
                <span className="wf-workspace-logs__toggle-knob" />
            </span>
        </label>
    </div>
);
