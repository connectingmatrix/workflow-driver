import { WorkflowCypherGraph } from './types';

const FORBIDDEN_RUNTIME_KEYS = new Set([
  'NODE_EXECUTORS',
  'NODE_EXECUTOR_SIGNATURES',
  'NODE_VALIDATORS',
  'connections',
  'nodeModels',
  'nodes',
  'output',
  'ports',
  'position',
  'render',
  'inspector',
  'gigaId',
  'id',
]);

function missingRequiredInputs(schema: any, runtime: Record<string, unknown>) {
  const fields = schema?.fields || {};
  return (schema?.documentation?.inputs || [])
    .filter((item: any) => item?.required === true && !String(item?.key || '').startsWith('port:'))
    .map((item: any) => String(item.key || '').trim())
    .filter((key: string) => {
      if (!key) return false;
      if (runtime[key] !== undefined && runtime[key] !== null && String(runtime[key]).trim() !== '') return false;
      // If the schema field has a default value, the requirement is satisfied
      const fieldDefault = fields[key]?.defaultValue;
      if (fieldDefault !== undefined && fieldDefault !== null && String(fieldDefault).trim() !== '') return false;
      return true;
    });
}

export function validateRuntimePayloads(graph: WorkflowCypherGraph, schemas: Record<string, any>) {
  const errors: string[] = [];
  for (const spec of graph.nodes) {
    for (const key of Object.keys(spec.runtime || {})) {
      if (FORBIDDEN_RUNTIME_KEYS.has(key)) errors.push(`${spec.alias}.${key} is a persisted workflow artifact and cannot be supplied in Cypher runtime.`);
    }
    const missing = missingRequiredInputs(schemas[spec.modelId], spec.runtime || {});
    missing.forEach((key: string) => errors.push(`${spec.alias}.${key} is required by ${spec.modelId}.`));
  }
  return errors;
}
