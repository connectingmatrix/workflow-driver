import React, { useMemo, useState } from 'react';
import { InputText } from 'primereact/inputtext';
import { PRIME_ICON_CLASSES } from './prime-icons.catalog';

interface UserNodePrimeIconPickerProps {
    iconClass: string;
    onChange: (value: string) => void;
}

const UserNodePrimeIconPicker: React.FC<UserNodePrimeIconPickerProps> = ({ iconClass, onChange }) => {
    const [search, setSearch] = useState<string>('');
    const filteredIcons = useMemo(
        () => PRIME_ICON_CLASSES.filter((value) => value.toLowerCase().includes(search.trim().toLowerCase())),
        [search]
    );

    return (
        <div className="wf-user-node-designer__icon-picker">
            <InputText value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search PrimeIcons" className="w-full" data-cy="user-node-icon-search" />
            <div className="wf-user-node-designer__icon-grid" data-cy="user-node-icon-grid">
                {filteredIcons.map((value) => {
                    const isSelected = value === iconClass;
                    return (
                        <button
                            key={value}
                            type="button"
                            className={`wf-user-node-designer__icon-option ${isSelected ? 'wf-user-node-designer__icon-option--selected' : ''}`}
                            onClick={() => onChange(value)}
                            title={value}
                            aria-label={`Select ${value}`}
                            data-cy={`user-node-icon-${value.replace(/\s+/g, '-')}`}
                        >
                            <i className={value} aria-hidden />
                            <span>{value.replace('pi pi-', '')}</span>
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

export default UserNodePrimeIconPicker;
