import React from 'react';

interface WorkspaceRenderedIconProps {
    iconClass?: string;
    iconColor?: string;
    iconSvg?: string;
    fallback?: React.ReactNode;
    className?: string;
}

export const WorkspaceRenderedIcon: React.FC<WorkspaceRenderedIconProps> = ({ iconClass, iconColor, iconSvg, fallback, className }) => {
    if (iconSvg?.trim()) {
        return <span className={className} style={{ color: iconColor }} dangerouslySetInnerHTML={{ __html: iconSvg }} />;
    }

    if (iconClass?.trim()) {
        return <i className={`${iconClass} ${className ?? ''}`.trim()} style={{ color: iconColor }} aria-hidden />;
    }

    return <>{fallback ?? null}</>;
};
