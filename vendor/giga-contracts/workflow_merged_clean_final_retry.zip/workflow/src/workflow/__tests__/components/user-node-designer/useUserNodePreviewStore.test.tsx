import { act, renderHook } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { useUserNodePreviewStore } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';

describe('useUserNodePreviewStore', () => {
    it('keeps failed result status even when stop reason reports completed', () => {
        const { result } = renderHook(() => useUserNodePreviewStore());

        act(() => {
            result.current.actions.startRun({
                runId: 'run_1',
                inputUsed: { hello: 'world' },
                requestedRuntime: 'auto',
                effectiveRuntime: 'node',
                sourceMode: 'unsaved',
                nodeModelId: 'user-node:test',
                nodeDefinitionId: 'def_1'
            });
            result.current.actions.setResult({ error: 'failed' }, 'failed');
            result.current.actions.stopRun('completed');
        });

        expect(result.current.state.status).toBe('failed');
    });

    it('stores diagnostics separately from raw logs', () => {
        const { result } = renderHook(() => useUserNodePreviewStore());

        act(() => {
            result.current.actions.startRun({
                runId: 'run_2',
                inputUsed: {},
                requestedRuntime: 'browser',
                effectiveRuntime: 'browser',
                sourceMode: 'unsaved',
                nodeModelId: 'user-node:test',
                nodeDefinitionId: null
            });
            result.current.actions.appendLog({
                runId: 'run_2',
                nodeId: 'node_preview_1',
                source: 'worker',
                line: 'worker-log-line',
                timestamp: new Date().toISOString()
            });
            result.current.actions.setDiagnostics({
                errors: ['invalid-json'],
                warnings: ['warn-json'],
                message: 'Invalid JSON'
            });
        });

        expect(result.current.state.logs.map((entry) => entry.line)).toEqual(['worker-log-line']);
        expect(result.current.state.diagnostics).toEqual(['warn-json', 'invalid-json']);
        expect(result.current.state.runtimeError).toBe('Invalid JSON');
    });
});
