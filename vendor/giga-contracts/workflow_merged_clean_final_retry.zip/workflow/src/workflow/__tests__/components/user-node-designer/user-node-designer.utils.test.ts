import { describe, expect, it } from 'vitest';
import { WorkflowDefinition, WorkflowNodeStatusEnum, WorkflowUserNodeDefinition } from '@workflow/ui/workflow/types';
import { buildUserNodePreviewWorkflow, mergeWorkflowUserNodeSchemas, toUserNodeLibraryItem, toUserNodeSchema, workflowNeedsUserNodeSchemaSync } from '@workflow/ui/workflow/components/user-node-designer/user-node-designer.utils';

const createUserNode = (): WorkflowUserNodeDefinition => ({
    id: 'def_1',
    userId: 'user_1',
    name: 'My User Node',
    slug: 'my-user-node',
    description: 'Custom node',
    groupName: 'User Nodes',
    nodeSchema: {
        iconClass: 'pi pi-sitemap',
        iconColor: '#0f766e',
        iconMode: 'svg',
        iconSvg: '<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="4"/></svg>',
        render: {
            iconClass: 'pi pi-sitemap',
            iconColor: '#0f766e',
            iconMode: 'svg',
            iconSvg: '<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="4"/></svg>'
        },
        fields: {
            prompt: {
                type: 'string'
            }
        },
        commands: {
            llm: {
                label: 'LLM',
                side: 'bottom',
                portType: 'bi-directional'
            }
        }
    },
    sourceFiles: {
        'worker.ts': 'export const execute = async () => ({ output: { ok: true }, status: "passed", logs: [] });'
    },
    isActive: true,
    createdAt: '2026-03-23T00:00:00.000Z',
    updatedAt: '2026-03-23T00:00:00.000Z',
    modelId: 'user-node:def_1'
});

const createWorkflow = (): WorkflowDefinition => ({
    metadata: {
        id: 'wf_1',
        name: 'Workflow 1'
    },
    nodeModels: {},
    nodes: [],
    connections: []
});

describe('user node designer utils', () => {
    it('maps user node definitions to node library items', () => {
        const item = toUserNodeLibraryItem(createUserNode());
        expect(item.modelId).toBe('user-node:def_1');
        expect(item.group).toBe('User Nodes');
        expect(item.iconClass).toBe('pi pi-sitemap');
        expect(item.iconColor).toBe('#0f766e');
        expect(typeof item.renderIcon).toBe('function');
    });

    it('builds a node schema with default io ports when missing', () => {
        const schema = toUserNodeSchema({ ...createUserNode(), nodeSchema: {} });
        expect(schema.id).toBe('user-node:def_1');
        expect(schema.inputs).toHaveProperty('input');
        expect(schema.outputs).toHaveProperty('output');
        expect(schema.commands).toBeUndefined();
    });

    it('preserves saved command ports and icon metadata in the generated schema', () => {
        const schema = toUserNodeSchema(createUserNode());
        expect(schema.iconClass).toBe('pi pi-sitemap');
        expect(schema.iconColor).toBe('#0f766e');
        expect(schema.iconMode).toBe('svg');
        expect(schema.iconSvg).toContain('<svg');
        expect(schema.render?.iconClass).toBe('pi pi-sitemap');
        expect(schema.render?.iconColor).toBe('#0f766e');
        expect(schema.render?.iconMode).toBe('svg');
        expect(schema.render?.iconSvg).toContain('<svg');
        expect(schema.commands).toHaveProperty('llm');
    });

    it('merges user node schema into workflow models and reports sync status', () => {
        const workflow = createWorkflow();
        const userNode = createUserNode();
        const merged = mergeWorkflowUserNodeSchemas(workflow, [userNode]);
        expect(merged.nodeModels?.['user-node:def_1']).toBeTruthy();
        expect(workflowNeedsUserNodeSchemaSync(merged, [userNode])).toBe(false);
    });

    it('builds a preview workflow containing one user node step', () => {
        const userNode = createUserNode();
        const workflow = buildUserNodePreviewWorkflow({
            userNode,
            schema: toUserNodeSchema(userNode),
            runtime: { prompt: 'hello' },
            settings: { graphqlUrl: '', authMode: 'none', maxExecutionSeconds: 300, manualHeaders: {} }
        });

        expect(workflow.nodes).toHaveLength(1);
        expect(workflow.nodes[0]?.modelId).toBe('user-node:def_1');
        expect(workflow.nodes[0]?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect(workflow.metadata.name).toContain('Preview');
    });
});
