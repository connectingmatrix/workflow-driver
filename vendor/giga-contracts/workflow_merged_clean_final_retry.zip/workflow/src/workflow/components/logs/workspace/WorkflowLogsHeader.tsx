import React from 'react';

interface WorkflowLogsHeaderProps {
    title: string;
    subtitle: string;
    runId: string;
    eventCount: number;
    byteLabel: string;
    warningCount: number;
    onDownload: () => void;
    onCopy: () => void;
    onClose: () => void;
}

export const WorkflowLogsHeader: React.FC<WorkflowLogsHeaderProps> = ({ title, subtitle, runId, eventCount, byteLabel, warningCount, onDownload, onCopy, onClose }) => (
    <header className="wf-workspace-logs__header">
        <div className="wf-workspace-logs__title-wrap">
            <div className="wf-workspace-logs__icon-shell">
                <i className="pi pi-align-left" aria-hidden />
            </div>
            <div>
                <h2 className="wf-workspace-logs__title">{title}</h2>
                <p className="wf-workspace-logs__subtitle">{subtitle}</p>
                <div className="wf-workspace-logs__meta-row">
                    <span className="wf-workspace-logs__live-pill">Live</span>
                    <span className="wf-workspace-logs__meta-copy">Run ID {runId}</span>
                    <span className="wf-workspace-logs__meta-copy">• {eventCount} events</span>
                    <span className="wf-workspace-logs__meta-copy">• {byteLabel}</span>
                    <span className="wf-workspace-logs__meta-copy">• {warningCount} warning{warningCount === 1 ? '' : 's'}</span>
                </div>
            </div>
        </div>
        <div className="wf-workspace-logs__actions">
            <button type="button" className="wf-workspace-logs__action-button" onClick={onDownload}>
                <i className="pi pi-download" aria-hidden />
                <span>Download</span>
            </button>
            <button type="button" className="wf-workspace-logs__action-button" onClick={onCopy}>
                <i className="pi pi-copy" aria-hidden />
                <span>Copy</span>
            </button>
            <button type="button" className="wf-workspace-logs__icon-button" aria-label="Close workflow logs" onClick={onClose}>
                <i className="pi pi-times" aria-hidden />
            </button>
        </div>
    </header>
);
