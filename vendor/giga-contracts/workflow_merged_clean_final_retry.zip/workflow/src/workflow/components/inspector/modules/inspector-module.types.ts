import type { ComponentType } from 'react';
import type { WorkflowExecutionResult, WorkflowInspectorConfig, WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';
import { WorkflowNodeFieldMap } from '@workflow/ui/workflow/types';
import type {
    WorkspaceFeatureItem,
    WorkspaceFieldPresentation,
    WorkspaceHeroCard,
    WorkspaceHintItem,
    WorkspaceIconName,
    WorkspacePanelEmptyState,
    WorkspaceParameterSectionVariant
} from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkflowVariableSuggestion } from '@workflow/ui/workflow/utils/workflow-variables.utils';

export interface WorkflowInspectorModuleSectionProps {
    modelId: string;
    fields: WorkflowNodeFieldMap;
    propertiesEditorState: Record<string, unknown>;
    workflowData?: Record<string, unknown>;
    onPropertyChange: (key: string, value: unknown) => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowVariableSuggestion[];
}

export interface WorkflowInspectorModuleFieldResolverContext {
    config: WorkflowInspectorConfig;
    fields: WorkflowNodeFieldMap;
    propertiesEditorState: Record<string, unknown>;
}

export interface WorkflowInspectorModuleViewerResolverContext {
    config: WorkflowInspectorConfig;
    viewers: WorkflowInspectorViewer[];
    propertiesEditorState: Record<string, unknown>;
    executionResult: WorkflowExecutionResult | null;
    renderedMarkdown: string;
}

export interface WorkflowInspectorModuleDefinition {
    propertyOrder?: string[];
    bodyClassName?: string;
    shouldDisplayField?: (fieldKey: string, values: Record<string, unknown>, fields: WorkflowNodeFieldMap) => boolean;
    appendSection?: ComponentType<WorkflowInspectorModuleSectionProps>;
    workspace?: {
        input?: {
            acceptedFormats?: string[];
            featureItems?: WorkspaceFeatureItem[];
            emptyState?: Partial<WorkspacePanelEmptyState>;
            icon?: WorkspaceIconName;
        };
        parameters?: {
            heroCard?: Partial<WorkspaceHeroCard>;
            hints?: WorkspaceHintItem[];
            resolveFields?: (context: WorkflowInspectorModuleFieldResolverContext) => WorkflowNodeFieldMap;
            sections?: Array<{
                id: string;
                title: string;
                description?: string;
                fieldKeys?: string[];
                includeRemaining?: boolean;
                variant?: WorkspaceParameterSectionVariant;
            }>;
            fieldPresentation?: Record<string, WorkspaceFieldPresentation>;
            fieldBadges?: Record<string, string>;
            fieldHelperText?: Record<string, string>;
            icon?: WorkspaceIconName;
        };
        output?: {
            icon?: WorkspaceIconName;
            summaryTip?: string;
            resolveViewers?: (context: WorkflowInspectorModuleViewerResolverContext) => WorkflowInspectorViewer[];
        };
    };
}
