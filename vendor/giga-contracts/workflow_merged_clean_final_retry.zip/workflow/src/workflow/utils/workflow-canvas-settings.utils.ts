import { ConnectionLineType } from '@xyflow/react';
import type { WorkflowCanvasEdgeStyle, WorkflowCanvasLayoutEngine, WorkflowCanvasSettings, WorkflowDefinition } from '@workflow/ui/workflow/types';

export const DEFAULT_WORKFLOW_CANVAS_LAYOUT_ENGINE: WorkflowCanvasLayoutEngine = 'legacy';
export const DEFAULT_WORKFLOW_CANVAS_EDGE_STYLE: WorkflowCanvasEdgeStyle = 'legacy';

export const resolveWorkflowCanvasSettings = (workflow: WorkflowDefinition | null | undefined): Required<WorkflowCanvasSettings> => {
    const canvas = workflow && workflow.metadata.ui && workflow.metadata.ui.canvas ? workflow.metadata.ui.canvas : {};
    return {
        layoutEngine: canvas.layoutEngine || DEFAULT_WORKFLOW_CANVAS_LAYOUT_ENGINE,
        edgeStyle: canvas.edgeStyle || DEFAULT_WORKFLOW_CANVAS_EDGE_STYLE
    };
};

export const resolveConnectionLineType = (edgeStyle: WorkflowCanvasEdgeStyle): ConnectionLineType => {
    if (edgeStyle === 'straight') return ConnectionLineType.Straight;
    if (edgeStyle === 'step') return ConnectionLineType.Step;
    if (edgeStyle === 'smoothstep') return ConnectionLineType.SmoothStep;
    return ConnectionLineType.Bezier;
};
