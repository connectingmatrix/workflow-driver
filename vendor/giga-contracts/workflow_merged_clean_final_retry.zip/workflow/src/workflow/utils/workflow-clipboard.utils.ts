import { WorkflowConnectionModel, WorkflowDefinition } from '@workflow/ui/workflow/types';
import { buildUniqueNodeName } from '@workflow/ui/workflow/utils/workflow-node-name.utils';
import { createWorkflowConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';

const STORAGE_KEY = 'giga_workflow_clipboard';
const MIME_MARKER = '__giga_workflow_clipboard__';

interface WorkflowClipboardPayload {
    marker: string;
    connections: WorkflowConnectionModel[];
    nodes: WorkflowDefinition['nodes'];
}

const cloneJson = <T>(value: T): T => JSON.parse(JSON.stringify(value));

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const nextNodeId = (workflow: WorkflowDefinition, modelId: string, sequence: number): string =>
    `${
        modelId
            .replace(/[^a-z0-9]+/gi, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '')
            .toLowerCase() || 'node'
    }-${sequence}`;

const nextSequence = (workflow: WorkflowDefinition): number =>
    workflow.nodes.reduce((maxValue, node) => {
        const match = node.id.match(/(\d+)$/);
        return match ? Math.max(maxValue, Number(match[1])) : maxValue;
    }, 0) + 1;

const parsePayload = (value: string): WorkflowClipboardPayload | null => {
    try {
        const parsed = JSON.parse(value);
        if (parsed?.marker !== MIME_MARKER || !Array.isArray(parsed?.nodes) || !Array.isArray(parsed?.connections)) {
            return null;
        }
        return parsed as WorkflowClipboardPayload;
    } catch {
        return null;
    }
};

export const copyWorkflowSelection = async (workflow: WorkflowDefinition, nodeIds: string[]): Promise<boolean> => {
    const selectedNodeIdSet = new Set(nodeIds);
    const nodes = workflow.nodes.filter((node) => selectedNodeIdSet.has(node.id));
    if (!nodes.length) {
        return false;
    }
    const payload: WorkflowClipboardPayload = {
        marker: MIME_MARKER,
        nodes: cloneJson(nodes),
        connections: cloneJson(workflow.connections.filter((connection) => selectedNodeIdSet.has(connection.from) && selectedNodeIdSet.has(connection.to)))
    };
    const serialized = JSON.stringify(payload);
    window.localStorage.setItem(STORAGE_KEY, serialized);
    await navigator.clipboard.writeText(serialized);
    return true;
};

export const readWorkflowClipboard = async (): Promise<WorkflowClipboardPayload | null> => {
    try {
        const clipboardText = await navigator.clipboard.readText();
        const payload = parsePayload(clipboardText);
        if (payload) {
            return payload;
        }
    } catch {
        // Clipboard access can fail in browser security contexts; localStorage fallback handles same-session paste.
    }
    return parsePayload(window.localStorage.getItem(STORAGE_KEY) || '');
};

export const pasteWorkflowSelection = (workflow: WorkflowDefinition, payload: WorkflowClipboardPayload, anchor: { x: number; y: number }): { insertedNodeIds: string[]; workflow: WorkflowDefinition } => {
    if (!payload.nodes.length) {
        return {
            insertedNodeIds: [],
            workflow
        };
    }

    const getFinite = (value: unknown, fallback = 0): number => (typeof value === 'number' && Number.isFinite(value) ? value : fallback);
    const minX = Math.min(...payload.nodes.map((node) => getFinite(node.position?.x)));
    const minY = Math.min(...payload.nodes.map((node) => getFinite(node.position?.y)));
    const sequenceStart = nextSequence(workflow);
    const nodeIdMap = new Map<string, string>();
    const namesInUse = new Set(workflow.nodes.map((node) => node.name));

    const insertedNodes = payload.nodes.map((node, index) => {
        const nextId = nextNodeId(workflow, node.modelId, sequenceStart + index);
        nodeIdMap.set(node.id, nextId);
        const nextNameSeed = buildUniqueNodeName(workflow, `${node.name} Copy`);
        let nextName = nextNameSeed;
        let duplicateIndex = 2;
        while (namesInUse.has(nextName)) {
            nextName = `${nextNameSeed} ${duplicateIndex}`;
            duplicateIndex += 1;
        }
        namesInUse.add(nextName);

        const sourceX = getFinite(node.position?.x);
        const sourceY = getFinite(node.position?.y);
        return {
            ...cloneJson(node),
            id: nextId,
            name: nextName,
            position: {
                x: anchor.x + (sourceX - minX),
                y: anchor.y + (sourceY - minY)
            },
            runtime: cloneJson(node.runtime),
            properties: cloneJson(node.properties),
            inspector: node.inspector
                ? {
                      ...cloneJson(node.inspector),
                      title: nextName
                  }
                : node.inspector
        };
    });

    const insertedConnections = payload.connections
        .map((connection) => {
            const mappedSource = nodeIdMap.get(connection.from);
            const mappedTarget = nodeIdMap.get(connection.to);
            if (!mappedSource || !mappedTarget) {
                return null;
            }
            return createWorkflowConnection({
                source: mappedSource,
                target: mappedTarget,
                sourceHandle: connection.sourceHandle ?? undefined,
                targetHandle: connection.targetHandle ?? undefined
            });
        })
        .filter((connection): connection is WorkflowConnectionModel => Boolean(connection));

    const nextWorkflow = {
        ...workflow,
        nodes: [...workflow.nodes, ...insertedNodes],
        connections: [...workflow.connections, ...insertedConnections]
    };

    insertedNodes.forEach((node) => {
        node.runtime = {
            ...toRecord(node.runtime),
            sourceWorkflowId: workflow.metadata.id
        };
    });

    return {
        insertedNodeIds: insertedNodes.map((node) => node.id),
        workflow: nextWorkflow
    };
};
