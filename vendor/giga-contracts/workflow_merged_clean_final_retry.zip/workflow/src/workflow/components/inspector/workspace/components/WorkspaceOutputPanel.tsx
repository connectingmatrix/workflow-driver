import React from 'react';
import type { WorkspaceOutputPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspacePanelFrame } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspacePanelFrame';
import { WorkspaceSegmentedTabs } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceSegmentedTabs';
import { WorkspaceActionButton } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceActionButton';
import { WorkspaceStatusBadge } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceStatusBadge';
import { WorkspaceOutputContent } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceOutputContent';

interface WorkspaceOutputPanelProps {
    model: WorkspaceOutputPanelModel;
    showOutputSummary: boolean;
    showRecentActivity: boolean;
    onTabChange: (tabId: string) => void;
    onAction: (actionId: string) => void;
}

const resolveActivityClass = (tone?: string): string => {
    switch (tone) {
        case 'success':
            return 'is-success';
        case 'info':
            return 'is-info';
        case 'warning':
            return 'is-warning';
        case 'danger':
            return 'is-danger';
        default:
            return '';
    }
};

export const WorkspaceOutputPanel: React.FC<WorkspaceOutputPanelProps> = ({ model, showOutputSummary, showRecentActivity, onTabChange, onAction }) => {
    return (
        <WorkspacePanelFrame panelClassName="cnw-panel--output" bodyClassName="cnw-panel__body--output" title={model.title} description={model.description} icon={model.icon}>
            <div className="cnw-output-panel">
                <div className="cnw-output-panel__toolbar-row">
                    <WorkspaceSegmentedTabs items={model.tabs} activeId={model.activeTab} onChange={onTabChange} />
                    {model.copyAction ? <WorkspaceActionButton action={model.copyAction} onClick={onAction} /> : null}
                </div>

                <div className="cnw-output-panel__scroll">
                    {model.status ? (
                        <div className="cnw-output-status-row">
                            <WorkspaceStatusBadge status={model.status} />
                            {model.status.meta ? <span className="cnw-output-status-row__meta">{model.status.meta}</span> : null}
                        </div>
                    ) : null}

                    <WorkspaceOutputContent model={model} />

                    {showOutputSummary && model.summary ? (
                        <div className="cnw-summary-card">
                            <h4 className="cnw-subsection__title">{model.summary.title}</h4>
                            {model.summary.description ? <p className="cnw-summary-card__description">{model.summary.description}</p> : null}
                            {model.summary.tip ? <div className="cnw-summary-card__tip">{model.summary.tip}</div> : null}
                        </div>
                    ) : null}

                    {showRecentActivity && model.activities?.length ? (
                        <div className="cnw-activity-block">
                            <h4 className="cnw-subsection__title">Recent activity</h4>
                            <div className="cnw-activity-list">
                                {model.activities.map((item) => (
                                    <div key={item.id} className="cnw-activity-card">
                                        <span className={`cnw-activity-card__dot ${resolveActivityClass(item.tone)}`} />
                                        <div>
                                            <p className="cnw-activity-card__title">{item.title}</p>
                                            {item.description ? <p className="cnw-activity-card__description">{item.description}</p> : null}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : null}
                </div>
            </div>
        </WorkspacePanelFrame>
    );
};
