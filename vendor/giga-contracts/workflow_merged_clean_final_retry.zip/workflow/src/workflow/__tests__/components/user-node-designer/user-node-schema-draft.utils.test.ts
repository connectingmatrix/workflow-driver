import { describe, expect, it } from 'vitest';
import {
    createEmptyUserNodeSchemaDraft,
    deserializeUserNodeSchemaDraft,
    serializeUserNodeSchemaDraft
} from '@workflow/ui/workflow/components/user-node-designer/designer/user-node-schema-draft.utils';

describe('user node schema draft utils', () => {
    it('round-trips command ports, field order, icon metadata, and credential binding', () => {
        const draft = createEmptyUserNodeSchemaDraft();
        draft.iconMode = 'svg';
        draft.iconClass = 'pi pi-bolt';
        draft.iconColor = '#0f766e';
        draft.iconSvg = '<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="4"/></svg>';
        draft.useCredentials = 'openai';
        draft.fields = [
            {
                id: 'field_b',
                key: 'second',
                label: 'Second',
                type: 'string',
                order: 2,
                hidden: false,
                editable: true,
                allowVariables: true,
                placeholder: 'later'
            },
            {
                id: 'field_a',
                key: 'first',
                label: 'First',
                type: 'number',
                order: 1,
                hidden: false,
                editable: true,
                allowVariables: false,
                placeholder: 'earlier'
            }
        ];
        draft.ports = [
            {
                id: 'command_llm',
                kind: 'command',
                key: 'llm',
                label: 'LLM',
                side: 'bottom',
                order: 1,
                allowMultipleArrows: true,
                portType: 'bi-directional',
                acceptedSourceGroups: 'AI Models',
                acceptedSourceModelIds: 'openai, claude',
                showQuickAdd: false
            }
        ];

        const serialized = serializeUserNodeSchemaDraft(draft);
        const roundTrip = deserializeUserNodeSchemaDraft(serialized);

        expect(serialized.iconClass).toBe('pi pi-bolt');
        expect(serialized.iconColor).toBe('#0f766e');
        expect(serialized.iconMode).toBe('svg');
        expect(serialized.iconSvg).toContain('<svg');
        expect(serialized.render?.iconClass).toBe('pi pi-bolt');
        expect(serialized.render?.iconColor).toBe('#0f766e');
        expect(serialized.render?.iconMode).toBe('svg');
        expect(serialized.render?.iconSvg).toContain('<svg');
        expect(serialized.useCredentials).toBe('openai');
        expect(Object.keys(serialized.fields ?? {})).toEqual(['first', 'second']);
        expect(serialized.commands?.llm?.acceptedSourceGroups).toEqual(['AI Models']);
        expect(serialized.commands?.llm?.acceptedSourceModelIds).toEqual(['openai', 'claude']);
        expect(roundTrip.fields.map((field) => field.key)).toEqual(['first', 'second']);
        expect(roundTrip.ports[0]?.key).toBe('llm');
        expect(roundTrip.iconClass).toBe('pi pi-bolt');
        expect(roundTrip.iconColor).toBe('#0f766e');
        expect(roundTrip.iconMode).toBe('svg');
        expect(roundTrip.iconSvg).toContain('<svg');
        expect(roundTrip.useCredentials).toBe('openai');
    });
});
