import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { packageAllowed } from './dependency-policy';

const text = (value: unknown): string => String(value ?? '').trim();
const cacheRoot = () => process.env.WF_DYNAMIC_NODE_PACKAGE_CACHE_DIR || path.join(process.cwd(), '.wf-dynamic-node-cache');
const installEnabled = () => String(process.env.WF_DYNAMIC_NODE_ALLOW_PACKAGE_INSTALL || '0') === '1';

const run = (cmd: string, args: string[], cwd: string) => new Promise<void>((resolve, reject) => {
  const child = spawn(cmd, args, { cwd, stdio: 'pipe', env: { ...process.env, npm_config_audit: 'false', npm_config_fund: 'false' } });
  let stderr = '';
  child.stderr.on('data', (chunk) => { stderr += String(chunk); });
  child.on('error', reject);
  child.on('close', (code) => code === 0 ? resolve() : reject(new Error(`${cmd} ${args.join(' ')} failed (${code}): ${stderr.slice(-4000)}`)));
});

export const dynamicPackageCacheKey = (packages: string[]) => packages.map(text).filter(Boolean).sort().join('__').replace(/[^a-zA-Z0-9@._-]+/g, '_') || 'empty';

export const ensureDynamicPackageCache = async (packages: string[]) => {
  const requested = packages.map(text).filter(Boolean);
  for (const pkg of requested) if (!packageAllowed(pkg)) throw new Error(`Dynamic node package is not allowlisted: ${pkg}`);
  const dir = path.join(cacheRoot(), dynamicPackageCacheKey(requested));
  await fs.mkdir(dir, { recursive: true });
  const packageJson = path.join(dir, 'package.json');
  try { await fs.access(packageJson); } catch { await fs.writeFile(packageJson, JSON.stringify({ private: true, type: 'module', dependencies: {} }, null, 2)); }
  if (!requested.length) return { dir, packages: requested, installed: false };
  const nodeModules = path.join(dir, 'node_modules');
  try { await fs.access(nodeModules); return { dir, packages: requested, installed: false }; } catch { /* install */ }
  if (!installEnabled()) throw new Error('Dynamic package installation is disabled. Set WF_DYNAMIC_NODE_ALLOW_PACKAGE_INSTALL=1 and allowlist packages.');
  await run('npm', ['install', '--ignore-scripts', '--no-audit', '--no-fund', ...requested], dir);
  return { dir, packages: requested, installed: true };
};
