import type { WorkflowQueueWorker } from "../queue/types";

export const startWorkflowExecutionPubsub = (params: {
  createEventConsumer: () => {
    start: () => Promise<void>;
    stop: (params?: { force?: boolean }) => Promise<void>;
  };
  createRequestRunner: () => WorkflowQueueWorker;
}) => {
  let startPromise: Promise<void> | null = null;
  let requestRunner: WorkflowQueueWorker | null = null;
  let eventConsumer: {
    stop: (params?: { force?: boolean }) => Promise<void>;
  } | null = null;

  return {
    start: (): Promise<void> => {
      if (!startPromise) {
        const nextRequestRunner = params.createRequestRunner();
        const nextEventConsumer = params.createEventConsumer();
        requestRunner = nextRequestRunner;
        eventConsumer = nextEventConsumer;
        startPromise = Promise.all([
          nextRequestRunner.start(),
          nextEventConsumer.start(),
        ])
          .then(() => undefined)
          .catch(async (error) => {
            await Promise.allSettled([
              nextRequestRunner.stop({ force: true }),
              nextEventConsumer.stop({ force: true }),
            ]);
            if (requestRunner === nextRequestRunner) requestRunner = null;
            if (eventConsumer === nextEventConsumer) eventConsumer = null;
            startPromise = null;
            throw error;
          });
      }
      return startPromise;
    },
    stop: async (options?: { force?: boolean }) => {
      if (!requestRunner || !eventConsumer) {
        startPromise = null;
        return;
      }
      const activeRequestRunner = requestRunner;
      const activeEventConsumer = eventConsumer;
      requestRunner = null;
      eventConsumer = null;
      startPromise = null;
      await Promise.all([
        activeRequestRunner.stop(options),
        activeEventConsumer.stop(options),
      ]);
    },
    cancelRun: (runId: string) => requestRunner?.cancelRun(runId) || 0,
    cancelWorkflow: (workflowId: string) =>
      requestRunner?.cancelWorkflow(workflowId) || 0,
    getRunning: (workflowId?: string | null) =>
      requestRunner?.getRunning(workflowId) || [],
  };
};
