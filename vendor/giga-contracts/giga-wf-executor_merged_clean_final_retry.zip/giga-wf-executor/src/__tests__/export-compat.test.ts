import { describe, expect, it } from 'vitest';
import * as executor from '../index';
import * as nodeCore from '../node-core';

describe('package export compatibility', () => {
    it('keeps root executor exports available', () => {
        expect(typeof executor.createWorkflowExecutor).toBe('function');
        expect(typeof executor.createWorkerNodeHandler).toBe('function');
        expect(typeof executor.createJsonlLogger).toBe('function');
        expect(typeof executor.createWorkflowExecutionTimeoutController).toBe('function');
        expect(typeof executor.createNodeExecutorSignature).toBe('function');
        expect(typeof executor.normalizeResult).toBe('function');
        expect(typeof executor.toErrorResult).toBe('function');
        expect(typeof executor.toNode).toBe('function');
        expect(typeof executor.toRecord).toBe('function');
        expect('createWorkflowQueueKafkaClient' in executor).toBe(false);
    });

    it('keeps node-core compatibility exports available', () => {
        expect(typeof nodeCore.createRunId).toBe('function');
        expect(typeof nodeCore.buildNodeInputContext).toBe('function');
        expect(typeof nodeCore.buildRunningNodeState).toBe('function');
        expect(typeof nodeCore.buildWorkflowSummaryInput).toBe('function');
    });
});
