import { WorkflowNodeDocumentation, WorkflowNodeFieldMap, WorkflowNodeInstructionConfig, WorkflowNodeRenderConfig, WorkflowViewerType } from '@workflow/ui/workflow/types';

export interface WorkflowInspectorVariableSuggestion {
    path: string;
    token: string;
    label: string;
    preview?: string;
}

export interface WorkflowInspectorViewer {
    id: string;
    label: string;
    type: WorkflowViewerType;
    value: unknown;
}

export interface WorkflowInspectorConfig {
    nodeId: string;
    modelId: string;
    nodeTypeLabel: string;
    executorKey?: string;
    useCredentials?: string | null;
    useWorkflows?: Array<'user' | 'organization'> | null;
    render?: WorkflowNodeRenderConfig;
    renderIcon?: (size: number) => string;
    instruction: WorkflowNodeInstructionConfig;
    name: string;
    title: string;
    input: Record<string, unknown>;
    workflow?: Record<string, unknown>;
    workflowVariableContext?: Record<string, unknown>;
    controlNodes?: Record<string, unknown> | null;
    properties: Record<string, unknown>;
    fields: WorkflowNodeFieldMap;
    viewers: WorkflowInspectorViewer[];
    documentation?: WorkflowNodeDocumentation;
    hiddenFieldKeys?: string[];
    instructionOnly?: boolean;
    showGraphqlQuerySection?: boolean;
    inspectorColumns?: number;
    codeAllowVariables?: boolean;
    code?: string;
    markdown?: string;
}

export interface WorkflowExecutionResult {
    output: unknown;
    logs: string[];
    error: string | null;
    renderedMarkdown?: string | null;
}
