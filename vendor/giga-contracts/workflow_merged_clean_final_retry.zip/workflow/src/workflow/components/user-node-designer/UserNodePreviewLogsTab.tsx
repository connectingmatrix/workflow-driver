import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { WorkflowPreviewLogEvent, WorkflowPreviewLogSource } from '@workflow/ui/workflow/types';

interface UserNodePreviewLogsTabProps {
    logs: WorkflowPreviewLogEvent[];
    onClearLogs: () => void;
}

const SOURCE_OPTIONS: Array<{ label: string; value: WorkflowPreviewLogSource | 'all' }> = [
    { label: 'All Sources', value: 'all' },
    { label: 'stdout', value: 'stdout' },
    { label: 'stderr', value: 'stderr' },
    { label: 'worker', value: 'worker' },
    { label: 'browser', value: 'browser' },
    { label: 'runtime', value: 'runtime' }
];

const UserNodePreviewLogsTab: React.FC<UserNodePreviewLogsTabProps> = ({ logs, onClearLogs }) => {
    const [sourceFilter, setSourceFilter] = useState<WorkflowPreviewLogSource | 'all'>('all');
    const [search, setSearch] = useState<string>('');
    const [showTimestamps, setShowTimestamps] = useState<boolean>(false);
    const [autoScroll, setAutoScroll] = useState<boolean>(true);
    const logContainerRef = useRef<HTMLPreElement | null>(null);
    const normalizedSearch = useMemo(() => search.trim().toLowerCase(), [search]);
    const filteredLogs = useMemo(
        () =>
            logs.filter((entry) => {
                if (sourceFilter !== 'all' && entry.source !== sourceFilter) return false;
                if (!normalizedSearch) return true;
                return entry.line.toLowerCase().includes(normalizedSearch);
            }),
        [logs, normalizedSearch, sourceFilter]
    );
    const renderedLogs = useMemo(
        () => filteredLogs.map((entry) => `${showTimestamps ? `${entry.timestamp} ` : ''}[${entry.source}] ${entry.line}`).join('\n'),
        [filteredLogs, showTimestamps]
    );

    const copyLogs = useCallback(() => {
        if (!navigator?.clipboard?.writeText) return;
        void navigator.clipboard.writeText(renderedLogs).catch(() => undefined);
    }, [renderedLogs]);

    useEffect(() => {
        if (!autoScroll || !logContainerRef.current) return;
        logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }, [autoScroll, filteredLogs]);

    return (
        <div className="wf-user-node-preview-logs">
            <div className="wf-user-node-preview-logs__controls">
                <Dropdown value={sourceFilter} options={SOURCE_OPTIONS} onChange={(event) => setSourceFilter(event.value)} className="p-inputtext-sm wf-user-node-preview-logs__source" />
                <InputText value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search logs" className="p-inputtext-sm wf-user-node-preview-logs__search" />
                <div className="wf-user-node-preview-logs__actions">
                    <Button
                        className="p-button-sm wf-user-node-icon-btn"
                        text
                        rounded
                        icon={showTimestamps ? 'pi pi-history' : 'pi pi-clock'}
                        onClick={() => setShowTimestamps((value) => !value)}
                        data-cy="user-node-toggle-log-timestamps"
                        aria-label={showTimestamps ? 'Hide timestamps' : 'Show timestamps'}
                        tooltip={showTimestamps ? 'Hide Time' : 'Show Time'}
                        tooltipOptions={{ position: 'bottom' }}
                    />
                    <Button
                        className="p-button-sm wf-user-node-icon-btn"
                        text
                        rounded
                        icon="pi pi-copy"
                        onClick={copyLogs}
                        data-cy="user-node-copy-logs"
                        aria-label="Copy logs"
                        tooltip="Copy Logs"
                        tooltipOptions={{ position: 'bottom' }}
                    />
                    <Button
                        className="p-button-sm wf-user-node-icon-btn p-button-danger"
                        text
                        rounded
                        icon="pi pi-trash"
                        onClick={onClearLogs}
                        data-cy="user-node-clear-preview-logs"
                        aria-label="Clear logs"
                        tooltip="Clear"
                        tooltipOptions={{ position: 'bottom' }}
                    />
                    {!autoScroll ? (
                        <Button
                            className="p-button-sm wf-user-node-icon-btn"
                            text
                            rounded
                            icon="pi pi-angle-double-down"
                            onClick={() => setAutoScroll(true)}
                            data-cy="user-node-log-resume-scroll"
                            aria-label="Resume auto scroll"
                            tooltip="Resume Scroll"
                            tooltipOptions={{ position: 'bottom' }}
                        />
                    ) : null}
                </div>
            </div>
            <pre
                ref={logContainerRef}
                className="text-xs overflow-auto wf-user-node-preview-scroll wf-user-node-preview-logs__content"
                data-cy="user-node-preview-logs"
                onScroll={(event) => {
                    const target = event.currentTarget;
                    const atBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 8;
                    setAutoScroll((previous) => (previous === atBottom ? previous : atBottom));
                }}
            >
                {renderedLogs}
            </pre>
        </div>
    );
};

export default UserNodePreviewLogsTab;
