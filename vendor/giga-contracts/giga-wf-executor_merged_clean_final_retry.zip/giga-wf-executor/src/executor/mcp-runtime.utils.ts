import type { WorkflowMcpServerRegistration, WorkflowMcpTransport } from './mcp-runtime.types';

export const toRecordValue = (value: unknown): Record<string, unknown> =>
    value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

export const parseStringValue = (value: unknown): string => String(value ?? '').trim();

export const parseTransport = (value: unknown): WorkflowMcpTransport | undefined => {
    const transport = parseStringValue(value).toLowerCase();
    if (transport === 'streamable-http' || transport === 'sse' || transport === 'ws' || transport === 'stdio') {
        return transport;
    }
    return undefined;
};

export const parseHeaders = (value: unknown): Record<string, string> | undefined => {
    const record = toRecordValue(parseJsonValue(value));
    const entries = Object.entries(record)
        .map(([key, entry]) => [parseStringValue(key), parseStringValue(entry)] as const)
        .filter(([key, entry]) => key.length > 0 && entry.length > 0);
    return entries.length > 0 ? Object.fromEntries(entries) : undefined;
};

export const parseArrayValue = (value: unknown): unknown[] => {
    if (Array.isArray(value)) return value;
    if (typeof value !== 'string') return [];
    const parsed = parseJsonValue(value);
    return Array.isArray(parsed) ? parsed : [];
};

export const parseStringArray = (value: unknown): string[] =>
    parseArrayValue(value).map((entry) => parseStringValue(entry)).filter((entry) => entry.length > 0);

export const parseJsonValue = (value: unknown): unknown => {
    if (typeof value !== 'string') return value;
    const normalized = value.trim();
    if (!normalized) return {};
    try {
        return JSON.parse(normalized);
    } catch {
        return {};
    }
};

export const buildEndpointUrl = (server: WorkflowMcpServerRegistration): string => {
    const serverUrl = parseStringValue(server.url);
    if (!serverUrl) {
        throw new Error(`MCP server "${server.key}" is missing a streamable-http URL.`);
    }
    const endpointPath = parseStringValue(toRecordValue(server.metadata).httpEndpointPath) || '/mcp';
    const url = new URL(serverUrl);
    if (url.pathname && url.pathname !== '/') {
        return url.toString();
    }
    url.pathname = endpointPath.startsWith('/') ? endpointPath : `/${endpointPath}`;
    return url.toString();
};

export const resolveRuntimeHeaders = (server: WorkflowMcpServerRegistration): Record<string, string> => {
    const metadata = toRecordValue(server.metadata);
    const headers = {
        ...(server.headers ?? {})
    };
    const headersFromEnv = toRecordValue(metadata.headersFromEnv);
    Object.entries(headersFromEnv).forEach(([headerName, envKey]) => {
        const resolved = typeof process !== 'undefined' && process.env ? parseStringValue(process.env[parseStringValue(envKey)]) : '';
        if (resolved) {
            headers[parseStringValue(headerName)] = resolved;
        }
    });
    const bearerTokenEnvVar = parseStringValue(metadata.bearerTokenEnvVar);
    const bearerToken =
        bearerTokenEnvVar && typeof process !== 'undefined' && process.env ? parseStringValue(process.env[bearerTokenEnvVar]) : '';
    if (bearerToken && !headers.Authorization) {
        headers.Authorization = `Bearer ${bearerToken}`;
    }
    return headers;
};
