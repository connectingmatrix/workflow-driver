export type GigaAgentOutputMarkerKind = 'charts' | 'excel' | 'file';
export type GigaAgentOutputMarker = { kind: GigaAgentOutputMarkerKind; body: string; start: number; end: number };

const markerPatterns: Array<{ kind: GigaAgentOutputMarkerKind; pattern: RegExp }> = [
  { kind: 'charts', pattern: /\[(charts?|chart)\]([\s\S]*?)\[\/\1\]/gi },
  { kind: 'excel', pattern: /\[excel\]([\s\S]*?)\[\/excel\]/gi },
  { kind: 'file', pattern: /\[\[file:([^\]]+)\]\]/gi },
];

export function parseGigaAgentOutputMarkers(markdown: string): GigaAgentOutputMarker[] {
  const markers: GigaAgentOutputMarker[] = [];
  for (const { kind, pattern } of markerPatterns) {
    for (const match of markdown.matchAll(pattern)) {
      markers.push({ kind, body: String(match[2] ?? match[1] ?? ''), start: match.index ?? 0, end: (match.index ?? 0) + match[0].length });
    }
  }
  return markers.sort((a, b) => a.start - b.start);
}
