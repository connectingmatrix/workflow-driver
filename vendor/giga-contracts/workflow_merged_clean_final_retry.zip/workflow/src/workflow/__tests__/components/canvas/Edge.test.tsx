/** @vitest-environment jsdom */
import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import Edge from '@workflow/ui/workflow/components/canvas/Edge';

const { buildWorkflowEdgePath } = vi.hoisted(() => ({
    buildWorkflowEdgePath: vi.fn(() => ({ path: 'M 0 0', labelX: 24, labelY: 32, controlsX: 40, controlsY: 56 }))
}));

vi.mock('@workflow/ui/workflow/components/canvas/workflow-edge-path.utils', () => ({ buildWorkflowEdgePath }));
vi.mock('@xyflow/react', () => ({
    BaseEdge: (props: { path: string }) => <div data-testid="base-edge" data-path={props.path} />,
    EdgeLabelRenderer: (props: { children: React.ReactNode }) => <div>{props.children}</div>,
}));

vi.mock('primereact/button', () => ({
    Button: (props: { onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void; 'aria-label'?: string }) => <button type="button" aria-label={props['aria-label']} onClick={props.onClick} />
}));

describe('Edge', () => {
    it('routes canvas edges with the selected edge style', () => {
        render(<Edge id="edge_1" sourceX={0} sourceY={0} targetX={100} targetY={120} sourcePosition="right" targetPosition="left" markerEnd="" style={{}} selected={false} label="" data={{ edgeStyle: 'step' }} />);
        expect(buildWorkflowEdgePath).toHaveBeenCalledWith('step', expect.any(Object));
    });

    it('passes lane offsets into the custom edge path builder', () => {
        render(
            <Edge
                id="edge_lane"
                sourceX={0}
                sourceY={0}
                targetX={100}
                targetY={120}
                sourcePosition="right"
                targetPosition="left"
                markerEnd=""
                style={{}}
                selected={false}
                label="2"
                data={{ edgeStyle: 'smoothstep', sourceLaneOffset: 18, targetLaneOffset: -18 }}
            />
        );

        expect(buildWorkflowEdgePath).toHaveBeenCalledWith(
            'smoothstep',
            expect.objectContaining({ sourceLaneOffset: 18, targetLaneOffset: -18 })
        );
    });

    it('keeps insert and delete actions available across styles', () => {
        const onInsert = vi.fn();
        const onDelete = vi.fn();

        render(<Edge id="edge_2" sourceX={0} sourceY={0} targetX={100} targetY={120} sourcePosition="right" targetPosition="left" markerEnd="" style={{}} selected label="4" data={{ edgeStyle: 'smoothstep', onInsert, onDelete }} />);

        fireEvent.click(screen.getByLabelText('Insert node'));
        fireEvent.click(screen.getByLabelText('Remove connection'));
        expect(onInsert).toHaveBeenCalledWith(expect.objectContaining({ edgeId: 'edge_2' }));
        expect(onDelete).toHaveBeenCalledWith('edge_2');
    });
});
