import type { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { layoutWorkflowWithLegacy } from '@workflow/ui/workflow/layout/legacy-layout';
import { layoutWorkflowWithElk } from '@workflow/ui/workflow/layout/elk-layout';
import { resolveWorkflowCanvasSettings } from '@workflow/ui/workflow/utils/workflow-canvas-settings.utils';

export const layoutWorkflowGraph = async (workflow: WorkflowDefinition): Promise<WorkflowDefinition> => {
    const canvas = resolveWorkflowCanvasSettings(workflow);
    if (canvas.layoutEngine === 'elk') return layoutWorkflowWithElk(workflow);
    return layoutWorkflowWithLegacy(workflow);
};
