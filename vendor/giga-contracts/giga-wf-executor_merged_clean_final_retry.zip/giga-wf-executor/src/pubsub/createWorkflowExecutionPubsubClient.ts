import { Kafka, logLevel, type KafkaConfig } from "kafkajs";
import { readWorkflowQueueRedpandaConfig } from "../queue";
import type { WorkflowQueueRedpandaConfig } from "../queue/types";

const resolveWorkflowExecutionPubsubConfig = (
  config?: WorkflowQueueRedpandaConfig,
) => config || readWorkflowQueueRedpandaConfig(process.env);

export const createWorkflowExecutionPubsubClient = (
  config?: WorkflowQueueRedpandaConfig,
): Kafka => {
  const resolvedConfig = resolveWorkflowExecutionPubsubConfig(config);
  const clientConfig: KafkaConfig = {
    clientId: resolvedConfig.clientId,
    brokers: resolvedConfig.brokers,
    logLevel: logLevel.NOTHING,
    ...(resolvedConfig.kafka || {}),
  };
  if (resolvedConfig.username && resolvedConfig.password) {
    clientConfig.sasl = {
      mechanism: "scram-sha-256",
      username: resolvedConfig.username,
      password: resolvedConfig.password,
    };
    clientConfig.ssl = resolvedConfig.ssl || false;
  }
  return new Kafka(clientConfig);
};
