import type { WorkflowNodeCatalog } from '@workflow/ui';
import type { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeLibraryItem, WorkflowNodeModel } from '@workflow/ui';

const createNodeFactory = (nodeCatalog: WorkflowNodeCatalog) => {
    const nodeModels = nodeCatalog.getAllNodeSchemas();
    const libraryItemsByModelId = new Map<string, WorkflowNodeLibraryItem>(nodeCatalog.getNodeLibraryItems().map((item) => [item.modelId, item]));

    return (params: { nodeId: string; modelId: string; nodeName: string; x: number; y: number }): WorkflowNodeModel => {
        const nodeModule = nodeCatalog.getNodeModuleById(params.modelId);
        if (!nodeModule) {
            throw new Error(`Unknown node model: ${params.modelId}`);
        }
        const libraryItem = libraryItemsByModelId.get(params.modelId);
        if (!libraryItem) {
            throw new Error(`Missing library item for model: ${params.modelId}`);
        }

        return nodeModule.buildInitialNode({
            nodeId: params.nodeId,
            nodeName: params.nodeName,
            schema: nodeCatalog.resolveNodeSchema(params.modelId, nodeModels),
            libraryItem,
            position: {
                x: params.x,
                y: params.y
            }
        });
    };
};

const buildWorkflow = (nodes: WorkflowNodeModel[], connections: WorkflowConnectionModel[]): WorkflowDefinition => ({
    metadata: {
        id: 'workflow_playground_stub',
        name: 'Workflow Playground Stub',
        description: 'Local workflow playground with stubbed server/realtime driver.'
    },
    nodeModels: [],
    nodes,
    connections
});

const withNodeRuntimeOverrides = (
    node: WorkflowNodeModel,
    overrides: {
        name?: string;
        description?: string;
        runtime?: Record<string, unknown>;
        inspectorCode?: string;
        inspectorMarkdown?: string;
    }
): WorkflowNodeModel => {
    const nextName = overrides.name ?? node.name;
    const nextDescription = overrides.description ?? node.description ?? '';
    const nextRuntime = {
        ...(typeof node.runtime === 'object' && node.runtime && !Array.isArray(node.runtime) ? node.runtime : {}),
        ...(typeof node.properties === 'object' && node.properties && !Array.isArray(node.properties) ? node.properties : {}),
        ...(overrides.runtime ?? {}),
        description: nextDescription
    };

    return {
        ...node,
        name: nextName,
        description: nextDescription,
        runtime: nextRuntime,
        properties: nextRuntime,
        inspector: node.inspector
            ? {
                  ...node.inspector,
                  title: nextName,
                  properties: {
                      ...(typeof node.inspector.properties === 'object' && node.inspector.properties && !Array.isArray(node.inspector.properties) ? node.inspector.properties : {}),
                      ...nextRuntime,
                      name: nextName,
                      description: nextDescription
                  },
                  code: overrides.inspectorCode ?? node.inspector.code,
                  markdown: overrides.inspectorMarkdown ?? node.inspector.markdown
              }
            : node.inspector
    };
};

const createCodeScenario = (buildNode: ReturnType<typeof createNodeFactory>, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    const codeNode = withNodeRuntimeOverrides(buildNode({ nodeId: 'code-1', modelId: 'code', nodeName: 'Code Node 1', x: 620, y: 280 }), {
        name: 'Code Node 1',
        description: 'JavaScript execution node for transforming inputs and returning a structured response.',
        runtime: {
            code: 'return {};',
            payload: {}
        },
        inspectorCode: 'return {};',
        inspectorMarkdown: ''
    });

    const workflow = buildWorkflow([codeNode], []);
    workflow.nodeModels = nodeCatalog.getAllNodeSchemas();
    return workflow;
};

const createOutputFormatScenario = (buildNode: ReturnType<typeof createNodeFactory>, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    const startNode = buildNode({ nodeId: 'start-1', modelId: 'start', nodeName: 'Start 1', x: 120, y: 260 });
    const outputFormatNode = buildNode({ nodeId: 'output-format-1', modelId: 'output-format', nodeName: 'Output Format 1', x: 460, y: 260 });
    const endNode = buildNode({ nodeId: 'respond-end-1', modelId: 'respond-end', nodeName: 'Respond / End 1', x: 810, y: 260 });

    const workflow = buildWorkflow(
        [startNode, outputFormatNode, endNode],
        [
            { id: 'conn-start-output', name: 'Start -> Output Format', from: startNode.id, to: outputFormatNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-output-end', name: 'Output Format -> Respond', from: outputFormatNode.id, to: endNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' }
        ]
    );
    workflow.nodeModels = nodeCatalog.getAllNodeSchemas();
    return workflow;
};

const createAiGovernorScenario = (buildNode: ReturnType<typeof createNodeFactory>, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    const startNode = buildNode({ nodeId: 'start-1', modelId: 'start', nodeName: 'Start 1', x: 120, y: 280 });
    const openAiNode = buildNode({ nodeId: 'openai-1', modelId: 'openai', nodeName: 'OpenAI 1', x: 380, y: 120 });
    const claudeNode = buildNode({ nodeId: 'claude-1', modelId: 'claude', nodeName: 'Claude 1', x: 380, y: 430 });
    const governorNode = buildNode({ nodeId: 'ai-governor-1', modelId: 'ai-governor', nodeName: 'AI Governor 1', x: 720, y: 280 });
    const endNode = buildNode({ nodeId: 'respond-end-1', modelId: 'respond-end', nodeName: 'Respond / End 1', x: 1080, y: 280 });

    const workflow = buildWorkflow(
        [startNode, openAiNode, claudeNode, governorNode, endNode],
        [
            { id: 'conn-start-governor', name: 'Start -> Governor', from: startNode.id, to: governorNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-openai-llm', name: 'OpenAI -> Governor LLM', from: openAiNode.id, to: governorNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
            { id: 'conn-claude-llm', name: 'Claude -> Governor LLM', from: claudeNode.id, to: governorNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
            { id: 'conn-governor-end', name: 'Governor -> Respond', from: governorNode.id, to: endNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' }
        ]
    );
    workflow.nodeModels = nodeCatalog.getAllNodeSchemas();
    return workflow;
};

const createGalleryScenario = (buildNode: ReturnType<typeof createNodeFactory>, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    const startNode = buildNode({ nodeId: 'start-1', modelId: 'start', nodeName: 'Start 1', x: 80, y: 320 });
    const codeNode = buildNode({ nodeId: 'code-1', modelId: 'code', nodeName: 'Code 1', x: 360, y: 130 });
    const outputFormatNode = buildNode({ nodeId: 'output-format-1', modelId: 'output-format', nodeName: 'Output Format 1', x: 360, y: 520 });
    const openAiNode = buildNode({ nodeId: 'openai-1', modelId: 'openai', nodeName: 'OpenAI 1', x: 760, y: 120 });
    const claudeNode = buildNode({ nodeId: 'claude-1', modelId: 'claude', nodeName: 'Claude 1', x: 760, y: 520 });
    const governorNode = buildNode({ nodeId: 'ai-governor-1', modelId: 'ai-governor', nodeName: 'AI Governor 1', x: 1080, y: 320 });
    const endNode = buildNode({ nodeId: 'respond-end-1', modelId: 'respond-end', nodeName: 'Respond / End 1', x: 1420, y: 320 });

    const workflow = buildWorkflow(
        [startNode, codeNode, outputFormatNode, openAiNode, claudeNode, governorNode, endNode],
        [
            { id: 'conn-start-code', name: 'Start -> Code', from: startNode.id, to: codeNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-code-output', name: 'Code -> Output Format', from: codeNode.id, to: outputFormatNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-output-governor', name: 'Output Format -> Governor', from: outputFormatNode.id, to: governorNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-openai-llm', name: 'OpenAI -> Governor LLM', from: openAiNode.id, to: governorNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
            { id: 'conn-claude-llm', name: 'Claude -> Governor LLM', from: claudeNode.id, to: governorNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
            { id: 'conn-governor-end', name: 'Governor -> Respond', from: governorNode.id, to: endNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' }
        ]
    );
    workflow.nodeModels = nodeCatalog.getAllNodeSchemas();
    return workflow;
};

const createAiAgentWorkflowScenario = (buildNode: ReturnType<typeof createNodeFactory>, nodeCatalog: WorkflowNodeCatalog): WorkflowDefinition => {
    const startNode = buildNode({ nodeId: 'start-1', modelId: 'start', nodeName: 'Start 1', x: 80, y: 260 });
    const chatNode = buildNode({ nodeId: 'current-chat-1', modelId: 'current-chat', nodeName: 'Current Chat 1', x: 360, y: 260 });
    const analysisNode = buildNode({ nodeId: 'text-analysis-1', modelId: 'text-analysis', nodeName: 'Text Analysis 1', x: 660, y: 260 });
    const openAiNode = buildNode({ nodeId: 'openai-1', modelId: 'openai', nodeName: 'OpenAI 1', x: 960, y: 40 });
    const subjectActionNode = buildNode({ nodeId: 'run-subject-action-1', modelId: 'run-subject-action', nodeName: 'Subject Action 1', x: 960, y: 500 });
    const actionRouterNode = buildNode({ nodeId: 'action-router-1', modelId: 'action-router', nodeName: 'Action Router 1', x: 1260, y: 500 });
    const agentNode = buildNode({ nodeId: 'ai-agent-1', modelId: 'ai-agent', nodeName: 'AI Agent 1', x: 1260, y: 260 });
    const ifElseNode = buildNode({ nodeId: 'if-else-1', modelId: 'if-else', nodeName: 'If Else 1', x: 1560, y: 260 });
    const endNode = buildNode({ nodeId: 'respond-end-1', modelId: 'respond-end', nodeName: 'Respond / End 1', x: 1860, y: 260 });

    const workflow = buildWorkflow(
        [startNode, chatNode, analysisNode, openAiNode, subjectActionNode, actionRouterNode, agentNode, ifElseNode, endNode],
        [
            { id: 'conn-start-chat', name: 'Start -> Current Chat', from: startNode.id, to: chatNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-chat-analysis', name: 'Current Chat -> Text Analysis', from: chatNode.id, to: analysisNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-analysis-agent', name: 'Text Analysis -> AI Agent', from: analysisNode.id, to: agentNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-openai-agent', name: 'OpenAI -> AI Agent LLM', from: openAiNode.id, to: agentNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:llm' },
            { id: 'conn-subject-router', name: 'Subject Action -> Action Router', from: subjectActionNode.id, to: actionRouterNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:actions' },
            { id: 'conn-router-agent', name: 'Action Router -> AI Agent Tool', from: actionRouterNode.id, to: agentNode.id, sourceHandle: 'cmd:command', targetHandle: 'cmd:tools' },
            { id: 'conn-agent-ifelse', name: 'AI Agent -> If Else', from: agentNode.id, to: ifElseNode.id, sourceHandle: 'out:output', targetHandle: 'in:input' },
            { id: 'conn-ifelse-end', name: 'If Else -> Respond', from: ifElseNode.id, to: endNode.id, sourceHandle: 'out:true', targetHandle: 'in:input' }
        ]
    );
    workflow.nodeModels = nodeCatalog.getAllNodeSchemas();
    return workflow;
};

export const createSampleWorkflow = (nodeCatalog: WorkflowNodeCatalog, scenario: string = 'code'): WorkflowDefinition => {
    const buildNode = createNodeFactory(nodeCatalog);

    switch (scenario) {
        case 'ai-agent-workflow':
            return createAiAgentWorkflowScenario(buildNode, nodeCatalog);
        case 'output-format':
            return createOutputFormatScenario(buildNode, nodeCatalog);
        case 'ai-governor':
            return createAiGovernorScenario(buildNode, nodeCatalog);
        case 'gallery':
            return createGalleryScenario(buildNode, nodeCatalog);
        case 'code':
        default:
            return createCodeScenario(buildNode, nodeCatalog);
    }
};
