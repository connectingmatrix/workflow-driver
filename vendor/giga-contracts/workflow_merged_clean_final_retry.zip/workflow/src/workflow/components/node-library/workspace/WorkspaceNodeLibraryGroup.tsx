import React from 'react';
import { WorkspaceNodeLibraryCard } from '@workflow/ui/workflow/components/node-library/workspace/WorkspaceNodeLibraryCard';
import type { WorkspaceNodeLibraryGroupSection } from '@workflow/ui/workflow/components/node-library/workspace/workspace-node-library.utils';
import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

interface WorkspaceNodeLibraryGroupProps {
    group: WorkspaceNodeLibraryGroupSection;
    collapsed: boolean;
    onToggle: (groupName: string) => void;
    onInsert?: (item: WorkflowNodeLibraryItem) => void;
}

export const WorkspaceNodeLibraryGroup: React.FC<WorkspaceNodeLibraryGroupProps> = ({ group, collapsed, onToggle, onInsert }) => (
    <section className="wf-workspace-node-library__group">
        <button type="button" className="wf-workspace-node-library__group-header" onClick={() => onToggle(group.groupName)} aria-expanded={!collapsed}>
            <span>{group.groupName}</span>
            <div className="wf-workspace-node-library__group-meta">
                <span className="wf-workspace-node-library__group-count">{group.items.length}</span>
                <i className={`pi ${collapsed ? 'pi-chevron-down' : 'pi-chevron-up'}`} aria-hidden />
            </div>
        </button>
        {!collapsed ? (
            <div className="wf-workspace-node-library__group-cards">
                {group.items.map((item) => (
                    <WorkspaceNodeLibraryCard key={item.id} item={item} onInsert={onInsert} />
                ))}
            </div>
        ) : null}
    </section>
);
