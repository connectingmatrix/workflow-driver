// @vitest-environment jsdom
import React, { useState } from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it } from 'vitest';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import { WorkflowVariableSuggestion } from '@workflow/ui/workflow/utils/workflow-variables.utils';

const suggestions: WorkflowVariableSuggestion[] = [
    {
        path: 'node_1.title',
        token: '{{node_1.title}}',
        label: 'node_1.title',
        preview: 'Hello'
    },
    {
        path: 'node_1.summary',
        token: '{{node_1.summary}}',
        label: 'node_1.summary',
        preview: 'World'
    }
];

const StatefulField = ({ initialValue }: { initialValue: string }) => {
    const [value, setValue] = useState(initialValue);
    return (
        <VariableTextField
            id="wf-variable-test"
            value={value}
            onChange={setValue}
            allowVariables
            variableContext={{
                node_1: {
                    title: 'Hello'
                }
            }}
            variableSuggestions={suggestions}
        />
    );
};

afterEach(() => {
    cleanup();
});

describe('VariableTextField', () => {
    it('shows suggestions when typing {{ and inserts selected token', () => {
        render(<StatefulField initialValue="" />);
        const textbox = screen.getByRole('textbox');

        fireEvent.change(textbox, { target: { value: '{{' } });
        fireEvent.keyUp(textbox);

        const suggestion = screen.getByText('node_1.title').closest('button');
        expect(suggestion).toBeTruthy();
        fireEvent.mouseDown(suggestion as HTMLButtonElement);

        expect((textbox as HTMLInputElement).value).toBe('{{node_1.title}}');
    });

    it('renders unresolved token styling in overlay', () => {
        const { container } = render(
            <VariableTextField
                id="wf-variable-test-2"
                value="{{node_1.missing}}"
                onChange={() => undefined}
                allowVariables
                variableContext={{
                    node_1: {
                        title: 'Hello'
                    }
                }}
                variableSuggestions={suggestions}
            />
        );

        expect(container.querySelector('.wf-variable-field__token--unresolved')).toBeTruthy();
    });

    it('supports keyboard suggestion navigation and insertion', () => {
        render(<StatefulField initialValue="" />);
        const textbox = screen.getByRole('textbox');

        fireEvent.change(textbox, { target: { value: '{{' } });
        fireEvent.keyUp(textbox);
        fireEvent.keyDown(textbox, { key: 'ArrowDown' });
        fireEvent.keyDown(textbox, { key: 'Enter' });

        expect((textbox as HTMLInputElement).value).toBe('{{node_1.summary}}');
    });

    it('closes suggestions on escape', () => {
        render(<StatefulField initialValue="" />);
        const textbox = screen.getByRole('textbox');

        fireEvent.change(textbox, { target: { value: '{{' } });
        fireEvent.keyUp(textbox);
        expect(screen.getByRole('listbox')).toBeTruthy();

        fireEvent.keyDown(textbox, { key: 'Escape' });
        expect(screen.queryByRole('listbox')).toBeNull();
    });

    it('renders hover title for resolved token values', () => {
        const { container } = render(
            <VariableTextField
                id="wf-variable-test-3"
                value="{{node_1.title}}"
                onChange={() => undefined}
                allowVariables
                variableContext={{
                    node_1: {
                        title: 'Hello'
                    }
                }}
                variableSuggestions={suggestions}
            />
        );

        const token = container.querySelector('.wf-variable-field__token--resolved');
        expect(token).toBeTruthy();
        expect(token?.getAttribute('title')).toBe('Current value: Hello');
    });

    it('accepts dropped workflow variables through the hover overlay', () => {
        const { container } = render(<StatefulField initialValue="" />);
        const overlay = container.querySelector('.wf-variable-field__overlay--hover');
        const dataTransfer = {
            getData: (type: string) => (type === 'application/x-workflow-variable-path' ? 'node_1.title' : '')
        } as DataTransfer;

        expect(overlay).toBeTruthy();
        fireEvent.dragOver(overlay as HTMLElement, { dataTransfer });
        fireEvent.drop(overlay as HTMLElement, { dataTransfer });

        expect((screen.getByRole('textbox') as HTMLInputElement).value).toBe('{{node_1.title}}');
    });
});
