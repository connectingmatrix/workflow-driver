import type { WorkflowRunLogEvent } from '../../types';

export type AgentLogListener = (event: WorkflowRunLogEvent | Record<string, unknown>) => void | Promise<void>;

export class AgentWorkflowLogTap {
  private readonly listeners = new Set<AgentLogListener>();
  private readonly history: Array<WorkflowRunLogEvent | Record<string, unknown>> = [];

  constructor(private readonly limit = 1000) {}

  emit(event: WorkflowRunLogEvent | Record<string, unknown>) {
    this.history.push(event);
    while (this.history.length > this.limit) this.history.shift();
    for (const listener of this.listeners) void listener(event);
  }

  listen(listener: AgentLogListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  read(filter: { workflowId?: string | null; runId?: string | null; since?: string | null } = {}) {
    const sinceTime = filter.since ? Date.parse(filter.since) : 0;
    return this.history.filter((entry) => {
      const row = entry as Record<string, unknown>;
      if (filter.workflowId && row.workflowId !== filter.workflowId) return false;
      if (filter.runId && row.runId !== filter.runId) return false;
      if (sinceTime && Date.parse(String(row.timestamp || '')) < sinceTime) return false;
      return true;
    });
  }
}

export const globalAgentWorkflowLogTap = new AgentWorkflowLogTap();
