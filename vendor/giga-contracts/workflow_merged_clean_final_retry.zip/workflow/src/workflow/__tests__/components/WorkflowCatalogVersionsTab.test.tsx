import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

type VersionRow = { id: string; label?: string; isCurrent?: boolean; referencedByExecutions?: boolean };

vi.mock('@/common/components/atomic', () => ({
    UiButton: ({ disabled, label, onClick }: { disabled?: boolean; label?: string; onClick?: () => void }) => (
        <button type="button" disabled={disabled} onClick={onClick}>
            {label}
        </button>
    )
}));

vi.mock('@/common/components/table', () => ({
    SakaiFilterTable: ({ value, selection = [], onSelectionChange, isDataSelectable }: { value: VersionRow[]; selection?: VersionRow[]; onSelectionChange?: (event: { value: VersionRow[] }) => void; isDataSelectable?: (event: { data: VersionRow }) => boolean }) => (
        <div>
            {value.map((row) => {
                const checked = selection.some((selected) => selected.id === row.id);
                const disabled = isDataSelectable?.({ data: row }) === false;
                const nextSelection = checked ? selection.filter((selected) => selected.id !== row.id) : [...selection, row];
                return <input key={row.id} type="checkbox" checked={checked} disabled={disabled} aria-label={row.label} onChange={() => onSelectionChange?.({ value: nextSelection })} />;
            })}
        </div>
    )
}));

vi.mock('primereact/tag', () => ({
    Tag: ({ value }: { value: string }) => <span>{value}</span>
}));

import WorkflowCatalogVersionsTab from '@/modules/workflow-catalog/components/catalog/WorkflowCatalogVersionsTab';

describe('WorkflowCatalogVersionsTab', () => {
    it('protects current and referenced versions while allowing historical cleanup', () => {
        const onSelectionChange = vi.fn();

        render(
            <WorkflowCatalogVersionsTab
                historyBusy={false}
                onDeleteSelected={vi.fn()}
                onSelectionChange={onSelectionChange}
                selectedVersionIds={[]}
                versions={[
                    {
                        id: 'version_current',
                        label: 'v2',
                        createdAt: '2026-03-22T00:00:00.000Z',
                        publishedAt: '2026-03-22T00:00:00.000Z',
                        isCurrent: true,
                        referencedByExecutions: false,
                        executionCount: 0,
                        versionNumber: 2
                    },
                    {
                        id: 'version_referenced',
                        label: 'v1',
                        createdAt: '2026-03-21T00:00:00.000Z',
                        publishedAt: '2026-03-21T00:00:00.000Z',
                        isCurrent: false,
                        referencedByExecutions: true,
                        executionCount: 3,
                        versionNumber: 1
                    },
                    {
                        id: 'version_cleanup',
                        label: 'v0',
                        createdAt: '2026-03-20T00:00:00.000Z',
                        publishedAt: '2026-03-20T00:00:00.000Z',
                        isCurrent: false,
                        referencedByExecutions: false,
                        executionCount: 0,
                        versionNumber: 0
                    }
                ]}
            />
        );

        const checkboxes = screen.getAllByRole('checkbox');
        expect(checkboxes[0]).toBeDisabled();
        expect(checkboxes[1]).toBeDisabled();
        expect(checkboxes[2]).not.toBeDisabled();

        fireEvent.click(checkboxes[2]);
        expect(onSelectionChange).toHaveBeenCalledWith(['version_cleanup']);
    });
});
