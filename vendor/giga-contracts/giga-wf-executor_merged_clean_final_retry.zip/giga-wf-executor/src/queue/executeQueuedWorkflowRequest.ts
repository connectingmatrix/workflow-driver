import util from "node:util";
import { createWorkflowExecutionTimeoutController } from "../execution-timeout";
import {
  WorkflowLogLevelEnum,
  type WorkflowDefinition,
  type WorkflowNodeModel,
  type WorkflowRunLogEvent,
  type WorkflowRuntimeSettings,
} from "../types";
import {
  normalizeWorkflowQueueDefinition,
  normalizeWorkflowQueueLogEvent,
  normalizeWorkflowQueueLogs,
  normalizeWorkflowQueueResponsePayload,
} from "./normalizeWorkflowQueuePayload";
import type {
  WorkflowQueueEvent,
  WorkflowQueueRequest,
  WorkflowQueueRequestContextSnapshot,
} from "./types";

const normalizeLogEvent = (
  request: WorkflowQueueRequest,
  event: WorkflowRunLogEvent,
): WorkflowRunLogEvent => ({
  timestamp: event.timestamp || new Date().toISOString(),
  level: event.level || WorkflowLogLevelEnum.Info,
  workflowId: request.workflowReference.workflowId,
  runId: request.runId,
  nodeId: event.nodeId,
  message: event.message,
  event: event.event,
  data: event.data,
});
const nodeDeltaLevel = (status: unknown): WorkflowLogLevelEnum =>
  status === "failed"
    ? WorkflowLogLevelEnum.Error
    : status === "warning" || status === "stopped"
      ? WorkflowLogLevelEnum.Warn
      : WorkflowLogLevelEnum.Info;
const recordValue = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
const textValue = (value: unknown): string => String(value || "").trim();
type WorkflowQueueList = Array<object | string | number | boolean | null>;
type WorkflowQueueTextPayload =
  | string
  | {
      markdown?: string | null;
      output?: string | null;
      retrievedChunks?: WorkflowQueueList;
      retrieved_chunks?: WorkflowQueueList;
      source_refs?: WorkflowQueueList;
      sources?: WorkflowQueueList;
      text?: string | null;
      value?: string | null;
    };
const workflowResponseText = (payload: WorkflowQueueTextPayload): string => {
  if (typeof payload === "string") return payload.trim();
  return textValue(payload.markdown || payload.text || payload.output || payload.value);
};
const errorMessage = (error: unknown): string =>
  error instanceof Error
    ? error.message || error.name
    : util.inspect(error, { depth: 10, breakLength: 120 }) ||
      "Workflow queue event publish failed.";
const listValue = (
  value: WorkflowQueueTextPayload,
  primary: "retrievedChunks" | "sources",
  secondary: "retrieved_chunks" | "source_refs",
): WorkflowQueueList =>
  typeof value === "object" && Array.isArray(value[primary] || value[secondary])
    ? (value[primary] || value[secondary] || [])
    : [];
const buildNodeDelta = (node: WorkflowNodeModel) =>
  normalizeWorkflowQueueDefinition({
    metadata: {
      id: "workflow_queue_node_delta",
      name: "Workflow Queue Node Delta",
    },
    nodes: [node],
    connections: [],
  }).nodes[0] as WorkflowNodeModel;
const failedRunMessage = (
  logs: WorkflowRunLogEvent[],
  workflow: WorkflowDefinition,
) =>
  textValue(
    (
      logs.find(
        (entry) =>
          entry.event === "node.failed" ||
          (entry.level === WorkflowLogLevelEnum.Error &&
            textValue(entry.message)),
      ) || {}
    ).message,
  ) ||
  (logs.some((entry) => entry.event === "workflow.completed")
    ? ""
    : Array.isArray(workflow?.nodes)
      ? (() => {
          const failedNode = workflow.nodes.find(
            (node) => node?.status === "failed",
          );
          return textValue(failedNode?.name || failedNode?.id)
            ? `${textValue(failedNode?.name || failedNode?.id)} failed.`
            : "";
        })()
      : "");

export const createQueuedWorkflowRequestExecutor =
  <RequestContext = unknown>(dependencies: {
    createHostContext: (requestContext: RequestContext) => unknown;
    executeWorkflowImpl: (
      workflow: WorkflowDefinition,
      params: {
        hostContext: unknown;
        logger: {
          entries: WorkflowRunLogEvent[];
          push: (
            event: Omit<WorkflowRunLogEvent, "timestamp"> | WorkflowRunLogEvent,
          ) => void;
        };
        onNodeFinish: (node: WorkflowNodeModel) => void;
        requestContext: RequestContext;
        runId: string;
        settings: WorkflowRuntimeSettings;
        signal: AbortSignal;
      },
    ) => Promise<{
      workflow: WorkflowDefinition;
      stopped: boolean;
      runId: string;
    }>;
    extractTerminalPayload: (workflow: WorkflowDefinition) => unknown;
    restoreRequestContext: (
      snapshot: WorkflowQueueRequestContextSnapshot,
    ) => RequestContext;
  }) =>
  async (
    request: WorkflowQueueRequest,
    helpers: {
      publishEvent: (event: WorkflowQueueEvent) => Promise<void>;
      signal: AbortSignal;
    },
  ): Promise<void> => {
    const requestContext = dependencies.restoreRequestContext(
      request.requestContext,
    );
    const logEntries: WorkflowRunLogEvent[] = [];
    const pending = new Set<Promise<void>>();
    const timeoutController = createWorkflowExecutionTimeoutController({
      settings: request.settings,
      label: "Queued workflow execution",
    });
    const executionController = new AbortController();
    const publishErrors: string[] = [];
    const safePublishEvent = async (event: WorkflowQueueEvent) => {
      try {
        await helpers.publishEvent(event);
      } catch (error) {
        publishErrors.push(errorMessage(error));
      }
    };
    const abortExecution = () => executionController.abort();
    helpers.signal.addEventListener("abort", abortExecution, { once: true });
    timeoutController.signal.addEventListener("abort", abortExecution, {
      once: true,
    });
    const publishLog = (event: WorkflowRunLogEvent) => {
      const publishPromise = helpers
        .publishEvent({
          type: "log",
          timestamp: event.timestamp,
          executionId: request.executionId,
          runId: request.runId,
          workflowId: request.workflowReference.workflowId,
          userId: request.userId,
          broadcastId: request.broadcastId,
          broadcastChannelName: request.broadcastChannelName,
          triggerType: request.triggerType,
          workflowReference: request.workflowReference,
          log: normalizeWorkflowQueueLogEvent(event),
        })
        .catch((error) => {
          publishErrors.push(errorMessage(error));
        })
        .finally(() => pending.delete(publishPromise));
      pending.add(publishPromise);
    };
    const logger = {
      entries: logEntries,
      push: (
        event: Omit<WorkflowRunLogEvent, "timestamp"> | WorkflowRunLogEvent,
      ) => {
        const normalized = normalizeLogEvent(
          request,
          Object.prototype.hasOwnProperty.call(event, "timestamp")
            ? (event as WorkflowRunLogEvent)
            : ({
                timestamp: new Date().toISOString(),
                ...event,
              } as WorkflowRunLogEvent),
        );
        logEntries.push(normalized);
        publishLog(normalized);
      },
    };
    const buildEventWorkflow = (workflow: WorkflowDefinition) =>
      ({
        ...normalizeWorkflowQueueDefinition(workflow || request.workflow),
        metadata: {
          ...recordValue(
            normalizeWorkflowQueueDefinition(workflow || request.workflow)
              .metadata,
          ),
          id: request.workflowReference.workflowId,
          name: textValue(
            recordValue(
              normalizeWorkflowQueueDefinition(workflow || request.workflow)
                .metadata,
            ).name ||
              request.workflow.metadata?.name ||
              "Workflow",
          ),
        },
      }) as WorkflowDefinition;
    const buildResponsePayload = (workflow: WorkflowDefinition) => {
      const terminalPayload = normalizeWorkflowQueueResponsePayload(
        dependencies.extractTerminalPayload(workflow),
      );
      const chatPayload =
        typeof terminalPayload === "string" ||
        (terminalPayload &&
          typeof terminalPayload === "object" &&
          !Array.isArray(terminalPayload))
          ? (terminalPayload as WorkflowQueueTextPayload)
          : "";
      return request.triggerType === "webhook"
        ? {
            route_type:
              textValue(recordValue(request.metadata).routeType) || "published",
            output: terminalPayload,
          }
        : {
            text: workflowResponseText(chatPayload),
            terminal_payload: terminalPayload,
            source_refs: listValue(chatPayload, "sources", "source_refs"),
            retrieved_chunks: listValue(
              chatPayload,
              "retrievedChunks",
              "retrieved_chunks",
            ),
          };
    };
    await safePublishEvent({
      type: "started",
      timestamp: new Date().toISOString(),
      executionId: request.executionId,
      runId: request.runId,
      workflowId: request.workflowReference.workflowId,
      userId: request.userId,
      broadcastId: request.broadcastId,
      broadcastChannelName: request.broadcastChannelName,
      triggerType: request.triggerType,
      workflowReference: request.workflowReference,
    });
    try {
      const result = await dependencies.executeWorkflowImpl(request.workflow, {
        signal: executionController.signal,
        settings: request.settings,
        hostContext: dependencies.createHostContext(requestContext),
        logger,
        onNodeFinish: (node) =>
          logger.push({
            level: nodeDeltaLevel(node.status),
            event: "node.delta",
            workflowId: request.workflowReference.workflowId,
            runId: request.runId,
            nodeId: node.id,
            data: { node: buildNodeDelta(node) },
          }),
        requestContext,
        runId: request.runId,
      });
      const logs = normalizeWorkflowQueueLogs(logEntries);
      const workflow = buildEventWorkflow(result.workflow);
      const responsePayload = buildResponsePayload(result.workflow);
      const runErrorMessage = failedRunMessage(logEntries, workflow);
      const queueErrorMessage = publishErrors[0] || "";
      await safePublishEvent(
        runErrorMessage
          ? {
              type: "failed",
              timestamp: new Date().toISOString(),
              executionId: request.executionId,
              runId: request.runId,
              workflowId: request.workflowReference.workflowId,
              userId: request.userId,
              broadcastId: request.broadcastId,
              broadcastChannelName: request.broadcastChannelName,
              triggerType: request.triggerType,
              workflowReference: request.workflowReference,
              errorMessage: runErrorMessage,
              logs,
              workflow,
              responsePayload,
            }
          : {
              type: "completed",
              timestamp: new Date().toISOString(),
              executionId: request.executionId,
              runId: request.runId,
              workflowId: request.workflowReference.workflowId,
              userId: request.userId,
              broadcastId: request.broadcastId,
              broadcastChannelName: request.broadcastChannelName,
              triggerType: request.triggerType,
              workflowReference: request.workflowReference,
              result: {
                workflow,
                stopped: result.stopped,
                runId: result.runId,
                logs,
                responsePayload,
              },
            },
      );
      void Promise.allSettled(Array.from(pending));
    } catch (error) {
      const logs = normalizeWorkflowQueueLogs(logEntries);
      await safePublishEvent({
        type: "failed",
        timestamp: new Date().toISOString(),
        executionId: request.executionId,
        runId: request.runId,
        workflowId: request.workflowReference.workflowId,
        userId: request.userId,
        broadcastId: request.broadcastId,
        broadcastChannelName: request.broadcastChannelName,
        triggerType: request.triggerType,
        workflowReference: request.workflowReference,
        errorMessage: errorMessage(error) || "Queued workflow execution failed.",
        logs,
        workflow: buildEventWorkflow(request.workflow),
      });
      void Promise.allSettled(Array.from(pending));
    } finally {
      helpers.signal.removeEventListener("abort", abortExecution);
      timeoutController.cleanup();
    }
  };
