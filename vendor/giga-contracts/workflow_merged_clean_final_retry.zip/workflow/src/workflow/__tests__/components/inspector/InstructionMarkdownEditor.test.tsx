// @vitest-environment jsdom
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import InstructionMarkdownEditor from '@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor';

const quillState: { current: any } = {
    current: null
};

vi.mock('@workflow/ui/workflow/components/form/index', async () => {
    const ReactModule = await vi.importActual<typeof import('react')>('react');

    const createMockQuill = () => {
        let text = '';
        let selection = { index: 0, length: 0 };
        const root = document.createElement('div');

        return {
            root,
            __setText: (nextText: string) => {
                text = nextText;
            },
            __getText: () => text,
            getText: (start = 0, length?: number) => {
                if (typeof length !== 'number') return text.slice(start);
                return text.slice(start, start + length);
            },
            getSelection: () => selection,
            setSelection: (index: number, length = 0) => {
                selection = { index, length };
            },
            getLength: () => text.length + 1,
            insertText: (index: number, insertText: string) => {
                text = `${text.slice(0, index)}${insertText}${text.slice(index)}`;
                selection = { index: index + insertText.length, length: 0 };
            },
            deleteText: (index: number, deleteLength: number) => {
                text = `${text.slice(0, index)}${text.slice(index + deleteLength)}`;
                selection = { index, length: 0 };
            }
        };
    };

    return {
        FloatingFieldShell: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
        RichEditorField: ({
            value,
            onChange,
            onSelectionChange,
            onEditorLoad
        }: {
            value: string;
            onChange?: (value: string) => void;
            onSelectionChange?: (selection: { index: number; length: number } | null) => void;
            onEditorLoad?: (quill: unknown) => void;
        }) => {
            ReactModule.useEffect(() => {
                const quill = createMockQuill();
                quillState.current = quill;
                onEditorLoad?.(quill);
                return () => {
                    quillState.current = null;
                };
            }, []);

            return (
                <div>
                    <textarea
                        data-testid="mock-rich-editor"
                        value={value}
                        onChange={(event) => {
                            onChange?.(event.target.value);
                        }}
                    />
                    <button
                        type="button"
                        onClick={() => {
                            if (!quillState.current) return;
                            quillState.current.__setText('{{');
                            quillState.current.setSelection(2, 0);
                            onSelectionChange?.({ index: 2, length: 0 });
                        }}
                    >
                        Open Suggestions
                    </button>
                </div>
            );
        }
    };
});

const suggestions = [
    {
        path: 'node_1.title',
        token: '{{node_1.title}}',
        label: 'node_1.title',
        preview: 'Hello'
    },
    {
        path: 'node_1.summary',
        token: '{{node_1.summary}}',
        label: 'node_1.summary',
        preview: 'World'
    }
];

afterEach(() => {
    cleanup();
});

describe('InstructionMarkdownEditor', () => {
    it('inserts variable token when suggestion is clicked', () => {
        render(<InstructionMarkdownEditor value="" onChange={() => undefined} allowVariables variableSuggestions={suggestions} />);

        fireEvent.click(screen.getByRole('button', { name: 'Open Suggestions' }));
        const suggestion = screen.getByText('node_1.title').closest('button');
        expect(suggestion).toBeTruthy();
        fireEvent.mouseDown(suggestion as HTMLButtonElement);

        expect(quillState.current.__getText()).toBe('{{node_1.title}}');
    });

    it('supports keyboard selection in markdown suggestion list', () => {
        render(<InstructionMarkdownEditor value="" onChange={() => undefined} allowVariables variableSuggestions={suggestions} />);

        fireEvent.click(screen.getByRole('button', { name: 'Open Suggestions' }));
        fireEvent.keyDown(quillState.current.root, { key: 'ArrowDown' });
        fireEvent.keyDown(quillState.current.root, { key: 'Enter' });

        expect(quillState.current.__getText()).toBe('{{node_1.summary}}');
    });
});
