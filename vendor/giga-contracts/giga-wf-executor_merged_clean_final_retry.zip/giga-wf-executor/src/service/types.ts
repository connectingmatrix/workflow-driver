import type { WorkflowActionCatalogEntry } from '../api/readWorkflowActionCatalog';
import type { WorkflowShapeSummary } from '../api/readWorkflowSummary';
import type { WorkflowPubsubEventName, WorkflowPubsubHandler } from '../pubsub';
import type { WorkflowQueueEvent, WorkflowQueueRedpandaConfig, WorkflowQueueRequest, WorkflowQueueRunState } from '../queue/types';
import type {
  ExecuteNodeStepOptions,
  WorkflowDefinition,
  WorkflowExecutorResult,
  WorkflowNodeModel,
  WorkflowNodeSchema,
  WorkflowStepExecutorResult,
} from '../types';
import type { CompiledWorkflowDraft } from '../workflow-ai-creation/agent-workflow';
import type { WorkflowCypherCompileResult } from '../workflow-ai-creation/types';

export type ExecuteNodeStepWithWorkflowOptions = ExecuteNodeStepOptions & Record<string, unknown>;

export interface ExecuteNodeStepWithNodeOptions {
  node: WorkflowNodeModel;
  nodeModels: Record<string, WorkflowNodeSchema>;
  settings: ExecuteNodeStepOptions['settings'];
  workflowInput?: Record<string, unknown>;
  runtimeInput?: Record<string, unknown>;
  metadata?: { id?: string; name?: string };
  hostContext?: unknown;
  overrides?: ExecuteNodeStepOptions['overrides'];
  signal?: AbortSignal;
  isNodeLocalCapable?: ExecuteNodeStepOptions['isNodeLocalCapable'];
  executeNodeRemotely?: ExecuteNodeStepOptions['executeNodeRemotely'];
  onEvent?: ExecuteNodeStepOptions['onEvent'];
  onPreviewLogLine?: ExecuteNodeStepOptions['onPreviewLogLine'];
  onPreviewState?: ExecuteNodeStepOptions['onPreviewState'];
  requestContext?: unknown;
  [key: string]: unknown;
}

export type ExecutorStepOptions = ExecuteNodeStepWithWorkflowOptions | ExecuteNodeStepWithNodeOptions;
export type ExecutorEventEnvelope = { eventName: ExecutorPublishEventName; payload: unknown; roomName: string };
export type ExecutorEventHandler = (event: ExecutorEventEnvelope) => void;

export interface ExecutorTransportSession {
  userId: string;
  [key: string]: unknown;
}

export interface ExecutorTransportBindings {
  authorize: (request: unknown, token: string) => Promise<ExecutorTransportSession>;
  closeEditorSession?: (params: { connectionId: string; workflowId: string }) => void;
  closeEditorSessionByConnection?: (connectionId: string) => void;
  createPendingWebhookTestRequest?: (params: { requestId: string; workflowId: string; timeoutMs?: number }) => Promise<unknown>;
  getWorkflowEditorSession?: (workflowId: string) => { connectionId: string } | null;
  heartbeatEditorSession?: (params: { connectionId: string; editable?: boolean; workflowId: string }) => { connectionId: string } | null;
  readRequestContext: (params: { request: unknown; session: ExecutorTransportSession }) => Promise<unknown> | unknown;
  registerEditorSession?: (params: { connectionId: string; editable?: boolean; userId: string; workflowId: string }) => { accepted: boolean; session?: { editable: boolean } };
  rejectPendingWebhookTestRequest?: (requestId: string, error: Error) => void;
  resolvePendingWebhookTestRequest?: (requestId: string, payload: unknown) => void;
}

export interface ExecutorChatAdapterBindings {
  execute: (name: string, runtime: unknown, input?: Record<string, unknown>) => Promise<Record<string, unknown>>;
}

export interface ExecutorBackendBindings {
  execute: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition, signal: AbortSignal) => Promise<WorkflowExecutorResult>;
  executeBrowser?: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition, signal: AbortSignal) => Promise<WorkflowExecutorResult>;
  executeStep?: (id: string, options: ExecutorStepOptions, signal: AbortSignal) => Promise<WorkflowStepExecutorResult>;
  workflowExecutionQueue?: {
    applyExecutionEvent: (event: WorkflowQueueEvent) => Promise<void>;
    config?: WorkflowQueueRedpandaConfig;
    createExecutionRequest: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition) => WorkflowQueueRequest;
    handleExecutionEventError?: (params: { error: unknown; event: WorkflowQueueEvent }) => Promise<void> | void;
    runExecutionRequest: (request: WorkflowQueueRequest, helpers: { publishEvent: (event: WorkflowQueueEvent) => Promise<void>; signal: AbortSignal }) => Promise<void>;
  };
}

export interface ExecutorSetup {
  callbacks?: {
    chatAdapter?: ExecutorChatAdapterBindings;
    transport?: ExecutorTransportBindings;
  };
  executeBackend: ExecutorBackendBindings;
}

export interface ExecutorRunState {
  id: string;
  runId: string;
  status: 'running';
  workflowId: string;
}

export type ExecutorRunningState = ExecutorRunState | WorkflowQueueRunState;

export type ExecutorListenHandler = WorkflowPubsubHandler;
export type ExecutorPublishEventName = WorkflowPubsubEventName;

export interface ExecutorChatAdapter {
  catalog: () => WorkflowActionCatalogEntry[];
  execute: (name: string, runtime: unknown, input?: Record<string, unknown>) => Promise<Record<string, unknown>>;
}

export interface ExecutorService {
  catalogRoom: (broadcastId: string, channelName: string) => string;
  compileNode: (input: Record<string, unknown>) => ReturnType<typeof import('../workflow-ai-creation/dynamic-node-operation').createDynamicNodeOperation>;
  compileWorkflow: (input: Record<string, unknown>) => CompiledWorkflowDraft;
  compileWorkflowCypher: (input: Record<string, unknown>) => WorkflowCypherCompileResult;
  createQueuedWorkflowRequestExecutor: typeof import('../queue').createQueuedWorkflowRequestExecutor;
  createWorkflowQueueEventApplier: typeof import('../queue').createWorkflowQueueEventApplier;
  createWorkflowQueueRequestContextSnapshot: typeof import('../queue').createWorkflowQueueRequestContextSnapshot;
  createWorkflowQueueTimingPayload: typeof import('../queue').createWorkflowQueueTimingPayload;
  consumeWorkflowExecutionEvents: typeof import('../pubsub').consumeWorkflowExecutionEvents;
  enqueue: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition) => Promise<{ executionId: string; runId: string; status: 'queued'; workflowId: string }>;
  errorMessage: (error: unknown) => string;
  execute: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition) => Promise<WorkflowExecutorResult>;
  executeBrowser: (id: string, options: Record<string, unknown>, workflow: WorkflowDefinition) => Promise<WorkflowExecutorResult>;
  executeStep: (id: string, options: ExecutorStepOptions) => Promise<WorkflowStepExecutorResult>;
  getRunning: (workflowId?: string) => ExecutorRunningState[];
  isWorkflowQueueExecutionStalled: typeof import('../queue').isWorkflowQueueExecutionStalled;
  listen: (roomName: string, handler: ExecutorListenHandler) => (() => void) | Promise<() => void>;
  logsRoom: (userId: string, runId: string) => string;
  mergeWorkflowQueueTimingPayload: typeof import('../queue').mergeWorkflowQueueTimingPayload;
  normalizeWorkflowQueueDefinition: typeof import('../queue').normalizeWorkflowQueueDefinition;
  normalizeWorkflowQueueLogEvent: typeof import('../queue').normalizeWorkflowQueueLogEvent;
  normalizeWorkflowQueueLogs: typeof import('../queue').normalizeWorkflowQueueLogs;
  publish: (roomName: string, eventName: ExecutorPublishEventName, payload: unknown) => undefined;
  readWorkflowActionCatalog: () => WorkflowActionCatalogEntry[];
  readWorkflowEditorUrl: (workflowId?: string | null) => string | null;
  readWorkflowExcerpt: (value: unknown, limit?: number) => string;
  readWorkflowNodeCatalog: () => unknown[];
  readWorkflowNodeDetails: (modelIds: string[]) => unknown[];
  readWorkflowPlannerContext: (message: string) => string;
  readWorkflowShape: (workflow: any) => WorkflowShapeSummary;
  resolveWorkflowQueueCompletion: typeof import('../queue').resolveWorkflowQueueCompletion;
  resolveWorkflowQueueTiming: typeof import('../queue').resolveWorkflowQueueTiming;
  restart: () => Promise<void>;
  runWorkflowExecutionQueue: typeof import('../pubsub').runWorkflowExecutionQueue;
  setup: (next: ExecutorSetup) => undefined;
  startWorkflowExecutionPubsub: typeof import('../pubsub').startWorkflowExecutionPubsub;
  start: () => Promise<void>;
  stop: (targetRunId?: string) => Promise<number | void>;
  stopRun: (runId: string) => Promise<number>;
  stopWorkflow: (workflowId: string) => Promise<number>;
  userRoom: (userId: string) => string;
  validateCypher: (input: Record<string, unknown>) => WorkflowCypherCompileResult;
  validateJSON: (input: string) => unknown;
  waitForWorkflowQueueCompletion: typeof import('../queue').waitForWorkflowQueueCompletion;
  workflowRoom: (broadcastId: string, workflowId: string) => string;
  withWorkflowQueueExecutionStarted: typeof import('../queue').withWorkflowQueueExecutionStarted;
  withWorkflowQueueTimingPayload: typeof import('../queue').withWorkflowQueueTimingPayload;
  on: (eventName: ExecutorPublishEventName, handler: ExecutorEventHandler) => () => void;
  readChatAdapter: () => ExecutorChatAdapter;
}
