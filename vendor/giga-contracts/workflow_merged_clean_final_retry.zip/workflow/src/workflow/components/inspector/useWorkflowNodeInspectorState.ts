import { useEffect, useMemo, useRef, useState } from 'react';
import { executeNodeCode, parsePropertiesInput, renderInstructionMarkdown } from '@workflow/ui/workflow/components/inspector/executor';
import { buildInstructionCodeFromMarkdown, extractInstructionMarkdownFromCode } from '@workflow/ui/workflow/components/inspector/instruction-code.utils';
import { WorkflowExecutionResult, WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import { stripHiddenUnknownInspectorValues } from '@workflow/ui/workflow/components/inspector/inspector-properties-pane.utils';
import { buildEditorPropertiesState } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';

interface UseWorkflowNodeInspectorStateArgs {
    config: WorkflowInspectorConfig | null;
    readOnly?: boolean;
    onExecuteStep?: (payload: { nodeId: string; properties: Record<string, unknown>; code: string; markdown: string }) => Promise<{ output: unknown; logs: string[]; error: string | null }>;
    onDraftChange?: (payload: { nodeId: string; propertiesEditorState: Record<string, unknown>; code: string; markdown: string }) => void;
    onSave?: (nextConfig: WorkflowInspectorConfig) => void;
}

interface UseWorkflowNodeInspectorStateResult {
    propertiesEditorState: Record<string, unknown>;
    code: string;
    markdown: string;
    executionResult: WorkflowExecutionResult | null;
    isExecuting: boolean;
    hasUnsavedChanges: boolean;
    setProperty: (key: string, value: unknown) => void;
    setProperties: (values: Record<string, unknown>) => void;
    onCodeChange: (nextCode: string) => void;
    onMarkdownChange: (nextMarkdown: string) => void;
    runCurrentCode: () => Promise<void>;
    saveChanges: () => void;
    canClose: () => boolean;
}

const queryTextFromRuntimeCatalog = (properties: Record<string, unknown>, queryKey: string): string => {
    const catalog = properties.queryCatalog as Record<string, string> | undefined;
    return String(catalog?.[queryKey] ?? '').trim();
};

export const useWorkflowNodeInspectorState = ({ config, readOnly = false, onExecuteStep, onDraftChange, onSave }: UseWorkflowNodeInspectorStateArgs): UseWorkflowNodeInspectorStateResult => {
    const [propertiesEditorState, setPropertiesEditorState] = useState<Record<string, unknown>>({});
    const [code, setCode] = useState<string>('');
    const [markdown, setMarkdown] = useState<string>('');
    const [executionResult, setExecutionResult] = useState<WorkflowExecutionResult | null>(null);
    const [isExecuting, setIsExecuting] = useState<boolean>(false);
    const [savedSnapshot, setSavedSnapshot] = useState<{ properties: string; code: string; markdown: string }>({
        properties: '{}',
        code: '',
        markdown: ''
    });
    const savedSnapshotRef = useRef<{ properties: string; code: string; markdown: string }>({
        properties: '{}',
        code: '',
        markdown: ''
    });
    const currentNodeIdRef = useRef<string | null>(null);
    const propertiesEditorStateRef = useRef<Record<string, unknown>>({});
    const codeRef = useRef<string>('');
    const markdownRef = useRef<string>('');
    const editorSnapshotRef = useRef<{ properties: string; code: string; markdown: string }>({
        properties: '{}',
        code: '',
        markdown: ''
    });

    const publishDraft = (): void => {
        if (!currentNodeIdRef.current) return;
        onDraftChange?.({
            nodeId: currentNodeIdRef.current,
            propertiesEditorState: propertiesEditorStateRef.current,
            code: codeRef.current,
            markdown: markdownRef.current
        });
    };

    useEffect(() => {
        propertiesEditorStateRef.current = propertiesEditorState;
        codeRef.current = code;
        markdownRef.current = markdown;
        editorSnapshotRef.current = {
            properties: JSON.stringify(propertiesEditorState),
            code,
            markdown
        };
    }, [code, markdown, propertiesEditorState]);

    useEffect(() => {
        savedSnapshotRef.current = savedSnapshot;
    }, [savedSnapshot]);

    useEffect(() => {
        publishDraft();
    }, [code, markdown, onDraftChange, propertiesEditorState]);

    useEffect(() => {
        if (!config) {
            setPropertiesEditorState({});
            setCode('');
            setMarkdown('');
            propertiesEditorStateRef.current = {};
            codeRef.current = '';
            markdownRef.current = '';
            setExecutionResult(null);
            setIsExecuting(false);
            setSavedSnapshot({ properties: '{}', code: '', markdown: '' });
            currentNodeIdRef.current = null;
            return;
        }

        const nextProperties = buildEditorPropertiesState(config.fields ?? {}, {
            ...stripHiddenUnknownInspectorValues(config.fields ?? {}, config.properties ?? {}, config.hiddenFieldKeys ?? []),
            name: config.name,
            description: config.properties?.description ?? ''
        });
        const canUseCode = config.instruction.code;
        const canUseMarkdown = config.instruction.markdown;
        const nextMarkdown = canUseMarkdown ? config.markdown ?? extractInstructionMarkdownFromCode(config.code ?? '') ?? '' : '';
        const nextCode = canUseCode ? config.code ?? buildInstructionCodeFromMarkdown(nextMarkdown) : '';
        const nextSavedSnapshot = {
            properties: JSON.stringify(nextProperties),
            code: nextCode,
            markdown: nextMarkdown
        };
        const isSameNode = currentNodeIdRef.current === config.nodeId;
        const hasPendingEdits =
            editorSnapshotRef.current.properties !== savedSnapshotRef.current.properties ||
            editorSnapshotRef.current.code !== savedSnapshotRef.current.code ||
            editorSnapshotRef.current.markdown !== savedSnapshotRef.current.markdown;

        if (isSameNode) {
            setSavedSnapshot(nextSavedSnapshot);
            currentNodeIdRef.current = config.nodeId;
            if (hasPendingEdits) {
                return;
            }

            setPropertiesEditorState(nextProperties);
            setCode(nextCode);
            setMarkdown(nextMarkdown);
            propertiesEditorStateRef.current = nextProperties;
            codeRef.current = nextCode;
            markdownRef.current = nextMarkdown;
            return;
        }

        setPropertiesEditorState(nextProperties);
        setCode(nextCode);
        setMarkdown(nextMarkdown);
        propertiesEditorStateRef.current = nextProperties;
        codeRef.current = nextCode;
        markdownRef.current = nextMarkdown;
        setExecutionResult(null);
        setIsExecuting(false);
        setSavedSnapshot(nextSavedSnapshot);
        currentNodeIdRef.current = config.nodeId;
    }, [config]);

    useEffect(() => {
        if (!config || config.modelId !== 'output-format') return;
        const modelField = config.fields?.modelId;
        const options = Array.isArray(modelField?.options) ? modelField.options : [];
        const availableValues = options.map((option) => String(option?.value ?? '').trim()).filter((value) => value.length > 0);
        const currentValue = String(propertiesEditorStateRef.current.modelId ?? '').trim();

        if (availableValues.length === 0) {
            if (currentValue) {
                setPropertiesEditorState((prev) => ({ ...prev, modelId: '' }));
                propertiesEditorStateRef.current = { ...propertiesEditorStateRef.current, modelId: '' };
            }
            return;
        }

        if (availableValues.includes(currentValue)) {
            return;
        }

        const nextValue = availableValues.length === 1 ? availableValues[0] : '';
        if (currentValue === nextValue) return;

        setPropertiesEditorState((prev) => ({ ...prev, modelId: nextValue }));
        propertiesEditorStateRef.current = { ...propertiesEditorStateRef.current, modelId: nextValue };
    }, [config, propertiesEditorState]);

    const hasUnsavedChanges = useMemo(() => {
        if (readOnly) {
            return false;
        }
        return JSON.stringify(propertiesEditorState) !== savedSnapshot.properties || code !== savedSnapshot.code || markdown !== savedSnapshot.markdown;
    }, [code, markdown, propertiesEditorState, readOnly, savedSnapshot]);

    const runCurrentCode = async (): Promise<void> => {
        if (readOnly || isExecuting || !config) return;
        setIsExecuting(true);
        setExecutionResult({ output: null, logs: [], error: null, renderedMarkdown: null });
        try {
            const liveProperties = parsePropertiesInput(propertiesEditorStateRef.current, config.fields ?? {});
            const liveCode = codeRef.current;
            const liveMarkdown = markdownRef.current;
            const executionContext = { input: config.input ?? {}, properties: liveProperties, workflow: config.workflowVariableContext ?? {} };
            if (onExecuteStep) {
                const stepResult = await onExecuteStep({
                    nodeId: config.nodeId,
                    properties: liveProperties,
                    code: liveCode,
                    markdown: liveMarkdown
                });
                setExecutionResult({
                    output: stepResult.output,
                    logs: stepResult.logs ?? [],
                    error: stepResult.error,
                    renderedMarkdown: renderInstructionMarkdown(liveMarkdown, executionContext)
                });
            } else {
                const result = await executeNodeCode(liveCode, config.input ?? {}, liveProperties, config.workflowVariableContext ?? {}, (line) => {
                    setExecutionResult((prev) => ({ output: prev?.output ?? null, logs: [...(prev?.logs ?? []), line], error: prev?.error ?? null, renderedMarkdown: prev?.renderedMarkdown ?? null }));
                });
                setExecutionResult({ ...result, renderedMarkdown: renderInstructionMarkdown(liveMarkdown, executionContext) });
            }
        } finally {
            setIsExecuting(false);
        }
    };

    return {
        propertiesEditorState,
        code,
        markdown,
        executionResult,
        isExecuting,
        hasUnsavedChanges,
        setProperty: (key, value) =>
            setPropertiesEditorState((prev) => {
                const next = { ...prev, [key]: value };
                if (key === 'queryKey' && typeof value === 'string' && 'queryText' in next) {
                    next.queryText = queryTextFromRuntimeCatalog(next, value);
                }
                propertiesEditorStateRef.current = next;
                return next;
            }),
        setProperties: (values) =>
            setPropertiesEditorState((prev) => {
                const next = { ...prev, ...values };
                if (typeof values.queryKey === 'string' && 'queryText' in next) {
                    next.queryText = queryTextFromRuntimeCatalog(next, values.queryKey);
                }
                propertiesEditorStateRef.current = next;
                return next;
            }),
        onCodeChange: (nextCode) => {
            codeRef.current = nextCode;
            setCode(nextCode);
            if (config?.instruction.markdown) {
                const nextMarkdownFromCode = extractInstructionMarkdownFromCode(nextCode);
                if (nextMarkdownFromCode !== null) {
                    markdownRef.current = nextMarkdownFromCode;
                    setMarkdown(nextMarkdownFromCode);
                }
            }
        },
        onMarkdownChange: (nextMarkdown) => {
            markdownRef.current = nextMarkdown;
            setMarkdown(nextMarkdown);
            if (config?.instruction.code) {
                const nextCode = buildInstructionCodeFromMarkdown(nextMarkdown);
                codeRef.current = nextCode;
                setCode(nextCode);
            }
        },
        runCurrentCode,
        saveChanges: () => {
            if (readOnly || !config) return;
            onSave?.({
                ...config,
                properties: parsePropertiesInput(propertiesEditorStateRef.current, config.fields ?? {}),
                code: config.instruction.code ? codeRef.current : '',
                markdown: config.instruction.markdown ? markdownRef.current : ''
            });
            setSavedSnapshot({
                properties: JSON.stringify(propertiesEditorStateRef.current),
                code: codeRef.current,
                markdown: markdownRef.current
            });
        },
        canClose: () => !hasUnsavedChanges || window.confirm('You have unsaved inspector changes. Discard them and close?')
    };
};
