import { describe, expect, it } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const TEST_DIR = path.dirname(fileURLToPath(import.meta.url));
const WORKER_ROOT = path.resolve(TEST_DIR, '../../nodes');

const listWorkerFiles = (dir: string): string[] => {
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) return listWorkerFiles(fullPath);
        return entry.name === 'worker.ts' ? [fullPath] : [];
    });
};

const readSchema = (workerFile: string): Record<string, any> => {
    const nodeDir = path.dirname(workerFile);
    const schemaFile = fs.readdirSync(nodeDir).find((entry) => entry.endsWith('-schema.json'));
    if (!schemaFile) return {};
    return JSON.parse(fs.readFileSync(path.join(nodeDir, schemaFile), 'utf8'));
};

describe('worker contract', () => {
    it('does not use legacy executeBackend({ modelId }) calls in first-party workers', () => {
        const offenders = listWorkerFiles(WORKER_ROOT).filter((file) => {
            const source = fs.readFileSync(file, 'utf8');
            return /executeBackend\(\s*\{\s*modelId\s*:/.test(source);
        });

        expect(offenders).toEqual([]);
    });

    it('only exposes executeBackend in workers that declare backend metadata', () => {
        const offenders = listWorkerFiles(WORKER_ROOT).filter((file) => {
            const source = fs.readFileSync(file, 'utf8');
            if (!/executeBackend\(/.test(source)) return false;
            const schema = readSchema(file);
            return !schema.documentation?.backend?.service || !schema.documentation?.backend?.handler;
        });

        expect(offenders).toEqual([]);
    });
});
