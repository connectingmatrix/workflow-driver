/// <reference types="cypress" />
import { assertWorkspaceInspectorShell, closeNodeInspector, openNodeInspector } from '../../support/inspector';

const assertTreeMultiSelect = (fieldId: string, placeholder: string, optionText: string): void => {
    cy.get(`[data-field-id="${fieldId}"]`).scrollIntoView().should('contain.text', placeholder);
    cy.get(`[data-field-id="${fieldId}"]`).within(() => {
        cy.get('.p-multiselect').first().scrollIntoView().click({ force: true });
    });
    cy.contains('.p-multiselect-item', optionText).first().should('be.visible');
    cy.contains('.p-multiselect-item', optionText).first().click({ force: true });
    cy.get(`[data-field-id="${fieldId}"]`).within(() => {
        cy.get('.p-multiselect').first().click({ force: true });
        cy.get('.p-multiselect-token-label').should('contain.text', optionText);
    });
};

const ensureDesignerOpen = (): void => {
    cy.get('body').then(($body) => {
        if ($body.text().includes('Open Designer')) {
            cy.contains('button', 'Open Designer').click({ force: true });
        }
    });
};

describe('ai agent workflow protocol', () => {
    it('uses multi-select scope pickers and a single explicit message contract', () => {
        cy.visit('/?scenario=ai-agent-workflow&preview=designer');
        ensureDesignerOpen();
        cy.contains('.base-node__name', 'Subject Action 1', { timeout: 10000 }).should('be.visible');

        openNodeInspector('Subject Action 1');
        assertWorkspaceInspectorShell('Subject Action 1');
        cy.get('body').should('not.contain.text', 'Subject IDs');
        cy.get('[data-field-id="subjectIds"]').should('contain.text', 'Subjects');
        cy.get('[data-field-id="postIds"]').should('contain.text', 'Posts');
        cy.get('[data-field-id="tagSlugs"]').should('contain.text', 'Tags');
        assertTreeMultiSelect('subjectIds', 'All subjects in the current tree path', 'Retention');
        assertTreeMultiSelect('postIds', 'All posts in the current tree path', 'Q1 Notes');
        assertTreeMultiSelect('tagSlugs', 'All tags in the current tree path', 'research');
        closeNodeInspector();

        openNodeInspector('Action Router 1');
        assertWorkspaceInspectorShell('Action Router 1');
        assertTreeMultiSelect('subjectIds', 'All subjects in the current tree path', 'Retention');
        closeNodeInspector();

        openNodeInspector('Current Chat 1');
        assertWorkspaceInspectorShell('Current Chat 1');
        assertTreeMultiSelect('subjectIds', 'All subjects in the current tree path', 'Retention');
        closeNodeInspector();

        openNodeInspector('AI Agent 1');
        assertWorkspaceInspectorShell('AI Agent 1');
        cy.get('[data-field-id="message"]').should('contain.text', 'Message');
        cy.get('body').find('[data-field-id="normalizedMessage"]').should('not.exist');
        cy.get('body').find('[data-field-id="originalMessage"]').should('not.exist');
        cy.get('[data-field-id="context"]').find('.monaco-editor').should('not.exist');
        cy.get('[data-field-id="pendingPlan"]').find('.monaco-editor').should('not.exist');
        closeNodeInspector();

        openNodeInspector('Text Analysis 1');
        assertWorkspaceInspectorShell('Text Analysis 1');
        cy.get('[data-field-id="message"]').should('contain.text', 'Message');
        cy.get('body').find('[data-field-id="normalizedMessage"]').should('not.exist');
        cy.get('body').find('[data-field-id="originalMessage"]').should('not.exist');
        cy.get('[data-field-id="context"]').find('.monaco-editor').should('not.exist');
        cy.get('[data-field-id="pendingPlan"]').find('.monaco-editor').should('not.exist');
        closeNodeInspector();

        openNodeInspector('If Else 1');
        assertWorkspaceInspectorShell('If Else 1');
        cy.get('[data-field-id="value"]').should('contain.text', 'Value');
        cy.get('[data-field-id="leftPath"]').should('contain.text', 'Left Path');
        cy.get('[data-field-id="operator"]').should('contain.text', 'Operator');
        cy.get('body').find('.monaco-editor').should('not.exist');
        closeNodeInspector();

        openNodeInspector('Respond / End 1');
        assertWorkspaceInspectorShell('Respond / End 1');
        cy.get('[data-field-id="response"]').should('contain.text', 'Response');
        cy.get('[data-field-id="response"]').find('.monaco-editor').should('not.exist');
    });
});
