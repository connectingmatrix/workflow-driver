import { createBrowserWorkerNodeHandler, createWorkflowExecutor, WorkflowExecutorModeEnum } from '@workflow/executor/browser';
import { WorkflowNodeStatusEnum } from '@workflow/executor/types';
import { loadTypeScriptModule } from '@workflow/ui/workflow/executor/typescript-loader';
import type { ExecuteWorkflowPreviewParams } from '../shared/preview-runtime.types';

const browserExecutor = createWorkflowExecutor({
    mode: WorkflowExecutorModeEnum.Local,
    adapters: {
        getNodeHandler: (modelId) =>
            createBrowserWorkerNodeHandler({
                modelId: modelId ?? 'unknown-node',
                typescriptModuleLoader: loadTypeScriptModule,
                executeHelpers: {
                    executeBackend: async () => ({
                        output: { stub: true },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: ['playground executeBackend is stubbed']
                    }),
                    resolveNodeSourceFiles: async ({ context }) => {
                        const preview = (context.hostContext ?? {}) as { __workflowPreview?: { sourceFiles?: Record<string, string> } };
                        return preview.__workflowPreview?.sourceFiles ?? null;
                    },
                    updateNode: () => undefined
                }
            })
    }
});

export const executeBrowserWorkflowPreview = async (params: ExecuteWorkflowPreviewParams) =>
    browserExecutor.executeNodeStep({
        workflow: params.workflow,
        nodeId: params.nodeId,
        settings: params.settings,
        signal: params.signal,
        hostContext: {
            __workflowPreview: {
                sourceFiles: params.overrides?.sourceFiles ?? {}
            }
        },
        overrides: params.overrides,
        onPreviewLogLine: (event) => params.emitLog({ ...event, runId: params.runId }),
        onPreviewState: (event) => params.emitState({ ...event, runId: params.runId })
    });
