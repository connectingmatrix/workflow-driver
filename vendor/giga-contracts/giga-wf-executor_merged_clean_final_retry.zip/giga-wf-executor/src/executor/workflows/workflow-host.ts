import type { WorkflowExecutionHostContext, WorkflowManagementHostContext } from '../../types';

const toRecord = (value: unknown): Record<string, unknown> =>
    value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

const isWorkflowExecutionHostContext = (value: unknown): value is WorkflowExecutionHostContext => {
    const record = toRecord(value);
    return typeof record.executeWorkflowReference === 'function';
};

const isWorkflowManagementHostContext = (value: unknown): value is WorkflowManagementHostContext => {
    const record = toRecord(value);
    return (
        typeof record.listWorkflowDefinitions === 'function' ||
        typeof record.getWorkflowDefinition === 'function' ||
        typeof record.saveWorkflowDefinition === 'function' ||
        typeof record.deleteWorkflowDefinition === 'function' ||
        typeof record.publishWorkflowDefinition === 'function'
    );
};

export const getWorkflowExecutionHostContext = (hostContext: unknown): WorkflowExecutionHostContext | null => {
    if (isWorkflowExecutionHostContext(hostContext)) {
        return hostContext;
    }

    const nested = toRecord(hostContext).workflows;
    if (isWorkflowExecutionHostContext(nested)) {
        return nested;
    }

    return null;
};

export const getWorkflowManagementHostContext = (hostContext: unknown): WorkflowManagementHostContext | null => {
    if (isWorkflowManagementHostContext(hostContext)) {
        return hostContext;
    }

    const nested = toRecord(hostContext).workflows;
    if (isWorkflowManagementHostContext(nested)) {
        return nested;
    }

    return null;
};
