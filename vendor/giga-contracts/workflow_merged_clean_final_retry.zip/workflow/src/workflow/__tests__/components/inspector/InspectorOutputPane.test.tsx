import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import InspectorOutputPane from '@workflow/ui/workflow/components/inspector/InspectorOutputPane';
import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';

describe('InspectorOutputPane', () => {
    it('renders output viewer tabs with no terminal console controls', () => {
        render(<InspectorOutputPane viewers={[{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: { ok: true } }]} renderedMarkdown="" />);

        expect(screen.getByText('JSON')).toBeInTheDocument();
        expect(screen.queryByRole('button', { name: /console/i })).not.toBeInTheDocument();
    });

    it('adds rendered markdown tab when markdown output exists', () => {
        render(<InspectorOutputPane viewers={[{ id: 'json', label: 'JSON', type: WorkflowViewerTypeEnum.Json, value: { ok: true } }]} renderedMarkdown="# Result" />);

        expect(screen.getByText('Rendered Markdown')).toBeInTheDocument();
    });
});
