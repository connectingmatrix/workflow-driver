import type { ReactNode } from 'react';
import { WorkflowNodeRenderConfig } from '@workflow/ui/workflow/types';

const isNonEmptyString = (value: unknown): value is string => typeof value === 'string' && value.trim().length > 0;

const resizeSvgMarkup = (svg: string, size: number): string => {
    const trimmed = svg.trim();
    if (!trimmed.startsWith('<svg')) {
        return trimmed;
    }

    return trimmed.replace(/<svg\b([^>]*)>/i, (_match, attributes: string) => {
        let nextAttributes = attributes;
        if (/\bwidth\s*=/.test(nextAttributes)) {
            nextAttributes = nextAttributes.replace(/\bwidth\s*=\s*(['"]).*?\1/i, ` width="${size}"`);
        } else {
            nextAttributes += ` width="${size}"`;
        }
        if (/\bheight\s*=/.test(nextAttributes)) {
            nextAttributes = nextAttributes.replace(/\bheight\s*=\s*(['"]).*?\1/i, ` height="${size}"`);
        } else {
            nextAttributes += ` height="${size}"`;
        }
        if (!/\baria-hidden\s*=/.test(nextAttributes)) {
            nextAttributes += ' aria-hidden="true"';
        }
        return `<svg${nextAttributes}>`;
    });
};

export const resolveIconRenderMode = (render: WorkflowNodeRenderConfig | null | undefined, fallbackClass = 'pi pi-code'): WorkflowNodeRenderConfig['iconMode'] => {
    if (render?.iconMode === 'svg' && isNonEmptyString(render.iconSvg)) {
        return 'svg';
    }
    if (isNonEmptyString(render?.iconClass ?? fallbackClass)) {
        return 'prime';
    }
    return 'prime';
};

export const createSvgIconRenderer = (iconSvg: string | null | undefined): ((size: number) => string) | undefined => {
    if (!isNonEmptyString(iconSvg)) {
        return undefined;
    }

    const source = iconSvg.trim();
    return (size: number) => resizeSvgMarkup(source, size);
};

export const resolveIconRenderer = (
    render: WorkflowNodeRenderConfig | null | undefined,
    fallbackRenderer?: ((size: number) => string | ReactNode) | null
): ((size: number) => string | ReactNode) | undefined => {
    const svgRenderer = createSvgIconRenderer(render?.iconSvg);
    if (resolveIconRenderMode(render) === 'svg' && svgRenderer) {
        return svgRenderer;
    }
    return fallbackRenderer ?? undefined;
};
