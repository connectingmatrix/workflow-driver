import React from 'react';
import { Skeleton } from 'primereact/skeleton';

const WorkflowDesignerFullscreenSkeleton: React.FC = () => (
    <div className="flex flex-column h-screen surface-ground">
        <div className="p-3 border-bottom-1 surface-border flex justify-content-between align-items-center">
            <div className="flex gap-2">
                {Array.from({ length: 6 }).map((_, index) => (
                    <Skeleton key={`wf-designer-toolbar-${index}`} width="2.5rem" height="2.5rem" borderRadius="12px" />
                ))}
            </div>
            <div className="flex gap-2">
                <Skeleton width="7rem" height="2.5rem" borderRadius="999px" />
                <Skeleton width="7rem" height="2.5rem" borderRadius="999px" />
            </div>
        </div>
        <div className="flex-1 p-4">
            <Skeleton width="100%" height="100%" borderRadius="24px" />
        </div>
    </div>
);

export default WorkflowDesignerFullscreenSkeleton;
