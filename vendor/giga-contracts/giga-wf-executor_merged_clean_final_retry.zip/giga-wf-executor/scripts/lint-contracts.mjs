import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const walk = (dir) =>
  readdirSync(dir).flatMap((entry) => {
    const path = join(dir, entry);
    if (path.includes(`${root}/node_modules`) || path.includes(`${root}/dist`)) return [];
    return statSync(path).isDirectory() ? walk(path) : [path];
  });
const relativePath = (path) => path.slice(root.length + 1);
const sourceFiles = walk(root).filter((path) => /\.(ts|mts|cts|mjs|cjs|js)$/.test(path));
const fallbackTextName = ["workflow", "Text", "Value"].join("");
const globalPatterns = [
  { pattern: new RegExp(`\\b${fallbackTextName}\\b`), message: "Do not add recursive workflow text fallbacks." },
  { pattern: /\[object Object\]/, message: "Do not add object-string placeholder handling." },
];
const baselinePatterns = [
  { key: "any", pattern: /\bany\b/g, message: "Do not add new any usage." },
  { key: "unknown", pattern: /\bunknown\b/g, message: "Do not add new unknown usage." },
  { key: "recordAny", pattern: /Record<string,\s*any>/g, message: "Do not add Record<string, any>." },
];
const baseline = JSON.parse(readFileSync(join(root, "scripts", "lint-contracts-baseline.json"), "utf8"));
const failures = [];
const observed = {};
for (const file of sourceFiles) {
  const source = readFileSync(file, "utf8");
  const rel = relativePath(file);
  for (const { pattern, message } of globalPatterns) if (pattern.test(source)) failures.push(`${rel}: ${message}`);
  const lines = source.split(/\r?\n/);
  for (const rule of baselinePatterns) {
    for (const [index, line] of lines.entries()) {
      rule.pattern.lastIndex = 0;
      if (!rule.pattern.test(line)) continue;
      const id = `${rel}:${index + 1}:${line.trim()}`;
      observed[rule.key] = [...(observed[rule.key] || []), id];
      if (!(baseline[rule.key] || []).includes(id)) failures.push(`${id}: ${rule.message}`);
    }
  }
}
for (const key of Object.keys(baseline)) {
  const missing = baseline[key].filter((id) => !(observed[key] || []).includes(id));
  if (missing.length) failures.push(`scripts/lint-contracts-baseline.json: stale ${key} baseline entries. Regenerate after removing legacy debt.`);
}
if (failures.length) {
  console.error([...new Set(failures)].join("\n"));
  process.exit(1);
}
