import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowCredentialOption, WorkflowExecutableOption, WorkflowNodeFieldOption, WorkflowNodeFieldOptionsRequest } from '@workflow/ui/workflow/types';

export interface NodeInspectorProps {
    visible: boolean;
    readOnly?: boolean;
    config: WorkflowInspectorConfig | null;
    onHide: () => void;
    fetchCredentials?: (serviceId: string) => Promise<WorkflowCredentialOption[]>;
    openCredentialManager?: () => void;
    fetchExecutableWorkflows?: () => Promise<WorkflowExecutableOption[]>;
    fetchNodeFieldOptions?: (request: WorkflowNodeFieldOptionsRequest) => Promise<WorkflowNodeFieldOption[]>;
    onExecuteStep?: (payload: { nodeId: string; properties: Record<string, unknown>; code: string; markdown: string }) => Promise<{ output: unknown; logs: string[]; error: string | null }>;
    onDraftChange?: (payload: { nodeId: string; propertiesEditorState: Record<string, unknown>; code: string; markdown: string }) => void;
    onSave?: (nextConfig: WorkflowInspectorConfig) => void;
}
