import { describe, expect, it } from 'vitest';
import { buildWorkspaceHeaderModel } from '@workflow/ui/workflow/components/inspector/workspace/builders/build-workspace-header-model';
import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';

const config: WorkflowInspectorConfig = {
    nodeId: 'node_1',
    modelId: 'mcp-capabilities',
    executorKey: 'mcp-capabilities',
    nodeTypeLabel: 'MCP Capabilities',
    name: 'MCP Capabilities',
    title: 'MCP Capabilities',
    instruction: { code: false, markdown: false },
    input: {},
    properties: {},
    fields: {},
    viewers: []
};

describe('buildWorkspaceHeaderModel', () => {
    it('keeps the idle run action enabled', () => {
        expect(buildWorkspaceHeaderModel(config, false).primaryAction).toMatchObject({ label: 'Run Node', disabled: false, busy: false });
    });

    it('shows a disabled busy action while execution is active', () => {
        expect(buildWorkspaceHeaderModel(config, true).primaryAction).toMatchObject({ label: 'Running...', disabled: true, busy: true });
    });

    it('removes run and preview actions in read-only mode', () => {
        const model = buildWorkspaceHeaderModel(config, false, true);
        expect(model.previewAction).toBeUndefined();
        expect(model.primaryAction).toBeUndefined();
        expect(model.utilityActions?.map((action) => action.id)).toEqual(['close-node']);
    });
});
