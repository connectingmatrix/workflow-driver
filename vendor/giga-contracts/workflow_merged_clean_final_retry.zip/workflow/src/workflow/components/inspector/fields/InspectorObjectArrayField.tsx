import React from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputSwitch } from 'primereact/inputswitch';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import { WorkflowNodeFieldDefinition, WorkflowNodeFieldTypeEnum, WorkflowNodeObjectArraySubFieldDefinition } from '@workflow/ui/workflow/types';
import { WorkflowVariableSuggestion } from '@workflow/ui/workflow/utils/workflow-variables.utils';
import { buildObjectArrayEditorRows, createObjectArrayEditorRow, WorkflowObjectArrayEditorRow } from '@workflow/ui/workflow/utils/workflow-object-array.utils';

interface InspectorObjectArrayFieldProps {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    onChange: (key: string, value: unknown) => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowVariableSuggestion[];
}

const GRID_MAX_COLUMNS = 12;

const clampColumns = (value: number | undefined, fallback: number): number => {
    if (!Number.isFinite(value)) return fallback;
    const rounded = Math.trunc(Number(value));
    if (rounded < 1) return 1;
    if (rounded > GRID_MAX_COLUMNS) return GRID_MAX_COLUMNS;
    return rounded;
};

const toColClass = (columns: number): string => `col-12 md:col-${clampColumns(columns, GRID_MAX_COLUMNS)}`;

const parseStringValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null || value === undefined) return '';
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const parseNumberValue = (value: unknown): number | null => {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    const parsed = Number(String(value ?? '').trim());
    return Number.isFinite(parsed) ? parsed : null;
};

const resolveSubFieldColumns = (definition: WorkflowNodeObjectArraySubFieldDefinition, totalFieldCount: number): number => {
    if (typeof definition.styleCol === 'number' && Number.isFinite(definition.styleCol)) {
        return clampColumns(definition.styleCol, 12);
    }
    if (totalFieldCount <= 1) return 11;
    return Math.max(3, Math.floor(11 / totalFieldCount));
};

const InspectorObjectArrayField: React.FC<InspectorObjectArrayFieldProps> = ({ fieldKey, definition, value, onChange, variableContext = {}, variableSuggestions = [] }) => {
    const rows = React.useMemo(() => buildObjectArrayEditorRows(definition, value), [definition, value]);
    const subFields = React.useMemo(() => Object.entries(definition.subFields ?? {}), [definition.subFields]);
    const minimum = Math.max(0, Number(definition.minimum ?? 0) || 0);

    const commitRows = React.useCallback(
        (nextRows: WorkflowObjectArrayEditorRow[]): void => {
            onChange(fieldKey, nextRows);
        },
        [fieldKey, onChange]
    );

    const onUpdateCell = React.useCallback(
        (rowIndex: number, subFieldKey: string, nextValue: unknown): void => {
            commitRows(rows.map((row, index) => (index === rowIndex ? { ...row, [subFieldKey]: nextValue } : row)));
        },
        [commitRows, rows]
    );

    if (subFields.length === 0) {
        return <div className="wf-inspector__hint">No object-array fields configured.</div>;
    }

    return (
        <div className="wf-inspector__object-array">
            <div className="wf-inspector__object-array-rows">
                {rows.length === 0 ? <div className="wf-inspector__hint">No entries configured.</div> : null}
                {rows.map((row, rowIndex) => (
                    <div key={`${fieldKey}-${rowIndex}`} className="wf-inspector__object-array-row grid formgrid">
                        {subFields.map(([subFieldKey, subFieldDefinition]) => {
                            const columns = resolveSubFieldColumns(subFieldDefinition, subFields.length);
                            const editable = definition.editable !== false && !definition.auto;
                            const allowVariables = subFieldDefinition.allowVariables ?? definition.allowVariables ?? false;
                            const label = subFieldDefinition.label ?? subFieldKey;
                            const inputId = `wf-object-array-${fieldKey}-${rowIndex}-${subFieldKey}`;
                            return (
                                <div key={subFieldKey} className={toColClass(columns)}>
                                    <label htmlFor={inputId} className="wf-inspector__object-array-label">
                                        {label}
                                    </label>
                                    {subFieldDefinition.type === WorkflowNodeFieldTypeEnum.Boolean ? (
                                        <div className="wf-inspector__object-array-switch">
                                            <InputSwitch inputId={inputId} checked={row[subFieldKey] === true} disabled={!editable} onChange={(event) => onUpdateCell(rowIndex, subFieldKey, event.value === true)} />
                                        </div>
                                    ) : subFieldDefinition.type === WorkflowNodeFieldTypeEnum.Number ? (
                                        <InputNumber
                                            inputId={inputId}
                                            className="w-full"
                                            inputClassName="w-full"
                                            value={parseNumberValue(row[subFieldKey])}
                                            min={subFieldDefinition.min}
                                            max={subFieldDefinition.max}
                                            step={subFieldDefinition.step}
                                            onValueChange={(event) => onUpdateCell(rowIndex, subFieldKey, event.value)}
                                            disabled={!editable}
                                        />
                                    ) : Array.isArray(subFieldDefinition.options) && subFieldDefinition.options.length > 0 ? (
                                        <Dropdown
                                            inputId={inputId}
                                            className="w-full"
                                            value={parseStringValue(row[subFieldKey])}
                                            options={subFieldDefinition.options.map((item) => ({ label: item.label, value: item.value }))}
                                            onChange={(event) => onUpdateCell(rowIndex, subFieldKey, event.value)}
                                            disabled={!editable}
                                        />
                                    ) : (
                                        <VariableTextField
                                            id={inputId}
                                            value={parseStringValue(row[subFieldKey])}
                                            onChange={(nextValue) => onUpdateCell(rowIndex, subFieldKey, nextValue)}
                                            className="w-full"
                                            disabled={!editable}
                                            allowVariables={allowVariables}
                                            variableContext={variableContext}
                                            variableSuggestions={variableSuggestions}
                                            placeholder={subFieldDefinition.placeholder}
                                        />
                                    )}
                                </div>
                            );
                        })}
                        <div className="col-12 md:col-1 wf-inspector__object-array-actions">
                            <Button
                                type="button"
                                icon="pi pi-trash"
                                text
                                rounded
                                className="wf-inspector__object-array-remove"
                                onClick={() => commitRows(rows.filter((_, index) => index !== rowIndex))}
                                disabled={rows.length <= minimum}
                                aria-label={`Remove ${definition.label ?? fieldKey} row ${rowIndex + 1}`}
                            />
                        </div>
                    </div>
                ))}
            </div>
            <Button
                type="button"
                text
                icon="pi pi-plus"
                className="wf-inspector__object-array-add"
                label={definition.addButtonLabel ?? 'Add Row'}
                onClick={() => commitRows([...rows, createObjectArrayEditorRow(definition)])}
            />
        </div>
    );
};

export default InspectorObjectArrayField;
