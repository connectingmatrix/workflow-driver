import { WorkflowCypherEdgeSpec, WorkflowCypherNodeSpec } from './cypher-types';

const isCommandEdge = (edge: WorkflowCypherEdgeSpec): boolean => edge.source.startsWith('cmd:') && edge.target.startsWith('cmd:');
const incomingDataEdges = (alias: string, edges: WorkflowCypherEdgeSpec[]): WorkflowCypherEdgeSpec[] => edges.filter((edge) => edge.to === alias && !isCommandEdge(edge));
const outgoingDataEdges = (alias: string, edges: WorkflowCypherEdgeSpec[]): WorkflowCypherEdgeSpec[] => edges.filter((edge) => edge.from === alias && !isCommandEdge(edge));

const dataDepth = (alias: string, edges: WorkflowCypherEdgeSpec[], seen = new Set<string>()): number => {
    if (seen.has(alias)) return 0;
    seen.add(alias);
    const incoming = incomingDataEdges(alias, edges);
    if (!incoming.length) return 0;
    return Math.max(...incoming.map((edge) => dataDepth(edge.from, edges, seen))) + 1;
};

const nearestOpenRow = (usedRows: Set<number>, preferredRow: number): number => {
    const rounded = Math.max(0, Math.round(preferredRow));
    if (!usedRows.has(rounded)) return rounded;
    for (let offset = 1; offset < 24; offset += 1) {
        const above = rounded - offset;
        if (above >= 0 && !usedRows.has(above)) return above;
        const below = rounded + offset;
        if (!usedRows.has(below)) return below;
    }
    return rounded + usedRows.size + 1;
};

const preferredRow = (node: WorkflowCypherNodeSpec, edges: WorkflowCypherEdgeSpec[], rowsByAlias: Record<string, number>): number => {
    const parents = incomingDataEdges(node.alias, edges).map((edge) => rowsByAlias[edge.from]).filter(Number.isFinite);
    if (!parents.length) return 0;
    const average = parents.reduce((sum, value) => sum + value, 0) / parents.length;
    if (node.modelId === 'merge') return average;
    if (outgoingDataEdges(node.alias, edges).length > 1) return average;
    return average;
};

export const buildCypherPositions = (nodes: WorkflowCypherNodeSpec[], edges: WorkflowCypherEdgeSpec[]): Record<string, { x: number; y: number }> => {
    const positions: Record<string, { x: number; y: number }> = {};
    const rowsByDepth: Record<number, Set<number>> = {};
    const rowsByAlias: Record<string, number> = {};
    const placed = nodes
        .filter((node) => !edges.some((edge) => edge.from === node.alias && isCommandEdge(edge)))
        .sort((left, right) => dataDepth(left.alias, edges) - dataDepth(right.alias, edges));

    placed.forEach((node) => {
        const depth = dataDepth(node.alias, edges);
        const usedRows = rowsByDepth[depth] || new Set<number>();
        const row = nearestOpenRow(usedRows, preferredRow(node, edges, rowsByAlias));
        usedRows.add(row);
        rowsByDepth[depth] = usedRows;
        rowsByAlias[node.alias] = row;
        positions[node.alias] = { x: 140 + depth * 340, y: 140 + row * 220 };
    });

    const commandBuckets: Record<string, WorkflowCypherNodeSpec[]> = {};
    nodes.forEach((node) => {
        if (positions[node.alias]) return;
        const commandLinks = edges.filter((edge) => edge.from === node.alias && isCommandEdge(edge));
        const bucketKey = commandLinks.map((edge) => edge.to).sort().join('|') || node.alias;
        commandBuckets[bucketKey] = [...(commandBuckets[bucketKey] || []), node];
    });

    Object.entries(commandBuckets).forEach(([bucketKey, bucketNodes]) => {
        const anchorPositions = bucketKey.split('|').map((alias) => positions[alias]).filter(Boolean);
        const anchorX = anchorPositions.length ? anchorPositions.reduce((sum, point) => sum + point.x, 0) / anchorPositions.length : 500;
        const anchorY = anchorPositions.length ? Math.min(...anchorPositions.map((point) => point.y)) : 180;
        const columns = bucketNodes.length > 4 ? 3 : bucketNodes.length > 2 ? 2 : Math.max(1, bucketNodes.length);
        bucketNodes.forEach((node, index) => {
            const column = index % columns;
            const row = Math.floor(index / columns);
            const xOffset = ((columns - 1) * 150) / 2;
            positions[node.alias] = {
                x: anchorX - xOffset + column * 300,
                y: anchorY - 280 - row * 200
            };
        });
    });

    nodes.forEach((node) => {
        if (positions[node.alias]) return;
        positions[node.alias] = {
            x: 500,
            y: 160
        };
    });

    return positions;
};
