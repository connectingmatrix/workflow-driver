import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import { hydrateWorkflowDefinition } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { exportPayloadToWorkflow, workflowToExportPayload } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { WorkflowAuthModeEnum, WorkflowDefinition, WorkflowExportPayload } from '@workflow/ui/workflow/types';

interface WorkflowManifestEntry {
    id: string;
    title: string;
    domain: string;
    problem: string;
    filename?: string;
    file?: string;
}

interface WorkflowManifest {
    generatedAt: string;
    workflows: WorkflowManifestEntry[];
}

const TEST_DIR = path.dirname(fileURLToPath(import.meta.url));
const WORKFLOW_EXAMPLES_DIR = path.resolve(TEST_DIR, '../../../../../giga-ai-ui/examples/workflows');
const WORKFLOW_MANIFEST_PATH = path.join(WORKFLOW_EXAMPLES_DIR, 'index.json');

const PROMPT_FIELD_KEYS = ['prompt', 'selectionPromptMd', 'message', 'question'];

const { evaluateJavascriptInIframeMock, runGraphqlRequestMock, resolveAuthHeadersMock } = vi.hoisted(() => ({
    evaluateJavascriptInIframeMock: vi.fn(),
    runGraphqlRequestMock: vi.fn(),
    resolveAuthHeadersMock: vi.fn()
}));

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', () => ({
    evaluateJavascriptInIframe: evaluateJavascriptInIframeMock
}));

vi.mock('@workflow/nodes/nodes/graphql/graphql-client', () => ({
    runGraphqlRequest: runGraphqlRequestMock,
    resolveAuthHeaders: resolveAuthHeadersMock
}));

const hasText = (value: unknown): boolean => typeof value === 'string' && value.trim().length > 0;

const readWorkflowManifest = (): WorkflowManifest => JSON.parse(fs.readFileSync(WORKFLOW_MANIFEST_PATH, 'utf8')) as WorkflowManifest;

const resolveWorkflowFilename = (entry: WorkflowManifestEntry): string => entry.filename ?? entry.file ?? '';

const readWorkflowPayload = (entry: WorkflowManifestEntry): WorkflowExportPayload => {
    const filename = resolveWorkflowFilename(entry);
    const workflowPath = path.join(WORKFLOW_EXAMPLES_DIR, filename);
    return JSON.parse(fs.readFileSync(workflowPath, 'utf8')) as WorkflowExportPayload;
};

beforeEach(() => {
    evaluateJavascriptInIframeMock.mockReset();
    evaluateJavascriptInIframeMock.mockResolvedValue({
        result: {
            mocked: true,
            summary: 'code-node executed in test mock'
        },
        logs: ['code execution mocked'],
        error: null
    });

    runGraphqlRequestMock.mockReset();
    runGraphqlRequestMock.mockResolvedValue({
        ok: true,
        status: 200,
        response: {
            data: {
                ai_chat_messagesCollection: { edges: [{ node: { id: 'msg-1', text: 'sample chat message' } }] },
                ai_subjectsCollection: { edges: [{ node: { id: 'subject-1', title: 'Sample Subject' } }] },
                ai_postsCollection: { edges: [{ node: { id: 'post-1', title: 'Sample Post', narrative: 'Sample narrative', subject_id: 'subject-1' } }] }
            }
        }
    });

    resolveAuthHeadersMock.mockReset();
    resolveAuthHeadersMock.mockReturnValue({});

    vi.stubGlobal(
        'fetch',
        vi.fn(async () => ({
            ok: true,
            status: 200,
            text: async () =>
                JSON.stringify({
                    success: true,
                    source: 'mocked-fetch',
                    rows: [{ id: 'news-1', title: 'Mocked news snapshot row' }]
                })
        }))
    );
});

afterEach(() => {
    vi.unstubAllGlobals();
});

describe('workflow example pack', () => {
    it('contains a manifest with one canonical sample and required metadata fields', () => {
        const manifest = readWorkflowManifest();
        expect(manifest.workflows).toHaveLength(1);

        const seenIds = new Set<string>();
        const seenFiles = new Set<string>();

        manifest.workflows.forEach((entry) => {
            expect(hasText(entry.id)).toBe(true);
            expect(hasText(entry.title)).toBe(true);
            expect(hasText(entry.domain)).toBe(true);
            expect(hasText(entry.problem)).toBe(true);

            const filename = resolveWorkflowFilename(entry);
            expect(hasText(filename)).toBe(true);
            expect(filename.endsWith('.json')).toBe(true);

            expect(seenIds.has(entry.id)).toBe(false);
            expect(seenFiles.has(filename)).toBe(false);
            seenIds.add(entry.id);
            seenFiles.add(filename);

            const workflowPath = path.join(WORKFLOW_EXAMPLES_DIR, filename);
            expect(fs.existsSync(workflowPath)).toBe(true);
        });
    });

    const manifest = readWorkflowManifest();

    manifest.workflows.forEach((entry) => {
        it(`${entry.id} imports, validates, executes, and roundtrips`, async () => {
            const payload = readWorkflowPayload(entry);
            const workflow = hydrateWorkflowDefinition(exportPayloadToWorkflow(payload));

            expect(workflow.nodes.some((node) => node.modelId === 'start')).toBe(true);
            expect(workflow.nodes.some((node) => node.modelId === 'respond-end')).toBe(true);

            const nodeIds = new Set(workflow.nodes.map((node) => node.id));
            workflow.connections.forEach((connection) => {
                expect(nodeIds.has(connection.from)).toBe(true);
                expect(nodeIds.has(connection.to)).toBe(true);
            });

            workflow.nodes.forEach((node) => {
                expect(hasText(node.description)).toBe(true);

                const runtime = node.runtime && typeof node.runtime === 'object' && !Array.isArray(node.runtime) ? (node.runtime as Record<string, unknown>) : {};
                if (Object.prototype.hasOwnProperty.call(runtime, 'description')) {
                    expect(hasText(runtime.description)).toBe(true);
                }
                if (Object.prototype.hasOwnProperty.call(runtime, 'model')) {
                    expect(hasText(runtime.model)).toBe(true);
                }

                PROMPT_FIELD_KEYS.forEach((promptKey) => {
                    if (!Object.prototype.hasOwnProperty.call(runtime, promptKey)) return;
                    expect(hasText(runtime[promptKey])).toBe(true);
                });
            });

            const result = await workflowExecutor.executeWorkflow(workflow, {
                settings: {
                    graphqlUrl: 'http://localhost/graphql',
                    authMode: WorkflowAuthModeEnum.None,
                    manualHeaders: {}
                }
            });

            expect(result.events.some((event) => event.event === 'workflow.validation_failed')).toBe(false);

            const endNode = result.workflow.nodes.find((node) => node.modelId === 'respond-end');
            expect(endNode).toBeTruthy();
            expect((endNode?.ports?.out as Record<string, unknown> | undefined)?.output).toBeTruthy();

            const roundTripPayload = workflowToExportPayload(result.workflow as unknown as WorkflowDefinition, 'with-data');
            const reImportedWorkflow = hydrateWorkflowDefinition(exportPayloadToWorkflow(roundTripPayload));

            expect(reImportedWorkflow.nodes).toHaveLength(workflow.nodes.length);
            expect(reImportedWorkflow.connections).toHaveLength(workflow.connections.length);
        }, 15000);
    });

    it('keeps manifest workflow sample importable/executable/roundtrippable', async () => {
        const manifest = readWorkflowManifest();
        const entry = manifest.workflows[0];
        const payload = readWorkflowPayload(entry);
        const workflow = hydrateWorkflowDefinition(exportPayloadToWorkflow(payload));

        const result = await workflowExecutor.executeWorkflow(workflow, {
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: WorkflowAuthModeEnum.None,
                manualHeaders: {}
            }
        });

        expect(result.events.some((event) => event.event === 'workflow.validation_failed')).toBe(false);

        const roundTripPayload = workflowToExportPayload(result.workflow as unknown as WorkflowDefinition, 'with-data');
        const reImported = hydrateWorkflowDefinition(exportPayloadToWorkflow(roundTripPayload));
        expect(reImported.nodes.length).toBe(workflow.nodes.length);
        expect(reImported.connections.length).toBe(workflow.connections.length);
    });
});
