import type { WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';
import { WORKSPACE_NODE_LIBRARY_CATEGORY_ORDER, WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER, type WorkflowNodeLibraryCategory } from '@workflow/ui/constants';

export interface WorkspaceNodeLibraryGroupSection {
    groupName: string;
    items: WorkflowNodeLibraryItem[];
}

const resolveHash = (value: string): number => value.split('').reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0);

export const resolveFallbackIconStyle = (key: string): { iconColor: string; iconBackground: string } => {
    const hue = Math.abs(resolveHash(key)) % 360;
    return {
        iconColor: `hsl(${hue} 70% 32%)`,
        iconBackground: `hsl(${hue} 95% 94%)`
    };
};

export const resolveWorkspaceNodeLibraryCategory = (item: WorkflowNodeLibraryItem): WorkflowNodeLibraryCategory => {
    const group = `${item.group ?? ''}`.trim().toLowerCase();
    const fallback = `${item.nodeType ?? ''} ${item.modelId ?? ''}`.toLowerCase();
    const source = group || fallback;
    if (source.includes('mcp')) return 'mcp';
    if (source.includes('ai') || source.includes('logic')) return 'logic';
    if (source.includes('data') || source.includes('output')) return 'data';
    if (source.includes('flow')) return 'flow';
    return 'other';
};

export const resolveWorkspaceNodeLibraryGroupLabel = (item: WorkflowNodeLibraryItem): string => item.group?.trim() || 'Other';

export const resolveWorkspaceNodeLibraryCategoryLabel = (category: WorkflowNodeLibraryCategory): string => {
    switch (category) {
        case 'flow':
            return 'Flow';
        case 'logic':
            return 'Logic';
        case 'mcp':
            return 'MCP';
        case 'data':
            return 'Data';
        case 'other':
            return 'Other';
        case 'all':
        default:
            return 'All';
    }
};

export const buildWorkspaceNodeLibraryCategories = (items: WorkflowNodeLibraryItem[]): WorkflowNodeLibraryCategory[] => {
    const seen = new Set<WorkflowNodeLibraryCategory>();
    items.forEach((item) => seen.add(resolveWorkspaceNodeLibraryCategory(item)));
    return WORKSPACE_NODE_LIBRARY_CATEGORY_ORDER.filter((category) => category === 'all' || seen.has(category));
};

export const filterWorkspaceNodeLibraryItems = (items: WorkflowNodeLibraryItem[], search: string, category: WorkflowNodeLibraryCategory): WorkflowNodeLibraryItem[] => {
    const normalizedSearch = search.trim().toLowerCase();
    return items.filter((item) => {
        const matchesCategory = category === 'all' || resolveWorkspaceNodeLibraryCategory(item) === category;
        if (!matchesCategory) return false;
        if (!normalizedSearch) return true;
        return [item.label, item.description, item.gigaId, item.modelId, item.group, item.nodeType]
            .filter(Boolean)
            .some((value) => String(value).toLowerCase().includes(normalizedSearch));
    });
};

export const getWorkspaceNodeLibraryCount = (items: WorkflowNodeLibraryItem[], category: WorkflowNodeLibraryCategory): number => {
    if (category === 'all') return items.length;
    return items.filter((item) => resolveWorkspaceNodeLibraryCategory(item) === category).length;
};

export const buildWorkspaceNodeLibraryGroups = (items: WorkflowNodeLibraryItem[]): WorkspaceNodeLibraryGroupSection[] => {
    const groupedItems = new Map<string, WorkflowNodeLibraryItem[]>();
    items.forEach((item) => {
        const groupName = resolveWorkspaceNodeLibraryGroupLabel(item);
        const next = groupedItems.get(groupName) ?? [];
        next.push(item);
        groupedItems.set(groupName, next);
    });

    return Array.from(groupedItems.entries())
        .sort(([left], [right]) => {
            const leftPriority = WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER.indexOf(left as (typeof WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER)[number]);
            const rightPriority = WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER.indexOf(right as (typeof WORKSPACE_NODE_LIBRARY_PRIORITY_GROUP_ORDER)[number]);
            if (leftPriority >= 0 && rightPriority >= 0) return leftPriority - rightPriority;
            if (leftPriority >= 0) return -1;
            if (rightPriority >= 0) return 1;
            return left.localeCompare(right);
        })
        .map(([groupName, groupItems]) => ({
            groupName,
            items: groupItems
        }));
};
