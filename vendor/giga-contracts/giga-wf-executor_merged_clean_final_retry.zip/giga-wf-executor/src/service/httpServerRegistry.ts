import { Server } from 'node:http';

const servers = new Set<Server>();
const handlers = new Set<(server: Server) => void>();

let patched = false;

const patchListen = () => {
  if (patched) return;
  patched = true;
  const listen = Server.prototype.listen;
  Server.prototype.listen = function patchedListen(this: Server, ...args: any[]) {
    const server = this;
    if (!servers.has(server)) {
      servers.add(server);
      handlers.forEach((handler) => handler(server));
    }
    return listen.apply(server, args as any);
  } as typeof Server.prototype.listen;
};

patchListen();

export const onTrackedHttpServer = (handler: (server: Server) => void) => {
  patchListen();
  handlers.add(handler);
  servers.forEach((server) => handler(server));
  return () => {
    handlers.delete(handler);
    return undefined;
  };
};

export const trackedHttpServers = () => Array.from(servers.values());
