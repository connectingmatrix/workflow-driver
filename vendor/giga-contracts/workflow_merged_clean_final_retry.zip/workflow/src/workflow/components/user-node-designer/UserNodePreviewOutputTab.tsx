import React, { useMemo, useState } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { UserNodePreviewState } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';

type OutputViewMode = 'json' | 'raw' | 'table';

interface UserNodePreviewOutputTabProps {
    state: UserNodePreviewState;
}

const VIEW_OPTIONS: Array<{ label: string; value: OutputViewMode }> = [
    { label: 'JSON', value: 'json' },
    { label: 'Raw', value: 'raw' },
    { label: 'Table', value: 'table' }
];

const toRows = (result: unknown): Record<string, unknown>[] => {
    if (Array.isArray(result)) {
        return result.filter((entry) => entry && typeof entry === 'object' && !Array.isArray(entry)) as Record<string, unknown>[];
    }
    if (result && typeof result === 'object' && !Array.isArray(result)) {
        const rows = (result as { rows?: unknown[] }).rows;
        if (Array.isArray(rows)) {
            return rows.filter((entry) => entry && typeof entry === 'object' && !Array.isArray(entry)) as Record<string, unknown>[];
        }
    }
    return [];
};

const UserNodePreviewOutputTab: React.FC<UserNodePreviewOutputTabProps> = ({ state }) => {
    const [viewMode, setViewMode] = useState<OutputViewMode>('json');
    const rows = useMemo(() => toRows(state.result), [state.result]);
    const columns = useMemo(() => Array.from(new Set(rows.flatMap((row) => Object.keys(row)))).slice(0, 10), [rows]);

    return (
        <div className="wf-user-node-preview-output" data-cy="user-node-preview-output-root">
            <div className="wf-user-node-preview-output__toolbar">
                <span className="text-xs text-500">
                    Status: {state.status} | Duration: {state.durationMs ?? '-'} ms
                </span>
                <Dropdown value={viewMode} options={VIEW_OPTIONS} onChange={(event) => setViewMode(event.value)} className="p-inputtext-sm" data-cy="user-node-preview-output-mode" />
            </div>
            {viewMode === 'table' ? (
                <div className="wf-user-node-preview-output__content wf-user-node-preview-scroll" data-cy="user-node-preview-output">
                    {!rows.length ? (
                        <div className="text-xs text-500">Output is not table-like.</div>
                    ) : (
                        <table className="w-full text-xs wf-user-node-preview-output__table">
                            <thead>
                                <tr>
                                    {columns.map((column) => (
                                        <th key={column} className="text-left px-2 py-1">
                                            {column}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {rows.slice(0, 50).map((row, rowIndex) => (
                                    <tr key={`${rowIndex}-${columns[0] ?? 'row'}`}>
                                        {columns.map((column) => (
                                            <td key={`${rowIndex}-${column}`} className="px-2 py-1">
                                                {String(row[column] ?? '')}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            ) : (
                <pre className="text-xs wf-user-node-preview-output__content wf-user-node-preview-scroll" data-cy="user-node-preview-output">
                    {viewMode === 'raw' ? String(state.result ?? '') : JSON.stringify(state.result, null, 2)}
                </pre>
            )}
        </div>
    );
};

export default UserNodePreviewOutputTab;
