import {
    WorkflowDefinition,
    WorkflowDisplayStatus,
    WorkflowDisplayStatusEnum,
    WorkflowStatus,
    WorkflowStatusEnum
} from '@workflow/ui/workflow/types';

export const resolveWorkflowDisplayStatus = (input: {
    isRunning?: boolean;
    publishedAt?: string | null;
    publishedWorkflow?: WorkflowDefinition | null;
    status?: WorkflowStatus | null;
}): WorkflowDisplayStatus => {
    if (input.isRunning) return WorkflowDisplayStatusEnum.Running;
    if (input.status === WorkflowStatusEnum.Published) return WorkflowDisplayStatusEnum.Published;
    if (input.publishedAt || input.publishedWorkflow) return WorkflowDisplayStatusEnum.UnPublished;
    return WorkflowDisplayStatusEnum.Draft;
};

export const readWorkflowDisplayStatusLabel = (status: WorkflowDisplayStatus | null | undefined): string => {
    if (status === WorkflowDisplayStatusEnum.Running) return 'Running';
    if (status === WorkflowDisplayStatusEnum.Published) return 'Published';
    if (status === WorkflowDisplayStatusEnum.UnPublished) return 'Un-Published';
    return 'Draft';
};

export const readWorkflowDisplayStatusSeverity = (
    status: WorkflowDisplayStatus | null | undefined
): 'contrast' | 'info' | 'success' | 'warning' => {
    if (status === WorkflowDisplayStatusEnum.Running) return 'warning';
    if (status === WorkflowDisplayStatusEnum.Published) return 'success';
    if (status === WorkflowDisplayStatusEnum.UnPublished) return 'contrast';
    return 'info';
};
