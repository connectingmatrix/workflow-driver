// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import InspectorObjectArrayField from '@workflow/ui/workflow/components/inspector/fields/InspectorObjectArrayField';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';

const HEADERS_DEFINITION = {
    type: WorkflowNodeFieldTypeEnum.ObjectArray,
    label: 'HTTP Headers',
    editable: true,
    valueMode: 'record',
    keyField: 'key',
    valueField: 'value',
    addButtonLabel: 'Add Header',
    subFields: {
        key: { label: 'Key', required: true, styleCol: 5 },
        value: { label: 'Value', required: true, styleCol: 6 }
    }
};

describe('InspectorObjectArrayField', () => {
    afterEach(() => {
        cleanup();
    });

    it('renders shared record rows and writes canonical row state', () => {
        const onChange = vi.fn();
        render(<InspectorObjectArrayField fieldKey="headers" definition={HEADERS_DEFINITION} value={{ Authorization: 'Bearer token' }} onChange={onChange} />);

        const textboxes = screen.getAllByRole('textbox');
        expect(textboxes).toHaveLength(2);
        expect(textboxes[0]).toHaveValue('Authorization');
        expect(textboxes[1]).toHaveValue('Bearer token');

        fireEvent.change(textboxes[1], { target: { value: 'Updated token' } });
        expect(onChange).toHaveBeenCalledWith('headers', [{ key: 'Authorization', value: 'Updated token' }]);
    });

    it('adds new rows through the shared designer control', () => {
        const onChange = vi.fn();
        render(<InspectorObjectArrayField fieldKey="stdioArgs" definition={{ ...HEADERS_DEFINITION, valueMode: 'string-array', valueField: 'value', subFields: { value: { label: 'Value', required: true, styleCol: 11 } } }} value={['--debug']} onChange={onChange} />);

        fireEvent.click(screen.getByRole('button', { name: 'Add Header' }));
        expect(onChange).toHaveBeenCalledWith('stdioArgs', [{ value: '--debug' }, { value: '' }]);
    });
});
