import type { Connection } from '@xyflow/react';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeLibraryItem, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { addDroppedNode } from '@workflow/ui/workflow/utils/workflow-state-updates.utils';
import { arrangeWorkflowState } from '@workflow/ui/workflow/utils/workflow-arrange.utils';
import { canAttachConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';
import { hydrateWorkflowDefinition } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { parseWorkflowCypher } from './cypher-parse';
import { WorkflowCypherBuildInput, WorkflowCypherEdgeSpec, WorkflowCypherResult } from './cypher-types';

const itemByModel = (items: WorkflowNodeLibraryItem[]): Record<string, WorkflowNodeLibraryItem> =>
    items.reduce<Record<string, WorkflowNodeLibraryItem>>((acc, item) => {
        acc[item.modelId] = item;
        return acc;
    }, {});

const mergeRuntime = (runtime: Record<string, unknown>, patch: Record<string, unknown>): Record<string, unknown> => ({
    ...runtime,
    ...patch
});

const applyRuntimePatch = (node: WorkflowDefinition['nodes'][number], name: string | undefined, patch: Record<string, unknown>): WorkflowDefinition['nodes'][number] => {
    const runtime = mergeRuntime({ ...(node.runtime || {}), ...(node.properties || {}) }, patch);
    return {
        ...node,
        name: name || node.name,
        status: WorkflowNodeStatusEnum.Stopped,
        runtime,
        properties: runtime,
        inspector: node.inspector
            ? {
                  ...node.inspector,
                  properties: { ...(node.inspector.properties || {}), ...runtime },
                  code: typeof runtime.code === 'string' ? runtime.code : node.inspector.code,
                  markdown: typeof runtime.markdown === 'string' ? runtime.markdown : node.inspector.markdown
              }
            : node.inspector
    };
};

const buildConnection = (edge: WorkflowCypherEdgeSpec, ids: Record<string, string>, index: number): WorkflowConnectionModel | null => {
    const from = ids[edge.from];
    const to = ids[edge.to];
    if (!from || !to) return null;
    return {
        id: `cypher_${index + 1}_${from}_${to}`,
        name: `${from} -> ${to}`,
        from,
        to,
        sourceHandle: edge.source,
        targetHandle: edge.target
    };
};

const validateConnection = (workflow: WorkflowDefinition, connection: WorkflowConnectionModel): boolean =>
    canAttachConnection(workflow, {
        source: connection.from,
        target: connection.to,
        sourceHandle: connection.sourceHandle,
        targetHandle: connection.targetHandle
    } as Connection);

export const workflowFromCypher = async (input: WorkflowCypherBuildInput): Promise<WorkflowCypherResult> => {
    const graph = parseWorkflowCypher(input.cypher);
    const warnings: string[] = [];
    const library = itemByModel(input.nodeLibraryItems);
    let workflow: WorkflowDefinition = hydrateWorkflowDefinition({
        ...input.baseWorkflow,
        nodes: [],
        connections: []
    });
    const ids: Record<string, string> = {};

    graph.nodes.forEach((spec) => {
        const item = library[spec.modelId];
        if (!item) throw new Error(`Unknown node model "${spec.modelId}" in workflow cypher.`);
        const before = new Set(workflow.nodes.map((node) => node.id));
        workflow = addDroppedNode(workflow, item, { x: 140, y: 160 });
        const inserted = workflow.nodes.find((node) => !before.has(node.id));
        if (!inserted) throw new Error(`Unable to create node "${spec.alias}" from workflow cypher.`);
        ids[spec.alias] = inserted.id;
        workflow = {
            ...workflow,
            nodes: workflow.nodes.map((node) => (node.id === inserted.id ? applyRuntimePatch(node, spec.name, spec.runtime) : node))
        };
    });

    for (const [index, edge] of graph.edges.entries()) {
        const connection = buildConnection(edge, ids, index);
        if (!connection) throw new Error(`Unknown cypher edge alias "${edge.from}" -> "${edge.to}".`);
        if (!validateConnection(workflow, connection)) {
            throw new Error(`Invalid workflow cypher connection "${edge.from}" -> "${edge.to}" (${edge.source} -> ${edge.target}).`);
        }
        workflow = { ...workflow, connections: [...workflow.connections, connection] };
    }

    return { workflow: hydrateWorkflowDefinition(await arrangeWorkflowState(workflow)), warnings };
};
