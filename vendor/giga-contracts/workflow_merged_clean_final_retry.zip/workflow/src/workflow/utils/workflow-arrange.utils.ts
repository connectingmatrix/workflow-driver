import { layoutWorkflowGraph } from '@workflow/ui/workflow/layout';
import type { WorkflowDefinition } from '@workflow/ui/workflow/types';

export const arrangeWorkflowState = async (workflow: WorkflowDefinition): Promise<WorkflowDefinition> => layoutWorkflowGraph(workflow);
