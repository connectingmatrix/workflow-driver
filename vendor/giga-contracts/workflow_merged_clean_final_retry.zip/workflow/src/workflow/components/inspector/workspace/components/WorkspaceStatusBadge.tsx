import React from 'react';
import type { WorkspaceOutputStatus } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface WorkspaceStatusBadgeProps {
    status: WorkspaceOutputStatus;
}

export const WorkspaceStatusBadge: React.FC<WorkspaceStatusBadgeProps> = ({ status }) => {
    return <span className={`cnw-status-badge cnw-status-badge--${status.tone ?? 'default'}`}>{status.label}</span>;
};
