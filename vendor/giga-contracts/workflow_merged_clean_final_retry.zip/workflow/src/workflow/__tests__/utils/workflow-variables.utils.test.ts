import { describe, expect, it } from 'vitest';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import { buildVariableSuggestionsFromContext, getVariableTokenStates, resolveFieldAllowVariables, resolveWorkflowVariables, restoreWorkflowVariableTokenEscapes } from '@workflow/ui/workflow/utils/workflow-variables.utils';

describe('workflow-variables.utils', () => {
    it('resolves template tokens and reports unresolved paths', () => {
        const context = {
            node_1: {
                title: 'Hello',
                stats: { total: 4 }
            }
        };

        const result = resolveWorkflowVariables('Value: {{node_1.title}} / {{node_1.missing}}', context);
        expect(result.value).toBe('Value: Hello / {{node_1.missing}}');
        expect(result.unresolved).toEqual(['node_1.missing']);
    });

    it('returns object values when a whole token points to structured data', () => {
        const context = {
            node_1: {
                payload: { ok: true }
            }
        };

        const result = resolveWorkflowVariables('{{node_1.payload}}', context);
        expect(result.unresolved).toHaveLength(0);
        expect(result.value).toEqual({ ok: true });
    });

    it('computes resolved/unresolved token states for highlighting', () => {
        const states = getVariableTokenStates('A {{a}} B {{missing}}', { a: 'x' });
        expect(states.map((item) => item.status)).toEqual(['resolved', 'unresolved']);
    });

    it('resolves markdown escaped variable paths', () => {
        const result = resolveWorkflowVariables('Run {{code\\_5.query}}', { code_5: { query: 'Iran news' } });
        const states = getVariableTokenStates('{{code\\_5.query}}', { code_5: { query: 'Iran news' } });

        expect(result.value).toBe('Run Iran news');
        expect(result.unresolved).toHaveLength(0);
        expect(states[0]?.path).toBe('code_5.query');
        expect(states[0]?.status).toBe('resolved');
    });

    it('builds variable suggestions from input context paths', () => {
        const suggestions = buildVariableSuggestionsFromContext({
            node_1: {
                title: 'Hello'
            }
        });
        expect(suggestions.some((item) => item.path === 'node_1.title')).toBe(true);
    });

    it('builds variable suggestions from workflow context when workflow root is requested', () => {
        const suggestions = buildVariableSuggestionsFromContext(
            {
                workflow: {
                    runtime: {
                        graphqlUrl: 'http://localhost/graphql'
                    }
                }
            },
            ['workflow']
        );

        expect(suggestions.some((item) => item.path === 'workflow.runtime.graphqlUrl')).toBe(true);
    });

    it('stops suggestion flattening at circular references', () => {
        const value: Record<string, unknown> = { query: 'Iran news' };
        value.self = value;

        const suggestions = buildVariableSuggestionsFromContext({ code_5: value });

        expect(suggestions.some((item) => item.path === 'code_5.query')).toBe(true);
    });

    it('restores markdown escaped variable tokens', () => {
        expect(restoreWorkflowVariableTokenEscapes('Use {{code\\_5.query}} now')).toBe('Use {{code_5.query}} now');
    });

    it('enforces variable defaults for technical fields', () => {
        expect(resolveFieldAllowVariables('status', { type: WorkflowNodeFieldTypeEnum.String, editable: true })).toBe(false);
        expect(resolveFieldAllowVariables('prompt', { type: WorkflowNodeFieldTypeEnum.Textarea, editable: true })).toBe(true);
        expect(resolveFieldAllowVariables('temperature', { type: WorkflowNodeFieldTypeEnum.Number, editable: true })).toBe(false);
    });
});
