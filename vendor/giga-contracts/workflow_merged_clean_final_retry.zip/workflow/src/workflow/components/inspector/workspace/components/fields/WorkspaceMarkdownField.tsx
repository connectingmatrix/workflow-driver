import React from 'react';
import InstructionMarkdownEditor from '@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';

interface WorkspaceMarkdownFieldProps {
    id: string;
    value: string;
    editable: boolean;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: string) => void;
}

export const WorkspaceMarkdownField: React.FC<WorkspaceMarkdownFieldProps> = ({ id, value, editable, variableSuggestions, onChange }) => {
    return (
        <div className="cnw-markdown-field-shell" data-readonly={!editable}>
            <InstructionMarkdownEditor id={id} value={value} onChange={editable ? onChange : () => undefined} allowVariables={editable} variableSuggestions={variableSuggestions} />
        </div>
    );
};
