import React from 'react';

interface WorkspaceDependingFieldProps {
    primary: React.ReactNode;
    dependent: React.ReactNode;
    dependentLabel: string;
}

export const WorkspaceDependingField: React.FC<WorkspaceDependingFieldProps> = ({ primary, dependent, dependentLabel }) => {
    return (
        <div className="cnw-depending-field">
            <div className="cnw-depending-field__primary">{primary}</div>
            <div className="cnw-depending-field__dependent">
                <span className="cnw-depending-field__dependent-label">{dependentLabel}</span>
                {dependent}
            </div>
        </div>
    );
};
