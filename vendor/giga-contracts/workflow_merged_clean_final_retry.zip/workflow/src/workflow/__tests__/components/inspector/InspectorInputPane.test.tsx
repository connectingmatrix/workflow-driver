import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import InspectorInputPane from '@workflow/ui/workflow/components/inspector/InspectorInputPane';

describe('InspectorInputPane', () => {
    it('renders input header and provided JSON keys', () => {
        render(<InspectorInputPane inputData={{ inputA: { nested: 'value' } }} nodeTypeLabel="Code" />);
        expect(screen.getByText('Input')).toBeInTheDocument();
        expect(screen.getByText('inputA')).toBeInTheDocument();
    });

    it('renders control nodes tab when bi-directional peers are present', () => {
        render(
            <InspectorInputPane
                inputData={{}}
                nodeTypeLabel="AI Governor"
                controlNodes={{
                    'openai-1': {
                        status: 'passed'
                    }
                }}
            />
        );
        expect(screen.getByText('Control Nodes')).toBeInTheDocument();
    });
});
