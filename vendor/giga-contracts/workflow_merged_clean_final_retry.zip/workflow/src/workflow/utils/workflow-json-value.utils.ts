const isPlainWorkflowJsonObject = (value: object): value is Record<string, unknown> => {
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
};

const isWorkflowBrowserRuntimeObject = (value: unknown): boolean =>
    (typeof Element !== 'undefined' && value instanceof Element) ||
    (typeof Window !== 'undefined' && value instanceof Window) ||
    (typeof Document !== 'undefined' && value instanceof Document) ||
    (typeof Event !== 'undefined' && value instanceof Event);

export const cleanWorkflowJsonValue = (value: unknown, seen: WeakSet<object> = new WeakSet<object>()): unknown => {
    if (value === null) return null;
    const valueKind = typeof value;
    if (valueKind === 'string' || valueKind === 'boolean') return value;
    if (valueKind === 'number') return Number.isFinite(value) ? value : null;
    if (valueKind !== 'object' || isWorkflowBrowserRuntimeObject(value)) return undefined;
    const objectValue = value as object;
    if (seen.has(objectValue)) return undefined;

    seen.add(objectValue);
    if (Array.isArray(value)) {
        const items: unknown[] = [];
        for (const item of value) {
            const cleanedItem = cleanWorkflowJsonValue(item, seen);
            if (typeof cleanedItem !== 'undefined') items.push(cleanedItem);
        }
        seen.delete(objectValue);
        return items;
    }

    if (!isPlainWorkflowJsonObject(objectValue)) {
        seen.delete(objectValue);
        return undefined;
    }

    const record: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(objectValue)) {
        const cleanedItem = cleanWorkflowJsonValue(item, seen);
        if (typeof cleanedItem !== 'undefined') record[key] = cleanedItem;
    }
    seen.delete(objectValue);
    return record;
};

export const stringifyWorkflowJsonValue = (value: unknown, space = 0): string => JSON.stringify(cleanWorkflowJsonValue(value), null, space);
