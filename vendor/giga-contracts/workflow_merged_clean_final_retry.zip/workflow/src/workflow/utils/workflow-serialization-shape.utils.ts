import { WorkflowDefinition, WorkflowNodeKind, WorkflowNodeKindEnum, WorkflowNodeModel, WorkflowNodePorts, WorkflowNodeStatus, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { cleanWorkflowJsonValue } from '@workflow/ui/workflow/utils/workflow-json-value.utils';

export const parseRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

export const parseStatus = (value: unknown): WorkflowNodeStatus =>
    value === WorkflowNodeStatusEnum.Passed || value === WorkflowNodeStatusEnum.Failed || value === WorkflowNodeStatusEnum.Warning || value === WorkflowNodeStatusEnum.Running ? value : WorkflowNodeStatusEnum.Stopped;

export const parseKind = (value: unknown): WorkflowNodeKind => (value === WorkflowNodeKindEnum.Output || value === WorkflowNodeKindEnum.Error ? value : WorkflowNodeKindEnum.Process);

export const parsePosition = (value: unknown, index: number): { x: number; y: number } => {
    const x = Number(parseRecord(value).x);
    const y = Number(parseRecord(value).y);
    return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : { x: index * 340, y: 120 };
};

export const buildNodeRuntimeMap = (node: WorkflowNodeModel): Record<string, unknown> => {
    const runtime = { ...parseRecord(node.properties), ...parseRecord(node.runtime) };
    const code = node.inspector?.code;
    const markdown = node.inspector?.markdown;
    if (typeof code === 'string') runtime.code = code;
    if (typeof markdown === 'string') runtime.markdown = markdown;
    return cleanWorkflowJsonValue(runtime) as Record<string, unknown>;
};

export const buildNodePorts = (node: WorkflowNodeModel): WorkflowNodePorts => {
    const portsIn = Object.keys(node.ports?.in ?? {}).length > 0 ? parseRecord(node.ports.in) : { input: parseRecord(node.input) };
    const portsOut = Object.keys(node.ports?.out ?? {}).length > 0 ? parseRecord(node.ports.out) : { output: node.output };
    return cleanWorkflowJsonValue({
        in: portsIn as WorkflowNodePorts['in'],
        out: portsOut
    }) as WorkflowNodePorts;
};

export const stripSessionLogs = (metadata: WorkflowDefinition['metadata']): WorkflowDefinition['metadata'] => {
    if (!metadata.runtime) return metadata;
    return {
        ...metadata,
        runtime: {
            ...metadata.runtime
        }
    };
};
