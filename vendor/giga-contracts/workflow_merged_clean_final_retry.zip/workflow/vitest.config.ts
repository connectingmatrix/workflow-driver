import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';
import { workflowOptimizeDepsExclude, workflowResolveAliases, workflowResolveDedupe } from './vite.shared';

process.env.WORKFLOW_NODE_SANDBOX_POOL_SIZE = '0';
process.env.WORKFLOW_SANDBOX_POOL_SIZE = '0';

export default defineConfig({
    plugins: [react()],
    test: {
        environment: 'jsdom',
        setupFiles: ['./src/workflow/__tests__/setup.ts']
    },
    resolve: {
        dedupe: workflowResolveDedupe,
        alias: workflowResolveAliases
    },
    optimizeDeps: {
        exclude: workflowOptimizeDepsExclude
    }
});
