// @vitest-environment jsdom
import '@testing-library/jest-dom/vitest';
import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import StartWebhookUsageInspectorSection from '@workflow/ui/workflow/components/inspector/modules/start/StartWebhookUsageInspectorSection';

vi.mock('@workflow/ui/workflow/nodes/start/start-webhook-usage-card', () => ({
    default: ({ publishedUrl }: { publishedUrl: string }) => <div data-testid="start-webhook-usage-card">{publishedUrl}</div>
}));

describe('StartWebhookUsageInspectorSection', () => {
    it('renders webhook usage only for webhook-triggered start nodes', () => {
        render(
            <StartWebhookUsageInspectorSection
                modelId="start"
                fields={{}}
                propertiesEditorState={{ triggerSource: 'webhook' }}
                workflowData={{ metadata: { webhook: { publishedUrl: 'https://example.test/published', testUrl: 'https://example.test/test', secret: 'secret_123', method: 'POST' } } }}
                onPropertyChange={vi.fn()}
            />
        );

        expect(screen.getByTestId('start-webhook-usage-card')).toHaveTextContent('https://example.test/published');
    });

    it('stays hidden for programmatic start nodes', () => {
        const { container } = render(
            <StartWebhookUsageInspectorSection modelId="start" fields={{}} propertiesEditorState={{ triggerSource: 'programmatic' }} workflowData={{}} onPropertyChange={vi.fn()} />
        );

        expect(container).toBeEmptyDOMElement();
    });
});
