import type { WorkspaceSegmentedTabItem } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface WorkspaceSegmentedTabsProps {
    items: WorkspaceSegmentedTabItem[];
    activeId: string;
    onChange: (id: string) => void;
}

export const WorkspaceSegmentedTabs = ({ items, activeId, onChange }: WorkspaceSegmentedTabsProps) => {
    return (
        <div className="cnw-segmented-tabs" role="tablist" aria-label="Panel tabs">
            {items.map((item) => {
                const isActive = item.id === activeId;
                return (
                    <button
                        key={item.id}
                        type="button"
                        className={`cnw-segmented-tabs__button${isActive ? ' is-active' : ''}`}
                        role="tab"
                        aria-selected={isActive}
                        aria-pressed={isActive}
                        disabled={item.disabled}
                        onClick={() => onChange(item.id)}
                    >
                        <span>{item.label}</span>
                        {item.badge !== undefined ? <span className="cnw-segmented-tabs__badge">{item.badge}</span> : null}
                    </button>
                );
            })}
        </div>
    );
};
