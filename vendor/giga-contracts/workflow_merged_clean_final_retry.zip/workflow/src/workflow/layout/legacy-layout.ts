import type { WorkflowDefinition } from '@workflow/ui/workflow/types';
import { placeCommandNodes } from '@workflow/ui/workflow/layout/layout-command';
import { readLayoutGraph } from '@workflow/ui/workflow/layout/layout-graph';
import { placeMainNodes } from '@workflow/ui/workflow/layout/layout-main';

export const layoutWorkflowWithLegacy = (workflow: WorkflowDefinition): WorkflowDefinition => {
    if (!(workflow.nodes || []).length) return workflow;
    const graph = readLayoutGraph(workflow);
    const main = placeMainNodes(graph);
    const command = placeCommandNodes(graph, main);

    return {
        ...workflow,
        nodes: workflow.nodes.map((node) => ({ ...node, position: main.positions[node.id] || command[node.id] || node.position }))
    };
};
