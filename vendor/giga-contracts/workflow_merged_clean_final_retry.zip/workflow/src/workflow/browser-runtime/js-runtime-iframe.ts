interface IframeEvalResult {
    result: unknown;
    logs: string[];
    error?: string;
}

interface RuntimeMessage {
    type: 'WF_EVAL_READY' | 'WF_EVAL_RESULT';
    frameId?: string;
    id?: string;
    result?: unknown;
    logs?: Array<{ level: string; args: unknown[] }>;
    error?: string;
}

const FRAME_ID = '__giga_workflow_runtime_frame__';
const FRAME_READY_TIMEOUT_MS = 4000;
const FRAME_EVAL_TIMEOUT_MS = 25000;
const listeners = new Map<string, (message: RuntimeMessage) => void>();
const readyListeners = new Set<(frame: HTMLIFrameElement) => void>();
let runtimeReady = false;
let runtimeReadyPromise: Promise<HTMLIFrameElement> | null = null;

const serializeRuntimeLogEntry = (entry: { level: string; args: unknown[] }): string => {
    const payload = entry.args.map((item) => {
        if (typeof item === 'string') return item;
        try {
            return JSON.stringify(item);
        } catch {
            return String(item);
        }
    });
    return `${entry.level.toUpperCase()} ${payload.join(' ')}`.trim();
};

const createEvalMessageId = (): string => {
    const randomId = Math.random().toString(36).slice(2, 8);
    return `wf_eval_${Date.now()}_${randomId}`;
};

const resolveReadyListeners = (): void => {
    const frame = document.getElementById(FRAME_ID) as HTMLIFrameElement | null;
    if (!frame) {
        readyListeners.clear();
        return;
    }
    const callbacks = Array.from(readyListeners.values());
    readyListeners.clear();
    callbacks.forEach((callback) => callback(frame));
};

const markRuntimeReady = (): void => {
    runtimeReady = true;
    resolveReadyListeners();
    runtimeReadyPromise = null;
};

const getRuntimeFrame = (): HTMLIFrameElement => {
    let frame = document.getElementById(FRAME_ID) as HTMLIFrameElement | null;
    if (frame) return frame;
    runtimeReady = false;
    runtimeReadyPromise = null;
    frame = document.createElement('iframe');
    frame.id = FRAME_ID;
    frame.style.display = 'none';
    frame.setAttribute('aria-hidden', 'true');
    frame.srcdoc = `<script>
      window.addEventListener('message', async (event) => {
        const payload = event.data || {};
        if (payload.type === 'WF_EVAL_PING') {
          parent.postMessage({ type: 'WF_EVAL_READY', frameId: '${FRAME_ID}', id: payload.id || '' }, '*');
          return;
        }
        if (payload.type !== 'WF_EVAL_REQUEST') return;
        const logs = [];
        const consoleProxy = {
          log: (...args) => logs.push({ level: 'log', args }),
          info: (...args) => logs.push({ level: 'info', args }),
          warn: (...args) => logs.push({ level: 'warn', args }),
          error: (...args) => logs.push({ level: 'error', args })
        };
        try {
          const runner = new Function('input', 'properties', 'workflow', 'console', '"use strict"; return (async () => { ' + payload.code + ' })();');
          const result = await runner(payload.context?.input || {}, payload.context?.properties || {}, payload.context?.workflow || {}, consoleProxy);
          parent.postMessage({ type: 'WF_EVAL_RESULT', id: payload.id, result, logs }, '*');
        } catch (error) {
          parent.postMessage({ type: 'WF_EVAL_RESULT', id: payload.id, error: error?.message || 'Execution failed.', logs }, '*');
        }
      });
      parent.postMessage({ type: 'WF_EVAL_READY', frameId: '${FRAME_ID}', id: '' }, '*');
    <\/script>`;
    document.body.appendChild(frame);
    return frame;
};

export const ensureRuntimeFrameReady = async (timeoutMs = FRAME_READY_TIMEOUT_MS): Promise<HTMLIFrameElement> => {
    if (typeof window === 'undefined' || typeof document === 'undefined') {
        throw new Error('Workflow runtime frame is unavailable outside browser context.');
    }

    const frame = getRuntimeFrame();
    if (runtimeReady) {
        return frame;
    }

    if (runtimeReadyPromise) {
        return runtimeReadyPromise;
    }

    runtimeReadyPromise = new Promise<HTMLIFrameElement>((resolve, reject) => {
        const onReady = (readyFrame: HTMLIFrameElement): void => {
            window.clearTimeout(timeoutId);
            readyListeners.delete(onReady);
            markRuntimeReady();
            resolve(readyFrame);
        };

        const timeoutId = window.setTimeout(() => {
            readyListeners.delete(onReady);
            runtimeReadyPromise = null;
            reject(new Error('Workflow runtime iframe did not become ready before timeout.'));
        }, timeoutMs);

        readyListeners.add(onReady);

        try {
            frame.contentWindow?.postMessage({ type: 'WF_EVAL_PING', id: createEvalMessageId() }, '*');
        } catch {
            // Ignore ping errors and rely on startup ready event.
        }

        if (runtimeReady) {
            onReady(frame);
        }
    });

    return runtimeReadyPromise;
};

export const prewarmJavascriptRuntimeFrame = async (): Promise<void> => {
    await ensureRuntimeFrameReady();
};

export const __resetWorkflowRuntimeFrameForTests = (): void => {
    if (typeof document !== 'undefined') {
        const frame = document.getElementById(FRAME_ID);
        frame?.parentElement?.removeChild(frame);
    }
    listeners.clear();
    readyListeners.clear();
    runtimeReady = false;
    runtimeReadyPromise = null;
};

if (typeof window !== 'undefined') {
    window.addEventListener('message', (event) => {
        const payload = event.data as RuntimeMessage;
        if (!payload || typeof payload !== 'object') return;
        if (payload.type === 'WF_EVAL_READY') {
            if (!payload.frameId || payload.frameId === FRAME_ID) {
                markRuntimeReady();
            }
            if (payload.id) {
                const readyListener = listeners.get(payload.id);
                if (readyListener) {
                    readyListener(payload);
                    listeners.delete(payload.id);
                }
            }
            return;
        }
        if (payload.type !== 'WF_EVAL_RESULT' || !payload.id) return;
        const listener = listeners.get(payload.id);
        if (!listener) return;
        listener(payload);
        listeners.delete(payload.id);
    });
}

export const evaluateJavascriptInIframe = async (code: string, context: { input?: Record<string, unknown>; properties?: Record<string, unknown>; workflow?: Record<string, unknown> }, signal?: AbortSignal): Promise<IframeEvalResult> => {
    const frame = await ensureRuntimeFrameReady();
    const runtimeWindow = frame.contentWindow;
    if (!runtimeWindow) {
        runtimeReady = false;
        runtimeReadyPromise = null;
        return { result: null, logs: [], error: 'Runtime window is unavailable.' };
    }
    const id = createEvalMessageId();
    return new Promise<IframeEvalResult>((resolve) => {
        const timeoutId = window.setTimeout(() => {
            cleanup();
            resolve({
                result: null,
                logs: [],
                error: 'Execution timed out while waiting for runtime response.'
            });
        }, FRAME_EVAL_TIMEOUT_MS);

        const cleanup = (): void => {
            listeners.delete(id);
            signal?.removeEventListener('abort', onAbort);
            window.clearTimeout(timeoutId);
        };

        const onAbort = (): void => {
            cleanup();
            resolve({ result: null, logs: [], error: 'Execution aborted.' });
        };
        listeners.set(id, (payload) => {
            cleanup();
            resolve({
                result: payload.result,
                error: payload.error,
                logs: (payload.logs || []).map((entry) => serializeRuntimeLogEntry(entry))
            });
        });
        signal?.addEventListener('abort', onAbort, { once: true });
        runtimeWindow.postMessage({ type: 'WF_EVAL_REQUEST', id, code, context }, '*');
    });
};
