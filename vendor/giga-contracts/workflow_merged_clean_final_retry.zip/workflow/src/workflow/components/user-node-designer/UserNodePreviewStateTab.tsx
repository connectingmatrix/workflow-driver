import React from 'react';
import { UserNodePreviewState } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';

interface UserNodePreviewStateTabProps {
    state: UserNodePreviewState;
}

const UserNodePreviewStateTab: React.FC<UserNodePreviewStateTabProps> = ({ state }) => {
    const summary = {
        runId: state.runId,
        status: state.status,
        requestedRuntime: state.requestedRuntime,
        effectiveRuntime: state.effectiveRuntime,
        sourceMode: state.sourceMode,
        nodeModelId: state.nodeModelId,
        nodeDefinitionId: state.nodeDefinitionId,
        startedAt: state.startedAt,
        durationMs: state.durationMs,
        validation: state.validation
            ? {
                  ok: state.validation.ok,
                  warningCount: state.validation.warnings?.length ?? 0,
                  errorCount: state.validation.errors?.length ?? 0
              }
            : null,
        cancelled: state.wasCancelled,
        inputUsed: state.inputUsed
    };

    return (
        <pre className="text-xs overflow-auto wf-user-node-preview-scroll" data-cy="user-node-preview-state">
            {JSON.stringify(summary, null, 2)}
        </pre>
    );
};

export default UserNodePreviewStateTab;
