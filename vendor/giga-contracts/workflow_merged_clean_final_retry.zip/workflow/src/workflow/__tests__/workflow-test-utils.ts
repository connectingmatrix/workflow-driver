import { getAllNodeSchemas, getNodeLibraryItems, getNodeModule } from '@workflow/nodes/node-utils';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeModel } from '@workflow/ui/workflow/types';

const nodeLibraryByModelId = getNodeLibraryItems().reduce<Record<string, ReturnType<typeof getNodeLibraryItems>[number]>>((acc, item) => {
    acc[item.modelId] = item;
    return acc;
}, {});

export const createEmptyWorkflow = (id = 'wf_test'): WorkflowDefinition => ({
    metadata: {
        id,
        name: 'Workflow Test'
    },
    nodeModels: getAllNodeSchemas(),
    nodes: [],
    connections: []
});

export const createWorkflowNode = (workflow: WorkflowDefinition, modelId: string, name: string, index: number): WorkflowNodeModel => {
    const nodeModule = getNodeModule(modelId);
    const libraryItem = nodeLibraryByModelId[modelId];
    if (!libraryItem) {
        throw new Error(`Library item not found for modelId: ${modelId}`);
    }

    return nodeModule.buildInitialNode({
        nodeId: `node_${index}`,
        nodeName: name,
        schema: (workflow.nodeModels ?? getAllNodeSchemas())[modelId],
        libraryItem,
        position: { x: index * 320, y: 120 }
    });
};

export const createConnection = (id: string, from: string, to: string, sourceHandle = 'out:output', targetHandle = 'in:input'): WorkflowConnectionModel => ({
    id,
    name: `${from} -> ${to}`,
    from,
    to,
    sourceHandle,
    targetHandle
});
