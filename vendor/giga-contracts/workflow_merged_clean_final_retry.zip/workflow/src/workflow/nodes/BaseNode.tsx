import React, { useRef, useState } from 'react';
import { Node, NodeProps } from '@xyflow/react';
import { Menu } from 'primereact/menu';
import { MenuItem } from 'primereact/menuitem';
import { WorkflowNodeKind, WorkflowNodePortProperty, WorkflowNodePortSideEnum, WorkflowNodeRenderConfig, WorkflowNodeStatus, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import BaseNodeCommandPort from '@workflow/ui/workflow/nodes/BaseNodeCommandPort';
import BaseNodeDataPort from '@workflow/ui/workflow/nodes/BaseNodeDataPort';
import { buildPortPlacement, resolvePortSide, sortPortsByOrder } from '@workflow/ui/workflow/nodes/base-node-port-layout.utils';
import './base-node.scss';

export interface BaseNodePort {
    id: string;
    name: string;
    rules: WorkflowNodePortProperty;
}

export interface BaseNodeData extends Record<string, unknown> {
    nodeId: string;
    cacheKey: string;
    title: string;
    nodeTypeLabel?: string;
    kind: WorkflowNodeKind;
    status: WorkflowNodeStatus;
    isActive: boolean;
    isCompleted: boolean;
    isLoading: boolean;
    progressIndicatorMode?: 'local' | 'server' | null;
    nameEditable: boolean;
    render: WorkflowNodeRenderConfig;
    renderIcon?: (size: number) => React.ReactNode | string;
    inputs: BaseNodePort[];
    outputs: BaseNodePort[];
    commands: BaseNodePort[];
    readOnly?: boolean;
    isEnabled: boolean;
    outputConnectionCounts: Record<string, number>;
    onRename?: (nodeId: string, nextName: string) => void;
    onOpenInspector?: (nodeId: string) => void;
    onOpenAi?: (nodeId: string) => void;
    onExecuteStep?: (nodeId: string) => void;
    onToggleEnabled?: (nodeId: string, nextEnabled: boolean) => void;
    onDeleteNode?: (nodeId: string) => void;
    onQuickAddFromPort?: (payload: { nodeId: string; outputPortId: string; anchor: HTMLElement }) => void;
}

interface CommandPortPlacement {
    id: string;
    label: string;
    side: WorkflowNodePortSideEnum;
    order: number;
    rules: WorkflowNodePortProperty;
}

const buildCommandPortPlacement = (commandPorts: BaseNodePort[]): Array<{ port: CommandPortPlacement; side: WorkflowNodePortSideEnum; index: number; total: number }> => {
    const ports = [...commandPorts]
        .map((port) => ({
            id: port.id,
            label: port.rules.label ?? port.name,
            side: resolvePortSide(port),
            order: Number(port.rules.order ?? 0),
            rules: port.rules
        }))
        .sort((left, right) => left.order - right.order);
    const counts: Record<WorkflowNodePortSideEnum, number> = {
        [WorkflowNodePortSideEnum.Left]: 0,
        [WorkflowNodePortSideEnum.Right]: 0,
        [WorkflowNodePortSideEnum.Top]: 0,
        [WorkflowNodePortSideEnum.Bottom]: 0
    };
    ports.forEach((port) => {
        counts[port.side] += 1;
    });
    const seen: Record<WorkflowNodePortSideEnum, number> = {
        [WorkflowNodePortSideEnum.Left]: 0,
        [WorkflowNodePortSideEnum.Right]: 0,
        [WorkflowNodePortSideEnum.Top]: 0,
        [WorkflowNodePortSideEnum.Bottom]: 0
    };
    return ports.map((port) => {
        const index = seen[port.side];
        seen[port.side] += 1;
        return { port, side: port.side, index, total: counts[port.side] };
    });
};

const BaseNodeComponent: React.FC<NodeProps<Node<BaseNodeData>>> = ({ data, selected }) => {
    const [isHovered, setIsHovered] = useState<boolean>(false);
    const moreMenuRef = useRef<Menu>(null);
    const showLocalProgress = data.progressIndicatorMode === 'local';
    const showServerProgress = data.progressIndicatorMode === 'server';
    const showDone = !showLocalProgress && !showServerProgress && (data.status === WorkflowNodeStatusEnum.Passed || data.isCompleted);
    const nodeWidth = data.render.nodeWidth ?? data.render.nodeSize ?? 200;
    const nodeHeight = data.render.nodeHeight ?? data.render.nodeSize ?? 200;
    const iconSize = data.render.iconSize ?? 72;
    const renderedIcon = data.renderIcon ? data.renderIcon(iconSize) : null;
    const sortedInputs = sortPortsByOrder(data.inputs);
    const sortedOutputs = sortPortsByOrder(data.outputs);
    const inputPlacement = buildPortPlacement(sortedInputs);
    const outputPlacement = buildPortPlacement(sortedOutputs);
    const commandPlacement = buildCommandPortPlacement(sortPortsByOrder(data.commands));
    const containerWidth = Math.max(nodeWidth + 36, 236);
    const showQuickActions = !data.readOnly && (isHovered || selected);
    const moreMenuItems: MenuItem[] = [
        {
            label: 'Open Inspector',
            icon: 'pi pi-sliders-h',
            command: () => data.onOpenInspector?.(data.nodeId)
        },
        {
            label: data.isEnabled ? 'Disable Node' : 'Enable Node',
            icon: 'pi pi-power-off',
            command: () => data.onToggleEnabled?.(data.nodeId, !data.isEnabled)
        },
        {
            label: 'Delete Node',
            icon: 'pi pi-trash',
            command: () => data.onDeleteNode?.(data.nodeId)
        }
    ];

    return (
        <div
            className={`base-node base-node--status-${data.status} ${data.isActive ? 'base-node--active' : ''} ${data.isCompleted ? 'base-node--completed' : ''} ${selected ? 'base-node--selected' : ''} ${
                !data.isEnabled ? 'base-node--disabled' : ''
            }`}
            data-cy="workflow-node"
            data-node-id={data.nodeId}
            data-node-title={data.title}
            data-node-type={data.nodeTypeLabel ?? ''}
            style={{ width: containerWidth }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            {showQuickActions ? (
                <div className="base-node__quick-actions">
                    <button
                        type="button"
                        className="base-node__quick-btn"
                        data-cy="workflow-node-run"
                        onClick={(event) => {
                            event.stopPropagation();
                            data.onExecuteStep?.(data.nodeId);
                        }}
                        title="Execute Step"
                        aria-label={`Execute ${data.title}`}
                    >
                        <i className="pi pi-play" />
                    </button>
                    <button
                        type="button"
                        className="base-node__quick-btn"
                        data-cy="workflow-node-toggle"
                        onClick={(event) => {
                            event.stopPropagation();
                            data.onToggleEnabled?.(data.nodeId, !data.isEnabled);
                        }}
                        title={data.isEnabled ? 'Disable Node' : 'Enable Node'}
                        aria-label={`${data.isEnabled ? 'Disable' : 'Enable'} ${data.title}`}
                    >
                        <i className="pi pi-power-off" />
                    </button>
                    <button
                        type="button"
                        className="base-node__quick-btn"
                        data-cy="workflow-node-delete"
                        onClick={(event) => {
                            event.stopPropagation();
                            data.onDeleteNode?.(data.nodeId);
                        }}
                        title="Delete Node"
                        aria-label={`Delete ${data.title}`}
                    >
                        <i className="pi pi-trash" />
                    </button>
                    {data.onOpenAi ? (
                        <button
                            type="button"
                            className="base-node__quick-btn"
                            data-cy="workflow-node-ai"
                            onClick={(event) => {
                                event.stopPropagation();
                                data.onOpenAi?.(data.nodeId);
                            }}
                            title="AI Helper"
                            aria-label={`Open AI helper for ${data.title}`}
                        >
                            <i className="pi pi-sparkles" />
                        </button>
                    ) : null}
                    <button
                        type="button"
                        className="base-node__quick-btn"
                        data-cy="workflow-node-more"
                        onClick={(event) => {
                            event.stopPropagation();
                            moreMenuRef.current?.toggle(event);
                        }}
                        title="More Actions"
                        aria-label={`More actions for ${data.title}`}
                    >
                        <i className="pi pi-ellipsis-h" />
                    </button>
                    <Menu popup ref={moreMenuRef} model={moreMenuItems} />
                </div>
            ) : null}
            {commandPlacement.map(({ port, side, index, total }) => (
                <BaseNodeCommandPort key={`cmd-${port.id}`} port={port} side={side} index={index} total={total} />
            ))}
            {inputPlacement.map(({ port, side, index, total }) => (
                <BaseNodeDataPort key={`in-${port.id}`} direction="input" nodeId={data.nodeId} port={port} side={side} index={index} total={total} />
            ))}
            {outputPlacement.map(({ port, side, index, total }) => (
                <BaseNodeDataPort
                    key={`out-${port.id}`}
                    direction="output"
                    nodeId={data.nodeId}
                    port={port}
                    side={side}
                    index={index}
                    total={total}
                    outputConnections={data.outputConnectionCounts[port.id] ?? 0}
                    onQuickAddFromPort={data.onQuickAddFromPort}
                />
            ))}
            <div className="base-node__content">
                <div
                    className={`base-node__icon-shell ${data.render.containerClassName ?? ''}`}
                    style={{ width: nodeWidth, height: nodeHeight, ['--base-node-shell-tone' as string]: data.render.iconBackground ?? undefined }}
                >
                    <div
                        className="base-node__icon"
                        style={{
                            color: data.render.iconColor ?? undefined,
                            background: data.render.iconBackground ?? undefined
                        }}
                    >
                        {typeof renderedIcon === 'string' ? <span dangerouslySetInnerHTML={{ __html: renderedIcon }} /> : renderedIcon}
                        {!renderedIcon ? <i className={data.render.iconClass ?? 'pi pi-box'} style={{ fontSize: iconSize }} aria-hidden /> : null}
                    </div>
                    <div className="base-node__type-badge">{data.nodeTypeLabel ?? data.title}</div>
                    {showLocalProgress && <div className="base-node__loading-spinner" />}
                    {showServerProgress && (
                        <div className="base-node__server-running" aria-label="Server node running">
                            <i className="pi pi-bolt" />
                        </div>
                    )}
                    {showDone && (
                        <div className="base-node__done-badge">
                            <i className="pi pi-check" />
                        </div>
                    )}
                </div>
                <div className="base-node__name" style={{ maxWidth: containerWidth - 12 }}>
                    {data.title}
                </div>
            </div>
        </div>
    );
};

const areBaseNodePropsEqual = (previous: NodeProps<Node<BaseNodeData>>, next: NodeProps<Node<BaseNodeData>>): boolean => {
    return previous.selected === next.selected && previous.data.cacheKey === next.data.cacheKey;
};

const BaseNode = React.memo(BaseNodeComponent, areBaseNodePropsEqual);

export default BaseNode;
