import React, { useEffect, useMemo, useState } from 'react';
import { Tree } from 'primereact/tree';
import { TreeNode } from 'primereact/treenode';
import { formatWorkflowVariablePreviewValue } from '@workflow/ui/workflow/utils/workflow-variables.utils';

interface JsonViewerProps {
    value: unknown;
    draggableKeys?: boolean;
    rootPath?: string;
}

interface JsonTreeMeta {
    keyLabel: string;
    path: string;
    isKeyDraggable: boolean;
    valueClass?: string;
    valueLabel?: string;
    valuePreview?: string;
}

const isObjectRecord = (value: unknown): value is Record<string, unknown> => {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
};

const getValueClass = (value: unknown): string => {
    if (value === null) return 'wf-json-tree__value--null';
    if (typeof value === 'boolean') return 'wf-json-tree__value--boolean';
    if (typeof value === 'number') return 'wf-json-tree__value--number';
    if (typeof value === 'string') return 'wf-json-tree__value--string';
    return 'wf-json-tree__value--default';
};

const getValueLabel = (value: unknown): string => {
    if (typeof value === 'string') return `"${value}"`;
    if (typeof value === 'undefined') return 'undefined';
    return String(value);
};

const getValuePreview = (value: unknown): string => {
    const formatted = formatWorkflowVariablePreviewValue(value);
    if (formatted.length <= 240) return formatted;
    return `${formatted.slice(0, 237)}...`;
};

const getRuntimeObjectLabel = (value: unknown): string | null => {
    if (typeof Window !== 'undefined' && value instanceof Window) return '[Window]';
    if (typeof Document !== 'undefined' && value instanceof Document) return '[Document]';
    if (typeof Element !== 'undefined' && value instanceof Element) return `[${value.tagName.toLowerCase()}]`;
    if (typeof Event !== 'undefined' && value instanceof Event) return `[${value.type || 'event'} event]`;
    return null;
};

const buildTerminalNode = (nodeLabel: string, path: string, valueLabel: string): TreeNode => ({
    key: path,
    label: nodeLabel,
    data: {
        keyLabel: nodeLabel,
        path,
        isKeyDraggable: true,
        valueClass: 'wf-json-tree__value--default',
        valueLabel,
        valuePreview: valueLabel
    } satisfies JsonTreeMeta,
    leaf: true
});

const buildTreeNode = (value: unknown, nodeLabel: string, path: string, seen: WeakSet<object> = new WeakSet<object>()): TreeNode => {
    const runtimeObjectLabel = getRuntimeObjectLabel(value);
    if (runtimeObjectLabel) return buildTerminalNode(nodeLabel, path, runtimeObjectLabel);

    if (value && typeof value === 'object') {
        if (seen.has(value)) return buildTerminalNode(nodeLabel, path, '[Circular]');
        seen.add(value);
    }

    if (Array.isArray(value)) {
        const children = value.map((item, index) => buildTreeNode(item, `[${index}]`, `${path}[${index}]`, seen));
        seen.delete(value);
        return {
            key: path,
            label: nodeLabel,
            data: {
                keyLabel: nodeLabel,
                path,
                isKeyDraggable: true,
                valueLabel: `[${value.length}]`,
                valueClass: 'wf-json-tree__value--default',
                valuePreview: getValuePreview(value)
            } satisfies JsonTreeMeta,
            children
        };
    }

    if (isObjectRecord(value)) {
        const children = Object.entries(value).map(([childKey, childValue]) => buildTreeNode(childValue, childKey, `${path}.${childKey}`, seen));
        seen.delete(value);
        return {
            key: path,
            label: nodeLabel,
            data: {
                keyLabel: nodeLabel,
                path,
                isKeyDraggable: true,
                valueLabel: `{${Object.keys(value).length}}`,
                valueClass: 'wf-json-tree__value--default',
                valuePreview: getValuePreview(value)
            } satisfies JsonTreeMeta,
            children
        };
    }

    if (value && typeof value === 'object') seen.delete(value);
    return {
        key: path,
        label: nodeLabel,
        data: {
            keyLabel: nodeLabel,
            path,
            isKeyDraggable: true,
            valueClass: getValueClass(value),
            valueLabel: getValueLabel(value),
            valuePreview: getValuePreview(value)
        } satisfies JsonTreeMeta,
        leaf: true
    };
};

const collectExpandedKeys = (nodes: TreeNode[], depthLimit: number): Record<string, boolean> => {
    const expanded: Record<string, boolean> = {};
    const visit = (node: TreeNode, depth: number): void => {
        if (!node.children?.length || !node.key) {
            return;
        }
        if (depth <= depthLimit) {
            expanded[String(node.key)] = true;
        }
        node.children.forEach((child) => visit(child, depth + 1));
    };
    nodes.forEach((node) => visit(node, 0));
    return expanded;
};

const JsonViewer: React.FC<JsonViewerProps> = ({ value, draggableKeys = false, rootPath }) => {
    const nodes = useMemo<TreeNode[]>(() => {
        if (!rootPath && isObjectRecord(value)) {
            return Object.entries(value).map(([key, childValue]) => buildTreeNode(childValue, key, key));
        }
        const resolvedRootPath = rootPath || 'root';
        return [buildTreeNode(typeof value === 'undefined' ? null : value, resolvedRootPath, resolvedRootPath)];
    }, [rootPath, value]);
    const [expandedKeys, setExpandedKeys] = useState<Record<string, boolean>>({});

    useEffect(() => {
        setExpandedKeys(collectExpandedKeys(nodes, 2));
    }, [nodes]);

    return (
        <div className="wf-json-tree__wrapper">
            <Tree
                value={nodes}
                expandedKeys={expandedKeys}
                onToggle={(event) => setExpandedKeys(event.value as Record<string, boolean>)}
                className="wf-json-tree"
                nodeTemplate={(node) => {
                    const meta = (node.data || {}) as JsonTreeMeta;
                    return (
                        <div className="wf-json-tree__node">
                            <span
                                className={`wf-json-tree__key${draggableKeys && meta.isKeyDraggable ? ' wf-json-tree__key--draggable' : ''}`}
                                draggable={draggableKeys && meta.isKeyDraggable}
                                title={meta.valuePreview ? `Current value: ${meta.valuePreview}` : undefined}
                                onDragStart={(event) => {
                                    if (!draggableKeys || !meta.path) return;
                                    event.dataTransfer.setData('application/x-workflow-variable-path', meta.path);
                                    event.dataTransfer.setData('text/plain', `{{${meta.path}}}`);
                                    event.dataTransfer.effectAllowed = 'copy';
                                }}
                            >
                                {meta.keyLabel || node.label}
                            </span>
                            {meta.valueLabel && <span className={`wf-json-tree__value ${meta.valueClass || ''}`}>{meta.valueLabel}</span>}
                        </div>
                    );
                }}
            />
        </div>
    );
};

export default JsonViewer;
