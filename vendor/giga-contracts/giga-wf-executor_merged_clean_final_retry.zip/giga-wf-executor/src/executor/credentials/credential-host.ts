import type { WorkflowCredentialHostContext } from '../../types';

const toRecord = (value: unknown): Record<string, unknown> =>
    value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {};

const isCredentialHostContext = (value: unknown): value is WorkflowCredentialHostContext => {
    const record = toRecord(value);
    return typeof record.fetchCredentialById === 'function' || typeof record.recordCredentialExecutionResult === 'function';
};

export const getWorkflowCredentialHostContext = (hostContext: unknown): WorkflowCredentialHostContext | null => {
    if (isCredentialHostContext(hostContext)) {
        return hostContext;
    }

    const nested = toRecord(hostContext).credentials;
    if (isCredentialHostContext(nested)) {
        return nested;
    }

    return null;
};
