import React from 'react';
import type { WorkflowInspectorConfig } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowNodeFieldOption, WorkflowNodeFieldOptionsRequest } from '@workflow/ui/workflow/types';
import type { WorkspaceAsyncSelectorState } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface WorkspaceFieldOptionsState {
    status: WorkspaceAsyncSelectorState;
    options: WorkflowNodeFieldOption[];
    message?: string;
}

interface UseWorkspaceFieldOptionsArgs {
    visible: boolean;
    config: WorkflowInspectorConfig | null;
    propertiesEditorState: Record<string, unknown>;
    fetchNodeFieldOptions?: (request: WorkflowNodeFieldOptionsRequest) => Promise<WorkflowNodeFieldOption[]>;
}

const labelText = (value: unknown): string => String(value || 'options').trim().toLowerCase();

export const useWorkspaceFieldOptions = ({ visible, config, propertiesEditorState, fetchNodeFieldOptions }: UseWorkspaceFieldOptionsArgs): Record<string, WorkspaceFieldOptionsState> => {
    const [state, setState] = React.useState<Record<string, WorkspaceFieldOptionsState>>({});
    const fieldEntries = React.useMemo(
        () => Object.entries(config?.fields || {}).filter(([, definition]) => definition.type === 'select' && definition.multi === true && String(definition.optionsSource || '').trim()),
        [config?.fields]
    );
    const requestKey = React.useMemo(
        () => JSON.stringify({ nodeId: config?.nodeId || '', input: config?.input || {}, workflow: config?.workflow || {}, properties: propertiesEditorState }),
        [config?.input, config?.nodeId, config?.workflow, propertiesEditorState]
    );

    React.useEffect(() => {
        if (!visible || !fieldEntries.length) return setState({});
        if (!fetchNodeFieldOptions) {
            return setState(
                Object.fromEntries(fieldEntries.map(([fieldKey, definition]) => [fieldKey, { status: 'error', options: [], message: `The workflow host did not provide ${labelText(definition.label)} options.` }]))
            );
        }
        let cancelled = false;
        setState((previous) => Object.fromEntries(fieldEntries.map(([fieldKey]) => [fieldKey, { status: 'loading', options: previous[fieldKey]?.options || [] }])));
        void Promise.all(
            fieldEntries.map(async ([fieldKey, definition]) => ({
                fieldKey,
                definition,
                options: await fetchNodeFieldOptions({
                    modelId: config?.modelId || '',
                    fieldKey,
                    optionsSource: String(definition.optionsSource || '').trim() || null,
                    properties: propertiesEditorState,
                    workflowInput: config?.input || {},
                    workflowMetadata: (config?.workflow?.metadata as Record<string, unknown>) || null
                })
            }))
        ).then((results) => {
            if (cancelled) return;
            setState(
                Object.fromEntries(
                    results.map(({ fieldKey, definition, options }) => [
                        fieldKey,
                        options.length ? { status: 'ready', options } : { status: 'empty', options: [], message: `No ${labelText(definition.label)} are available in the current tree path.` }
                    ])
                )
            );
        }).catch((error) => {
            if (!cancelled) setState(Object.fromEntries(fieldEntries.map(([fieldKey]) => [fieldKey, { status: 'error', options: [], message: error instanceof Error ? error.message : 'Could not load options.' }])));
        });
        return () => {
            cancelled = true;
        };
    }, [config?.modelId, fieldEntries, fetchNodeFieldOptions, propertiesEditorState, requestKey, visible]);

    return state;
};
