import React from 'react';
import type { WorkspaceCredentialSelectorModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkflowServiceIcon } from '@workflow/ui/workflow/icons';
import { WorkspaceCredentialOptionRow } from '@workflow/ui/workflow/components/inspector/workspace/components/credentials/WorkspaceCredentialOptionRow';
import { WorkspaceCredentialState } from '@workflow/ui/workflow/components/inspector/workspace/components/credentials/WorkspaceCredentialState';

interface WorkspaceCredentialSelectorProps {
    model: WorkspaceCredentialSelectorModel;
    readOnly?: boolean;
    onChange: (credentialId: string | null) => void;
    onRefresh?: () => void;
    onAddCredential?: () => void;
}

export const WorkspaceCredentialSelector: React.FC<WorkspaceCredentialSelectorProps> = ({ model, readOnly = false, onChange, onRefresh, onAddCredential }) => {
    const [isOpen, setIsOpen] = React.useState<boolean>(false);
    const containerRef = React.useRef<HTMLDivElement | null>(null);
    const selectedOption = React.useMemo(
        () => model.options.find((option) => option.credentialId === model.selectedCredentialId) ?? null,
        [model.options, model.selectedCredentialId]
    );

    React.useEffect(() => {
        const handlePointerDown = (event: MouseEvent) => {
            if (!containerRef.current || containerRef.current.contains(event.target as Node)) {
                return;
            }
            setIsOpen(false);
        };
        document.addEventListener('mousedown', handlePointerDown);
        return () => document.removeEventListener('mousedown', handlePointerDown);
    }, []);

    React.useEffect(() => {
        if (model.state !== 'ready') {
            setIsOpen(false);
        }
    }, [model.state]);

    return (
        <div className="cnw-credential-selector" ref={containerRef}>
            <div className="cnw-credential-selector__header">
                <div>
                    <h4 className="cnw-subsection__title">{model.title}</h4>
                    {model.description ? <p className="cnw-section-block__description">{model.description}</p> : null}
                </div>
                <div className="cnw-credential-selector__actions">
                    {onRefresh ? (
                        <button type="button" className="cnw-credential-selector__clear" onClick={onRefresh} disabled={readOnly || model.state === 'loading'} aria-label="Refresh credentials">
                            Refresh
                        </button>
                    ) : null}
                    {selectedOption ? (
                        <button type="button" className="cnw-credential-selector__clear" onClick={() => onChange(null)} disabled={readOnly}>
                            Clear
                        </button>
                    ) : null}
                </div>
            </div>
            <WorkspaceCredentialState state={model.state} message={model.message} />
            {model.state === 'empty' && onAddCredential ? (
                <button type="button" className="cnw-credential-selector__empty-action" onClick={onAddCredential} disabled={readOnly}>
                    Add Credentials
                </button>
            ) : null}
            {model.state === 'ready' ? (
                <>
                    <button type="button" className={`cnw-credential-selector__trigger${isOpen ? ' cnw-credential-selector__trigger--open' : ''}`} onClick={() => setIsOpen((previous) => !previous)} disabled={readOnly}>
                        <span className="cnw-credential-selector__trigger-main">
                            <WorkflowServiceIcon serviceIcon={selectedOption?.serviceIcon ?? model.options[0]?.serviceIcon} serviceName={selectedOption?.serviceName ?? model.options[0]?.serviceName ?? model.serviceId} />
                            <span className="cnw-credential-selector__trigger-copy">
                                <strong>{selectedOption?.credentialName ?? 'Select a credential'}</strong>
                                <span>
                                    {selectedOption ? `${selectedOption.scopeTag} · ${selectedOption.credentialId}` : `Service ${model.serviceId}`}
                                </span>
                            </span>
                        </span>
                        <span className="cnw-credential-selector__trigger-caret">▾</span>
                    </button>
                    {isOpen ? (
                        <div className="cnw-credential-selector__menu">
                            {model.options.map((option) => (
                                <WorkspaceCredentialOptionRow
                                    key={option.credentialId}
                                    option={option}
                                    selected={option.credentialId === model.selectedCredentialId}
                                    onSelect={(credentialId) => {
                                        onChange(credentialId);
                                        setIsOpen(false);
                                    }}
                                />
                            ))}
                        </div>
                    ) : null}
                </>
            ) : null}
        </div>
    );
};
