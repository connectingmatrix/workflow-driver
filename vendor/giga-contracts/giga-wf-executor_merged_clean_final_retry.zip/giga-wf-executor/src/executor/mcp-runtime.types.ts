export type WorkflowMcpTransport = 'streamable-http' | 'sse' | 'ws' | 'stdio';

export interface WorkflowMcpServerRegistration {
    key: string;
    label?: string;
    url?: string;
    transport?: WorkflowMcpTransport;
    headers?: Record<string, string>;
    capabilities?: Record<string, unknown>;
    metadata?: Record<string, unknown>;
}

export interface WorkflowMcpCapabilityQueryInput {
    serverKey: string;
    query: string;
    workload?: unknown;
    includeServerMetadata?: boolean;
}

export interface WorkflowMcpCapabilityQueryResult {
    server?: WorkflowMcpServerRegistration;
    query: string;
    matchedCapabilities: Record<string, unknown>;
    workload: unknown;
    source: 'registered' | 'ephemeral';
}

export interface WorkflowMcpInitializeResult {
    server: WorkflowMcpServerRegistration;
    sessionId?: string;
    protocolVersion: string;
    serverInfo: Record<string, unknown>;
    capabilities: Record<string, unknown>;
}

export interface WorkflowMcpListToolsResult extends WorkflowMcpInitializeResult {
    tools: Record<string, unknown>[];
}

export interface WorkflowMcpCallToolResult extends WorkflowMcpListToolsResult {
    toolCall: {
        name: string;
        arguments: Record<string, unknown>;
    };
    toolResult: unknown;
}

export interface WorkflowMcpRuntimeManager {
    registerServer: (server: WorkflowMcpServerRegistration) => WorkflowMcpServerRegistration;
    removeServer: (serverKey: string) => boolean;
    getServer: (serverKey: string) => WorkflowMcpServerRegistration | undefined;
    listServers: () => WorkflowMcpServerRegistration[];
    queryCapabilities: (input: WorkflowMcpCapabilityQueryInput) => WorkflowMcpCapabilityQueryResult;
    resolveNodeServer: (runtime: Record<string, unknown>) => WorkflowMcpServerRegistration | undefined;
    initialize: (input: { serverKey?: string; server?: WorkflowMcpServerRegistration }) => Promise<WorkflowMcpInitializeResult>;
    listTools: (input: { serverKey?: string; server?: WorkflowMcpServerRegistration }) => Promise<WorkflowMcpListToolsResult>;
    callTool: (input: {
        serverKey?: string;
        server?: WorkflowMcpServerRegistration;
        toolName: string;
        toolArguments?: Record<string, unknown>;
    }) => Promise<WorkflowMcpCallToolResult>;
    resetSession: (serverKey: string) => void;
}

export interface WorkflowExecutorHostContext {
    mcp: WorkflowMcpRuntimeManager;
}
