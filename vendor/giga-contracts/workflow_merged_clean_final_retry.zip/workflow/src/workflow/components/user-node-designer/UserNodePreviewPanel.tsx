import React from 'react';
import { TabPanel, TabView } from 'primereact/tabview';
import UserNodePreviewDiagnosticsTab from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewDiagnosticsTab';
import UserNodePreviewLogsTab from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewLogsTab';
import UserNodePreviewOutputTab from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewOutputTab';
import UserNodePreviewStateTab from '@workflow/ui/workflow/components/user-node-designer/UserNodePreviewStateTab';
import { UserNodePreviewState } from '@workflow/ui/workflow/components/user-node-designer/useUserNodePreviewStore';

interface UserNodePreviewPanelProps {
    onClearLogs: () => void;
    state: UserNodePreviewState;
}

const UserNodePreviewPanel: React.FC<UserNodePreviewPanelProps> = ({ onClearLogs, state }) => {
    return (
        <div className="wf-user-node-preview-panel border-round border-1 surface-border p-2 h-full flex flex-column" data-cy="user-node-preview-panel">
            <div className="flex align-items-center justify-content-between mb-2">
                <span className="text-sm text-600" data-cy="user-node-preview-status">
                    Status: {state.status}
                </span>
                <span className="text-sm text-500" data-cy="user-node-preview-runtime">
                    Runtime: {state.effectiveRuntime ?? '-'}
                </span>
            </div>
            <TabView className="wf-user-node-preview-tabs">
                <TabPanel header="Output">
                    <UserNodePreviewOutputTab state={state} />
                </TabPanel>
                <TabPanel header="Logs">
                    <UserNodePreviewLogsTab logs={state.logs} onClearLogs={onClearLogs} />
                </TabPanel>
                <TabPanel header="State">
                    <UserNodePreviewStateTab state={state} />
                </TabPanel>
                <TabPanel header="Diagnostics">
                    <UserNodePreviewDiagnosticsTab state={state} />
                </TabPanel>
            </TabView>
        </div>
    );
};

export default UserNodePreviewPanel;
