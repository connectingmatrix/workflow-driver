import path from 'node:path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { workflowOptimizeDepsExclude, workflowResolveAliases, workflowResolveDedupe } from '../vite.shared';
import { workflowNodePreviewPlugin } from './server/node-preview-plugin';

export default defineConfig({
    root: path.resolve(__dirname),
    plugins: [react(), workflowNodePreviewPlugin()],
    server: {
        fs: {
            allow: [path.resolve(__dirname, '../..')]
        },
        host: '127.0.0.1',
        port: 4173
    },
    resolve: {
        dedupe: workflowResolveDedupe,
        alias: workflowResolveAliases
    },
    optimizeDeps: {
        exclude: workflowOptimizeDepsExclude
    }
});
