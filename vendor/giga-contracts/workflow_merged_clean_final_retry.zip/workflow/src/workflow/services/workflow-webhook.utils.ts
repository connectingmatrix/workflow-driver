import { WorkflowCatalogScope, WorkflowDefinition, WorkflowDerivedCapabilities, WorkflowWebhookRouteType } from '@workflow/ui/workflow/types';
import { isStartWorkflowModel } from '@workflow/ui/workflow/utils/workflow-model-id.utils';

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const toSafeString = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

export const deriveWorkflowCapabilities = (workflow: WorkflowDefinition | null | undefined): WorkflowDerivedCapabilities => {
    const startNode = workflow?.nodes.find((node) => isStartWorkflowModel(node.modelId)) ?? null;
    const runtime = toRecord(startNode?.runtime);
    const triggerSource = toSafeString(runtime.triggerSource).toLowerCase();
    const webhookMethod = toSafeString(runtime.webhookMethod).toUpperCase();

    return {
        isWebhookBased: triggerSource === 'webhook',
        webhookMethod: webhookMethod === 'GET' || webhookMethod === 'POST' ? webhookMethod : null
    };
};

export const buildWorkflowSummary = (workflow: WorkflowDefinition | null | undefined): string => {
    if (!workflow) {
        return 'No workflow summary is available yet.';
    }

    const parts = [
        workflow.metadata?.description,
        workflow.nodes
            .slice(0, 4)
            .map((node) => node.name || node.modelId)
            .join(', ')
    ]
        .map((value) => toSafeString(value))
        .filter(Boolean);

    if (!parts.length) {
        return `Contains ${workflow.nodes.length} node${workflow.nodes.length === 1 ? '' : 's'}.`;
    }

    return parts.join(' ');
};

export const buildWorkflowWebhookCurl = (params: { method: 'GET' | 'POST' | null; routeType: WorkflowWebhookRouteType; secret?: string | null; testUrl?: string | null; publishedUrl?: string | null }): string => {
    const url = params.routeType === 'published' ? params.publishedUrl : params.testUrl;
    const method = params.method || 'POST';
    const lines = [`curl -X ${method} "${url || ''}"`, '  -H "Content-Type: application/json"'];
    if (params.routeType === 'published' && params.secret) {
        lines.push(`  -H "x-workflow-secret: ${params.secret}"`);
    }
    if (method !== 'GET') {
        lines.push(`  -d '{"message":"hello"}'`);
    }
    return lines.join(' \\\n');
};

export const resolveWorkflowScopeLabel = (scope: WorkflowCatalogScope): string => (scope === 'global' ? 'Global' : 'User');
