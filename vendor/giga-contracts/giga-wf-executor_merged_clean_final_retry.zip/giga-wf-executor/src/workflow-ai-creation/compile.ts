import { randomUUID } from 'node:crypto';
import type { WorkflowDefinition, WorkflowNodeSchema } from '../types';
import { parseWorkflowCypher } from './parse';
import { workflowNodeById } from './files';
import { buildWorkflowNode } from './node-build';
import { buildWorkflowConnection } from './connections';
import { attachWorkflowExecutors } from './executors';
import { validateExecutableGraph } from './graph-rules';
import { layoutWorkflowGraph } from './layout';
import { validateRuntimePayloads } from './runtime-rules';
import { WorkflowCypherCompileResult } from './types';

function workflowMetadata(name: string, input: any) {
  return {
    id: input.id || randomUUID(),
    name,
    chatId: input.chat_id || null,
    message: input.message || null,
    createdAt: new Date().toISOString(),
  };
}

function usedSchemas(modelIds: string[]) {
  const byId = workflowNodeById();
  return Array.from(new Set(modelIds)).reduce<Record<string, WorkflowNodeSchema>>((acc, modelId) => {
    const source = byId[modelId];
    if (!source) throw new Error(`Unknown node model "${modelId}" in workflow cypher.`);
    acc[modelId] = source.schema;
    return acc;
  }, {});
}

function terminalNodeIds(workflow: WorkflowDefinition) {
  return workflow.nodes.filter((node) => node.modelId === 'respond-end').map((node) => node.id);
}

const RESERVED_BINDINGS = new Set(['workflow', 'input', 'variables', 'request', 'metadata', 'runtime']);

function replaceAliasBindings(value: unknown, ids: Record<string, string>): unknown {
  if (typeof value === 'string') {
    return value.replace(/\{\{\s*([A-Za-z][\w-]*)([^}]*)\s*\}\}/g, (match, alias, path) => {
      if (RESERVED_BINDINGS.has(alias) || !ids[alias]) return match;
      return `{{${ids[alias]}${String(path || '').trim()}}}`;
    });
  }
  if (Array.isArray(value)) return value.map((entry) => replaceAliasBindings(entry, ids));
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, replaceAliasBindings(entry, ids)]));
}

function bindRuntimeAliases(workflow: WorkflowDefinition, ids: Record<string, string>) {
  return {
    ...workflow,
    nodes: workflow.nodes.map((node) => {
      const runtime = replaceAliasBindings(node.runtime || {}, ids) as Record<string, unknown>;
      const inspector = (node as any).inspector || {};
      return {
        ...node,
        runtime,
        properties: runtime,
        inspector: { ...inspector, properties: runtime }
      };
    })
  };
}

export function compileWorkflowCypher(input: {
  cypher: string;
  name?: string;
  description?: string;
  executable?: boolean;
  metadata?: Record<string, unknown>;
}): WorkflowCypherCompileResult {
  const graph = parseWorkflowCypher(input.cypher);
  const schemas = usedSchemas(graph.nodes.map((node) => node.modelId));
  const ids: Record<string, string> = {};
  let workflow: WorkflowDefinition = {
    metadata: { ...workflowMetadata(input.name || 'Workflow', input.metadata || {}), description: input.description || '' },
    nodeModels: schemas,
    nodes: [],
    connections: [],
  };
  graph.nodes.forEach((spec, index) => {
    const node = buildWorkflowNode(spec, schemas[spec.modelId], index + 1);
    ids[spec.alias] = node.id;
    workflow.nodes.push(node);
  });
  workflow = bindRuntimeAliases(workflow, ids);
  graph.edges.forEach((edge, index) => {
    const connection = buildWorkflowConnection({ edge, workflow, schemas, ids, index });
    workflow = { ...workflow, connections: [...workflow.connections, connection] };
  });
  workflow = layoutWorkflowGraph(workflow);
  workflow = attachWorkflowExecutors(workflow);
  const errors = [...validateRuntimePayloads(graph, schemas), ...validateExecutableGraph(workflow, input.executable !== false)];
  const warnings: string[] = [];
  return {
    workflow,
    graph,
    warnings,
    validation: {
      ok: errors.length === 0,
      errors,
      warnings,
      node_ids: workflow.nodes.map((node) => node.id),
      connection_count: workflow.connections.length,
      terminal_node_ids: terminalNodeIds(workflow),
    },
  };
}
