import { createHash } from 'node:crypto';
import type { WorkflowDefinition } from '../types';
import { workflowNodeById } from './files';

function signature(modelId: string, source: string) {
  let hash = 5381;
  const input = `${modelId}:${source}`;
  for (let index = 0; index < input.length; index += 1) hash = ((hash << 5) + hash) ^ input.charCodeAt(index);
  return `wf-sign-v1-${(hash >>> 0).toString(16)}`;
}

function sha(source: string) {
  return createHash('sha256').update(source).digest('hex').slice(0, 16);
}

export function attachWorkflowExecutors(workflow: WorkflowDefinition) {
  const byId = workflowNodeById();
  const modelIds = Array.from(new Set((workflow.nodes || []).map((node) => node.modelId).filter(Boolean)));
  const NODE_EXECUTORS: Record<string, string> = {};
  const NODE_EXECUTOR_SIGNATURES: Record<string, string> = {};
  const NODE_SOURCE_FILES: Record<string, string> = {};
  const worker_hashes: Record<string, string> = {};
  for (const modelId of modelIds) {
    const source = byId[modelId];
    const worker = source?.worker || '';
    if (!worker.trim()) continue;
    NODE_EXECUTORS[modelId] = Buffer.from(worker, 'utf8').toString('base64');
    NODE_EXECUTOR_SIGNATURES[modelId] = signature(modelId, worker);
    if (source?.sourceFiles && Object.keys(source.sourceFiles).length) {
      NODE_SOURCE_FILES[modelId] = Buffer.from(JSON.stringify(source.sourceFiles), 'utf8').toString('base64');
    }
    worker_hashes[modelId] = sha(worker);
  }
  return {
    ...workflow,
    NODE_EXECUTORS,
    NODE_EXECUTOR_SIGNATURES,
    NODE_SOURCE_FILES,
    metadata: {
      ...workflow.metadata,
      worker_hashes,
    },
  };
}
