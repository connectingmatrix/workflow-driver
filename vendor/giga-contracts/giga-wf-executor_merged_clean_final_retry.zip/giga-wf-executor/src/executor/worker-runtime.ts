import {
    WorkerExecuteHelpers,
    WorkerRuntimeEnvironment,
    WorkerRuntimeEnvironmentEnum,
    WorkflowNodeHandler
} from '../types';
import { createBrowserWorkerNodeHandler } from './browser/browser-runtime';
import { TypeScriptModuleLoader, createNodeExecutorSignature } from './core/compiler/typescript-compiler';
import { resolveNodeCredentialBinding } from './credentials/resolve-node-credential';
import { recordNodeCredentialExecutionResult } from './credentials/report-credential-execution';
import { toErrorResult } from './core/compiler/worker-module-loader';

export {
    normalizeResult,
    toErrorResult,
    toNode,
    toRecord
} from './core/compiler/worker-module-loader';
export { createNodeExecutorSignature } from './core/compiler/typescript-compiler';
export type { TypeScriptModuleLoader } from './core/compiler/typescript-compiler';

export interface WorkerNodeHandlerFactoryArgs {
    modelId: string;
    executeHelpers?: WorkerExecuteHelpers;
    runtimeEnvironment?: WorkerRuntimeEnvironment;
    typescriptModuleLoader?: TypeScriptModuleLoader;
}

export const createWorkerNodeHandler = (args: WorkerNodeHandlerFactoryArgs): WorkflowNodeHandler => {
    const runtimeEnvironment = args.runtimeEnvironment ?? WorkerRuntimeEnvironmentEnum.Node;

    if (runtimeEnvironment === WorkerRuntimeEnvironmentEnum.Browser) {
        return createBrowserWorkerNodeHandler({
            modelId: args.modelId,
            executeHelpers: args.executeHelpers,
            typescriptModuleLoader: args.typescriptModuleLoader
        });
    }

    let nodeHandlerPromise: Promise<WorkflowNodeHandler> | null = null;
    const loadNodeHandler = async (): Promise<WorkflowNodeHandler> => {
        if (!nodeHandlerPromise) {
            nodeHandlerPromise = import(
                /* @vite-ignore */
                './node/node-runtime'
            ).then((module) =>
                module.createNodeWorkerNodeHandler({
                    modelId: args.modelId,
                    executeHelpers: args.executeHelpers,
                    typescriptModuleLoader: args.typescriptModuleLoader
                })
            );
        }
        return nodeHandlerPromise;
    };

    return async (context) => {
        const credentialBinding = await resolveNodeCredentialBinding(context);
        if (credentialBinding.error) {
            const result = toErrorResult(credentialBinding.error);
            await recordNodeCredentialExecutionResult({
                credentialId: credentialBinding.credentialId,
                host: credentialBinding.host,
                result
            });
            return result;
        }

        const nodeHandler = await loadNodeHandler();
        const result = await nodeHandler({
            ...context,
            credential: credentialBinding.credential
        });
        await recordNodeCredentialExecutionResult({
            credentialId: credentialBinding.credentialId,
            host: credentialBinding.host,
            result
        });
        return result;
    };
};
