import React from 'react';
import type { WorkspaceParametersPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import { WorkspacePanelFrame } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspacePanelFrame';
import { WorkspaceSegmentedTabs } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceSegmentedTabs';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { WorkspaceInstructionTabs } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceInstructionTabs';
import { WorkspaceParametersSection } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceParametersSection';
import { WorkspaceCredentialSelector } from '@workflow/ui/workflow/components/inspector/workspace/components/credentials/WorkspaceCredentialSelector';
import { WorkspaceWorkflowSelector } from '@workflow/ui/workflow/components/inspector/workspace/components/workflows/WorkspaceWorkflowSelector';

interface WorkspaceParametersPanelProps {
    model: WorkspaceParametersPanelModel;
    readOnly?: boolean;
    showParametersHero: boolean;
    showBestPracticeHints: boolean;
    propertiesEditorState: Record<string, unknown>;
    onTabChange: (tabId: string) => void;
    onInstructionTabChange: (tabId: string) => void;
    onFieldChange: (fieldKey: string, value: unknown) => void;
    onCodeChange: (nextCode: string) => void;
    onMarkdownChange: (nextMarkdown: string) => void;
    onAction: (actionId: string) => void;
    onRefreshCredentialOptions?: () => void;
    onOpenCredentialManager?: () => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    inspectorColumns?: number;
    code: string;
    markdown: string;
}

export const WorkspaceParametersPanel: React.FC<WorkspaceParametersPanelProps> = ({
    model,
    readOnly = false,
    showParametersHero,
    showBestPracticeHints,
    propertiesEditorState,
    onTabChange,
    onInstructionTabChange,
    onFieldChange,
    onCodeChange,
    onMarkdownChange,
    onAction,
    onRefreshCredentialOptions,
    onOpenCredentialManager,
    variableContext,
    variableSuggestions,
    inspectorColumns,
    code,
    markdown
}) => {
    const allFields = React.useMemo(() => model.sections.flatMap((section) => section.fields), [model.sections]);

    return (
        <WorkspacePanelFrame panelClassName="cnw-panel--parameters" bodyClassName="cnw-panel__body--parameters" title={model.title} description={model.description} icon={model.icon} accent headerAction={model.headerAction} onAction={onAction}>
            <div className="cnw-parameters-panel">
                <WorkspaceSegmentedTabs items={model.tabs} activeId={model.activeTab} onChange={onTabChange} />

                <div className="cnw-parameters-panel__scroll">
                    {model.activeTab === 'instruction' && model.instructionPanel ? (
                        <WorkspaceInstructionTabs
                            model={model.instructionPanel}
                            code={code}
                            markdown={markdown}
                            readOnly={readOnly}
                            onTabChange={onInstructionTabChange}
                            onCodeChange={onCodeChange}
                            onMarkdownChange={onMarkdownChange}
                            variableContext={variableContext}
                            variableSuggestions={variableSuggestions}
                        />
                    ) : (
                        <>
                            {showParametersHero && model.heroCard ? (
                                <div className="cnw-hero-card">
                                    <div className="cnw-hero-card__icon-wrap">
                                        <WorkspaceGlyph name={model.heroCard.icon ?? 'play'} className="cnw-hero-card__icon" />
                                    </div>
                                    <div className="cnw-hero-card__content">
                                        <h4 className="cnw-hero-card__title">{model.heroCard.title}</h4>
                                        {model.heroCard.description ? <p className="cnw-hero-card__description">{model.heroCard.description}</p> : null}
                                    </div>
                                    {model.heroCard.chip ? <span className="cnw-hero-card__chip">{model.heroCard.chip}</span> : null}
                                </div>
                            ) : null}

                            {model.credentialSelector ? (
                                <WorkspaceCredentialSelector
                                    model={model.credentialSelector}
                                    readOnly={readOnly}
                                    onChange={(credentialId) => onFieldChange('credentialId', credentialId)}
                                    onRefresh={onRefreshCredentialOptions}
                                    onAddCredential={onOpenCredentialManager}
                                />
                            ) : null}
                            {model.workflowSelector ? (
                                <WorkspaceWorkflowSelector
                                    model={model.workflowSelector}
                                    readOnly={readOnly}
                                    onChange={(workflow) => {
                                        onFieldChange('workflowId', workflow?.workflowId ?? null);
                                        onFieldChange('workflowName', workflow?.workflowName ?? '');
                                        onFieldChange('workflowScope', workflow?.scope ?? '');
                                    }}
                                />
                            ) : null}

                            <div className="cnw-sections">
                                {model.sections.map((section) => (
                                    <WorkspaceParametersSection
                                        key={section.id}
                                        section={section}
                                        allFields={allFields}
                                        readOnly={readOnly}
                                        propertiesEditorState={propertiesEditorState}
                                        onFieldChange={onFieldChange}
                                        variableContext={variableContext}
                                        variableSuggestions={variableSuggestions}
                                        inspectorColumns={inspectorColumns}
                                    />
                                ))}
                            </div>

                            {showBestPracticeHints && model.hints?.length ? (
                                <div className="cnw-hints-card">
                                    <h4 className="cnw-subsection__title">Best-practice hints</h4>
                                    <ul className="cnw-hints-list">
                                        {model.hints.map((hint) => (
                                            <li key={hint.id} className="cnw-hints-list__item">
                                                <span className="cnw-hints-list__bullet" />
                                                <div>
                                                    <strong>{hint.title}</strong>
                                                    {hint.description ? <span> {hint.description}</span> : null}
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ) : null}
                        </>
                    )}
                </div>

            </div>
        </WorkspacePanelFrame>
    );
};
