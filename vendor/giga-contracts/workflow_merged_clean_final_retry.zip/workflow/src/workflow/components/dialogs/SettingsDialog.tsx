import React from 'react';
import type { SettingsDialogProps } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';
import WorkflowSettingsDialog from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsDialog';

const SettingsDialog: React.FC<SettingsDialogProps> = (props) => <WorkflowSettingsDialog {...props} />;

export type { SettingsDialogProps };
export type { WorkflowSettingsDialogSavePayload } from '@workflow/ui/workflow/components/dialogs/settings-dialog.types';
export default SettingsDialog;
