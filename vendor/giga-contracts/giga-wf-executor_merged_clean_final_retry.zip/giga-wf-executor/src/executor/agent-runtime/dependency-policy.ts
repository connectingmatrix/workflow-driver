export type DynamicDependencyPolicyInput = {
  allowInstall?: boolean;
  allowedPackages?: string[];
  dependencies?: string[];
};

export type DynamicDependencyPolicyResult = {
  ok: boolean;
  allowed: string[];
  denied: Array<{ dependency: string; reason: string }>;
};

const packagePattern = /^(?:@[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*|[a-z0-9][a-z0-9._-]*)(?:@[a-z0-9._~^<>=*+-]+)?$/i;

const baseName = (spec: string): string => {
  const trimmed = String(spec || '').trim();
  if (trimmed.startsWith('@')) {
    const parts = trimmed.split('/');
    return `${parts[0]}/${String(parts[1] || '').split('@')[0]}`;
  }
  return trimmed.split('@')[0];
};

const envList = (value: string | undefined): string[] => String(value || '').split(',').map((item) => item.trim()).filter(Boolean);

export const readDynamicDependencyPolicyFromEnv = (): DynamicDependencyPolicyInput => ({
  allowInstall: process.env.WF_DYNAMIC_NODE_ALLOW_PACKAGE_INSTALL === '1',
  allowedPackages: envList(process.env.WF_DYNAMIC_NODE_ALLOWED_PACKAGES),
});

export const validateDynamicDependencies = (input: DynamicDependencyPolicyInput): DynamicDependencyPolicyResult => {
  const dependencies = Array.from(new Set((input.dependencies || []).map((item) => String(item || '').trim()).filter(Boolean)));
  const allowedPackageNames = new Set((input.allowedPackages || []).map(baseName));
  const result: DynamicDependencyPolicyResult = { ok: true, allowed: [], denied: [] };

  for (const dependency of dependencies) {
    if (!packagePattern.test(dependency) || dependency.includes('..') || /^(?:file|git|https?|ssh):/i.test(dependency)) {
      result.denied.push({ dependency, reason: 'Dependency must be a simple npm package spec, not a URL, git reference, or local file.' });
      continue;
    }
    if (!input.allowInstall) {
      result.denied.push({ dependency, reason: 'Dynamic dependency installation is disabled. Set WF_DYNAMIC_NODE_ALLOW_PACKAGE_INSTALL=1 to enable the allowlist path.' });
      continue;
    }
    if (!allowedPackageNames.has(baseName(dependency))) {
      result.denied.push({ dependency, reason: `Package ${baseName(dependency)} is not in WF_DYNAMIC_NODE_ALLOWED_PACKAGES.` });
      continue;
    }
    result.allowed.push(dependency);
  }

  result.ok = result.denied.length === 0;
  return result;
};

export const packageAllowed = (dependency: string): boolean => validateDynamicDependencies({ ...readDynamicDependencyPolicyFromEnv(), dependencies: [dependency] }).ok;
