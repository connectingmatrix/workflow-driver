import type { WorkflowConnectionModel, WorkflowDefinition } from '../types';

export type WorkflowLayoutGraph = {
  nodeIds: string[];
  orderById: Record<string, number>;
  dataLinks: WorkflowConnectionModel[];
  commandLinks: WorkflowConnectionModel[];
  parentsById: Record<string, string[]>;
  childrenById: Record<string, string[]>;
  mainNodeIds: string[];
  commandNodeIds: string[];
  roots: string[];
};

const commandLink = (link: WorkflowConnectionModel) => String(link.sourceHandle || '').startsWith('cmd:') && String(link.targetHandle || '').startsWith('cmd:');
const append = (record: Record<string, string[]>, key: string, value: string) => {
  record[key] = [...(record[key] || []), value];
};

export function readLayoutGraph(workflow: WorkflowDefinition): WorkflowLayoutGraph {
  const nodeIds = (workflow.nodes || []).map((node) => node.id);
  const orderById = nodeIds.reduce<Record<string, number>>((record, nodeId, index) => ({ ...record, [nodeId]: index }), {});
  const dataLinks = (workflow.connections || []).filter((link) => !commandLink(link));
  const commandLinks = (workflow.connections || []).filter(commandLink);
  const parentsById: Record<string, string[]> = {};
  const childrenById: Record<string, string[]> = {};

  dataLinks.forEach((link) => {
    append(childrenById, link.from, link.to);
    append(parentsById, link.to, link.from);
  });

  const dataIds = new Set(dataLinks.flatMap((link) => [link.from, link.to]));
  const commandOnlyIds = new Set(
    nodeIds.filter((nodeId) => commandLinks.some((link) => link.from === nodeId || link.to === nodeId)).filter((nodeId) => !dataIds.has(nodeId)),
  );
  const mainNodeIds = nodeIds.filter((nodeId) => !commandOnlyIds.has(nodeId));
  const roots = mainNodeIds.filter((nodeId) => !(parentsById[nodeId] || []).length);

  return {
    nodeIds,
    orderById,
    dataLinks,
    commandLinks,
    parentsById,
    childrenById,
    mainNodeIds,
    commandNodeIds: [...commandOnlyIds],
    roots: roots.length ? roots : mainNodeIds.slice(0, 1),
  };
}
