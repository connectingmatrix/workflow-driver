/// <reference types="cypress" />
import { closeNodeInspector, openNodeInspector } from '../../support/inspector';

const NODE_NAMES = ['Start 1', 'Code 1', 'Output Format 1', 'OpenAI 1', 'Claude 1', 'AI Governor 1', 'Respond / End 1'];

describe('workspace inspector gallery', () => {
    it('captures every node inspector for visual review', () => {
        cy.visit('/?scenario=gallery');

        cy.wrap(NODE_NAMES).each((nodeName) => {
            openNodeInspector(String(nodeName));
            cy.contains('.cnw-header__title', String(nodeName)).should('be.visible');
            cy.screenshot(`workspace-gallery-${String(nodeName).toLowerCase().replace(/[^a-z0-9]+/g, '-')}`, { capture: 'viewport' });
            closeNodeInspector();
        });
    });
});
