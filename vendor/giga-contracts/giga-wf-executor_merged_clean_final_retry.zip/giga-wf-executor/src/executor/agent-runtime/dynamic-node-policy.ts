export type DynamicNodeSourcePolicyViolation = {
  code: string;
  message: string;
  path?: string;
};

const deniedPatterns: Array<{ code: string; pattern: RegExp; message: string }> = [
  { code: 'child_process', pattern: /\bchild_process\b|\bexecSync\b|\bspawnSync\b|\bspawn\s*\(/i, message: 'child_process is not allowed in dynamic workflow nodes.' },
  { code: 'eval', pattern: /\beval\s*\(|\bnew\s+Function\s*\(/i, message: 'eval/new Function is not allowed in dynamic workflow nodes.' },
  { code: 'raw_env', pattern: /\bprocess\.env\b/i, message: 'Use credential bindings instead of process.env in dynamic workflow nodes.' },
  { code: 'package_install', pattern: /\bnpm\s+i\b|\byarn\s+add\b|\bpnpm\s+add\b|\bbun\s+add\b/i, message: 'Package installation during execution is not allowed.' },
  { code: 'raw_fs', pattern: /from\s+['"]node:fs['"]|require\(['"]fs['"]\)|require\(['"]node:fs['"]\)/i, message: 'Raw filesystem access is not allowed.' },
  { code: 'raw_net', pattern: /from\s+['"]node:(net|tls|http|https|dgram)['"]|require\(['"](net|tls|http|https|dgram)['"]\)/i, message: 'Raw network/socket access is not allowed.' },
  { code: 'nested_vm', pattern: /from\s+['"]node:vm['"]|require\(['"]vm['"]\)|require\(['"]node:vm['"]\)/i, message: 'Nested VM creation is not allowed.' },
];

export const validateDynamicNodeSourcePolicy = (sourceFiles: Record<string, string>): DynamicNodeSourcePolicyViolation[] => {
  const violations: DynamicNodeSourcePolicyViolation[] = [];
  for (const [path, source] of Object.entries(sourceFiles)) {
    if (!path || path.includes('..')) violations.push({ code: 'invalid_path', message: `Invalid source path: ${path}`, path });
    for (const denied of deniedPatterns) if (denied.pattern.test(source)) violations.push({ code: denied.code, message: denied.message, path });
  }
  return violations;
};

export const assertDynamicNodeSourcePolicy = (sourceFiles: Record<string, string>) => {
  const violation = validateDynamicNodeSourcePolicy(sourceFiles)[0];
  if (violation) throw new Error(violation.message);
};
