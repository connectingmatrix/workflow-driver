# Workflow Execution Pubsub Contracts

## Folder Purpose

- Own queue event runtime consumer/producer orchestration for queued workflow execution.
- Preserve event ordering and terminal completion signaling for executor state.

## Core Contracts

- Event names:
  - `workflow:running`
  - `workflow:running:result`
  - `workflow:running:stop`
  - `workflow:running:stopped`
  - runtime event streams consumed from queue `eventsTopic`.
- `consumeWorkflowExecutionEvents` consumes `WorkflowQueueEvent` from Kafka and applies each parsed event via `applyExecutionEvent`.
- `runWorkflowExecutionQueue` creates a request consumer that parses `WorkflowQueueRequest` and schedules execution jobs.

## Wiring Rules

- `consumeWorkflowExecutionEventsRuntime` must:
  - parse `message.value` with `parseWorkflowQueueEvent`
  - ignore null/invalid payloads
  - forward parsed events to `applyExecutionEvent`.
- `runWorkflowExecutionQueueRuntime` path must publish `WorkflowQueueEvent` through `eventPublisher.publish` for:
  - `started`, `log`, `completed`, and `failed`.
- Terminal event handling must call completion resolver in `signalLocalTerminalCompletion` for `completed` and `failed`.

## Local Rules

- Do not route queue events through alternate pubsub message types.
- Keep consumer options surface (`config`, `consumer`, `eventsTopic`) explicit and typed.

## Validation

- Update/extend runtime consumer tests whenever event parsing/application behavior changes.
