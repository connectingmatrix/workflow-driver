import { describe, expect, it, vi } from 'vitest';
import { workflowExecutor } from '@workflow/ui/workflow/executor/runtime';
import { WorkflowAuthModeEnum, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

const settings = {
    graphqlUrl: 'http://localhost/graphql',
    authMode: WorkflowAuthModeEnum.None,
    manualHeaders: {}
};

const syncNodeRuntimeState = (node: ReturnType<typeof createWorkflowNode>, runtime: Record<string, unknown>) => {
    node.runtime = runtime;
    node.properties = runtime;
    node.inspector = {
        ...node.inspector,
        properties: runtime
    };
};

describe('executeNodeStep', () => {
    it('executes single node step and updates only that node', async () => {
        const workflow = createEmptyWorkflow('wf_step');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const metadataNode = createWorkflowNode(workflow, 'metadata', 'Meta', 3);
        workflow.nodes = [startNode, codeNode, metadataNode];
        workflow.connections = [createConnection('c1', startNode.id, codeNode.id), createConnection('c2', codeNode.id, metadataNode.id)];

        const result = await workflowExecutor.executeNodeStep({
            workflow,
            nodeId: codeNode.id,
            settings,
            overrides: {
                properties: { ...(codeNode.runtime ?? {}), description: 'Updated by test' },
                code: 'console.log("step executed"); return { ok: true, draftApplied: properties.description === "Updated by test" };',
                markdown: ''
            }
        });

        const updatedCodeNode = result.workflow.nodes.find((node) => node.id === codeNode.id);
        const untouchedMetadataNode = result.workflow.nodes.find((node) => node.id === metadataNode.id);
        expect(updatedCodeNode?.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(updatedCodeNode?.ports.out.output).toEqual({ ok: true, draftApplied: true });
        expect(untouchedMetadataNode?.status).toBe(WorkflowNodeStatusEnum.Stopped);
        expect(result.result.logs).toContain('step executed');
    }, 15000);

    it('returns failed status when node execution throws error', async () => {
        const workflow = createEmptyWorkflow('wf_step_failed');
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 1);
        workflow.nodes = [codeNode];

        const result = await workflowExecutor.executeNodeStep({
            workflow,
            nodeId: codeNode.id,
            settings,
            overrides: {
                properties: codeNode.runtime ?? {},
                code: 'throw new Error("Runtime exploded");',
                markdown: ''
            }
        });

        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect((result.result.output as { error?: string })?.error).toContain('Runtime exploded');
    });

    it('fails validation before step execution and does not run node handler', async () => {
        const workflow = createEmptyWorkflow('wf_step_validation_fail');
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 1);
        codeNode.id = '';
        codeNode.runtime = {
            ...(codeNode.runtime ?? {}),
            failureMitigation: 'retry-node',
            retryCount: '0'
        };
        workflow.nodes = [codeNode];

        const result = await workflowExecutor.executeNodeStep({
            workflow,
            nodeId: codeNode.id,
            settings
        });

        expect(result.node.status).toBe(WorkflowNodeStatusEnum.Failed);
        expect(result.result.status).toBe(WorkflowNodeStatusEnum.Failed);
    });

    it('passes runtime payloads through to remote step execution without ui-side normalization', async () => {
        const cases: Array<{
            modelId: 'serp-search' | 'run-chat-action' | 'run-subject-action';
            title: string;
            runtime: Record<string, unknown>;
            assertRuntime: (runtime: Record<string, unknown>) => void;
        }> = [
            {
                modelId: 'serp-search',
                title: 'Serp Search',
                runtime: {
                    description: 'test',
                    payload: {
                        query: 'latest ai agent benchmarks',
                        max_results: 4,
                        location: 'United States',
                        language: 'en'
                    }
                },
                assertRuntime: (runtime) => {
                    expect((runtime.payload as Record<string, unknown>)?.query).toBe('latest ai agent benchmarks');
                    expect((runtime.payload as Record<string, unknown>)?.max_results).toBe(4);
                    expect((runtime.payload as Record<string, unknown>)?.location).toBe('United States');
                    expect((runtime.payload as Record<string, unknown>)?.language).toBe('en');
                }
            },
            {
                modelId: 'run-chat-action',
                title: 'Chat',
                runtime: {
                    description: 'test',
                    action: 'search_cross_subject_knowledge',
                    chatId: 'chat_explicit',
                    message: 'Search related knowledge for this thread',
                    parameters: {
                        query: 'workflow-native chat parity',
                        top_k: 8
                    },
                    payload: {
                        chatId: 'chat_legacy',
                        max_messages: 12
                    }
                },
                assertRuntime: (runtime) => {
                    expect(runtime.action).toBe('search_cross_subject_knowledge');
                    expect(runtime.chatId).toBe('chat_explicit');
                    expect(runtime.message).toBe('Search related knowledge for this thread');
                    expect((runtime.parameters as Record<string, unknown>)?.query).toBe('workflow-native chat parity');
                    expect((runtime.payload as Record<string, unknown>)?.chatId).toBe('chat_legacy');
                }
            },
            {
                modelId: 'run-subject-action',
                title: 'Subject',
                runtime: {
                    description: 'test',
                    action: 'update_subject',
                    subjectIds: ['subject_1'],
                    parameters: {
                        subject_id: 'subject_1',
                        metadata: {
                            agent_references: {
                                links: [{ url: 'https://example.com', title: 'Example' }]
                            }
                        }
                    }
                },
                assertRuntime: (runtime) => {
                    expect(runtime.action).toBe('update_subject');
                    expect(runtime.subjectIds).toEqual(['subject_1']);
                    expect((runtime.parameters as Record<string, unknown>)?.subject_id).toBe('subject_1');
                }
            }
        ];

        for (const scenario of cases) {
            const workflow = createEmptyWorkflow(`wf_remote_${scenario.modelId}`);
            const node = createWorkflowNode(workflow, scenario.modelId, scenario.title, 1);
            syncNodeRuntimeState(node, scenario.runtime);
            workflow.nodes = [node];

            const executeNodeRemotely = vi.fn(async ({ workflow: remoteWorkflow, nodeId }: any) => {
                const remoteNode = remoteWorkflow.nodes.find((item: any) => item.id === nodeId);
                return {
                    workflow: remoteWorkflow,
                    node: remoteNode,
                    result: {
                        output: { ok: true, modelId: scenario.modelId },
                        status: WorkflowNodeStatusEnum.Passed,
                        logs: []
                    }
                };
            });

            await workflowExecutor.executeNodeStep({
                workflow: workflow as any,
                nodeId: node.id,
                settings,
                isNodeLocalCapable: () => false,
                executeNodeRemotely
            } as any);

            expect(executeNodeRemotely).toHaveBeenCalledTimes(1);
            const remoteArg = executeNodeRemotely.mock.calls[0][0];
            const remoteNode = remoteArg.workflow.nodes.find((item: any) => item.id === node.id);
            scenario.assertRuntime((remoteNode?.runtime ?? {}) as Record<string, unknown>);
        }
    });
});
