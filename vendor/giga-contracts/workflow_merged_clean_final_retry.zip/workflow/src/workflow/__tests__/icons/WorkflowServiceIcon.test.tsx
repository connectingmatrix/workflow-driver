// @vitest-environment jsdom
import React from 'react';
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, render, screen } from '@testing-library/react';
import { WorkflowServiceIcon, resolveWorkflowServiceIconMetadata } from '../../icons';

afterEach(() => {
    cleanup();
});

describe('resolveWorkflowServiceIconMetadata', () => {
    it('covers all catalog Google service icons without falling back', () => {
        const googleServiceIcons = [
            'simple-icons:google-gemini',
            'simple-icons:google-meet',
            'simple-icons:google-calendar',
            'simple-icons:google-drive',
            'simple-icons:google-sheets',
            'simple-icons:google-docs',
            'simple-icons:google-forms',
            'simple-icons:google-contacts',
            'simple-icons:google-cloud'
        ];

        for (const serviceIcon of googleServiceIcons) {
            const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);
            expect(resolved.source).not.toBe('fallback');
            expect(resolved.asset?.title).toBeTruthy();
        }
    });

    it('returns a manual asset for OpenAI', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:openai');

        expect(resolved.source).toBe('asset');
        expect(resolved.asset?.title).toBe('OpenAI');
    });

    it('returns a shared generated svg asset for Google Docs', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:google-docs');

        expect(resolved.source).toBe('component');
        expect(resolved.asset?.title).toBe('Google Docs');
    });

    it('returns the manual Google Contacts asset for the unsupported library entry', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:google-contacts');

        expect(resolved.source).toBe('asset');
        expect(resolved.asset?.title).toBe('Google Contacts');
    });

    it('returns a curated shared asset for Slack', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:slack');

        expect(resolved.source).toBe('asset');
        expect(resolved.asset?.title).toBeTruthy();
    });

    it('returns a curated shared asset for HubSpot', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:hubspot');

        expect(resolved.source).not.toBe('fallback');
        expect(resolved.asset?.title).toBeTruthy();
    });

    it('returns curated shared assets for n8n-backed support and crm services', () => {
        for (const serviceIcon of [
            'simple-icons:activecampaign',
            'simple-icons:customer-io',
            'simple-icons:freshdesk',
            'simple-icons:zoho-crm'
        ]) {
            const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);

            expect(resolved.source).toBe('asset');
            expect(resolved.asset?.title).toBeTruthy();
        }
    });

    it('returns curated shared assets for official-site and collection-backed commerce services', () => {
        for (const serviceIcon of [
            'simple-icons:omnisend',
            'simple-icons:recurly',
            'simple-icons:shippo',
            'simple-icons:shipstation',
            'simple-icons:easypost',
            'simple-icons:gorgias',
            'simple-icons:kayako',
            'simple-icons:kustomer',
            'simple-icons:drip'
        ]) {
            const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);

            expect(resolved.source).toBe('asset');
            expect(resolved.asset?.title).toBeTruthy();
        }
    });

    it('returns curated shared assets for official-site and collection-backed productivity services', () => {
        for (const serviceIcon of [
            'simple-icons:cohere',
            'simple-icons:assemblyai',
            'simple-icons:monday-com',
            'simple-icons:smartsheet',
            'simple-icons:amplitude',
            'simple-icons:honeycomb',
            'simple-icons:deel',
            'simple-icons:workday'
        ]) {
            const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);

            expect(resolved.source).toBe('asset');
            expect(resolved.asset?.title).toBeTruthy();
        }
    });

    it('returns curated shared assets for identity and design services', () => {
        for (const serviceIcon of [
            'simple-icons:linkedin',
            'simple-icons:canva',
            'simple-icons:workos',
            'simple-icons:stytch',
            'simple-icons:bamboohr',
            'simple-icons:adobe-acrobat-sign',
            'simple-icons:uptimerobot',
            'simple-icons:onelogin'
        ]) {
            const resolved = resolveWorkflowServiceIconMetadata(serviceIcon);

            expect(resolved.source).toBe('asset');
            expect(resolved.asset?.title).toBeTruthy();
        }
    });

    it('returns fallback metadata for unresolved generic integrations', () => {
        const resolved = resolveWorkflowServiceIconMetadata('simple-icons:rest-api');

        expect(resolved.source).toBe('fallback');
        expect(resolved.asset).toBeNull();
    });
});

describe('WorkflowServiceIcon', () => {
    it('renders asset-backed services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:openai" serviceName="OpenAI" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:openai');
    });

    it('renders curated shared assets for Slack', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:slack" serviceName="Slack" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:slack');
    });

    it('renders curated shared assets for HubSpot', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:hubspot" serviceName="HubSpot" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).not.toBe('fallback');
        expect(icon.getAttribute('data-service-icon')).toBe('simple-icons:hubspot');
    });

    it('renders curated shared assets for n8n-backed services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:freshdesk" serviceName="Freshdesk" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:freshdesk');
    });

    it('renders curated shared assets for official-site backed services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:shippo" serviceName="Shippo" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:shippo');
    });

    it('renders curated shared assets for official-site backed productivity services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:cohere" serviceName="Cohere" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:cohere');
    });

    it('renders curated shared assets for identity and design services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:linkedin" serviceName="LinkedIn" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('asset');
        expect(icon.getAttribute('data-asset')).toBe('simple-icons:linkedin');
    });

    it('renders component-backed Google services', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:google-docs" serviceName="Google Docs" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('component');
        expect(icon.getAttribute('data-component')).toBe('simple-icons:google-docs');
    });

    it('renders colored fallback initials when no asset or component exists', () => {
        render(<WorkflowServiceIcon serviceIcon="simple-icons:rest-api" serviceName="REST API" dataTestId="service-icon" />);

        const icon = screen.getByTestId('service-icon');
        expect(icon.getAttribute('data-source')).toBe('fallback');
        expect(screen.getByText('RA')).toBeTruthy();
    });
});
