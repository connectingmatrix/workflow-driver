const createBridgeCloneSource = (): string => `
const cloneBridgeArg = (value) => {
  if (value == null) return value;
  if (typeof value === 'function') return undefined;
  if (Array.isArray(value)) {
    const entries = [];
    for (let index = 0; index < value.length; index += 1) {
      entries.push(cloneBridgeArg(value[index]));
    }
    return entries;
  }
  if (value instanceof Date) return new Date(value.getTime());
  if (typeof value === 'object') {
    const record = {};
    for (const [key, entry] of Object.entries(value)) {
      const next = cloneBridgeArg(entry);
      if (typeof next !== 'undefined') {
        record[key] = next;
      }
    }
    return record;
  }
  return value;
};

const cloneBridgeArgs = (args) => {
  const entries = [];
  for (let index = 0; index < args.length; index += 1) {
    entries.push(cloneBridgeArg(args[index]));
  }
  return entries;
};
`;

export const createVirtualExecuteModuleSource = (helperId: string): string => `
${createBridgeCloneSource()}
const getHelpers = () => ((globalThis.__WF_EXECUTE_HELPERS__ || {})[${JSON.stringify(helperId)}] || {});
export const executeGigaService = async (...args) => {
  const helpers = getHelpers();
  if (typeof helpers.executeGigaService !== 'function' && typeof helpers.executeBackend !== 'function') {
    throw new Error('executeGigaService helper is not available in worker runtime.');
  }
  const execute = typeof helpers.executeGigaService === 'function' ? helpers.executeGigaService : helpers.executeBackend;
  return execute(...cloneBridgeArgs(args));
};
export const executeBackend = (...args) => executeGigaService(...args);
export const invokeConnectedNode = async (...args) => {
  const helpers = getHelpers();
  if (typeof helpers.invokeConnectedNode !== 'function') {
    throw new Error('invokeConnectedNode helper is not available in worker runtime.');
  }
  return helpers.invokeConnectedNode(...cloneBridgeArgs(args));
};
export const updateNode = async (...args) => {
  const helpers = getHelpers();
  if (typeof helpers.updateNode !== 'function') {
    return null;
  }
  return helpers.updateNode(...cloneBridgeArgs(args));
};
export const compileWorkflowCypher = async (...args) => {
  const helpers = getHelpers();
  if (typeof helpers.compileWorkflowCypher !== 'function') {
    throw new Error('compileWorkflowCypher helper is not available in worker runtime.');
  }
  return helpers.compileWorkflowCypher(...cloneBridgeArgs(args));
};
`;

export const createVirtualExecutorModuleSource = (): string => `
const toRecord = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const parseStringValue = (value) => String(value ?? '').trim();
const parseJsonValue = (value) => {
  if (typeof value !== 'string') return value;
  const normalized = value.trim();
  if (!normalized) return {};
  try {
    return JSON.parse(normalized);
  } catch {
    return {};
  }
};
const parseStringArray = (value) => {
  const source = Array.isArray(value) ? value : Array.isArray(parseJsonValue(value)) ? parseJsonValue(value) : [];
  return source.map((entry) => parseStringValue(entry)).filter((entry) => entry.length > 0);
};
const parseBooleanValue = (value, fallback) => {
  if (typeof value === 'boolean') return value;
  const normalized = parseStringValue(value).toLowerCase();
  if (!normalized) return fallback;
  return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
};
const WORKFLOW_CONTEXT_PATTERN = /\\b(workflow|node|cypher|execute|run)\\b/i;
const CHAT_PARITY_CONTEXT_PATTERN = /\\b(chat parity|chat pipeline|giga|agent action|action node|backend action|run-[a-z0-9-]+)\\b/i;
export const workflowPlannerContext = (message) => {
  const text = parseStringValue(message);
  if (!WORKFLOW_CONTEXT_PATTERN.test(text)) return '';
  const lower = text.toLowerCase();
  const hints = [
    'Workflow Cypher authoring context:',
    'Use Workflow for creation, update, publish, fetch, and delete operations. Use Execute Workflow for published execution.',
    'If the user asks to create and execute, plan Workflow with publishAfterSave=true, then Execute Workflow using workflowActionId from the prior Workflow action id.',
    'Cypher grammar:',
    '(alias:modelId {"name":"Name","runtime":{...}})',
    '(from)-[:CONNECT {"source":"out:output","target":"in:input"}]->(to)',
    'Executable workflows require exactly one start node and at least one respond-end node.',
    'Hello world template:',
    '(start:start {"name":"Start","runtime":{}})',
    '(hello:code {"name":"Hello World","runtime":{"code":"return \\"hello world\\";"}})',
    '(end:respond-end {"name":"Respond End","runtime":{"response":"{{hello.output}}"}})',
    '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(hello)',
    '(hello)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)'
  ];
  if (CHAT_PARITY_CONTEXT_PATTERN.test(lower)) {
    hints.push(
      'For chat action parity, use current-chat for input, context, history, and pending state bundles.',
      'Use text-analysis for confirmation, workflow-request, explanation, reference-sync, and workflow-followup detection.',
      'Use ai-governor with executionMode "plan-only"; it must not execute tools before Planner confirmation policy runs.',
      'Use grouped Action Router nodes as AI Governor tools only for Channel, Category, Subject, Post, User Tree, and Chat actions.',
      'Connect grouped action nodes into Action Router on cmd:actions. Approved plans should target router node ids and pass input.action plus input.actionInput.',
      'Use output-format with AI formatting for chat responses, then respond-end.'
    );
  }
  return hints.join('\\n');
};
const normalizeStatus = (status) => {
  if (status === 'failed') return 'failed';
  if (status === 'warning') return 'warning';
  if (status === 'running') return 'running';
  if (status === 'stopped') return 'stopped';
  return 'passed';
};
export const WorkflowNodeStatusEnum = {
  Passed: 'passed',
  Failed: 'failed',
  Warning: 'warning',
  Running: 'running',
  Stopped: 'stopped'
};
export const normalizeResult = (result) => {
  if (!result || typeof result !== 'object' || Array.isArray(result)) {
    return { output: result ?? null, status: 'passed', logs: [] };
  }
  const record = result;
  const logs = Array.isArray(record.logs)
    ? record.logs.map((entry) => String(entry)).filter((entry) => entry.trim().length > 0)
    : [];
  return {
    output: Object.prototype.hasOwnProperty.call(record, 'output') ? record.output : record,
    status: normalizeStatus(record.status),
    logs,
    ...(record.skipCommandPeerAutoRun === true ? { skipCommandPeerAutoRun: true } : {})
  };
};
export const toErrorResult = (message, logs = []) => ({
  output: { error: String(message) },
  status: 'failed',
  logs: [...logs, String(message)]
});
export const toNode = (payload) => toRecord(toRecord(payload).NODE);
const isWorkflowExecutionHostContext = (value) => typeof toRecord(value).executeWorkflowReference === 'function';
const isWorkflowManagementHostContext = (value) =>
  typeof toRecord(value).listWorkflowDefinitions === 'function' ||
  typeof toRecord(value).getWorkflowDefinition === 'function' ||
  typeof toRecord(value).saveWorkflowDefinition === 'function' ||
  typeof toRecord(value).deleteWorkflowDefinition === 'function' ||
  typeof toRecord(value).publishWorkflowDefinition === 'function';
export const getWorkflowExecutionHostContext = (hostContext) => {
  if (isWorkflowExecutionHostContext(hostContext)) return hostContext;
  const nested = toRecord(hostContext).workflows;
  return isWorkflowExecutionHostContext(nested) ? nested : null;
};
export const getWorkflowManagementHostContext = (hostContext) => {
  if (isWorkflowManagementHostContext(hostContext)) return hostContext;
  const nested = toRecord(hostContext).workflows;
  return isWorkflowManagementHostContext(nested) ? nested : null;
};
const normalizeWorkflowMcpRuntime = (runtime) => {
  const record = toRecord(runtime);
  const maxLoopPasses = Number(record.maxLoopPasses ?? 3);
  return {
    credentialId: parseStringValue(record.credentialId),
    capabilityQuery: parseStringValue(record.capabilityQuery),
    outputContract: toRecord(parseJsonValue(record.outputContract)),
    forwardNonMcpWork: parseBooleanValue(record.forwardNonMcpWork, true),
    loopNonMcpWork: parseBooleanValue(record.loopNonMcpWork, true),
    maxLoopPasses: Math.max(1, Math.min(6, Math.round(Number.isFinite(maxLoopPasses) ? maxLoopPasses : 3)))
  };
};
const resolveWorkflowMcpCredentialServer = (credential) => {
  const values = toRecord(credential?.values);
  const servers = toRecord(values.mcpServers);
  const entries = Object.entries(servers);
  if (!entries.length) {
    throw new Error('Selected MCP credential does not define an MCP server.');
  }
  const [serverKey, serverValue] = entries[0];
  const config = toRecord(serverValue);
  const transport = parseStringValue(config.type);
  const serverUrl = parseStringValue(config.url);
  if (!parseStringValue(serverKey)) {
    throw new Error('Selected MCP credential is missing the server key.');
  }
  if (transport !== 'streamable-http') {
    throw new Error('Selected MCP credential must use "streamable-http".');
  }
  if (!serverUrl) {
    throw new Error('Selected MCP credential is missing the server URL.');
  }
  return {
    serverKey,
    serverUrl,
    transport: 'streamable-http',
    headers: toRecord(config.headers)
  };
};
export const validateWorkflowMcpRuntime = (runtime) => {
  const record = toRecord(runtime);
  const normalized = normalizeWorkflowMcpRuntime(runtime);
  const errors = [];
  if (!normalized.credentialId) errors.push('MCP credential is required.');
  if (parseStringValue(record.maxLoopPasses) && (Number(record.maxLoopPasses) < 1 || Number(record.maxLoopPasses) > 6 || !Number.isFinite(Number(record.maxLoopPasses)))) {
    errors.push('Max Loop Passes must be between 1 and 6.');
  }
  return { ok: errors.length === 0, errors, normalizedRuntime: normalized };
};
export const getWorkflowMcpRuntimeManager = (hostContext) => {
  const nested = toRecord(toRecord(hostContext).mcp);
  if (typeof nested.resolveNodeServer === 'function' && typeof nested.listTools === 'function' && typeof nested.callTool === 'function') {
    return nested;
  }
  throw new Error('MCP runtime manager is not available in worker host context.');
};
const resolveWorkflowMcpToolCall = (input) => {
  const payload = toRecord(input);
  const candidates = [];
  const skipKeys = new Set(['payload', 'toolName', 'toolArguments', 'current', 'input']);
  const appendCandidate = (value, source) => {
    const record = toRecord(value);
    const envelope = toRecord(record.payload);
    const toolName = parseStringValue(record.toolName || envelope.toolName);
    if (!toolName) return;
    const directArguments = toRecord(record.toolArguments);
    candidates.push({
      source,
      toolName,
      toolArguments: Object.keys(directArguments).length > 0 ? directArguments : toRecord(envelope.toolArguments)
    });
  };
  appendCandidate(payload, 'root');
  appendCandidate(payload.current, 'current');
  appendCandidate(payload.input, 'input');
  Object.entries(toRecord(payload.input)).forEach(([key, value]) => appendCandidate(value, 'input.' + key));
  Object.entries(toRecord(payload.current)).forEach(([key, value]) => appendCandidate(value, 'current.' + key));
  Object.entries(payload).forEach(([key, value]) => {
    if (skipKeys.has(key)) return;
    appendCandidate(value, key);
  });
  if (candidates.length > 1) {
    return {
      payload,
      toolName: '',
      toolArguments: {},
      error: 'Received multiple MCP tool call candidates from ' + candidates.map((candidate) => candidate.source).join(', ') + '. Keep exactly one upstream MCP tool payload.'
    };
  }
  if (!candidates.length) {
    return {
      payload,
      toolName: '',
      toolArguments: {},
      error: ''
    };
  }
  const candidate = candidates[0];
  return {
    payload,
    toolName: candidate?.toolName || '',
    toolArguments: candidate?.toolArguments || {},
    error: ''
  };
};
const resolveWorkflowMcpServer = (manager, runtime, credential) => {
  const serverConfig = resolveWorkflowMcpCredentialServer(credential);
  const server = manager.resolveNodeServer({
    credentialId: runtime.credentialId,
    serverKey: serverConfig.serverKey,
    serverUrl: serverConfig.serverUrl,
    transport: serverConfig.transport,
    headers: serverConfig.headers
  });
  if (!server) throw new Error('MCP server configuration could not be resolved.');
  return server;
};
export const executeWorkflowMcpCapabilitiesNode = async (params) => {
  const runtime = normalizeWorkflowMcpRuntime(params.runtime);
  const listed = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential || null) });
  return {
    output: {
      capabilityQuery: runtime.capabilityQuery,
      tools: listed.tools,
      capabilities: listed.capabilities,
      serverInfo: listed.serverInfo,
      protocolVersion: listed.protocolVersion,
      __activeOutputs: ['output']
    },
    status: 'passed',
    logs: ['MCP capabilities resolved.']
  };
};
export const executeWorkflowMcpRuntimeNode = async (params) => {
  const runtime = normalizeWorkflowMcpRuntime(params.runtime);
  const resolved = await params.manager.listTools({ server: resolveWorkflowMcpServer(params.manager, runtime, params.credential || null) });
  const toolCall = resolveWorkflowMcpToolCall(params.input);
  if (toolCall.error) {
    return {
      output: {
        error: toolCall.error,
        __activeOutputs: ['output']
      },
      status: 'failed',
      logs: [toolCall.error]
    };
  }
  if (!toolCall.toolName) {
    const loopPass = Math.max(0, Math.round(Number(toolCall.payload.__loopPass ?? 0) || 0));
    const shouldLoop = runtime.loopNonMcpWork && loopPass < runtime.maxLoopPasses;
    const forwardedPayload = runtime.forwardNonMcpWork
      ? {
          ...toolCall.payload,
          __loopPass: loopPass + 1,
          __loopBudgetRemaining: Math.max(runtime.maxLoopPasses - (loopPass + 1), 0)
        }
      : {};
    return {
      output: {
        capabilityQuery: runtime.capabilityQuery,
        outputContract: runtime.outputContract,
        toolCall: null,
        toolResult: null,
        tools: resolved.tools,
        serverInfo: resolved.serverInfo,
        protocolVersion: resolved.protocolVersion,
        forwardedPayload,
        nonMcpRouting: {
          hasToolCall: false,
          loopEnabled: runtime.loopNonMcpWork,
          forwarded: runtime.forwardNonMcpWork,
          maxLoopPasses: runtime.maxLoopPasses,
          currentLoopPass: loopPass,
          hasLoopBudget: loopPass < runtime.maxLoopPasses
        },
        __activeOutputs: [shouldLoop ? 'loop' : 'output']
      },
      status: 'passed',
      logs: [shouldLoop ? 'Loop route selected because no MCP tool call was provided.' : 'No MCP tool call was provided.']
    };
  }
  const called = await params.manager.callTool({
    server: resolved.server,
    toolName: toolCall.toolName,
    toolArguments: toolCall.toolArguments
  });
  return {
    output: {
      capabilityQuery: runtime.capabilityQuery,
      outputContract: runtime.outputContract,
      toolCall: called.toolCall,
      toolResult: called.toolResult,
      tools: called.tools,
      serverInfo: called.serverInfo,
      protocolVersion: called.protocolVersion,
      __activeOutputs: ['output']
    },
    status: 'passed',
    logs: [\`MCP tool "\${called.toolCall.name}" executed.\`]
  };
};
export { normalizeWorkflowMcpRuntime, toRecord };
`;

export const createBrowserNodeBuiltinStubSource = (): string => `
const createStub = () => {
  let proxy;
  const fn = () => undefined;
  const handler = {
    get: (_target, key) => (key === 'then' ? undefined : proxy),
    apply: () => undefined,
    construct: () => ({})
  };
  proxy = new Proxy(fn, handler);
  return proxy;
};
const stub = createStub();
export default stub;
`;
