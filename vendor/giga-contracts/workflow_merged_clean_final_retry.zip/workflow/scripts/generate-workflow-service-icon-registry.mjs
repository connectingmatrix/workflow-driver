import fs from 'node:fs';
import https from 'node:https';
import path from 'node:path';

const workflowRepoRoot = '/Users/abeer/dev/giga/workflow';
const backendCatalogPath = '/Users/abeer/dev/giga/giga-ai-backend/src/services/credentials/catalog/api-credential-catalog-300-plus.json';
const simpleIconsSourceDir = path.join(workflowRepoRoot, 'node_modules/@icons-pack/react-simple-icons/src/icons');
const outputTsPath = path.join(workflowRepoRoot, 'src/workflow/icons/workflow-service-svg-assets.generated.ts');
const outputJsonPath = path.join(workflowRepoRoot, 'src/workflow/icons/workflow-service-icon.audit.generated.json');

const manualAssetKeys = new Set([
  'simple-icons:openai',
  'simple-icons:groq',
  'simple-icons:deepseek',
  'simple-icons:google-contacts'
]);

const manualAliases = {
  'simple-icons:graphql-api': 'SiGraphql',
  'simple-icons:bigquery': 'SiGooglebigquery',
  'simple-icons:facebook-graph-api': 'SiFacebook',
  'simple-icons:instagram-graph-api': 'SiInstagram',
  'simple-icons:youtube-data-api': 'SiYoutube',
  'simple-icons:whatsapp-business-cloud': 'SiWhatsapp',
  'simple-icons:apollo': 'SiApollographql'
};

const iconifyBackfillSources = {
  'simple-icons:slack': 'logos:slack',
  'simple-icons:microsoft-teams': 'logos:microsoft-teams',
  'simple-icons:outlook': 'file-icons:microsoft-outlook',
  'simple-icons:onedrive': 'logos:microsoft-onedrive',
  'simple-icons:sharepoint': 'streamline-logos:microsoft-sharepoint-logo-solid',
  'simple-icons:twilio': 'logos:twilio',
  'simple-icons:salesforce': 'logos:salesforce',
  'simple-icons:pipedrive': 'logos:pipedrive',
  'simple-icons:front': 'logos:frontapp',
  'simple-icons:docusign': 'simple-icons:docusign',
  'simple-icons:marketo': 'simple-icons:marketo',
  'simple-icons:quickbooks-online': 'simple-icons:quickbooks',
  'simple-icons:hubspot': 'simple-icons:hubspot',
  'simple-icons:chargebee': 'logos:chargebee',
  'simple-icons:braze': 'logos:braze',
  'simple-icons:magento': 'devicon:magento',
  'simple-icons:aws': 'logos:aws',
  'simple-icons:microsoft-azure': 'logos:microsoft-azure',
  'simple-icons:docker-hub': 'logos:docker-icon',
  'simple-icons:heroku': 'logos:heroku-icon',
  'simple-icons:launchdarkly': 'logos:launchdarkly-icon',
  'simple-icons:pinecone': 'logos:pinecone-icon',
  'simple-icons:stability-ai': 'logos:stability-ai-icon',
  'simple-icons:mailjet': 'logos:mailjet-icon',
  'simple-icons:azure-devops': 'devicon:azuredevops',
  'simple-icons:terraform-cloud': 'logos:terraform',
  'simple-icons:neon': 'logos:neon-icon',
  'simple-icons:redis-cloud': 'logos:redis',
  'simple-icons:grafana-cloud': 'logos:grafana',
  'simple-icons:qdrant': 'https://unpkg.com/simple-icons@latest/icons/qdrant.svg',
  'simple-icons:activecampaign': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/ActiveCampaign/activeCampaign.svg',
  'simple-icons:convertkit': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/ConvertKit/convertKit.svg',
  'simple-icons:customer-io': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/CustomerIo/customerio.svg',
  'simple-icons:freshdesk': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/Freshdesk/freshdesk.svg',
  'simple-icons:lemlist': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/Lemlist/lemlist.svg',
  'simple-icons:mailerlite': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/MailerLite/MailerLite.svg',
  'simple-icons:wufoo': 'logos:wufoo',
  'simple-icons:zoho-crm': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/Zoho/zoho.svg',
  'simple-icons:zoho-desk': 'https://unpkg.com/n8n-nodes-base@1.121.19/dist/nodes/Zoho/zoho.svg',
  'simple-icons:drip': 'logos:drip',
  'simple-icons:kustomer': 'logos:kustomer',
  'simple-icons:omnisend': 'https://www.omnisend.com/wp-content/themes/omnisend-v2/assets/img/omnisend_logo_dark.svg',
  'simple-icons:recurly': 'https://recurly.com/img2/logo-recurly.svg',
  'simple-icons:shippo': 'https://cdn.prod.website-files.com/6462967bbf70fa5b5b227351/646bd3ac70ee08fca9869afe_shippo-logo-dark.svg',
  'simple-icons:shipstation': 'https://www.shipstation.com/wp-content/uploads/2024/10/ShipStation-BoxedSymbol-DeepIndigo-BrightGreen-RGB.svg',
  'simple-icons:easypost': 'https://www.easypost.com/wp-content/uploads/2025/03/icon.svg',
  'simple-icons:gorgias': 'https://cdn.prod.website-files.com/5e4ff204e7b6f80e402d407a/669a5ab4a69be50c3a94800a_Gorgias%20Logo%20-%20Black.svg',
  'simple-icons:kayako': 'https://kayako.com/wp-content/uploads/2025/07/kayako-one-logo-dark.svg',
  'simple-icons:cohere': 'https://cohere.com/logo.svg',
  'simple-icons:assemblyai': 'https://cdn.prod.website-files.com/67a08d9d7d19f8fb63692894/67b5bd3d9e8ee1a6b2410b9e_AssemblyAI%20Logo.svg',
  'simple-icons:monday-com': 'https://dapulse-res.cloudinary.com/image/upload/f_auto,q_auto/remote_mondaycom_static/img/monday-logo-2.svg',
  'simple-icons:smartsheet': 'https://www.smartsheet.com/sites/default/files/smartsheet-logo-blue-new.svg',
  'simple-icons:amplitude': 'https://cdn.sanity.io/images/l5rq9j6r/production/09e2283969170dd9ddbd3731c33e968d1e1ea6c8-114x30.svg',
  'simple-icons:honeycomb': 'https://cdn.sanity.io/images/927dxq0h/production/16838d6e4bdca1c2239e2005b3cc92fde0c865f8-151x31.svg',
  'simple-icons:deel': 'https://website-media.deel.com/logo_revamp_164ddaed0c.svg',
  'simple-icons:workday': 'arcticons:workday',
  'simple-icons:linkedin': 'logos:linkedin-icon',
  'simple-icons:canva': 'devicon:canva',
  'simple-icons:workos': 'logos:workos-icon',
  'simple-icons:stytch': 'logos:stytch',
  'simple-icons:bamboohr': 'arcticons:bamboohr',
  'simple-icons:adobe-acrobat-sign': 'arcticons:adobe-acrobat-sign',
  'simple-icons:uptimerobot': 'arcticons:uptimerobot',
  'simple-icons:onelogin': 'https://www.onelogin.com/images/shared/onelogin-logo.svg'
};

const normalize = (value) => String(value ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');

const parseSimpleIconSource = (filePath) => {
    const text = fs.readFileSync(filePath, 'utf8');
    const titleMatch = text.match(/title\s*=\s*'([^']+)'/);
    const defaultColorMatch = text.match(/const\s+defaultColor\s*=\s*'([^']+)'/);
    const viewBoxMatch = text.match(/viewBox='([^']+)'/);
    const svgContentMatch = text.match(/<title>\{title\}<\/title>([\s\S]*?)<\/svg>/);
    return {
        title: titleMatch?.[1] ?? null,
        defaultColor: defaultColorMatch?.[1] ?? null,
        viewBox: viewBoxMatch?.[1] ?? '0 0 24 24',
        markup: svgContentMatch?.[1]?.trim() ?? ''
    };
};

const fetchText = (url) => new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (response) => {
        if (response.statusCode && response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
            resolve(fetchText(new URL(response.headers.location, url).toString()));
            return;
        }
        if (response.statusCode !== 200) {
            reject(new Error(`Request failed for ${url}: ${response.statusCode}`));
            return;
        }
        let body = '';
        response.setEncoding('utf8');
        response.on('data', (chunk) => {
            body += chunk;
        });
        response.on('end', () => resolve(body));
    }).on('error', reject);
});

const parseRemoteSvg = (svgText) => {
    const viewBoxMatch = svgText.match(/viewBox=(['"])([^'"]+)\1/);
    const innerMarkupMatch = svgText.match(/<svg[\s\S]*?>([\s\S]*?)<\/svg>/i);
    const titleMatch = svgText.match(/<title>([\s\S]*?)<\/title>/i);
    const normalizedMarkup = (innerMarkupMatch?.[1] ?? '')
        .replace(/<title>[\s\S]*?<\/title>/gi, '')
        .trim();
    return {
        title: titleMatch?.[1]?.trim() ?? null,
        viewBox: viewBoxMatch?.[2] ?? '0 0 24 24',
        markup: normalizedMarkup
    };
};

const catalog = JSON.parse(fs.readFileSync(backendCatalogPath, 'utf8'));
const services = Array.isArray(catalog?.services) ? catalog.services : [];
const uniqueServices = new Map();
for (const service of services) {
  if (typeof service?.service_icon === 'string' && service.service_icon.trim()) {
    uniqueServices.set(service.service_icon.trim().toLowerCase(), service);
  }
}

const iconFiles = fs.readdirSync(simpleIconsSourceDir).filter((file) => file.endsWith('.tsx'));
const componentsByTitle = new Map();
const availableComponents = new Set();
const componentSources = new Map();
for (const file of iconFiles) {
    const componentName = file.replace(/\.tsx$/, '');
    const source = parseSimpleIconSource(path.join(simpleIconsSourceDir, file));
    availableComponents.add(componentName);
    componentSources.set(componentName, source);
    if (source.title) {
        componentsByTitle.set(normalize(source.title), {
            componentName,
      title: source.title,
      defaultColor: source.defaultColor
    });
  }
}

const matched = [];
const unmatched = [];
for (const [serviceIcon, service] of uniqueServices) {
  if (manualAssetKeys.has(serviceIcon)) {
    matched.push({
      serviceIcon,
      serviceName: service.service_name,
      componentName: null,
      title: service.service_name,
      defaultColor: null,
      source: 'manual-asset'
    });
    continue;
  }

  const aliasComponentName = manualAliases[serviceIcon];
  if (aliasComponentName && availableComponents.has(aliasComponentName)) {
    const source = parseSimpleIconSource(path.join(simpleIconsSourceDir, `${aliasComponentName}.tsx`));
    matched.push({
      serviceIcon,
      serviceName: service.service_name,
      componentName: aliasComponentName,
      title: source.title ?? service.service_name,
      defaultColor: source.defaultColor,
      source: 'manual-alias'
    });
    continue;
  }

  const titleMatch = componentsByTitle.get(normalize(service.service_name));
  if (titleMatch) {
    matched.push({
      serviceIcon,
      serviceName: service.service_name,
      componentName: titleMatch.componentName,
      title: titleMatch.title,
      defaultColor: titleMatch.defaultColor,
      source: 'title-match'
    });
    continue;
  }

  unmatched.push({
    serviceIcon,
    serviceName: service.service_name,
    reason: 'fallback'
  });
}

const iconifyBackfilled = [];
const stillUnmatched = [];
for (const entry of unmatched) {
    const iconifyIconId = iconifyBackfillSources[entry.serviceIcon];
    if (!iconifyIconId) {
        stillUnmatched.push(entry);
        continue;
    }
    try {
        const remoteUrl = iconifyIconId.startsWith('http')
            ? iconifyIconId
            : `https://api.iconify.design/${iconifyIconId.replace(':', '/')}.svg`;
        const svgText = await fetchText(remoteUrl);
        const parsedSvg = parseRemoteSvg(svgText);
        iconifyBackfilled.push({
            serviceIcon: entry.serviceIcon,
            serviceName: entry.serviceName,
            componentName: null,
            title: parsedSvg.title ?? entry.serviceName,
            defaultColor: null,
            viewBox: parsedSvg.viewBox,
            markup: parsedSvg.markup,
            source: 'iconify-asset'
        });
    } catch (error) {
        console.warn(`Iconify backfill failed for ${entry.serviceIcon}: ${error.message}`);
        stillUnmatched.push(entry);
    }
}

const simpleIconMatches = matched.filter((entry) => entry.componentName);
const generatedAssetEntries = [
    ...simpleIconMatches.map((entry) => ({
        ...entry,
        source: 'component'
    })),
    ...iconifyBackfilled
];

const assetLines = generatedAssetEntries
  .slice()
  .sort((left, right) => left.serviceIcon.localeCompare(right.serviceIcon))
  .map((entry) => {
      if (entry.source === 'iconify-asset') {
          return [
              `    '${entry.serviceIcon}': {`,
              `        title: ${JSON.stringify(entry.title ?? entry.serviceName)},`,
              `        viewBox: ${JSON.stringify(entry.viewBox ?? '0 0 24 24')},`,
              `        brandColor: ${JSON.stringify(entry.defaultColor ?? '#4F6BFF')},`,
              `        markup: ${JSON.stringify(entry.markup ?? '')},`,
              `        source: 'asset'`,
              '    },'
          ].join('\n');
      }
      const componentSource = componentSources.get(entry.componentName);
      if (!componentSource?.markup) {
          throw new Error(`Unable to extract SVG markup for ${entry.componentName}`);
      }
      return [
          `    '${entry.serviceIcon}': {`,
          `        title: ${JSON.stringify(componentSource.title ?? entry.serviceName)},`,
          `        viewBox: ${JSON.stringify(componentSource.viewBox)},`,
          `        brandColor: ${JSON.stringify(componentSource.defaultColor ?? '#4F6BFF')},`,
          `        markup: ${JSON.stringify(componentSource.markup)},`,
          `        source: 'component'`,
          '    },'
      ].join('\n');
  });

const colorLines = simpleIconMatches
  .filter((entry) => entry.defaultColor)
  .sort((left, right) => left.serviceIcon.localeCompare(right.serviceIcon))
  .map((entry) => `    '${entry.serviceIcon}': '${entry.defaultColor}',`);

const generatedTs = `export interface GeneratedWorkflowServiceSvgAsset {\n    title: string;\n    viewBox: string;\n    brandColor: string;\n    markup: string;\n    source: 'component' | 'asset';\n}\n\nexport const WORKFLOW_SERVICE_GENERATED_SVG_ASSETS: Record<string, GeneratedWorkflowServiceSvgAsset> = {\n${assetLines.join('\n')}\n};\n\nexport const WORKFLOW_SERVICE_SIMPLE_ICON_DEFAULT_COLORS: Record<string, string> = {\n${colorLines.join('\n')}\n};\n`;

const report = {
  generatedAt: new Date().toISOString(),
  totalCatalogIcons: uniqueServices.size,
  manualAssetCount: matched.filter((entry) => entry.source === 'manual-asset').length,
  aliasBackedCount: matched.filter((entry) => entry.source === 'manual-alias').length,
  componentBackedCount: matched.filter((entry) => entry.source === 'title-match' || entry.source === 'manual-alias').length,
  iconifyAssetCount: iconifyBackfilled.length,
  fallbackBackedCount: stillUnmatched.length,
  matched,
  unmatched: stillUnmatched,
  iconifyBackfilled
};

fs.writeFileSync(outputTsPath, generatedTs);
fs.writeFileSync(outputJsonPath, JSON.stringify(report, null, 2) + '\n');
console.log(`Generated ${path.relative(workflowRepoRoot, outputTsPath)} and ${path.relative(workflowRepoRoot, outputJsonPath)}`);
console.log(JSON.stringify({
  totalCatalogIcons: report.totalCatalogIcons,
  manualAssetCount: report.manualAssetCount,
  aliasBackedCount: report.aliasBackedCount,
  componentBackedCount: report.componentBackedCount,
  fallbackBackedCount: report.fallbackBackedCount
}, null, 2));
