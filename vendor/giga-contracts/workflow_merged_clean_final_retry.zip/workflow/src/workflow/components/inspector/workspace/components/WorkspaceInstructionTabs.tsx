import React from 'react';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';
import InstructionMarkdownEditor from '@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor';
import type { WorkspaceInstructionPanelModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import { WorkspaceSegmentedTabs } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceSegmentedTabs';

interface WorkspaceInstructionTabsProps {
    model: WorkspaceInstructionPanelModel;
    code: string;
    markdown: string;
    readOnly?: boolean;
    onTabChange: (tabId: string) => void;
    onCodeChange: (nextCode: string) => void;
    onMarkdownChange: (nextMarkdown: string) => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
}

export const WorkspaceInstructionTabs: React.FC<WorkspaceInstructionTabsProps> = ({ model, code, markdown, readOnly = false, onTabChange, onCodeChange, onMarkdownChange, variableContext, variableSuggestions }) => {
    return (
        <div className="cnw-instruction-block">
            <WorkspaceSegmentedTabs items={model.tabs} activeId={model.activeTab} onChange={onTabChange} />
            {model.activeTab === 'markdown' ? (
                <div className="cnw-instruction-editor-shell">
                    <InstructionMarkdownEditor id="wf-workspace-instruction-markdown" value={markdown} readOnly={readOnly} onChange={onMarkdownChange} allowVariables variableSuggestions={variableSuggestions} />
                    <div className="cnw-instruction-helper">{'Drag JSON keys here to insert template tokens like {{code_1.output}}.'}</div>
                </div>
            ) : (
                <div className="cnw-instruction-editor-shell">
                    <CodeEditor value={code} onChange={onCodeChange} readOnly={readOnly} allowVariables variableContext={variableContext} variableSuggestions={variableSuggestions} />
                    <div className="cnw-instruction-helper">Use `NODE_ID.key` for upstream outputs, `workflow.runtime`, `workflow.input`, and `properties` for node properties.</div>
                </div>
            )}
        </div>
    );
};
