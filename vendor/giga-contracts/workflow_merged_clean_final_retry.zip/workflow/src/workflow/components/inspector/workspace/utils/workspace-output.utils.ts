import { WorkflowViewerTypeEnum } from '@workflow/ui/workflow/types';
import type { WorkflowInspectorViewer } from '@workflow/ui/workflow/components/inspector/types';

export const stringifyWorkspaceJson = (value: unknown): string => {
    if (typeof value === 'string') {
        return value;
    }

    try {
        return JSON.stringify(value ?? {}, null, 2);
    } catch {
        return '{}';
    }
};

export const buildWorkspaceOutputEditorValue = (viewer: WorkflowInspectorViewer | null): string => {
    if (!viewer) return '';
    if (viewer.type === WorkflowViewerTypeEnum.Raw) {
        return typeof viewer.value === 'string' ? viewer.value : stringifyWorkspaceJson(viewer.value);
    }
    return stringifyWorkspaceJson(viewer.value);
};

export const describeWorkspaceOutputShape = (value: unknown): string => {
    if (Array.isArray(value)) {
        return value.length === 0 ? 'array' : `array (${value.length} item${value.length === 1 ? '' : 's'})`;
    }
    if (value === null) return 'null';
    if (typeof value === 'object') return 'object';
    if (typeof value === 'string') return value.trim().length === 0 ? 'empty string' : 'string';
    return typeof value;
};
