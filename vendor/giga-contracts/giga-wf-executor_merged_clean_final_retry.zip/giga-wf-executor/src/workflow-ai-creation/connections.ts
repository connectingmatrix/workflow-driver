import type { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeSchema } from '../types';
import { WorkflowCypherEdgeSpec } from './types';

function handle(value: string, fallbackPrefix: string, fallbackPort: string) {
  const text = String(value || '').trim();
  const parts = text.includes(':') ? text.split(':') : [fallbackPrefix, text || fallbackPort];
  return { raw: text || `${fallbackPrefix}:${fallbackPort}`, prefix: parts[0], port: parts.slice(1).join(':') || fallbackPort };
}

function includesValue(values: any, candidate: string) {
  const normalized = candidate.trim().toLowerCase();
  return (Array.isArray(values) ? values : []).some((entry) => String(entry || '').trim().toLowerCase() === normalized);
}

function portRule(schema: WorkflowNodeSchema, side: 'inputs' | 'outputs' | 'commands', port: string) {
  return ((schema as any)[side] || {})[port] || null;
}

function ensureAllowedSource(targetRule: any, sourceSchema: WorkflowNodeSchema, sourceModelId: string) {
  if ((targetRule.acceptedSourceModelIds || []).length && !includesValue(targetRule.acceptedSourceModelIds, sourceModelId)) {
    throw new Error(`Target port does not accept source model ${sourceModelId}.`);
  }
  if ((targetRule.acceptedSourceGroups || []).length && !includesValue(targetRule.acceptedSourceGroups, String((sourceSchema as any).group || ''))) {
    throw new Error(`Target port does not accept source group ${(sourceSchema as any).group || 'Other'}.`);
  }
}

function ensureArrowLimit(workflow: WorkflowDefinition, connection: WorkflowConnectionModel, sourceRule: any, targetRule: any) {
  const sourceUsed = workflow.connections.filter((item) => item.from === connection.from && item.sourceHandle === connection.sourceHandle).length;
  const targetUsed = workflow.connections.filter((item) => item.to === connection.to && item.targetHandle === connection.targetHandle).length;
  if (sourceRule.allowMultipleArrows !== true && sourceUsed) throw new Error(`Source handle ${connection.sourceHandle} allows one connection.`);
  if (targetRule.allowMultipleArrows !== true && targetUsed) throw new Error(`Target handle ${connection.targetHandle} allows one connection.`);
}

export function buildWorkflowConnection(input: {
  edge: WorkflowCypherEdgeSpec;
  workflow: WorkflowDefinition;
  schemas: Record<string, WorkflowNodeSchema>;
  ids: Record<string, string>;
  index: number;
}) {
  const from = input.ids[input.edge.from];
  const to = input.ids[input.edge.to];
  if (!from || !to) throw new Error(`Unknown cypher edge alias "${input.edge.from}" -> "${input.edge.to}".`);
  if (from === to) throw new Error('Workflow nodes cannot connect to themselves.');
  const sourceNode = input.workflow.nodes.find((node) => node.id === from);
  const targetNode = input.workflow.nodes.find((node) => node.id === to);
  if (!sourceNode || !targetNode) throw new Error('Cypher connection resolved to missing workflow node.');
  const source = handle(input.edge.source, 'out', 'output');
  const target = handle(input.edge.target, 'in', 'input');
  if ((source.prefix === 'cmd') !== (target.prefix === 'cmd')) throw new Error('Command ports can only connect to command ports.');
  if (source.prefix !== 'out' && source.prefix !== 'cmd') throw new Error(`Invalid source handle ${source.raw}.`);
  if (target.prefix !== 'in' && target.prefix !== 'cmd') throw new Error(`Invalid target handle ${target.raw}.`);
  const sourceSchema = input.schemas[sourceNode.modelId];
  const targetSchema = input.schemas[targetNode.modelId];
  const sourceRule = source.prefix === 'cmd' ? portRule(sourceSchema, 'outputs', source.port) || portRule(sourceSchema, 'commands', source.port) : portRule(sourceSchema, 'outputs', source.port);
  const targetRule = target.prefix === 'cmd' ? portRule(targetSchema, 'inputs', target.port) || portRule(targetSchema, 'commands', target.port) : portRule(targetSchema, 'inputs', target.port);
  if (!sourceRule || !targetRule) throw new Error(`Invalid workflow cypher connection ${source.raw} -> ${target.raw}.`);
  ensureAllowedSource(targetRule, sourceSchema, sourceNode.modelId);
  const connection = { id: `cypher_${input.index + 1}_${from}_${to}`, name: `${from} -> ${to}`, from, to, sourceHandle: source.raw, targetHandle: target.raw };
  ensureArrowLimit(input.workflow, connection, sourceRule, targetRule);
  return connection;
}
