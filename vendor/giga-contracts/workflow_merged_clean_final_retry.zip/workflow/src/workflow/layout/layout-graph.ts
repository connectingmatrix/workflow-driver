import type { WorkflowConnectionModel, WorkflowDefinition } from '@workflow/ui/workflow/types';
import { isCommandConnection } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';

export interface WorkflowLayoutGraph {
    nodeIds: string[];
    orderById: Record<string, number>;
    dataLinks: WorkflowConnectionModel[];
    commandLinks: WorkflowConnectionModel[];
    parentsById: Record<string, string[]>;
    childrenById: Record<string, string[]>;
    mainNodeIds: string[];
    commandNodeIds: string[];
    roots: string[];
}

const append = (record: Record<string, string[]>, key: string, value: string): void => {
    record[key] = [...(record[key] || []), value];
};

export const readLayoutGraph = (workflow: WorkflowDefinition): WorkflowLayoutGraph => {
    const nodeIds = (workflow.nodes || []).map((node) => node.id);
    const orderById = nodeIds.reduce<Record<string, number>>((record, nodeId, index) => ({ ...record, [nodeId]: index }), {});
    const dataLinks = (workflow.connections || []).filter((connection) => !isCommandConnection(workflow, connection));
    const commandLinks = (workflow.connections || []).filter((connection) => isCommandConnection(workflow, connection));
    const parentsById: Record<string, string[]> = {};
    const childrenById: Record<string, string[]> = {};

    dataLinks.forEach((link) => {
        append(childrenById, link.from, link.to);
        append(parentsById, link.to, link.from);
    });

    const dataIds = new Set(dataLinks.flatMap((link) => [link.from, link.to]));
    const commandNodeIds = nodeIds.filter((nodeId) => !dataIds.has(nodeId) && commandLinks.some((link) => link.from === nodeId || link.to === nodeId));
    const mainNodeIds = nodeIds.filter((nodeId) => !commandNodeIds.includes(nodeId));
    const roots = mainNodeIds.filter((nodeId) => !(parentsById[nodeId] || []).length);

    return { nodeIds, orderById, dataLinks, commandLinks, parentsById, childrenById, mainNodeIds, commandNodeIds, roots: roots.length ? roots : mainNodeIds.slice(0, 1) };
};
