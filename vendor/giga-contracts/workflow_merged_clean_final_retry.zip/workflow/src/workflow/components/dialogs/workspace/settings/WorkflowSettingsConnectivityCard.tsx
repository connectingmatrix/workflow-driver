import React from 'react';
import { InputText } from 'primereact/inputtext';
import WorkflowSettingsSectionCard from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsSectionCard';

interface WorkflowSettingsConnectivityCardProps {
    readOnly?: boolean;
    graphqlUrl: string;
    httpBaseUrl: string;
    onGraphqlUrlChange: (value: string) => void;
    onHttpBaseUrlChange: (value: string) => void;
}

export const WorkflowSettingsConnectivityCard: React.FC<WorkflowSettingsConnectivityCardProps> = ({
    readOnly = false,
    graphqlUrl,
    httpBaseUrl,
    onGraphqlUrlChange,
    onHttpBaseUrlChange
}) => (
    <WorkflowSettingsSectionCard icon="pi pi-briefcase" title="Connectivity" description="Endpoints and API surfaces used by runtime-enabled nodes.">
        <label className="wf-workspace-settings__field-label">GraphQL endpoint</label>
        <InputText value={graphqlUrl} onChange={(event) => onGraphqlUrlChange(event.target.value)} readOnly={readOnly} className="wf-workspace-settings__input" />
        <span className="wf-workspace-settings__field-note">Used by graph-aware nodes and inspector previews.</span>
        <label className="wf-workspace-settings__field-label">HTTP base URL</label>
        <InputText value={httpBaseUrl} onChange={(event) => onHttpBaseUrlChange(event.target.value)} readOnly={readOnly} className="wf-workspace-settings__input" />
        <span className="wf-workspace-settings__field-note">Base path for requests and generated route helpers.</span>
    </WorkflowSettingsSectionCard>
);
