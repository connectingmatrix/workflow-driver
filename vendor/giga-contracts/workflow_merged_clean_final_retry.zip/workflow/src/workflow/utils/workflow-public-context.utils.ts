import { WorkflowDefinition } from '@workflow/ui/workflow/types';

const parseRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});

const cloneValue = <T>(value: T): T => {
    if (typeof value === 'undefined') return value;
    try {
        return JSON.parse(JSON.stringify(value)) as T;
    } catch {
        return value;
    }
};

export const normalizePublicOutput = (value: unknown): Record<string, unknown> => {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
        return cloneValue(value as Record<string, unknown>);
    }
    return {
        output: cloneValue(value)
    };
};

export const buildPublicWorkflowContext = (workflow: WorkflowDefinition | null | undefined): Record<string, unknown> => {
    const metadataRuntime = parseRecord(workflow?.metadata?.runtime);
    return {
        runtime: cloneValue(parseRecord(metadataRuntime.settings)),
        input: cloneValue(parseRecord(workflow?.input))
    };
};
