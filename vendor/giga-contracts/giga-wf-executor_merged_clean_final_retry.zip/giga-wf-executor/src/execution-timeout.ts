export {
    createWorkflowExecutionTimeoutController,
    DEFAULT_WORKFLOW_MAX_EXECUTION_SECONDS,
    normalizeWorkflowMaxExecutionSeconds,
    resolveWorkflowExecutionTimeoutMs,
    WORKFLOW_MAX_EXECUTION_SECONDS_OPTIONS
} from './executor/core/execution/execution-timeout';
export type { WorkflowExecutionTimeoutController, WorkflowMaxExecutionSeconds } from './executor/core/execution/execution-timeout';
