import { WorkflowPreviewRuntime } from '@workflow/ui/workflow/types';

const NODE_BUILTIN_MODULES = [
    'assert',
    'buffer',
    'child_process',
    'crypto',
    'dns',
    'events',
    'fs',
    'http',
    'https',
    'module',
    'net',
    'os',
    'path',
    'perf_hooks',
    'process',
    'readline',
    'stream',
    'timers',
    'tls',
    'tty',
    'url',
    'util',
    'vm',
    'worker_threads',
    'zlib'
] as const;

const escapeRegex = (value: string): string => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const detectNodeBuiltinImports = (source: string): string[] => {
    const matches = new Set<string>();
    NODE_BUILTIN_MODULES.forEach((moduleName) => {
        const pattern = new RegExp(`(?:from\\s+['\"](?:node:)?${escapeRegex(moduleName)}['\"]|import\\(\\s*['\"](?:node:)?${escapeRegex(moduleName)}['\"]\\s*\\)|require\\(\\s*['\"](?:node:)?${escapeRegex(moduleName)}['\"]\\s*\\))`, 'g');
        if (pattern.test(source)) {
            matches.add(moduleName);
        }
    });
    return [...matches].sort();
};

export interface UserNodePreviewRuntimeSupport {
    browserRuntimeAllowed: boolean;
    nodeImports: string[];
    browserBlockedReason: string | null;
    autoRuntimeReason: string | null;
}

export const analyzeUserNodePreviewRuntimeSupport = (params: { activeFile: 'worker.ts' | 'validate.ts'; workerSource: string }): UserNodePreviewRuntimeSupport => {
    if (params.activeFile !== 'worker.ts') {
        return {
            browserRuntimeAllowed: false,
            nodeImports: [],
            browserBlockedReason: 'Browser preview is available only for worker.ts preview.',
            autoRuntimeReason: 'Auto switched to Node runtime because browser preview is available only for worker.ts preview.'
        };
    }

    const nodeImports = detectNodeBuiltinImports(params.workerSource);
    if (nodeImports.length > 0) {
        return {
            browserRuntimeAllowed: false,
            nodeImports,
            browserBlockedReason: `Browser preview is unavailable because worker.ts imports Node module${nodeImports.length > 1 ? 's' : ''}: ${nodeImports.join(', ')}.`,
            autoRuntimeReason: `Auto switched to Node runtime because worker.ts imports Node module${nodeImports.length > 1 ? 's' : ''}: ${nodeImports.join(', ')}.`
        };
    }

    return {
        browserRuntimeAllowed: true,
        nodeImports: [],
        browserBlockedReason: null,
        autoRuntimeReason: null
    };
};

export const resolveUserNodePreviewRuntime = (
    requestedRuntime: WorkflowPreviewRuntime,
    support: UserNodePreviewRuntimeSupport
): { effectiveRuntime: 'browser' | 'node'; runtimeFallbackReason: string | null } => {
    if (requestedRuntime === 'node') {
        return { effectiveRuntime: 'node', runtimeFallbackReason: null };
    }

    if (requestedRuntime === 'browser') {
        return {
            effectiveRuntime: support.browserRuntimeAllowed ? 'browser' : 'node',
            runtimeFallbackReason: support.browserRuntimeAllowed ? null : support.browserBlockedReason
        };
    }

    return {
        effectiveRuntime: support.browserRuntimeAllowed ? 'browser' : 'node',
        runtimeFallbackReason: support.browserRuntimeAllowed ? null : support.autoRuntimeReason
    };
};
