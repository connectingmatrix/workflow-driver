import { createExecutor } from './createExecutor';
import type { ExecutorService } from './types';

export const Executor: ExecutorService = createExecutor();
export type { ExecutorListenHandler, ExecutorPublishEventName, ExecutorRunState, ExecutorRunningState, ExecutorService, ExecutorSetup } from './types';
