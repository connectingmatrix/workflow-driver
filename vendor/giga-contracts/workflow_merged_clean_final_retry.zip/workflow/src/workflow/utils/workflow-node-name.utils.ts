import { WorkflowDefinition, WorkflowNodeModel } from '@workflow/ui/workflow/types';

const DEFAULT_NODE_NAME = 'Node';

const normalizeWhitespace = (value: string): string => value.replace(/\s+/g, ' ').trim();
const toNameKey = (value: string): string => normalizeWhitespace(value).toLowerCase();

export const normalizeNodeName = (value: unknown, fallback = DEFAULT_NODE_NAME): string => {
    const asString = typeof value === 'string' ? value : String(value ?? '');
    const normalized = normalizeWhitespace(asString);
    return normalized.length > 0 ? normalized : fallback;
};

const hasNameConflict = (nodes: WorkflowNodeModel[], name: string, excludeNodeId?: string): boolean => {
    const targetKey = toNameKey(name);
    return nodes.some((node) => node.id !== excludeNodeId && toNameKey(node.name) === targetKey);
};

export const buildUniqueNodeName = (workflow: WorkflowDefinition, desiredName: unknown, excludeNodeId?: string): string => {
    const baseName = normalizeNodeName(desiredName);
    if (!hasNameConflict(workflow.nodes, baseName, excludeNodeId)) {
        return baseName;
    }

    let suffix = 2;
    while (hasNameConflict(workflow.nodes, `${baseName} ${suffix}`, excludeNodeId)) {
        suffix += 1;
    }

    return `${baseName} ${suffix}`;
};

export const claimUniqueNodeName = (desiredName: unknown, usedNames: Set<string>, fallback?: string): string => {
    const baseName = normalizeNodeName(desiredName, fallback ?? DEFAULT_NODE_NAME);
    let nextName = baseName;
    let suffix = 2;

    while (usedNames.has(toNameKey(nextName))) {
        nextName = `${baseName} ${suffix}`;
        suffix += 1;
    }

    usedNames.add(toNameKey(nextName));
    return nextName;
};
