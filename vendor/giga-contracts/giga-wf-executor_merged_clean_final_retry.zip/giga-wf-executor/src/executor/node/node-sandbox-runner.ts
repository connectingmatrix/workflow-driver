import { ChildProcess, fork } from 'node:child_process';
import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import path from 'node:path';
import {
    WorkflowCommandToolSpec,
    WorkerExecuteHelpers,
    WorkerValidateResult,
    WorkflowControlNodeExecuteArgs,
    WorkflowControlNodeExecuteInputsArgs,
    WorkflowControlNodePatch,
    WorkflowControlNodeValidateArgs,
    WorkflowNodeHandler,
    WorkflowNodeHandlerContext,
    WorkflowNodeHandlerResult,
    WorkflowNodeModel,
    WorkflowNodeSchema
} from '../../types';
import { applyControlNodePatch, buildControlNodeSnapshot, normalizeControlNodeSchema, persistControlNodePatch } from '../core/compiler/control-node-facade';
import { executeControlPeerInputs } from '../core/compiler/control-node-input-execution';
import { buildControlPeerContext, persistControlPeerFailure, persistControlPeerResult } from '../core/compiler/control-node-peer-execution';
import {
    createRegisteredWorkerRuntimeHelpers,
    createWorkerHelperId,
    registerWorkerRuntimeHelpers,
    resolveNodeSourceFilesFromHelper,
    resolvePreviewValidatorSource,
    resolveWorkerSource,
    toErrorResult,
    unregisterWorkerRuntimeHelpers
} from '../core/compiler/worker-module-loader';

export interface NodeSandboxWorkerNodeRunnerArgs {
    modelId: string;
    executeHelpers?: WorkerExecuteHelpers;
}

type SandboxChildRunMode = 'execute' | 'validate' | 'commandToolSpec';

interface SandboxChildRunRequest {
    type: 'run';
    mode?: SandboxChildRunMode;
    modelId: string;
    tempDir: string;
    workerEntryPath: string;
    validatorEntryPath?: string | null;
    resolutionBaseDir: string;
    timeoutMs?: number;
    context: {
        node: WorkflowNodeHandlerContext['node'];
        workflow: WorkflowNodeHandlerContext['workflow'];
        settings: WorkflowNodeHandlerContext['settings'];
        input: WorkflowNodeHandlerContext['input'];
        hostContext?: unknown;
        credential?: WorkflowNodeHandlerContext['credential'];
    };
}

type SandboxChildHelperRequest = {
    type: 'helper_request';
    callId: string;
    helper:
        | 'executeGigaService'
        | 'executeBackend'
        | 'compileWorkflowCypher'
        | 'invokeConnectedNode'
        | 'updateNode'
        | 'controlNodeGet'
        | 'controlNodeGetSchema'
        | 'controlNodeSet'
        | 'controlNodeValidate'
        | 'controlNodeExecuteInputs'
        | 'controlNodeCommandToolSpec'
        | 'controlNodeExecute';
    args: unknown[];
};

type SandboxChildHelperResponse = {
    type: 'helper_response';
    callId: string;
    ok: boolean;
    value?: unknown;
    error?: string;
};

type SandboxChildResultMessage = {
    type: 'result';
    result: WorkflowNodeHandlerResult | WorkerValidateResult | WorkflowCommandToolSpec | null;
};

type SandboxChildErrorMessage = {
    type: 'error';
    error: string;
};

type SandboxPoolChild = {
    child: ChildProcess;
    childScriptPath: string;
    key: string;
    resolutionBaseDir: string;
    rootDir: string;
    runs: number;
    sharedDrive?: { path?: string; access?: string } | null;
};

const runtimeRequire = createRequire(path.join(process.cwd(), '__workflow_executor__.cjs'));
const sandboxPools = new Map<string, SandboxPoolChild[]>();
const sandboxPoolWaiters = new Map<string, Array<(child: SandboxPoolChild) => void>>();
const sandboxPoolCounts = new Map<string, number>();

const sandboxPoolSize = (): number => Math.max(0, Number(process.env.WORKFLOW_NODE_SANDBOX_POOL_SIZE || process.env.WORKFLOW_SANDBOX_POOL_SIZE || 40) || 0);
const sandboxPoolMaxRuns = (): number => Math.max(1, Number(process.env.WORKFLOW_NODE_SANDBOX_CHILD_MAX_RUNS || 100) || 100);
const readNodeSchema = (context: WorkflowNodeHandlerContext, modelId: string): WorkflowNodeSchema | undefined =>
    context.workflow.nodeModels?.[modelId];
const sandboxProcessApiModels = (context: WorkflowNodeHandlerContext): string[] =>
    Object.entries(context.workflow.nodeModels || {})
        .filter(([, schema]) => schema.sandbox?.allowProcessApis === true)
        .map(([modelId]) => modelId.toLowerCase());
const sandboxAllowsProcessApis = (context: WorkflowNodeHandlerContext, modelId: string): boolean =>
    sandboxProcessApiModels(context).some((entry) => modelId.toLowerCase().startsWith(entry));
const sandboxTransport = (context: WorkflowNodeHandlerContext, modelId: string): string =>
    readNodeSchema(context, modelId)?.sandbox?.transport || 'worker-sandbox';
const sandboxPoolKey = (params: { childScriptPath: string; resolutionBaseDir: string; sharedDrive?: { path?: string; access?: string } | null }): string =>
    [params.childScriptPath, params.resolutionBaseDir, params.sharedDrive?.path || '', params.sharedDrive?.access || ''].join('|');

const resolveExecutorPackageRoot = (): string => {
    const resolvedEntry = runtimeRequire.resolve('@workflow/executor');
    return path.dirname(path.dirname(resolvedEntry));
};

const resolveSandboxChildScriptPath = (): string => {
    const packageRoot = resolveExecutorPackageRoot();
    const candidates = [
        path.join(process.cwd(), 'scripts', 'node-sandbox-child.mjs'),
        path.join(process.cwd(), 'dist', 'scripts', 'node-sandbox-child.mjs'),
        path.join(packageRoot, 'scripts', 'node-sandbox-child.mjs'),
        path.join(packageRoot, 'dist', 'scripts', 'node-sandbox-child.mjs')
    ];

    const match = candidates.find((candidate) => existsSync(candidate));
    if (!match) {
        throw new Error('Unable to locate node sandbox child runtime script.');
    }
    return match;
};

const findAncestorNodeModules = (startDir: string): string[] => {
    const results = new Set<string>();
    let current = path.resolve(startDir);

    while (true) {
        const nodeModulesPath = path.join(current, 'node_modules');
        if (existsSync(nodeModulesPath)) {
            results.add(nodeModulesPath);
        }
        const packageJsonPath = path.join(current, 'package.json');
        if (existsSync(packageJsonPath)) {
            results.add(packageJsonPath);
        }
        const parent = path.dirname(current);
        if (parent === current) break;
        current = parent;
    }

    return [...results];
};

const resolveModuleReadRoots = (specifier: string): string[] => {
    try {
        const resolved = runtimeRequire.resolve(specifier);
        return [resolved, path.dirname(resolved)];
    } catch {
        const packageRoot = resolveNodeModulePackageRoot(specifier);
        return packageRoot ? [packageRoot] : [];
    }
};

const resolveNodeModulePackageRoot = (specifier: string): string | null => {
    let current = path.resolve(process.cwd());
    while (true) {
        const packageRoot = path.join(current, 'node_modules', specifier);
        if (existsSync(path.join(packageRoot, 'package.json'))) return packageRoot;
        const parent = path.dirname(current);
        if (parent === current) return null;
        current = parent;
    }
};

const collectPermissionReadRoots = (params: {
    tempDir: string;
    childScriptPath: string;
    resolutionBaseDir: string;
}): string[] => {
    const roots = new Set<string>([
        params.tempDir,
        params.childScriptPath,
        path.dirname(params.childScriptPath)
    ]);

    findAncestorNodeModules(params.resolutionBaseDir).forEach((entry) => roots.add(entry));
    findAncestorNodeModules(path.dirname(params.childScriptPath)).forEach((entry) => roots.add(entry));
    resolveModuleReadRoots('isolated-vm').forEach((entry) => roots.add(entry));
    resolveModuleReadRoots('typescript').forEach((entry) => roots.add(entry));
    resolveModuleReadRoots('@workflow/nodes').forEach((entry) => roots.add(entry));
    resolveModuleReadRoots('@workflow/executor').forEach((entry) => roots.add(entry));
    resolveModuleReadRoots('@workflow/charts').forEach((entry) => roots.add(entry));

    return [...roots];
};

const sandboxExecArgv = (params: { readRoots: string[]; writeRoots: string[]; allowProcessApis?: boolean }): string[] => {
    const processApiFlags = params.allowProcessApis ? ['--allow-worker', '--allow-child-process'] : [];
    return [
        '--no-node-snapshot',
        '--experimental-permission',
        '--allow-addons',
        ...processApiFlags,
        ...toPermissionFsFlags('--allow-fs-read', params.readRoots),
        ...toPermissionFsFlags('--allow-fs-write', params.writeRoots)
    ];
};

const removePoolChild = (entry: SandboxPoolChild): void => {
    const count = sandboxPoolCounts.get(entry.key) || 0;
    sandboxPoolCounts.set(entry.key, Math.max(0, count - 1));
    sandboxPools.set(entry.key, (sandboxPools.get(entry.key) || []).filter((candidate) => candidate !== entry));
};

const closePoolChild = (entry: SandboxPoolChild): void => {
    removePoolChild(entry);
    if (entry.child.connected) entry.child.send({ type: 'shutdown' });
    if (!entry.child.killed) setTimeout(() => entry.child.kill('SIGKILL'), 250).unref();
    void fs.rm(entry.rootDir, { recursive: true, force: true });
};

const waitForPoolChildReady = async (child: ChildProcess, rootDir: string): Promise<void> =>
    await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            cleanup();
            reject(new Error('Sandbox worker process did not become ready in time.'));
        }, Number(process.env.WORKFLOW_NODE_SANDBOX_READY_TIMEOUT_MS || 15000));
        const cleanup = () => {
            clearTimeout(timeout);
            child.off('message', onMessage);
            child.off('error', onError);
            child.off('exit', onExit);
        };
        const onMessage = (message: unknown) => {
            if ((message as { type?: string } | null)?.type !== 'ready') return;
            cleanup();
            resolve();
        };
        const onError = (error: Error) => {
            cleanup();
            reject(error);
        };
        const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
            cleanup();
            void fs.rm(rootDir, { recursive: true, force: true });
            reject(new Error(`Sandbox worker process exited before ready (code=${String(code ?? 'null')}, signal=${String(signal ?? 'null')}).`));
        };
        child.on('message', onMessage);
        child.once('error', onError);
        child.once('exit', onExit);
    });

const waitForPoolChildIdle = async (child: ChildProcess): Promise<void> =>
    await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            cleanup();
            reject(new Error('Sandbox worker process did not become idle in time.'));
        }, Number(process.env.WORKFLOW_NODE_SANDBOX_READY_TIMEOUT_MS || 15000));
        const cleanup = () => {
            clearTimeout(timeout);
            child.off('message', onMessage);
            child.off('error', onError);
            child.off('exit', onExit);
        };
        const onMessage = (message: unknown) => {
            if ((message as { type?: string } | null)?.type !== 'idle') return;
            cleanup();
            resolve();
        };
        const onError = (error: Error) => {
            cleanup();
            reject(error);
        };
        const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
            cleanup();
            reject(new Error(`Sandbox worker process exited before idle (code=${String(code ?? 'null')}, signal=${String(signal ?? 'null')}).`));
        };
        child.on('message', onMessage);
        child.once('error', onError);
        child.once('exit', onExit);
    });

const createPoolChild = async (params: {
    childScriptPath: string;
    key: string;
    resolutionBaseDir: string;
    sharedDrive?: { path?: string; access?: string } | null;
}): Promise<SandboxPoolChild> => {
    const rootDir = await fs.mkdtemp(path.join(tmpdir(), 'workflow-executor-sandbox-pool-'));
    const readRoots = collectPermissionReadRoots({ tempDir: rootDir, childScriptPath: params.childScriptPath, resolutionBaseDir: params.resolutionBaseDir });
    if (params.sharedDrive?.path) readRoots.push(params.sharedDrive.path);
    const writeRoots = params.sharedDrive?.access === 'readwrite' && params.sharedDrive.path ? [rootDir, params.sharedDrive.path] : [rootDir];
    const child = fork(params.childScriptPath, [], {
        cwd: rootDir,
        execArgv: sandboxExecArgv({ readRoots, writeRoots }),
        env: createSandboxEnv(rootDir),
        silent: true,
        stdio: ['ignore', 'pipe', 'pipe', 'ipc']
    });
    const entry = {
        child,
        childScriptPath: params.childScriptPath,
        key: params.key,
        resolutionBaseDir: params.resolutionBaseDir,
        rootDir,
        runs: 0,
        sharedDrive: params.sharedDrive
    };
    sandboxPoolCounts.set(params.key, (sandboxPoolCounts.get(params.key) || 0) + 1);
    await waitForPoolChildReady(child, rootDir);
    child.once('exit', () => {
        removePoolChild(entry);
        void fs.rm(rootDir, { recursive: true, force: true });
    });
    return entry;
};

const acquirePoolChild = async (params: {
    childScriptPath: string;
    resolutionBaseDir: string;
    sharedDrive?: { path?: string; access?: string } | null;
}): Promise<SandboxPoolChild | null> => {
    const size = sandboxPoolSize();
    if (size <= 0) return null;
    const key = sandboxPoolKey({ childScriptPath: params.childScriptPath, resolutionBaseDir: params.resolutionBaseDir, sharedDrive: params.sharedDrive });
    const available = sandboxPools.get(key)?.pop();
    if (available && available.child.connected && !available.child.killed) return available;
    if ((sandboxPoolCounts.get(key) || 0) < size) return createPoolChild({ ...params, key });
    return new Promise((resolve) => {
        const waiters = sandboxPoolWaiters.get(key) || [];
        waiters.push(resolve);
        sandboxPoolWaiters.set(key, waiters);
    });
};

export const prewarmSandboxedNodeWorkerPool = async (count = sandboxPoolSize()): Promise<number> => {
    const size = sandboxPoolSize();
    if (size <= 0) return 0;
    const childScriptPath = resolveSandboxChildScriptPath();
    const resolutionBaseDir = process.cwd();
    const key = sandboxPoolKey({ childScriptPath, resolutionBaseDir, sharedDrive: null });
    const target = Math.min(size, Math.max(0, count));
    const current = sandboxPoolCounts.get(key) || 0;
    const needed = Math.max(0, target - current);
    await Promise.all(
        Array.from({ length: needed }, async () => {
            const child = await createPoolChild({ childScriptPath, key, resolutionBaseDir, sharedDrive: null });
            releasePoolChild(child);
        })
    );
    return needed;
};

const releasePoolChild = (entry: SandboxPoolChild): void => {
    if (!entry.child.connected || entry.child.killed || entry.runs >= sandboxPoolMaxRuns()) {
        const waiter = (sandboxPoolWaiters.get(entry.key) || []).shift();
        closePoolChild(entry);
        if (waiter) void createPoolChild(entry).then(waiter);
        return;
    }
    const waiter = (sandboxPoolWaiters.get(entry.key) || []).shift();
    if (waiter) {
        waiter(entry);
        return;
    }
    sandboxPools.set(entry.key, [...(sandboxPools.get(entry.key) || []), entry]);
};

const toSandboxSerializable = (value: unknown, seen = new WeakSet<object>(), depth = 0): unknown => {
    if (depth > 12) return undefined;
    if (
        value == null ||
        typeof value === 'string' ||
        typeof value === 'number' ||
        typeof value === 'boolean'
    ) {
        return value;
    }

    if (typeof value === 'bigint') {
        return Number(value);
    }

    if (value instanceof Date) {
        return value.toISOString();
    }

    if (value instanceof Error) {
        return {
            name: value.name,
            message: value.message,
            stack: value.stack
        };
    }

    if (Buffer.isBuffer(value)) {
        return Buffer.from(value);
    }

    if (ArrayBuffer.isView(value)) {
        return Buffer.from(value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength));
    }

    if (value instanceof ArrayBuffer) {
        return Buffer.from(value.slice(0));
    }

    if (typeof value === 'function' || typeof value === 'symbol') {
        return undefined;
    }

    if (Array.isArray(value)) {
        if (seen.has(value)) return undefined;
        seen.add(value);
        const entries: unknown[] = [];
        for (const entry of value) {
            entries.push(toSandboxSerializable(entry, seen, depth + 1));
        }
        seen.delete(value);
        return entries;
    }

    if (typeof value === 'object') {
        const objectValue = value as object;
        if (seen.has(objectValue)) return undefined;
        seen.add(objectValue);
        const out: Record<string, unknown> = {};
        Object.entries(value as Record<string, unknown>).forEach(([key, entry]) => {
            const normalized = toSandboxSerializable(entry, seen, depth + 1);
            if (typeof normalized !== 'undefined') {
                out[key] = normalized;
            }
        });
        seen.delete(objectValue);
        return out;
    }

    return undefined;
};

const createSandboxEnv = (tempDir: string): NodeJS.ProcessEnv => ({
    PATH: process.env.PATH ?? '',
    HOME: tempDir,
    USERPROFILE: tempDir,
    TMPDIR: tempDir,
    TMP: tempDir,
    TEMP: tempDir,
    NODE_NO_WARNINGS: '1'
});

const sandboxSharedDrive = (context: WorkflowNodeHandlerContext) => {
    const value = context.settings.sharedDrive;
    if (!value || value.virtualPath !== '/drive' || typeof value.path !== 'string') return null;
    return {
        access: value.access === 'readwrite' ? 'readwrite' : 'read',
        path: path.resolve(value.path)
    };
};

const toPermissionFsFlags = (flagName: string, values: string[]): string[] =>
    values.map((value) => `${flagName}=${value}`);

const normalizeChildError = (error: unknown): string =>
    error instanceof Error ? error.message : typeof error === 'string' && error.trim().length > 0 ? error : 'Sandbox worker execution failed.';

const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as T)
        : ({} as T);

const resolveControlNode = (context: WorkflowNodeHandlerContext, nodeId: string): WorkflowNodeModel => {
    const node = context.workflow.nodes.find((entry) => entry.id === nodeId);
    if (!node) throw new Error(`Control node "${nodeId}" was not found.`);
    return node;
};

const buildControlNodeContext = (
    context: WorkflowNodeHandlerContext,
    nodeId: string,
    args?: WorkflowControlNodeValidateArgs | WorkflowControlNodeExecuteArgs
): WorkflowNodeHandlerContext => {
    const baseNode = resolveControlNode(context, nodeId);
    const patchedNode = args?.patch ? applyControlNodePatch(baseNode, args.patch) : baseNode;
    return {
        ...context,
        node: patchedNode,
        input: args?.input ?? toRecord(patchedNode.ports?.in)
    };
};

const compactControlPeerOutput = (value: unknown): unknown => {
    const record = toRecord(value);
    if (Object.keys(record).length === 0) return value;
    const raw = toRecord(record.raw);
    if (Object.keys(raw).length === 0) return value;
    return {
        ...record,
        raw: {
            id: raw.id,
            model: raw.model,
            status: raw.status,
            output_text: raw.output_text,
            usage: raw.usage
        }
    };
};

const compactControlPeerExecution = (value: { node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }) => ({
    result: {
        ...value.result,
        output: compactControlPeerOutput(value.result.output)
    }
});

const executeSandboxedControlPeer = async (params: {
    context: WorkflowNodeHandlerContext;
    nodeId: string;
    input?: Record<string, Record<string, unknown>>;
    patch?: WorkflowControlNodePatch;
    executeHelpers?: WorkerExecuteHelpers;
}): Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }> => {
    const peerContext = buildControlPeerContext(params.context, params.nodeId, params.input, params.patch);
    try {
        const result = (await runSandboxedNodeWorker(
            {
                modelId: peerContext.node.modelId,
                executeHelpers: params.executeHelpers
            },
            peerContext,
            'execute'
        )) as WorkflowNodeHandlerResult;
        const nextNode = persistControlPeerResult(peerContext.workflow, params.nodeId, peerContext.input, result);
        return { node: nextNode, result };
    } catch (error) {
        const failedNode = persistControlPeerFailure(peerContext.workflow, params.nodeId, error);
        throw Object.assign(error instanceof Error ? error : new Error(String(error)), {
            node: failedNode
        });
    }
};

const readSandboxedCommandToolSpec = async (params: {
    context: WorkflowNodeHandlerContext;
    nodeId: string;
    executeHelpers?: WorkerExecuteHelpers;
}): Promise<WorkflowCommandToolSpec | null> => {
    const peerContext = buildControlNodeContext(params.context, params.nodeId);
    const result = await runSandboxedNodeWorker(
        {
            modelId: peerContext.node.modelId,
            executeHelpers: params.executeHelpers
        },
        peerContext,
        'commandToolSpec'
    );
    return (result as WorkflowCommandToolSpec | null) ?? null;
};

const buildSandboxFailure = (mode: SandboxChildRunMode, message: string): WorkflowNodeHandlerResult | WorkerValidateResult | null => {
    if (mode === 'commandToolSpec') return null;
    return mode === 'validate' ? { ok: false, errors: [message], warnings: [] } : toErrorResult(message);
};

function runSandboxedNodeWorker(
    args: NodeSandboxWorkerNodeRunnerArgs,
    context: WorkflowNodeHandlerContext,
    mode: 'execute'
): Promise<WorkflowNodeHandlerResult>;
function runSandboxedNodeWorker(
    args: NodeSandboxWorkerNodeRunnerArgs,
    context: WorkflowNodeHandlerContext,
    mode: 'validate'
): Promise<WorkerValidateResult>;
function runSandboxedNodeWorker(
    args: NodeSandboxWorkerNodeRunnerArgs,
    context: WorkflowNodeHandlerContext,
    mode: 'commandToolSpec'
): Promise<WorkflowCommandToolSpec | null>;
async function runSandboxedNodeWorker(
    args: NodeSandboxWorkerNodeRunnerArgs,
    context: WorkflowNodeHandlerContext,
    mode: SandboxChildRunMode
): Promise<WorkflowNodeHandlerResult | WorkerValidateResult | WorkflowCommandToolSpec | null> {
    let tempDir: string | null = null;
    const helperId = createWorkerHelperId(context);

    try {
        const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
            executeHelpers: args.executeHelpers,
            context,
            modelId: args.modelId
        });
        const workerSource = resolveWorkerSource({
            modelId: args.modelId,
            workflow: context.workflow,
            resolvedSourceFiles
        });
        const validatorSource = resolvePreviewValidatorSource({
            modelId: args.modelId,
            workflow: context.workflow,
            resolvedSourceFiles
        });
        const helperBindings = createRegisteredWorkerRuntimeHelpers({
            executeHelpers: args.executeHelpers,
            context
        });
        registerWorkerRuntimeHelpers(helperId, helperBindings);
        const childScriptPath = resolveSandboxChildScriptPath();
        const sharedDrive = sandboxSharedDrive(context);
        const allowProcessApis = sandboxAllowsProcessApis(context, args.modelId);
        const useOpenAiUnixSandbox = sandboxTransport(context, args.modelId) === 'openai-unix-sandbox';
        const pooledChild = allowProcessApis
            ? null
            : await acquirePoolChild({ childScriptPath, resolutionBaseDir: process.cwd(), sharedDrive });
        tempDir = await fs.mkdtemp(path.join(pooledChild?.rootDir || tmpdir(), 'workflow-executor-sandbox-'));
        const workerEntryPath = path.join(tempDir, 'worker.ts');
        const validatorEntryPath = validatorSource ? path.join(tempDir, 'validate.ts') : null;
        const timeoutMs =
            typeof context.settings.maxExecutionSeconds === 'number' && context.settings.maxExecutionSeconds > 0
                ? context.settings.maxExecutionSeconds * 1000
                : undefined;

        await fs.writeFile(workerEntryPath, workerSource.source, 'utf8');
        if (validatorEntryPath && validatorSource) {
            await fs.writeFile(validatorEntryPath, validatorSource.source, 'utf8');
        }
        if (resolvedSourceFiles) {
            for (const [fileName, source] of Object.entries(resolvedSourceFiles)) {
                if (fileName === 'worker.ts' || fileName === 'validate.ts') continue;
                if (typeof source !== 'string' || !source.trim()) continue;
                const targetPath = path.join(tempDir, fileName);
                await fs.mkdir(path.dirname(targetPath), { recursive: true });
                await fs.writeFile(targetPath, source, 'utf8');
            }
        }

        const fallbackReadRoots = collectPermissionReadRoots({ tempDir, childScriptPath, resolutionBaseDir: process.cwd() });
        if (sharedDrive) fallbackReadRoots.push(sharedDrive.path);
        const fallbackWriteRoots = sharedDrive?.access === 'readwrite' ? [tempDir, sharedDrive.path] : [tempDir];
        const child =
            pooledChild?.child ||
            fork(childScriptPath, [], {
                cwd: tempDir,
                execArgv: sandboxExecArgv({
                    readRoots: fallbackReadRoots,
                    writeRoots: fallbackWriteRoots,
                    allowProcessApis: allowProcessApis && !useOpenAiUnixSandbox
                }),
                env: createSandboxEnv(tempDir),
                silent: true,
                stdio: ['ignore', 'pipe', 'pipe', 'ipc']
            });

        const result = await new Promise<WorkflowNodeHandlerResult | WorkerValidateResult | WorkflowCommandToolSpec | null>((resolve) => {
            let settled = false;
            let timeoutHandle: ReturnType<typeof setTimeout> | undefined;
            let stderrBuffer = '';
            const onStdout = () => undefined;
            const onStderr = (chunk: unknown) => {
                stderrBuffer += String(chunk ?? '');
            };
            const onMessage = async (message: SandboxChildHelperRequest | SandboxChildResultMessage | SandboxChildErrorMessage) => {
                if (!message || settled) return;
                if (message.type === 'helper_request') {
                    try {
                        const value = await invokeHelper(message.helper, Array.isArray(message.args) ? message.args : []);
                        await reply({ type: 'helper_response', callId: message.callId, ok: true, value: toSandboxSerializable(value) });
                    } catch (error) {
                        await reply({ type: 'helper_response', callId: message.callId, ok: false, error: normalizeChildError(error) });
                    }
                    return;
                }
                if (message.type === 'result') {
                    settle(message.result);
                    return;
                }
                if (message.type === 'error') {
                    settle(buildSandboxFailure(mode, message.error));
                }
            };
            const onError = (error: Error) => {
                settle(buildSandboxFailure(mode, normalizeChildError(error)));
            };
            const onExit = (code: number | null, signal: NodeJS.Signals | null) => {
                if (settled) return;
                settle(
                    buildSandboxFailure(
                        mode,
                        `Sandbox worker process exited before returning a result (code=${String(code ?? 'null')}, signal=${String(signal ?? 'null')}).${stderrBuffer.trim().length > 0 ? ` ${stderrBuffer.trim()}` : ''}`
                    )
                );
            };
            const settle = (value: WorkflowNodeHandlerResult | WorkerValidateResult | WorkflowCommandToolSpec | null) => {
                if (settled) return;
                settled = true;
                clearTimeout(timeoutHandle);
                context.signal?.removeEventListener('abort', abortListener);
                child.off('message', onMessage);
                child.off('error', onError);
                child.off('exit', onExit);
                child.stdout?.off('data', onStdout);
                child.stderr?.off('data', onStderr);
                if (pooledChild) {
                    pooledChild.runs += 1;
                    if (child.connected && !child.killed) {
                        void waitForPoolChildIdle(child)
                            .then(() => releasePoolChild(pooledChild))
                            .catch(() => closePoolChild(pooledChild));
                    } else {
                        closePoolChild(pooledChild);
                    }
                } else if (child.connected) {
                    child.disconnect();
                    if (!child.killed) child.kill('SIGKILL');
                } else if (!child.killed) {
                    child.kill('SIGKILL');
                }
                resolve(value);
            };

            const sendChildMessage = async (message: SandboxChildHelperResponse | SandboxChildRunRequest) =>
                await new Promise<void>((resolve, reject) => {
                    if (!child.connected) {
                        resolve();
                        return;
                    }
                    child.send(message, (error) => {
                        if (error) {
                            reject(error);
                            return;
                        }
                        resolve();
                    });
                });

            const reply = async (message: SandboxChildHelperResponse) => {
                await sendChildMessage(message);
            };

            const invokeHelper = async (helper: SandboxChildHelperRequest['helper'], helperArgs: unknown[]): Promise<unknown> => {
                switch (helper) {
                    case 'executeGigaService':
                        if (helperBindings.executeGigaService) return helperBindings.executeGigaService(...helperArgs);
                        if (helperBindings.executeBackend) return helperBindings.executeBackend(...helperArgs);
                        throw new Error('executeGigaService helper is not available.');
                    case 'executeBackend':
                        if (helperBindings.executeBackend) return helperBindings.executeBackend(...helperArgs);
                        if (helperBindings.executeGigaService) return helperBindings.executeGigaService(...helperArgs);
                        throw new Error('executeBackend helper is not available.');
                    case 'compileWorkflowCypher':
                        if (!helperBindings.compileWorkflowCypher) throw new Error('compileWorkflowCypher helper is not available.');
                        return helperBindings.compileWorkflowCypher(...helperArgs);
                    case 'invokeConnectedNode':
                        if (!helperBindings.invokeConnectedNode) throw new Error('invokeConnectedNode helper is not available.');
                        return helperBindings.invokeConnectedNode(...helperArgs);
                    case 'updateNode':
                        if (!helperBindings.updateNode) return null;
                        return helperBindings.updateNode(helperArgs[0], helperArgs[1], helperArgs[2]);
                    case 'controlNodeGet': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        return buildControlNodeSnapshot(context.workflow, nodeId);
                    }
                    case 'controlNodeGetSchema': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        return normalizeControlNodeSchema(context.workflow, nodeId);
                    }
                    case 'controlNodeSet': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        const patch = toRecord<WorkflowControlNodePatch>(helperArgs[1]);
                        persistControlNodePatch(context.workflow, nodeId, patch);
                        return buildControlNodeSnapshot(context.workflow, nodeId);
                    }
                    case 'controlNodeValidate': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        const validationArgs = toRecord<WorkflowControlNodeValidateArgs>(helperArgs[1]);
                        const peerContext = buildControlNodeContext(context, nodeId, validationArgs);
                        return runSandboxedNodeWorker({ modelId: peerContext.node.modelId, executeHelpers: args.executeHelpers }, peerContext, 'validate');
                    }
                    case 'controlNodeExecuteInputs': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        const executeInputsArgs = toRecord<WorkflowControlNodeExecuteInputsArgs>(helperArgs[1]);
                        return executeControlPeerInputs({
                            context,
                            nodeId,
                            args: executeInputsArgs,
                            executePeer: async ({ nodeId: upstreamNodeId }) => {
                                const executed = await executeSandboxedControlPeer({
                                    context,
                                    nodeId: upstreamNodeId,
                                    executeHelpers: args.executeHelpers
                                });
                                return { node: executed.node };
                            }
                        });
                    }
                    case 'controlNodeCommandToolSpec': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        return readSandboxedCommandToolSpec({
                            context,
                            nodeId,
                            executeHelpers: args.executeHelpers
                        });
                    }
                    case 'controlNodeExecute': {
                        const nodeId = typeof helperArgs[0] === 'string' ? helperArgs[0] : context.node.id;
                        const executeArgs = toRecord<WorkflowControlNodeExecuteArgs>(helperArgs[1]);
                        return compactControlPeerExecution(await executeSandboxedControlPeer({
                            context,
                            nodeId,
                            input: executeArgs.input,
                            patch: executeArgs.patch,
                            executeHelpers: args.executeHelpers
                        }));
                    }
                }
            };

            child.stdout?.on('data', onStdout);
            child.stderr?.on('data', onStderr);
            child.on('message', onMessage);
            child.once('error', onError);
            child.once('exit', onExit);

            const abortListener = () => {
                settle(buildSandboxFailure(mode, 'Sandbox worker execution aborted.'));
            };
            if (context.signal) {
                if (context.signal.aborted) {
                    abortListener();
                    return;
                }
                context.signal.addEventListener('abort', abortListener, { once: true });
            }

            timeoutHandle =
                typeof timeoutMs === 'number' && timeoutMs > 0
                    ? setTimeout(() => settle(buildSandboxFailure(mode, `Sandbox worker execution timed out after ${timeoutMs}ms.`)), timeoutMs)
                    : undefined;

            const request: SandboxChildRunRequest = {
                type: 'run',
                mode,
                modelId: args.modelId,
                tempDir: tempDir!,
                workerEntryPath,
                validatorEntryPath,
                resolutionBaseDir: process.cwd(),
                timeoutMs,
                context: {
                    node: toSandboxSerializable(context.node) as WorkflowNodeHandlerContext['node'],
                    workflow: toSandboxSerializable(context.workflow) as WorkflowNodeHandlerContext['workflow'],
                    settings: toSandboxSerializable(context.settings) as WorkflowNodeHandlerContext['settings'],
                    input: toSandboxSerializable(context.input) as WorkflowNodeHandlerContext['input'],
                    hostContext: toSandboxSerializable(context.hostContext),
                    credential: toSandboxSerializable(context.credential) as WorkflowNodeHandlerContext['credential']
                }
            };

            void sendChildMessage(request).catch((error) => {
                settle(buildSandboxFailure(mode, normalizeChildError(error)));
            });
        });

        return result;
    } catch (error) {
        const message = normalizeChildError(error);
        return buildSandboxFailure(mode, message);
    } finally {
        unregisterWorkerRuntimeHelpers(helperId);
        if (tempDir) {
            await fs.rm(tempDir, { recursive: true, force: true });
        }
    }
}

export const createSandboxedNodeWorkerNodeRunner =
    (args: NodeSandboxWorkerNodeRunnerArgs): WorkflowNodeHandler =>
    async (context) =>
        (await runSandboxedNodeWorker(args, context, 'execute')) as WorkflowNodeHandlerResult;
