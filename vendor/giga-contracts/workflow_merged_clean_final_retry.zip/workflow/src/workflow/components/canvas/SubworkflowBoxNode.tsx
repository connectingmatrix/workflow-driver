import React from 'react';
import { NodeProps } from '@xyflow/react';

export interface SubworkflowBoxNodeData {
    title: string;
    onCollapse?: () => void;
}

const SubworkflowBoxNodeComponent: React.FC<NodeProps> = ({ data, selected }) => {
    const nodeData = data as unknown as SubworkflowBoxNodeData;
    return (
        <div className={`wf-subworkflow wf-subworkflow--box ${selected ? 'wf-subworkflow--selected' : ''}`}>
            <div className="wf-subworkflow__box-header">
                <span>{nodeData.title}</span>
                <button
                    type="button"
                    className="wf-subworkflow__action-btn nodrag"
                    onMouseDown={(event) => {
                        event.stopPropagation();
                    }}
                    onClick={(event) => {
                        event.stopPropagation();
                        nodeData.onCollapse?.();
                    }}
                >
                    Collapse
                </button>
            </div>
        </div>
    );
};

const areSubworkflowBoxNodePropsEqual = (previous: NodeProps, next: NodeProps): boolean => {
    const previousData = previous.data as unknown as SubworkflowBoxNodeData;
    const nextData = next.data as unknown as SubworkflowBoxNodeData;
    return previous.selected === next.selected && previousData.title === nextData.title;
};

const SubworkflowBoxNode = React.memo(SubworkflowBoxNodeComponent, areSubworkflowBoxNodePropsEqual);

export default SubworkflowBoxNode;
