import type { WorkflowQueueEvent, WorkflowQueueKafkaMessage, WorkflowQueueRequest } from './types';

const parseJsonPayload = <TValue>(payload: Buffer | string | null): TValue | null => {
  const raw = typeof payload === 'string' ? payload : payload?.toString('utf8') || '';
  if (!raw.trim()) return null;
  return JSON.parse(raw) as TValue;
};

export const parseWorkflowQueueRequest = (payload: Buffer | string | null): WorkflowQueueRequest | null =>
  parseJsonPayload<WorkflowQueueRequest>(payload);

export const parseWorkflowQueueEvent = (payload: Buffer | string | null): WorkflowQueueEvent | null =>
  parseJsonPayload<WorkflowQueueEvent>(payload);

export const toWorkflowQueueRequestMessage = (request: WorkflowQueueRequest): WorkflowQueueKafkaMessage => ({
  key: request.queueKey,
  value: JSON.stringify(request),
  headers: {
    executionId: request.executionId,
    runId: request.runId,
    userId: request.userId,
    broadcastId: request.broadcastId,
    broadcastChannelName: request.broadcastChannelName,
    triggerType: request.triggerType,
  },
});

export const toWorkflowQueueEventMessage = (event: WorkflowQueueEvent): WorkflowQueueKafkaMessage => ({
  key: event.userId,
  value: JSON.stringify(event),
  headers: {
    executionId: event.executionId,
    runId: event.runId,
    workflowId: event.workflowId,
    broadcastId: event.broadcastId,
    broadcastChannelName: event.broadcastChannelName,
    type: event.type,
    triggerType: event.triggerType,
  },
});
