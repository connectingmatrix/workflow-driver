import { describe, expect, it } from 'vitest';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

const forbiddenTokens = [
    'ai_' + 'workflowsCollection',
    'insertInto' + 'ai_',
    'ai_' + 'chat_messagesCollection',
    'services/workflow/nodes/' + 'node-handlers.ts'
];

function collectFiles(root: string): string[] {
    const files: string[] = [];
    if (!existsSync(root)) return files;
    for (const entry of readdirSync(root)) {
        const path = join(root, entry);
        if (statSync(path).isDirectory()) {
            files.push(...collectFiles(path));
            continue;
        }
        if (/\.(ts|tsx|js|mjs|json|md)$/.test(entry)) files.push(path);
    }
    return files;
}

describe('executor package boundary', () => {
    it('does not embed Giga query strings or backend service paths', () => {
        const offenders: string[] = [];
        for (const file of collectFiles(join(process.cwd(), 'src'))) {
            const source = readFileSync(file, 'utf8');
            for (const token of forbiddenTokens) {
                if (source.includes(token)) offenders.push(`${file}: ${token}`);
            }
        }
        expect(offenders).toEqual([]);
    });
});
