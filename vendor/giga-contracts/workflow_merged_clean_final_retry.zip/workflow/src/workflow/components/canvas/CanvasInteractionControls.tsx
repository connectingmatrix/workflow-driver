import React from 'react';
import { ControlButton, Controls } from '@xyflow/react';

export type CanvasInteractionMode = 'pan' | 'select';

interface CanvasInteractionControlsProps {
    isEditable: boolean;
    isInteractive: boolean;
    interactionMode: CanvasInteractionMode;
    onInteractiveChange: (interactive: boolean) => void;
    onInteractionModeChange: (mode: CanvasInteractionMode) => void;
}

const SelectIcon = () => (
    <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M5 4l11 11-4 1-1 4-2 1-1-4-4-1z" fill="currentColor" />
        <path d="M13 13l4 4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
);

const CanvasInteractionControls: React.FC<CanvasInteractionControlsProps> = ({ isEditable, isInteractive, interactionMode, onInteractiveChange, onInteractionModeChange }) => {
    const isSelectMode = interactionMode === 'select';

    return (
        <Controls showInteractive onInteractiveChange={onInteractiveChange}>
            <ControlButton
                className={`wf-canvas-controls__mode-button${isSelectMode ? ' is-active' : ''}`}
                disabled={!isEditable || !isInteractive}
                title={isSelectMode ? 'Switch to hand mode' : 'Switch to mouse selection'}
                aria-label={isSelectMode ? 'Switch to hand mode' : 'Switch to mouse selection'}
                onClick={() => onInteractionModeChange(isSelectMode ? 'pan' : 'select')}
            >
                {isSelectMode ? <SelectIcon /> : <i className="pi pi-arrows-alt" aria-hidden />}
            </ControlButton>
        </Controls>
    );
};

export default CanvasInteractionControls;
