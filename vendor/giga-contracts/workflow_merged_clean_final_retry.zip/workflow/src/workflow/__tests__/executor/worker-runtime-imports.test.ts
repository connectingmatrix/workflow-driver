import { describe, expect, it } from 'vitest';
import { createNodeExecutorSignature, createWorkerNodeHandler, WorkflowNodeStatusEnum } from '@workflow/executor';
import { WorkflowDefinition } from '@workflow/ui/workflow/types';

const toBase64 = (source: string): string => {
    if (typeof Buffer !== 'undefined') {
        return Buffer.from(source, 'utf8').toString('base64');
    }
    return btoa(source);
};

const createWorkflow = (modelId: string, source: string): WorkflowDefinition => ({
    metadata: {
        id: 'wf_worker_imports',
        name: 'Worker Imports'
    },
    nodes: [
        {
            id: 'node_1',
            gigaId: 'node_1',
            modelId,
            type: 'workflowStep',
            name: 'Node 1',
            description: '',
            kind: 'process',
            status: WorkflowNodeStatusEnum.Stopped,
            position: { x: 0, y: 0 },
            runtime: {},
            ports: {
                in: {},
                out: {}
            }
        }
    ],
    connections: [],
    NODE_EXECUTORS: {
        [modelId]: toBase64(source)
    },
    NODE_EXECUTOR_SIGNATURES: {
        [modelId]: createNodeExecutorSignature(modelId, source)
    }
});

describe('worker runtime imports', () => {
    it('allows node built-in imports in browser mode via stubs', async () => {
        const modelId = 'worker-browser-builtins';
        const source = `
import fs from 'fs';

export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({
  output: { hasReadFileSync: typeof fs.readFileSync === 'function' },
  status: 'passed',
  logs: ['browser-builtin']
});`;

        const workflow = createWorkflow(modelId, source);
        const node = workflow.nodes[0];
        const handler = createWorkerNodeHandler({
            modelId,
            runtimeEnvironment: 'browser'
        });

        const result = await handler({
            node,
            workflow,
            settings: {
                graphqlUrl: 'http://localhost/graphql',
                authMode: 'none'
            },
            input: {}
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect((result.output as Record<string, unknown>).hasReadFileSync).toBe(true);
    });
});
