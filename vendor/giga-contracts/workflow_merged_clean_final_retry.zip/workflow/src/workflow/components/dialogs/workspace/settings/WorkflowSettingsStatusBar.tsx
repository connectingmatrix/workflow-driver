import React from 'react';

interface WorkflowSettingsStatusBarProps {
    graphqlUrl: string;
    authModeLabel: string;
}

export const WorkflowSettingsStatusBar: React.FC<WorkflowSettingsStatusBarProps> = ({ graphqlUrl, authModeLabel }) => {
    const environment = graphqlUrl.includes('localhost') || graphqlUrl.includes('127.0.0.1') ? 'local-dev' : 'connected';
    return (
        <div className="wf-workspace-settings__status-bar">
            <span className="wf-workspace-settings__status-pill">Connected</span>
            <span className="wf-workspace-settings__status-copy">Environment: {environment}</span>
            <span className="wf-workspace-settings__status-copy">• Using {authModeLabel}</span>
        </div>
    );
};
