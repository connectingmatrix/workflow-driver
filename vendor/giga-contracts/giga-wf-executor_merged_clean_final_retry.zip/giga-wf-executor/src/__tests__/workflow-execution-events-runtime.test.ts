import { describe, expect, it, vi } from 'vitest';
import { consumeWorkflowExecutionEventsRuntime } from '../pubsub/consumeWorkflowExecutionEvents';
import type { WorkflowQueueEvent } from '../queue/types';

const createEvent = (): WorkflowQueueEvent => ({
  type: 'started',
  timestamp: new Date().toISOString(),
  executionId: 'execution-1',
  runId: 'run-1',
  workflowId: 'workflow-1',
  userId: 'user-1',
  broadcastId: 'user-1',
  broadcastChannelName: 'workflow-socket',
  triggerType: 'chat',
  workflowReference: { workflowId: 'workflow-1', scope: 'user', ownerUserId: 'user-1' },
});

describe('consumeWorkflowExecutionEventsRuntime', () => {
  it('subscribes to execution events and applies parsed events', async () => {
    const event = createEvent();
    const appliedEvents: WorkflowQueueEvent[] = [];
    const messageHandlerRef: { current: ((params: { message: { value: Buffer | string | null } }) => Promise<void>) | null } = { current: null };
    const consumer = {
      connect: vi.fn(async () => undefined),
      disconnect: vi.fn(async () => undefined),
      subscribe: vi.fn(async () => undefined),
      run: vi.fn(async ({ eachMessage }) => {
        messageHandlerRef.current = eachMessage;
      }),
    };
    const runtime = consumeWorkflowExecutionEventsRuntime({
      applyExecutionEvent: async (executionEvent) => {
        appliedEvents.push(executionEvent);
      },
      consumer: consumer as any,
      eventsTopic: 'workflow-execution-events',
    });

    await runtime.start();
    await messageHandlerRef.current?.({ message: { value: JSON.stringify(event) } });

    expect(consumer.subscribe).toHaveBeenCalledWith({ topic: 'workflow-execution-events', fromBeginning: false });
    expect(appliedEvents).toEqual([event]);
    await runtime.stop();
    expect(consumer.disconnect).toHaveBeenCalledOnce();
  });

  it('forwards event handler failures to the configured error handler without rethrowing', async () => {
    const event = createEvent();
    const error = new Error('event failed');
    const messageHandlerRef: { current: ((params: { message: { value: Buffer | string | null } }) => Promise<void>) | null } = { current: null };
    const handleExecutionEventError = vi.fn(async () => undefined);
    const runtime = consumeWorkflowExecutionEventsRuntime({
      applyExecutionEvent: async () => {
        throw error;
      },
      consumer: {
        connect: vi.fn(async () => undefined),
        disconnect: vi.fn(async () => undefined),
        subscribe: vi.fn(async () => undefined),
        run: vi.fn(async ({ eachMessage }) => {
          messageHandlerRef.current = eachMessage;
        }),
      } as any,
      handleExecutionEventError,
      eventsTopic: 'workflow-execution-events',
    });

    await runtime.start();
    await expect(messageHandlerRef.current?.({ message: { value: JSON.stringify(event) } })).resolves.toBeUndefined();
    expect(handleExecutionEventError).toHaveBeenCalledWith({ error, event });
  });
});
