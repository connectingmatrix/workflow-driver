import { describe, expect, it } from 'vitest';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { layoutWorkflowGraph } from '@workflow/ui/workflow/layout';

const withElk = (workflow: ReturnType<typeof createEmptyWorkflow>) => ({
    ...workflow,
    metadata: {
        ...workflow.metadata,
        ui: {
            ...(workflow.metadata.ui ?? {}),
            canvas: { layoutEngine: 'elk', edgeStyle: 'smoothstep' }
        }
    }
});

describe('workflow layout elk engine', () => {
    it('lays out main flow from left to right', async () => {
        const base = createEmptyWorkflow('wf_layout_elk_linear');
        const workflow = withElk(base);
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];
        const arranged = await layoutWorkflowGraph(workflow);

        expect(arranged.nodes[0].position.x).toBeLessThan(arranged.nodes[1].position.x);
        expect(arranged.nodes[1].position.x).toBeLessThan(arranged.nodes[2].position.x);
    });

    it('honors command port sides for model and tool sidecars', async () => {
        const base = createEmptyWorkflow('wf_layout_elk_commands');
        const workflow = withElk(base);
        const governor = createWorkflowNode(workflow, 'ai-governor', 'Governor', 1);
        const router = createWorkflowNode(workflow, 'action-router', 'Router', 2);
        const model = createWorkflowNode(workflow, 'openai', 'Model', 3);
        const tool = createWorkflowNode(workflow, 'run-channel-action', 'Tool', 4);
        workflow.nodes = [governor, router, model, tool];
        workflow.connections = [createConnection('c1', governor.id, router.id), createConnection('c2', model.id, governor.id, 'cmd:command', 'cmd:llm'), createConnection('c3', tool.id, router.id, 'cmd:command', 'cmd:actions')];
        const arranged = await layoutWorkflowGraph(workflow);
        const elkGovernor = arranged.nodes.find((node) => node.id === governor.id);
        const elkRouter = arranged.nodes.find((node) => node.id === router.id);
        const elkModel = arranged.nodes.find((node) => node.id === model.id);
        const elkTool = arranged.nodes.find((node) => node.id === tool.id);

        expect((elkModel?.position.y || 0) > (elkGovernor?.position.y || 0)).toBe(true);
        expect((elkTool?.position.y || 0) > (elkRouter?.position.y || 0)).toBe(true);
    });
});
