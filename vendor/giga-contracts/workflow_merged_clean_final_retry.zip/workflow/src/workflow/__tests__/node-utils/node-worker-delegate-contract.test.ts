import fs from 'fs';
import path from 'path';
import { describe, expect, it } from 'vitest';

const NODES_ROOT = path.resolve(process.cwd(), '../workflow-nodes/src/nodes');
const getNodeModulePaths = (): string[] =>
    fs
        .readdirSync(NODES_ROOT)
        .map((nodeId) => path.join(NODES_ROOT, nodeId, `${nodeId}-node.ts`))
        .filter((entryPath) => fs.existsSync(entryPath))
        .sort((left, right) => left.localeCompare(right));

describe('node worker delegate contract', () => {
    const nodeModulePaths = getNodeModulePaths();

    it('keeps every node module on the worker-first path', () => {
        expect(nodeModulePaths.length).toBeGreaterThan(0);

        nodeModulePaths.forEach((nodeModulePath) => {
            const source = fs.readFileSync(nodeModulePath, 'utf8');
            const usesWorkerDelegate = source.includes('createNodeModuleWorkerExecute(');
            const usesServerOnlyFactory = source.includes('createServerOnlyNodeModule(');
            const usesBackendToolFactory = source.includes('createBackendToolNodeModule(');

            expect(usesWorkerDelegate || usesServerOnlyFactory || usesBackendToolFactory, `${nodeModulePath} should use a worker delegate or a server-only wrapper factory`).toBe(true);
            expect(source).not.toContain('execute: async');
        });
    });
});
