# Plan Policy Runtime Settings

`@workflow/executor` no longer owns the shared-app concurrency and timeout defaults.

## Runtime Contract

`WorkflowRuntimeSettings` now accepts:

- `maxExecutionSeconds`
- `maxConcurrentExecutionsPerUser`

These values are resolved by the backend from plan policy and billing context before execution is queued.

## Queue Behavior

`src/queue/user-execution-queue.ts` now enforces concurrency per request.

If one user queue contains requests with different limits, the queue applies the lowest active or pending limit for that user key. This keeps stricter plan limits from being bypassed by other in-flight work.

## Timeout Behavior

`src/executor/core/execution/execution-timeout.ts` now normalizes the backend-provided timeout instead of relying on a shared hardcoded tier list.

The executor should stay policy-agnostic:

- backend resolves the effective limit
- executor applies the received limit safely
