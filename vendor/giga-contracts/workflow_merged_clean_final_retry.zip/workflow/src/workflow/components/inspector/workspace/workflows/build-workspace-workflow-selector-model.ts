import type { WorkflowExecutableOption } from '@workflow/ui/workflow/types';
import type { WorkspaceAsyncSelectorState, WorkspaceWorkflowSelectorModel } from '@workflow/ui/workflow/components/inspector/workspace/types';

interface BuildWorkspaceWorkflowSelectorModelArgs {
    selectedWorkflowId: string | null;
    options: WorkflowExecutableOption[];
    state: WorkspaceAsyncSelectorState;
    message?: string;
}

export const buildWorkspaceWorkflowSelectorModel = ({
    selectedWorkflowId,
    options,
    state,
    message
}: BuildWorkspaceWorkflowSelectorModelArgs): WorkspaceWorkflowSelectorModel => ({
    title: 'Workflow',
    description: 'Select the published workflow this node should execute at runtime.',
    selectedWorkflowId,
    options,
    state,
    message
});
