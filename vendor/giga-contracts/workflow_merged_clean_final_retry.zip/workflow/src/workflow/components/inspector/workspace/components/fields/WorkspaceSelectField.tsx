import { Dropdown } from 'primereact/dropdown';
import { MultiSelect } from 'primereact/multiselect';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';
import { parseWorkspaceFieldString } from '@workflow/ui/workflow/components/inspector/workspace/components/fields/workspace-field.utils';

interface WorkspaceSelectFieldProps {
    id: string;
    value: unknown;
    editable: boolean;
    definition: WorkflowNodeFieldDefinition;
    allowVariables: boolean;
    variableMode: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    onChange: (nextValue: unknown) => void;
}

export const WorkspaceSelectField = ({ id, value, editable, definition, allowVariables, variableMode, variableContext, variableSuggestions, onChange }: WorkspaceSelectFieldProps): JSX.Element => {
    const options = Array.isArray(definition.options) ? definition.options : [];

    const selectControl = definition.multi ? (
        <MultiSelect
            inputId={id}
            value={Array.isArray(value) ? value : []}
            options={options}
            optionLabel="label"
            optionValue="value"
            onChange={(event) => onChange(event.value)}
            display="chip"
            disabled={!editable}
            className="cnw-prime-dropdown"
            placeholder={definition.placeholder ?? 'Select options'}
            appendTo={document.body}
        />
    ) : (
        <Dropdown
            inputId={id}
            value={value}
            options={options}
            optionLabel="label"
            optionValue="value"
            onChange={(event) => onChange(event.value)}
            disabled={!editable}
            className="cnw-prime-dropdown"
            placeholder={definition.placeholder ?? 'Select an option'}
            appendTo={document.body}
        />
    );

    if (!allowVariables || !variableMode) return selectControl;

    return (
        <VariableTextField
            id={id}
            value={parseWorkspaceFieldString(value)}
            onChange={(nextValue) => onChange(nextValue)}
            allowVariables
            variableContext={variableContext}
            variableSuggestions={variableSuggestions}
            disabled={!editable}
            placeholder={definition.placeholder}
            className="cnw-prime-input"
        />
    );
};
