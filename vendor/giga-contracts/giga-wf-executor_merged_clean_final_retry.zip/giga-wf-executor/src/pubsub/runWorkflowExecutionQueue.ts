import type { Consumer } from "kafkajs";
import { createWorkflowQueueScheduler } from "../queue/createWorkflowQueueScheduler";
import { resolveWorkflowQueueCompletion } from "../queue/workflowQueueCompletion";
import { readWorkflowQueueRedpandaConfig } from "../queue/readWorkflowQueueConfig";
import { parseWorkflowQueueRequest } from "../queue/workflowQueueMessage";
import { waitForWorkflowQueueConsumerReady } from "../queue/waitForWorkflowQueueConsumerReady";
import { createWorkflowExecutionPubsubClient } from "./createWorkflowExecutionPubsubClient";
import { publishWorkflowExecutionEvent } from "./publishWorkflowExecutionEvent";
import type {
  WorkflowQueueEvent,
  WorkflowQueueRequest,
  WorkflowQueueRequestConsumer,
  WorkflowQueueScheduler,
  WorkflowQueueWorker,
  WorkflowQueueRedpandaConfig,
  WorkflowQueueEventProducer,
} from "../queue/types";

const signalLocalTerminalCompletion = (event: WorkflowQueueEvent): void => {
  if (event.type === "completed" || event.type === "failed") {
    resolveWorkflowQueueCompletion(event);
  }
};

export type WorkflowExecutionQueueRuntimeOptions = {
  consumer: WorkflowQueueRequestConsumer;
  eventPublisher: WorkflowQueueEventProducer;
  scheduler: WorkflowQueueScheduler;
  requestTopic: string;
  runExecutionRequest: (
    executionRequest: WorkflowQueueRequest,
    helpers: {
      publishEvent: (executionEvent: WorkflowQueueEvent) => Promise<void>;
      signal: AbortSignal;
    },
  ) => Promise<void>;
};

export type WorkflowExecutionQueueOptions = {
  config?: WorkflowQueueRedpandaConfig;
  runExecutionRequest: WorkflowExecutionQueueRuntimeOptions["runExecutionRequest"];
};

export const runWorkflowExecutionQueueRuntime = (
  options: WorkflowExecutionQueueRuntimeOptions,
): WorkflowQueueWorker => ({
  start: async () => {
    await options.eventPublisher.connect();
    await options.consumer.connect();
    await options.consumer.subscribe({
      topic: options.requestTopic,
      fromBeginning: false,
    });
    await waitForWorkflowQueueConsumerReady({
      consumer: options.consumer,
      start: async () =>
        options.consumer.run({
          eachMessage: async ({ message }) => {
            const executionRequest = parseWorkflowQueueRequest(message.value);
            if (!executionRequest) return;
            options.scheduler.enqueue({
              request: executionRequest,
              execute: async (signal) =>
                options.runExecutionRequest(executionRequest, {
                  publishEvent: async (event) => {
                    signalLocalTerminalCompletion(event);
                    await options.eventPublisher.publish(event);
                  },
                  signal,
                }),
            });
          },
        }),
    });
  },
  stop: async (params) => {
    await options.consumer.disconnect();
    await options.scheduler.close(params);
    await options.eventPublisher.disconnect();
  },
  cancelRun: (runId) => options.scheduler.cancelRun(runId),
  cancelWorkflow: (workflowId) => options.scheduler.cancelWorkflow(workflowId),
  getRunning: (workflowId) => options.scheduler.getRunning(workflowId),
});

export const runWorkflowExecutionQueue = (
  options: WorkflowExecutionQueueOptions,
): WorkflowQueueWorker => {
  const config = options.config || readWorkflowQueueRedpandaConfig(process.env);
  const kafka = createWorkflowExecutionPubsubClient(config);
  const consumer: Consumer = kafka.consumer({
    groupId: config.requestConsumerGroupId,
  });
  return runWorkflowExecutionQueueRuntime({
    consumer,
    eventPublisher: publishWorkflowExecutionEvent(config),
    scheduler: createWorkflowQueueScheduler(),
    requestTopic: config.requestTopic,
    runExecutionRequest: options.runExecutionRequest,
  });
};
