import React from 'react';
import type { WorkflowExecutableOption } from '@workflow/ui/workflow/types';
import { useWorkspaceAsyncSelectorOptions, type WorkspaceAsyncSelectorOptionsState } from '@workflow/ui/workflow/components/inspector/workspace/selectors/use-workspace-async-selector-options';

export type WorkspaceWorkflowOptionsState = WorkspaceAsyncSelectorOptionsState<WorkflowExecutableOption>;

interface UseWorkspaceWorkflowOptionsArgs {
    visible: boolean;
    scopes: Array<'user' | 'organization'>;
    fetchExecutableWorkflows?: () => Promise<WorkflowExecutableOption[]>;
}

const SORT_ORDER: Record<WorkflowExecutableOption['scope'], number> = {
    user: 0,
    organization: 1
};

const sortWorkflowOptions = (options: WorkflowExecutableOption[]): WorkflowExecutableOption[] =>
    [...options]
        .filter((option) => Boolean(option.workflowId.trim()) && Boolean(option.workflowName.trim()))
        .sort((left, right) => {
            const scopeOrder = (SORT_ORDER[left.scope] ?? 99) - (SORT_ORDER[right.scope] ?? 99);
            if (scopeOrder !== 0) return scopeOrder;
            return left.workflowName.localeCompare(right.workflowName);
        });

export const useWorkspaceWorkflowOptions = ({ visible, scopes, fetchExecutableWorkflows }: UseWorkspaceWorkflowOptionsArgs): WorkspaceWorkflowOptionsState =>
    useWorkspaceAsyncSelectorOptions({
        visible,
        enabled: scopes.length > 0,
        emptyMessage: 'No workflow scopes are configured for this node.',
        missingFetcherMessage: 'The workflow host did not provide fetchExecutableWorkflows().',
        emptyFetcherResultMessage: 'No executable workflows were returned for this node.',
        loadOptions: React.useCallback(() => (fetchExecutableWorkflows ? fetchExecutableWorkflows() : Promise.resolve([])), [fetchExecutableWorkflows]),
        normalizeOptions: React.useCallback((options: WorkflowExecutableOption[]) => sortWorkflowOptions(options.filter((option) => scopes.includes(option.scope))), [scopes])
    });
