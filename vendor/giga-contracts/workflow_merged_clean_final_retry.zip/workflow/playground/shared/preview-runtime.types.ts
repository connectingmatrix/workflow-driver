import type { WorkflowDefinition, WorkflowPreviewLogEvent, WorkflowPreviewRuntime, WorkflowPreviewStateEvent, WorkflowRuntimeSettings, WorkflowSourceFiles } from '../../src/workflow/types';
import type { WorkflowStepSocketResult } from '../../src/workflow/driver/types';

export interface PreviewOverrides {
    properties?: Record<string, unknown>;
    code?: string;
    markdown?: string;
    sourceFiles?: WorkflowSourceFiles;
    previewRuntime?: WorkflowPreviewRuntime;
    previewInput?: Record<string, unknown>;
    previewMode?: 'designer';
}

export interface ExecuteWorkflowPreviewParams {
    workflow: WorkflowDefinition;
    nodeId: string;
    settings: WorkflowRuntimeSettings;
    runId: string;
    overrides?: PreviewOverrides;
    signal?: AbortSignal;
    emitLog: (event: WorkflowPreviewLogEvent) => void;
    emitState: (event: WorkflowPreviewStateEvent) => void;
}

export interface WorkflowNodePreviewRequest {
    workflow: WorkflowDefinition;
    nodeId: string;
    settings: WorkflowRuntimeSettings;
    runId: string;
    overrides?: PreviewOverrides;
}

export interface WorkflowNodePreviewSuccessResponse {
    ok: true;
    logs: WorkflowPreviewLogEvent[];
    states: WorkflowPreviewStateEvent[];
    result: WorkflowStepSocketResult;
}

export interface WorkflowNodePreviewFailureResponse {
    ok: false;
    logs: WorkflowPreviewLogEvent[];
    states: WorkflowPreviewStateEvent[];
    error: string;
}

export type WorkflowNodePreviewResponse = WorkflowNodePreviewSuccessResponse | WorkflowNodePreviewFailureResponse;
