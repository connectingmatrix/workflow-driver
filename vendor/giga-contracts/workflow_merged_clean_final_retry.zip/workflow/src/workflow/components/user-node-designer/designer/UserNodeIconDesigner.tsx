import React from 'react';
import { SelectButton } from 'primereact/selectbutton';
import { createSvgIconRenderer } from '@workflow/ui/workflow/utils/workflow-icon-render.utils';
import UserNodePrimeIconPicker from './UserNodePrimeIconPicker';
import UserNodeSvgIconEditor from './UserNodeSvgIconEditor';

const ICON_MODE_OPTIONS = [
    { label: 'PrimeIcon', value: 'prime' },
    { label: 'SVG', value: 'svg' }
] as const;

interface UserNodeIconDesignerProps {
    iconMode: 'prime' | 'svg';
    iconClass: string;
    iconColor: string;
    iconSvg: string;
    onChange: (value: { iconMode: 'prime' | 'svg'; iconClass: string; iconColor: string; iconSvg: string }) => void;
}

const UserNodeIconDesigner: React.FC<UserNodeIconDesignerProps> = ({ iconMode, iconClass, iconColor, iconSvg, onChange }) => {
    const svgPreview = createSvgIconRenderer(iconSvg)?.(32);

    return (
        <div className="wf-user-node-designer__section">
            <div className="wf-user-node-designer__section-header">
                <div>
                    <h4>Node Icon</h4>
                    <p>Choose a PrimeIcon or paste custom SVG, then set the saved icon color for the library and canvas.</p>
                </div>
                <div className="wf-user-node-designer__icon-preview" style={{ color: iconColor }} data-cy="user-node-icon-preview">
                    {iconMode === 'svg' && svgPreview ? <span dangerouslySetInnerHTML={{ __html: svgPreview }} /> : <i className={iconClass || 'pi pi-code'} />}
                </div>
            </div>
            <div className="wf-user-node-designer__icon-controls">
                <SelectButton
                    value={iconMode}
                    options={ICON_MODE_OPTIONS as unknown as Array<{ label: string; value: 'prime' | 'svg' }>}
                    onChange={(event) => onChange({ iconMode: event.value, iconClass, iconColor, iconSvg })}
                    data-cy="user-node-icon-mode"
                />
                <label className="wf-user-node-designer__color-field">
                    <span>Color</span>
                    <input type="color" value={iconColor} onChange={(event) => onChange({ iconMode, iconClass, iconColor: event.target.value, iconSvg })} data-cy="user-node-icon-color" />
                </label>
            </div>
            {iconMode === 'prime' ? <UserNodePrimeIconPicker iconClass={iconClass} onChange={(value) => onChange({ iconMode, iconClass: value, iconColor, iconSvg })} /> : null}
            {iconMode === 'svg' ? <UserNodeSvgIconEditor iconSvg={iconSvg} onChange={(value) => onChange({ iconMode, iconClass, iconColor, iconSvg: value })} /> : null}
        </div>
    );
};

export default UserNodeIconDesigner;
