import type { IncomingMessage, Server } from "node:http";
import { Server as SocketServer, Socket } from "socket.io";
import { createRunId } from "../executor/core/graph/log";
import { createJsonlLogger } from "../executor/core/logging/jsonl-logger";
import type { WorkflowDefinition } from "../types";
import { onTrackedHttpServer } from "./httpServerRegistry";
import type {
  ExecutorService,
  ExecutorTransportBindings,
  ExecutorTransportSession,
} from "./types";

type ConnectionState = {
  connectionId: string;
  request: IncomingMessage;
  rooms: Map<string, () => void>;
  session: ExecutorTransportSession;
  socket: Socket;
};

const text = (value: unknown) => String(value || "").trim();
const record = (value: unknown) =>
  value && typeof value === "object" ? (value as Record<string, unknown>) : {};
const requestUrl = (request: IncomingMessage) =>
  new URL(request.url || "/", "http://localhost");
const queryToken = (request: IncomingMessage) => {
  const url = requestUrl(request);
  return text(
    url.searchParams.get("access_token") ||
      url.searchParams.get("token") ||
      url.searchParams.get("auth_token"),
  );
};
const parseToken = (request: IncomingMessage) => {
  const header = text(request.headers.authorization).replace(/^Bearer\s+/i, "");
  return header || queryToken(request);
};
const send = (socket: Socket, eventName: string, value: unknown) =>
  socket.emit(eventName, value);

export const createWorkflowTransportServer = (
  executor: ExecutorService,
  bindings: ExecutorTransportBindings,
) => {
  const cleanupByServer = new Map<object, () => void>();
  const previewAbort = new Map<string, AbortController>();
  const previewCancelled = new Set<string>();
  const previewNode = new Map<string, string>();
  const previewOwner = new Map<string, string>();
  let stopTracking = () => undefined;

  const previewKey = (userId: string, runId: string) => `${userId}:${runId}`;
  const previewRoom = (userId: string, runId: string) =>
    executor.logsRoom(userId, runId);
  const readRequestContext = (state: ConnectionState) =>
    bindings.readRequestContext({
      request: state.request,
      session: state.session,
    });
  const subscribe = (state: ConnectionState, roomName: string) => {
    if (!roomName || state.rooms.has(roomName)) return;
    const off = executor.listen(roomName, (_room, event) =>
      send(state.socket, event.eventName, event.payload),
    );
    state.rooms.set(roomName, off as () => void);
  };
  const unsubscribe = (state: ConnectionState, roomName: string) => {
    state.rooms.get(roomName)?.();
    state.rooms.delete(roomName);
  };
  const clear = (state: ConnectionState) =>
    Array.from(state.rooms.keys()).forEach((roomName) =>
      unsubscribe(state, roomName),
    );
  const previewStop = (
    key: string,
    runId: string,
    requestId: string | null,
    userId: string,
  ) => {
    executor.publish(previewRoom(userId, runId), "workflow:preview:stop", {
      channel: "designer",
      preview: true,
      reason: previewCancelled.has(key) ? "cancelled" : "completed",
      request_id: requestId,
      run_id: runId,
    });
    previewAbort.delete(key);
    previewCancelled.delete(key);
    previewNode.delete(key);
    previewOwner.delete(key);
  };

  const onMessage = async (state: ConnectionState, raw: unknown) => {
    const message = record(JSON.parse(String(raw || "{}")));
    const eventName = text(message.eventName);
    const input = record(message.payload);
    const requestId = text(input.request_id) || null;
    if (!eventName) return;
    if (eventName === "workflow:join")
      return subscribe(
        state,
        executor.logsRoom(state.session.userId, text(input.run_id)),
      );
    if (eventName === "workflow:catalog:subscribe")
      return subscribe(
        state,
        executor.catalogRoom(
          text(input.broadcast_id),
          text(input.channel_name),
        ),
      );
    if (eventName === "workflow:catalog:unsubscribe")
      return unsubscribe(
        state,
        executor.catalogRoom(
          text(input.broadcast_id),
          text(input.channel_name),
        ),
      );
    if (eventName === "workflow:execution:subscribe")
      return subscribe(
        state,
        executor.workflowRoom(
          text(input.broadcast_id),
          text(input.workflow_id),
        ),
      );
    if (eventName === "workflow:execution:unsubscribe")
      return unsubscribe(
        state,
        executor.workflowRoom(
          text(input.broadcast_id),
          text(input.workflow_id),
        ),
      );
    if (eventName === "workflow:execute") {
      const workflow = input.workflow as WorkflowDefinition;
      const options = {
        ...record(input.options),
        requestContext: await readRequestContext(state),
      };
      const result =
        text(input.mode).toUpperCase() === "ASYNC"
          ? await executor.enqueue(state.session.userId, options, workflow)
          : await executor.execute(state.session.userId, options, workflow);
      return send(state.socket, "workflow:execute:result", {
        request_id: requestId,
        ...result,
      });
    }
    if (eventName === "workflow:stop")
      return send(state.socket, "workflow:stop:result", {
        request_id: requestId,
        stopped: await executor.stopRun(text(input.run_id)),
      });
    if (eventName === "workflow:workflow:stop")
      return send(state.socket, "workflow:workflow:stop:result", {
        request_id: requestId,
        stopped: await executor.stopWorkflow(text(input.workflow_id)),
      });
    if (eventName === "workflow:running")
      return send(state.socket, "workflow:running:result", {
        request_id: requestId,
        running: executor.getRunning(text(input.workflow_id) || undefined),
      });
    if (eventName === "workflow:editor:open") {
      const workflowId = text(input.workflow_id);
      const result = bindings.registerEditorSession?.({
        connectionId: state.connectionId,
        editable: input.editable !== false,
        userId: state.session.userId,
        workflowId,
      });
      if (!result?.accepted)
        return send(state.socket, "workflow:error", {
          error: "This workflow is already being edited in another session.",
        });
      return send(state.socket, "workflow:editor:ready", {
        editable: result.session?.editable !== false,
        workflow_id: workflowId,
      });
    }
    if (eventName === "workflow:editor:heartbeat") {
      const current = bindings.heartbeatEditorSession?.({
        connectionId: state.connectionId,
        editable: input.editable !== false,
        workflowId: text(input.workflow_id),
      });
      if (!current)
        send(state.socket, "workflow:error", {
          error: "No active workflow editor session was found for heartbeat.",
        });
      return;
    }
    if (eventName === "workflow:editor:close")
      return bindings.closeEditorSession?.({
        connectionId: state.connectionId,
        workflowId: text(input.workflow_id),
      });
    if (eventName === "workflow:webhook:test:result")
      return bindings.resolvePendingWebhookTestRequest?.(
        text(input.request_id),
        input,
      );
    if (eventName === "workflow:webhook:test:error")
      return bindings.rejectPendingWebhookTestRequest?.(
        text(input.request_id),
        new Error(
          text(input.error) || "Workflow editor test execution failed.",
        ),
      );
    if (eventName === "workflow:step") {
      const runId = text(input.run_id) || createRunId("step");
      const roomName = previewRoom(state.session.userId, runId);
      const result = await executor.executeStep(state.session.userId, {
        logger: createJsonlLogger((entry) =>
          executor.publish(roomName, "workflow:event", entry),
        ),
        nodeId: text(input.node_id),
        overrides: input.overrides as Record<string, unknown>,
        requestContext: await readRequestContext(state),
        runId,
        settings: input.settings as any,
        workflow: input.workflow as WorkflowDefinition,
      });
      subscribe(state, roomName);
      return send(state.socket, "workflow:step:result", {
        logs: [],
        logs_jsonl: "",
        node: result.node,
        request_id: requestId,
        result: result.result,
        run_id:
          text((result.result as unknown as Record<string, unknown>).runId) ||
          runId,
        workflow: result.workflow,
      });
    }
    if (eventName === "workflow:preview:start") {
      const runId = text(input.run_id) || createRunId("step");
      const key = previewKey(state.session.userId, runId);
      const roomName = previewRoom(state.session.userId, runId);
      previewCancelled.delete(key);
      previewAbort.get(key)?.abort();
      previewAbort.set(key, new AbortController());
      previewNode.set(key, text(input.node_id));
      previewOwner.set(key, state.connectionId);
      subscribe(state, roomName);
      executor.publish(roomName, "workflow:preview:state", {
        channel: "designer",
        node_id: text(input.node_id),
        preview: true,
        request_id: requestId,
        run_id: runId,
        state: "starting",
        timestamp: new Date().toISOString(),
      });
      try {
        const result = await executor.executeStep(state.session.userId, {
          nodeId: text(input.node_id),
          onPreviewLogLine: (entry) =>
            executor.publish(roomName, "workflow:preview:log", {
              channel: "designer",
              preview: true,
              request_id: requestId,
              ...entry,
            }),
          onPreviewState: (entry) =>
            executor.publish(roomName, "workflow:preview:state", {
              channel: "designer",
              preview: true,
              request_id: requestId,
              timestamp: new Date().toISOString(),
              ...entry,
            }),
          overrides: { ...record(input.overrides), previewMode: "designer" },
          requestContext: await readRequestContext(state),
          runId,
          settings: input.settings as any,
          signal: previewAbort.get(key)?.signal,
          workflow: input.workflow as WorkflowDefinition,
        });
        executor.publish(roomName, "workflow:preview:result", {
          channel: "designer",
          preview: true,
          request_id: requestId,
          result: result.result,
          run_id: runId,
          workflow: result.workflow,
          node: result.node,
        });
      } catch (error) {
        executor.publish(roomName, "workflow:preview:error", {
          channel: "designer",
          preview: true,
          request_id: requestId,
          run_id: runId,
          error:
            error instanceof Error
              ? error.message
              : "Preview step execution failed.",
        });
      } finally {
        previewStop(key, runId, requestId, state.session.userId);
      }
      return;
    }
    if (eventName === "workflow:preview:cancel") {
      const runId = text(input.run_id);
      const key = previewKey(state.session.userId, runId);
      if (previewOwner.get(key) !== state.connectionId) return;
      previewCancelled.add(key);
      previewAbort.get(key)?.abort();
      return executor.publish(
        previewRoom(state.session.userId, runId),
        "workflow:preview:state",
        {
          channel: "designer",
          preview: true,
          run_id: runId,
          node_id: previewNode.get(key) || null,
          state: "cancelled",
          timestamp: new Date().toISOString(),
        },
      );
    }
  };

  const connect = (
    socket: Socket,
    request: IncomingMessage,
    session: ExecutorTransportSession,
  ) => {
    const state: ConnectionState = {
      connectionId: socket.id,
      request,
      rooms: new Map(),
      session,
      socket,
    };
    subscribe(state, state.connectionId);
    subscribe(state, executor.userRoom(session.userId));
    send(socket, "workflow:ready", {
      path: "/ws/workflow",
      user_id: session.userId,
    });
    socket.onAny(
      (eventName: string, input: unknown) =>
        void onMessage(
          state,
          JSON.stringify({ eventName, payload: input }),
        ).catch((error) =>
          send(socket, "workflow:error", {
            error:
              error instanceof Error
                ? error.message
                : "Workflow transport request failed.",
          }),
        ),
    );
    socket.on("disconnect", () => {
      bindings.closeEditorSessionByConnection?.(state.connectionId);
      clear(state);
      Array.from(previewOwner.entries()).forEach(([key, owner]) => {
        if (owner !== state.connectionId) return;
        previewCancelled.add(key);
        previewAbort.get(key)?.abort();
      });
    });
  };

  const startServer = (server: Server) => {
    if (!server || cleanupByServer.has(server)) return;
    const io = new SocketServer(server, {
      maxHttpBufferSize: 50 * 1024 * 1024,
      path: "/ws/workflow",
      transports: ["websocket"],
    });
    io.use(async (socket, next) => {
      try {
        const request = socket.request as IncomingMessage;
        const authToken = text((socket.handshake.auth || {}).token);
        const session = await bindings.authorize(
          request,
          authToken || parseToken(request),
        );
        socket.data.session = session;
        next();
      } catch {
        next(new Error("Unauthorized"));
      }
    });
    io.on("connection", (socket) =>
      connect(
        socket,
        socket.request as IncomingMessage,
        socket.data.session as ExecutorTransportSession,
      ),
    );
    cleanupByServer.set(server, () => {
      void io.close();
    });
  };

  return {
    start() {
      stopTracking();
      stopTracking = onTrackedHttpServer((server) => startServer(server));
    },
    stop() {
      stopTracking();
      stopTracking = () => {
        return undefined;
      };
      cleanupByServer.forEach((cleanup) => cleanup());
      cleanupByServer.clear();
    },
  };
};
