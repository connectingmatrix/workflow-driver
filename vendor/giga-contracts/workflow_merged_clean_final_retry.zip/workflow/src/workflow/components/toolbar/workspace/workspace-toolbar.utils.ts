import type { WorkflowMetadata } from '@workflow/ui/workflow/types';
import { readWorkflowDisplayStatusLabel } from '@workflow/ui/workflow/utils/workflow-display-status';

export const readFileAsText = async (file: File): Promise<string> => {
    if (typeof file.text === 'function') {
        return file.text();
    }

    return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result);
                return;
            }
            reject(new Error('Workflow JSON file did not produce a text payload.'));
        };
        reader.onerror = () => {
            reject(reader.error ?? new Error('Could not read workflow JSON.'));
        };
        reader.readAsText(file);
    });
};

export const resolveWorkflowToolbarStatus = (metadata: WorkflowMetadata | null): string => {
    return readWorkflowDisplayStatusLabel(metadata?.displayStatus || metadata?.status);
};

export const resolveWorkflowToolbarEditedLabel = (metadata: WorkflowMetadata | null): string => {
    const timestamp = metadata?.publishedAt ?? metadata?.createdAt ?? null;
    if (!timestamp) return 'Last edited just now';
    const diffMs = Date.now() - Date.parse(timestamp);
    if (!Number.isFinite(diffMs) || diffMs <= 0) return 'Last edited just now';
    const diffMinutes = Math.round(diffMs / 60000);
    if (diffMinutes < 1) return 'Last edited just now';
    if (diffMinutes < 60) return `Last edited ${diffMinutes} min ago`;
    const diffHours = Math.round(diffMinutes / 60);
    if (diffHours < 24) return `Last edited ${diffHours} hr ago`;
    const diffDays = Math.round(diffHours / 24);
    return `Last edited ${diffDays} day${diffDays === 1 ? '' : 's'} ago`;
};
