import { afterEach, describe, expect, it, vi } from 'vitest';
import { __resetWorkflowRuntimeFrameForTests, ensureRuntimeFrameReady, evaluateJavascriptInIframe } from '@workflow/ui/workflow/browser-runtime/js-runtime-iframe';

type RuntimeMockOptions = {
    respondToPing?: boolean;
    respondToEval?: boolean;
    evalResult?: unknown;
};

type RuntimeMockState = {
    pingCalls: number;
    evalCalls: number;
    restore: () => void;
};

const FRAME_ID = '__giga_workflow_runtime_frame__';

const installRuntimeIframeMock = (options: RuntimeMockOptions = {}): RuntimeMockState => {
    const originalCreateElement = document.createElement.bind(document);
    const state: RuntimeMockState = {
        pingCalls: 0,
        evalCalls: 0,
        restore: () => createElementSpy.mockRestore()
    };

    const createElementSpy = vi.spyOn(document, 'createElement').mockImplementation(((tagName: string) => {
        const element = originalCreateElement(tagName);
        if (tagName !== 'iframe') {
            return element;
        }

        const runtimeWindow = {
            postMessage: (payload: { type?: string; id?: string }) => {
                if (payload?.type === 'WF_EVAL_PING') {
                    state.pingCalls += 1;
                    if (options.respondToPing !== false) {
                        window.dispatchEvent(
                            new MessageEvent('message', {
                                data: {
                                    type: 'WF_EVAL_READY',
                                    frameId: FRAME_ID,
                                    id: payload.id
                                }
                            })
                        );
                    }
                    return;
                }

                if (payload?.type === 'WF_EVAL_REQUEST') {
                    state.evalCalls += 1;
                    if (options.respondToEval !== false) {
                        window.dispatchEvent(
                            new MessageEvent('message', {
                                data: {
                                    type: 'WF_EVAL_RESULT',
                                    id: payload.id,
                                    result: options.evalResult ?? { ok: true },
                                    logs: [{ level: 'log', args: ['mock eval log'] }]
                                }
                            })
                        );
                    }
                }
            }
        };

        Object.defineProperty(element, 'contentWindow', {
            configurable: true,
            value: runtimeWindow
        });

        return element;
    }) as typeof document.createElement);

    return state;
};

afterEach(() => {
    vi.restoreAllMocks();
    __resetWorkflowRuntimeFrameForTests();
    vi.useRealTimers();
});

describe('workflow runtime iframe', () => {
    it('resolves ready handshake once and reuses readiness for subsequent calls', async () => {
        const runtimeMock = installRuntimeIframeMock();

        const [frameA, frameB] = await Promise.all([ensureRuntimeFrameReady(), ensureRuntimeFrameReady()]);
        const frameC = await ensureRuntimeFrameReady();

        expect(frameA).toBe(frameB);
        expect(frameA).toBe(frameC);
        expect(runtimeMock.pingCalls).toBe(1);

        runtimeMock.restore();
    });

    it('executes first iframe evaluation without requiring a second run', async () => {
        const runtimeMock = installRuntimeIframeMock({ evalResult: { summary: 'first-run-ok' } });

        const result = await evaluateJavascriptInIframe('return { status: "ok" };', {
            input: { a: 1 },
            properties: { b: 2 }
        });

        expect(result.error).toBeUndefined();
        expect(result.result).toEqual({ summary: 'first-run-ok' });
        expect(result.logs).toEqual(['LOG mock eval log']);
        expect(runtimeMock.evalCalls).toBe(1);

        runtimeMock.restore();
    });

    it('returns explicit timeout error when eval response never arrives', async () => {
        vi.useFakeTimers();
        const runtimeMock = installRuntimeIframeMock({ respondToEval: false });

        const evalPromise = evaluateJavascriptInIframe('return "never";', {});
        await vi.advanceTimersByTimeAsync(25_000);
        const result = await evalPromise;

        expect(result.error).toBe('Execution timed out while waiting for runtime response.');
        expect(result.result).toBeNull();
        expect(result.logs).toEqual([]);

        runtimeMock.restore();
    });
});
