import React from 'react';
import { InputText } from 'primereact/inputtext';
import type { WorkflowNodeLibraryCategory } from '@workflow/ui/constants';
import type { NodeLibraryProps } from '@workflow/ui/workflow/components/node-library/node-library.types';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { WorkspaceNodeLibraryTabs } from '@workflow/ui/workflow/components/node-library/workspace/WorkspaceNodeLibraryTabs';
import { WorkspaceNodeLibraryGroup } from '@workflow/ui/workflow/components/node-library/workspace/WorkspaceNodeLibraryGroup';
import {
    buildWorkspaceNodeLibraryGroups,
    buildWorkspaceNodeLibraryCategories,
    filterWorkspaceNodeLibraryItems,
    resolveWorkspaceNodeLibraryCategoryLabel
} from '@workflow/ui/workflow/components/node-library/workspace/workspace-node-library.utils';
import '@workflow/ui/workflow/components/node-library/workspace/wf-workspace-node-library.scss';

const WorkspaceNodeLibrary: React.FC<NodeLibraryProps> = ({ visible, items, onClose, onInsertItem }) => {
    const [search, setSearch] = React.useState('');
    const categories = React.useMemo(() => buildWorkspaceNodeLibraryCategories(items), [items]);
    const [activeCategory, setActiveCategory] = React.useState<WorkflowNodeLibraryCategory>('all');
    const [collapsedGroups, setCollapsedGroups] = React.useState<Record<string, boolean>>({});

    React.useEffect(() => {
        if (!categories.includes(activeCategory)) {
            setActiveCategory('all');
        }
    }, [activeCategory, categories]);

    const filteredItems = React.useMemo(() => filterWorkspaceNodeLibraryItems(items, search, activeCategory), [activeCategory, items, search]);
    const groupedItems = React.useMemo(() => buildWorkspaceNodeLibraryGroups(filteredItems), [filteredItems]);

    const toggleGroup = React.useCallback((groupName: string) => {
        setCollapsedGroups((previous) => ({
            ...previous,
            [groupName]: !previous[groupName]
        }));
    }, []);

    if (!visible) {
        return null;
    }

    return (
        <aside className="wf-workspace-node-library" data-cy="workflow-node-library-workspace">
            <header className="wf-workspace-node-library__header">
                <div>
                    <h2>Workflow nodes</h2>
                    <p>Drag blocks onto the canvas or click to insert.</p>
                </div>
                {onClose ? (
                    <button type="button" className="wf-workspace-node-library__close" onClick={onClose} aria-label="Close node library">
                        <WorkspaceGlyph name="x" className="wf-workspace-node-library__close-icon" />
                    </button>
                ) : null}
            </header>
            <div className="wf-workspace-node-library__search-shell">
                <i className="pi pi-search" aria-hidden />
                <InputText value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search nodes, categories, actions..." className="wf-workspace-node-library__search-input" />
            </div>
            <WorkspaceNodeLibraryTabs categories={categories} activeCategory={activeCategory} items={items} onChange={setActiveCategory} />
            <div className="wf-workspace-node-library__section-label">
                <span>{resolveWorkspaceNodeLibraryCategoryLabel(activeCategory)} nodes</span>
                <span>{filteredItems.length} available</span>
            </div>
            <div className="wf-workspace-node-library__cards">
                {groupedItems.map((group) => (
                    <WorkspaceNodeLibraryGroup key={group.groupName} group={group} collapsed={Boolean(collapsedGroups[group.groupName])} onToggle={toggleGroup} onInsert={onInsertItem} />
                ))}
                {filteredItems.length === 0 ? <div className="wf-workspace-node-library__empty">No nodes match the current search.</div> : null}
            </div>
        </aside>
    );
};

export default WorkspaceNodeLibrary;
