# Giga Workflow Executor Guide

The workflow executor receives queued workflow requests, resolves runtime scope, executes nodes, and emits process-monitor events.

## Responsibilities

- Broadcast workflow queued/running/completed/failed states.
- Preserve `parentScopeId`, `scopeType`, `scopeId`, and `userId` on every queue message.
- Execute AI Agent nodes as AI Agent runtime children of the workflow run.
- Respect stop/kill requests by checking registered process cancellation state.

```mermaid
graph TD
  A[Queue message] --> B[Validate scope]
  B --> C[Register process]
  C --> D[Emit queued/running]
  D --> E[Execute nodes]
  E --> F[Emit node logs]
  F --> G[Complete or fail]
```


- [Process monitoring](./process-monitoring.md) documents executor event fields and AI Agent node child-process rules.
