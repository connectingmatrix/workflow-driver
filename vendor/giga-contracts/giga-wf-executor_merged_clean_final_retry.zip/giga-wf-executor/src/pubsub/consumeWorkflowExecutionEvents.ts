import util from "node:util";
import type { Consumer } from "kafkajs";
import { readWorkflowQueueRedpandaConfig } from "../queue/readWorkflowQueueConfig";
import { parseWorkflowQueueEvent } from "../queue/workflowQueueMessage";
import { waitForWorkflowQueueConsumerReady } from "../queue/waitForWorkflowQueueConsumerReady";
import { createWorkflowExecutionPubsubClient } from "./createWorkflowExecutionPubsubClient";
import type {
  WorkflowQueueEvent,
  WorkflowQueueRedpandaConfig,
} from "../queue/types";

type WorkflowExecutionEventConsumerOptions = {
  applyExecutionEvent: (executionEvent: WorkflowQueueEvent) => Promise<void>;
  config?: WorkflowQueueRedpandaConfig;
  handleExecutionEventError?: (params: {
    error: unknown;
    event: WorkflowQueueEvent;
  }) => Promise<void> | void;
};

export const consumeWorkflowExecutionEventsRuntime = (params: {
  applyExecutionEvent: WorkflowExecutionEventConsumerOptions["applyExecutionEvent"];
  consumer: Consumer;
  handleExecutionEventError?: WorkflowExecutionEventConsumerOptions["handleExecutionEventError"];
  eventsTopic: string;
}) => ({
  start: async () => {
    await params.consumer.connect();
    await params.consumer.subscribe({
      topic: params.eventsTopic,
      fromBeginning: false,
    });
    await waitForWorkflowQueueConsumerReady({
      consumer: params.consumer,
      start: async () =>
        params.consumer.run({
          eachMessage: async ({ message }) => {
            const executionEvent = parseWorkflowQueueEvent(message.value);
            if (!executionEvent) return;
            try {
              await params.applyExecutionEvent(executionEvent);
            } catch (error) {
              if (params.handleExecutionEventError) {
                await params.handleExecutionEventError({
                  error,
                  event: executionEvent,
                });
                return;
              }
              console.error("[workflow-execution-events] failed to apply event", {
                eventType: executionEvent.type,
                executionId: executionEvent.executionId,
                runId: executionEvent.runId,
                workflowId: executionEvent.workflowId,
                message: error instanceof Error ? error.stack || error.message : util.inspect(error, { depth: 10, breakLength: 120 }),
              });
            }
          },
        }),
    });
  },
  stop: async () => {
    await params.consumer.disconnect();
  },
});

export const consumeWorkflowExecutionEvents = (options: WorkflowExecutionEventConsumerOptions) => {
  const config = options.config || readWorkflowQueueRedpandaConfig(process.env);
  const kafka = createWorkflowExecutionPubsubClient(config);
  const consumer: Consumer = kafka.consumer({
    groupId: config.eventConsumerGroupId || "workflow-queue-events",
  });
  return consumeWorkflowExecutionEventsRuntime({
    applyExecutionEvent: options.applyExecutionEvent,
    consumer,
    handleExecutionEventError: options.handleExecutionEventError,
    eventsTopic: config.eventsTopic,
  });
};
