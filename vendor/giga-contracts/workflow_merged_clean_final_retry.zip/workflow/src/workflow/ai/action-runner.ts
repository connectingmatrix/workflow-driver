import type { Connection } from '@xyflow/react';
import { WorkflowConnectionModel, WorkflowDefinition, WorkflowNodeFieldDefinition, WorkflowNodeLibraryItem, WorkflowNodeModel, WorkflowNodePortProperty, WorkflowNodeSchema, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';
import { canAttachConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';
import { getNormalizedCommandPorts, getSortedCommandPortIds, resolveCommandPortIdFromHandle, toCanonicalCommandHandle } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';
import { applyConnection, addDroppedNode, removeNodeFromWorkflow } from '@workflow/ui/workflow/utils/workflow-state-updates.utils';
import { createOrExtendSubworkflow } from '@workflow/ui/workflow/utils/workflow-subworkflow.utils';
import { exportPayloadToWorkflow } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { hydrateWorkflowDefinition } from '@workflow/ui/workflow/utils/workflow-hydration.utils';
import { WorkflowAiAction } from './types';
import { workflowFromCypher } from './cypher-workflow';
import { buildWorkflowGraphHealth } from './graph-health';

interface ApplyWorkflowAiActionsInput {
    actions: WorkflowAiAction[];
    workflow: WorkflowDefinition | null;
    nodeLibraryItems: WorkflowNodeLibraryItem[];
    replaceWorkflow: (workflow: WorkflowDefinition) => void;
    runNodeStep: (nodeId: string) => Promise<void>;
    runWorkflowLocal: () => Promise<void>;
    runWorkflowServer: () => Promise<void>;
    openInspector: (nodeId: string) => void;
    showLogs: () => void;
    exportWorkflowWithData?: () => void;
    exportWorkflowOnly?: () => void;
}

export interface WorkflowAiActionRunResult {
    applied: string[];
    warnings: string[];
}

const toRecord = (value: unknown): Record<string, unknown> => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    return value as Record<string, unknown>;
};

const toArray = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);

const toString = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

const toFiniteNumber = (value: unknown): number | null => {
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) ? parsed : null;
};

const toNormalizedActionType = (value: unknown): string => toString(value).toLowerCase().replace(/_/g, '-');

const toComparable = (value: string): string => value.trim().toLowerCase();

const RESERVED_ACTION_KEYS = new Set<string>([
    'type',
    'workflow',
    'payload',
    'exportPayload',
    'data',
    'value',
    'modelId',
    'nodeModelId',
    'name',
    'description',
    'position',
    'connectFromNodeId',
    'connectToNodeId',
    'sourceNodeId',
    'targetNodeId',
    'source_node_id',
    'target_node_id',
    'fromNodeId',
    'toNodeId',
    'from_node_id',
    'to_node_id',
    'from',
    'to',
    'source',
    'target',
    'sourceNode',
    'targetNode',
    'sourceHandle',
    'targetHandle',
    'sourceHandleToTarget',
    'targetHandleToTarget',
    'nodeId',
    'node_id',
    'id',
    'node',
    'nodeIds',
    'subworkflowId',
    'subworkflow_id',
    'incoming',
    'outgoing',
    'cypher'
]);

const ACTION_NODE_ID_KEYS = ['nodeId', 'node_id', 'id', 'node', 'targetNodeId', 'target_node_id'] as const;
const DEFAULT_NODE_SIZE = {
    width: 236,
    height: 248
};
const AI_NODE_SPACING_MULTIPLIER = 1.5;

const mergeActionRecord = (actionRecord: Record<string, unknown>): Record<string, unknown> => ({
    ...toRecord(actionRecord.payload),
    ...toRecord(actionRecord.data),
    ...toRecord(actionRecord.value),
    ...actionRecord
});

const includesComparable = (candidates: string[] | undefined, value: string | undefined): boolean => {
    if (!candidates?.length || !value) return false;
    const normalizedValue = toComparable(value);
    return candidates.some((candidate) => toComparable(candidate) === normalizedValue);
};

const getCommandPortMatchScore = (sourceNode: WorkflowNodeModel, sourceGroup: string | undefined, port: WorkflowNodePortProperty | undefined): number => {
    if (!port) return 0;
    if (includesComparable(port.acceptedSourceModelIds, sourceNode.modelId)) return 4;
    if (includesComparable(port.acceptedSourceGroups, sourceGroup)) return 3;
    if ((port.acceptedSourceModelIds ?? []).length || (port.acceptedSourceGroups ?? []).length) return 2;
    return 1;
};

const isFinitePosition = (value: unknown): value is { x: number; y: number } => {
    if (!value || typeof value !== 'object') return false;
    const record = value as { x?: unknown; y?: unknown };
    return Number.isFinite(record.x) && Number.isFinite(record.y);
};

const createFallbackSchema = (modelId: string): WorkflowNodeSchema => ({
    id: modelId,
    name: {
        type: 'string',
        editable: true,
        autoGenerate: false
    },
    fields: {},
    inputs: {
        input: {
            allowMultipleArrows: true
        }
    },
    outputs: {
        output: {
            allowMultipleArrows: true
        }
    },
    instruction: {
        code: false,
        markdown: false
    }
});

const resolveNodeSchemaForModel = (workflow: WorkflowDefinition, modelId: string): WorkflowNodeSchema => {
    const nodeModels = workflow.nodeModels ?? {};
    return nodeModels[modelId] ?? createFallbackSchema(modelId);
};

const resolveNodeSize = (workflow: WorkflowDefinition, modelId: string): { width: number; height: number } => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const width = Number(schema.render?.nodeWidth ?? schema.render?.nodeSize ?? DEFAULT_NODE_SIZE.width);
    const height = Number(schema.render?.nodeHeight ?? schema.render?.nodeSize ?? DEFAULT_NODE_SIZE.height);
    return {
        width: Number.isFinite(width) && width > 0 ? width : DEFAULT_NODE_SIZE.width,
        height: Number.isFinite(height) && height > 0 ? height : DEFAULT_NODE_SIZE.height
    };
};

const isPositionOverlapping = (workflow: WorkflowDefinition, modelId: string, position: { x: number; y: number }, excludeNodeId?: string): boolean => {
    const targetSize = resolveNodeSize(workflow, modelId);
    return workflow.nodes.some((node) => {
        if (excludeNodeId && node.id === excludeNodeId) return false;
        const sourceSize = resolveNodeSize(workflow, node.modelId);
        const minX = ((targetSize.width + sourceSize.width) / 2) * AI_NODE_SPACING_MULTIPLIER;
        const minY = ((targetSize.height + sourceSize.height) / 2) * AI_NODE_SPACING_MULTIPLIER;
        return Math.abs(position.x - node.position.x) < minX && Math.abs(position.y - node.position.y) < minY;
    });
};

const resolveCollisionFreePosition = (workflow: WorkflowDefinition, modelId: string, preferred: { x: number; y: number } | null, excludeNodeId?: string): { x: number; y: number } => {
    if (preferred && !isPositionOverlapping(workflow, modelId, preferred, excludeNodeId)) {
        return preferred;
    }
    const size = resolveNodeSize(workflow, modelId);
    const spacingX = Math.round(size.width * AI_NODE_SPACING_MULTIPLIER);
    const spacingY = Math.round(size.height * AI_NODE_SPACING_MULTIPLIER);
    const fallbackStart = workflow.nodes.length
        ? {
              x: Math.max(...workflow.nodes.map((node) => node.position.x)) + spacingX,
              y: Math.min(...workflow.nodes.map((node) => node.position.y))
          }
        : { x: 140, y: 140 };
    for (let row = 0; row < 30; row += 1) {
        for (let col = 0; col < 8; col += 1) {
            const candidate = {
                x: fallbackStart.x + col * spacingX,
                y: fallbackStart.y + row * spacingY
            };
            if (!isPositionOverlapping(workflow, modelId, candidate, excludeNodeId)) {
                return candidate;
            }
        }
    }
    return fallbackStart;
};

const getSortedInputPorts = (workflow: WorkflowDefinition, modelId: string): string[] => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const commands = getNormalizedCommandPorts(schema);
    return Object.entries(schema.inputs)
        .filter(([portId]) => !commands[portId])
        .sort((left, right) => Number(left[1].order ?? 0) - Number(right[1].order ?? 0))
        .map(([portId]) => portId);
};

const getPrioritizedInputPorts = (workflow: WorkflowDefinition, modelId: string): string[] => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const commands = getNormalizedCommandPorts(schema);
    return Object.entries(schema.inputs)
        .filter(([portId]) => !commands[portId])
        .sort((left, right) => {
            const leftHasCompatibility = Boolean((left[1].acceptedSourceGroups ?? []).length || (left[1].acceptedSourceModelIds ?? []).length);
            const rightHasCompatibility = Boolean((right[1].acceptedSourceGroups ?? []).length || (right[1].acceptedSourceModelIds ?? []).length);
            if (leftHasCompatibility !== rightHasCompatibility) return leftHasCompatibility ? -1 : 1;
            return Number(left[1].order ?? 0) - Number(right[1].order ?? 0);
        })
        .map(([portId]) => portId);
};

const getSortedOutputPorts = (workflow: WorkflowDefinition, modelId: string): string[] => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const commands = getNormalizedCommandPorts(schema);
    return Object.entries(schema.outputs)
        .filter(([portId]) => !commands[portId])
        .sort((left, right) => Number(left[1].order ?? 0) - Number(right[1].order ?? 0))
        .map(([portId]) => portId);
};

const getSortedCommandPorts = (workflow: WorkflowDefinition, modelId: string): string[] => getSortedCommandPortIds(resolveNodeSchemaForModel(workflow, modelId));

const getOutputPortType = (workflow: WorkflowDefinition, modelId: string, outputPortId: string): string | undefined => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const commands = getNormalizedCommandPorts(schema);
    if (commands[outputPortId]) return commands[outputPortId]?.portType;
    return schema.outputs[outputPortId]?.portType;
};

const getInputPortType = (workflow: WorkflowDefinition, modelId: string, inputPortId: string): string | undefined => {
    const schema = resolveNodeSchemaForModel(workflow, modelId);
    const commands = getNormalizedCommandPorts(schema);
    if (commands[inputPortId]) return commands[inputPortId]?.portType;
    return schema.inputs[inputPortId]?.portType;
};

const resolveInputHandleWithCompatibility = (workflow: WorkflowDefinition, sourceNode: WorkflowNodeModel, targetNode: WorkflowNodeModel, sourceHandle: string): string => {
    const sourceSchema = resolveNodeSchemaForModel(workflow, sourceNode.modelId);
    const targetSchema = resolveNodeSchemaForModel(workflow, targetNode.modelId);
    const sourceCommandPortId = resolveCommandPortIdFromHandle(sourceSchema, sourceHandle, 'outputs');
    if (sourceCommandPortId) {
        const targetCommandPorts = getSortedCommandPortIds(targetSchema);
        const targetCommands = getNormalizedCommandPorts(targetSchema);
        const sourceGroup = toString(sourceSchema.group);
        const matchingCommandPort = targetCommandPorts
            .filter((portId) =>
                canAttachConnection(workflow, {
                    source: sourceNode.id,
                    target: targetNode.id,
                    sourceHandle: toCanonicalCommandHandle(sourceCommandPortId),
                    targetHandle: toCanonicalCommandHandle(portId)
                })
            )
            .sort((left, right) => getCommandPortMatchScore(sourceNode, sourceGroup, targetCommands[right]) - getCommandPortMatchScore(sourceNode, sourceGroup, targetCommands[left]))[0];
        return toCanonicalCommandHandle(matchingCommandPort ?? targetCommandPorts[0] ?? sourceCommandPortId);
    }
    const [, sourcePortId = 'output'] = sourceHandle.split(':');
    const sourcePortType = getOutputPortType(workflow, sourceNode.modelId, sourcePortId);
    const sortedInputPorts = getPrioritizedInputPorts(workflow, targetNode.modelId).sort((left, right) => {
        const leftRule = targetSchema.inputs[left];
        const rightRule = targetSchema.inputs[right];
        const leftMatchesType = leftRule?.portType === sourcePortType;
        const rightMatchesType = rightRule?.portType === sourcePortType;
        if (leftMatchesType !== rightMatchesType) return leftMatchesType ? -1 : 1;
        return 0;
    });
    if (!sortedInputPorts.length) return 'in:input';
    for (const portId of sortedInputPorts) {
        const candidateConnection: Connection = {
            source: sourceNode.id,
            target: targetNode.id,
            sourceHandle,
            targetHandle: `in:${portId}`
        };
        if (canAttachConnection(workflow, candidateConnection)) {
            return `in:${portId}`;
        }
    }
    return `in:${sortedInputPorts[0]}`;
};

const resolveConnectedOptionValues = (workflow: WorkflowDefinition, node: WorkflowNodeModel, field: WorkflowNodeFieldDefinition): Set<string> => {
    const sourcePort = toString(field.aiSourcePort);
    if (!sourcePort) return new Set<string>();
    const schema = resolveNodeSchemaForModel(workflow, node.modelId);
    const incomingConnections = workflow.connections.filter((connection) => {
        if (connection.to !== node.id) return false;
        const commandPortId = resolveCommandPortIdFromHandle(schema, connection.targetHandle, 'inputs');
        if (commandPortId) return commandPortId === sourcePort;
        return connection.targetHandle === `in:${sourcePort}`;
    });
    const connectedValues = new Set<string>();
    incomingConnections.forEach((connection) => {
        const sourceNode = workflow.nodes.find((item) => item.id === connection.from);
        if (!sourceNode) return;
        connectedValues.add(toComparable(sourceNode.modelId));
    });
    return connectedValues;
};

const sanitizeRuntimeOverridesForNode = (workflow: WorkflowDefinition, node: WorkflowNodeModel, runtimeOverrides: Record<string, unknown>, warnings: string[]): Record<string, unknown> => {
    const schema = resolveNodeSchemaForModel(workflow, node.modelId);
    const sanitized: Record<string, unknown> = {};
    const allowedRuntimeKeys = new Set<string>(Object.keys(schema.fields));
    if (schema.instruction?.code) allowedRuntimeKeys.add('code');
    if (schema.instruction?.markdown) allowedRuntimeKeys.add('markdown');
    Object.entries(runtimeOverrides).forEach(([key, value]) => {
        if (!allowedRuntimeKeys.has(key)) return;
        const field = schema.fields[key];
        if (field?.aiWriteMode === 'deny') {
            warnings.push(`AI update ignored for "${node.name}.${key}" because this field is not AI-writable.`);
            return;
        }
        if (field?.aiWriteMode === 'connected-options-only') {
            const connectedValues = resolveConnectedOptionValues(workflow, node, field);
            if (connectedValues.size === 0) {
                warnings.push(`AI update ignored for "${node.name}.${key}" because required port "${field.aiSourcePort}" has no connected nodes.`);
                return;
            }
            if (Array.isArray(value)) {
                const filtered = value.map((entry) => toString(entry)).filter((entry) => includesComparable(Array.from(connectedValues), entry));
                if (!filtered.length) {
                    warnings.push(`AI update ignored for "${node.name}.${key}" because provided values are not connected on "${field.aiSourcePort}".`);
                    return;
                }
                sanitized[key] = filtered;
                return;
            }
            const scalarValue = toString(value);
            if (!includesComparable(Array.from(connectedValues), scalarValue)) {
                warnings.push(`AI update ignored for "${node.name}.${key}" because "${scalarValue}" is not connected on "${field.aiSourcePort}".`);
                return;
            }
            sanitized[key] = scalarValue;
            return;
        }
        sanitized[key] = value;
    });
    return sanitized;
};

const isWorkflowDefinitionLike = (value: unknown): value is WorkflowDefinition => {
    const record = toRecord(value);
    return Array.isArray(record.nodes) && Array.isArray(record.connections) && Boolean(record.metadata && typeof record.metadata === 'object');
};

const isWorkflowExportPayloadLike = (value: unknown): boolean => {
    const record = toRecord(value);
    return Boolean(record.exportMode && record.nodes && typeof record.nodes === 'object' && !Array.isArray(record.nodes));
};

const parseWorkflowCandidate = (value: unknown): WorkflowDefinition | null => {
    if (!value) return null;
    const record = toRecord(value);
    const nestedCandidates = [record.workflow, record.payload, record.exportPayload, record.data, record.value];
    for (const nestedCandidate of nestedCandidates) {
        if (nestedCandidate && nestedCandidate !== value) {
            const parsedNested = parseWorkflowCandidate(nestedCandidate);
            if (parsedNested) return parsedNested;
        }
    }
    if (isWorkflowDefinitionLike(value)) {
        return hydrateWorkflowDefinition(value as WorkflowDefinition);
    }
    if (isWorkflowExportPayloadLike(value)) {
        return hydrateWorkflowDefinition(exportPayloadToWorkflow(value as any));
    }
    return null;
};

const resolveNodeId = (workflow: WorkflowDefinition, candidateValue: unknown): string => {
    const candidate = toString(candidateValue);
    if (!candidate) return '';
    const byId = workflow.nodes.find((node) => node.id === candidate);
    if (byId) return byId.id;
    const comparableCandidate = toComparable(candidate);
    const byName = workflow.nodes.find((node) => toComparable(node.name) === comparableCandidate);
    if (byName) return byName.id;
    const byModel = workflow.nodes.filter((node) => toComparable(node.modelId) === comparableCandidate);
    if (byModel.length === 1) return byModel[0].id;
    return '';
};

const resolveFirstExistingNodeId = (workflow: WorkflowDefinition, candidates: unknown[]): string => {
    for (const candidate of candidates) {
        const nodeId = resolveNodeId(workflow, candidate);
        if (nodeId) return nodeId;
    }
    return '';
};

const resolveNodeIdFromKeys = (workflow: WorkflowDefinition, actionRecord: Record<string, unknown>, keys: readonly string[]): string =>
    resolveFirstExistingNodeId(
        workflow,
        keys.map((key) => actionRecord[key]).filter((candidate) => typeof candidate !== 'undefined')
    );

const resolveConnectNodeId = (workflow: WorkflowDefinition, actionRecord: Record<string, unknown>, key: 'sourceNodeId' | 'targetNodeId'): string => {
    if (!Object.prototype.hasOwnProperty.call(actionRecord, key)) return '';
    return resolveNodeId(workflow, actionRecord[key]);
};

const resolveNodeIdsFromValue = (workflow: WorkflowDefinition, value: unknown): string[] => {
    const candidates = Array.isArray(value) ? value : [value];
    const resolvedIds = candidates.map((candidate) => resolveNodeId(workflow, candidate)).filter(Boolean);
    return [...new Set(resolvedIds)];
};

const toRuntimeOverrides = (actionRecord: Record<string, unknown>): Record<string, unknown> => {
    const runtimeOverrides: Record<string, unknown> = {
        ...toRecord(actionRecord.runtime),
        ...toRecord(actionRecord.properties)
    };
    if (typeof actionRecord.code === 'string') runtimeOverrides.code = actionRecord.code;
    if (typeof actionRecord.markdown === 'string') runtimeOverrides.markdown = actionRecord.markdown;
    Object.entries(actionRecord).forEach(([key, entry]) => {
        if (RESERVED_ACTION_KEYS.has(key)) return;
        if (typeof entry === 'undefined') return;
        runtimeOverrides[key] = entry;
    });
    return runtimeOverrides;
};

const getDefaultInputHandle = (workflow: WorkflowDefinition, modelId: string): string | null => {
    const sortedInputs = getSortedInputPorts(workflow, modelId);
    if (sortedInputs.length > 0) return `in:${sortedInputs[0]}`;
    const sortedCommands = getSortedCommandPorts(workflow, modelId);
    return sortedCommands.length > 0 ? toCanonicalCommandHandle(sortedCommands[0]) : 'in:input';
};

const getDefaultOutputHandle = (workflow: WorkflowDefinition, modelId: string): string | null => {
    const sortedOutputs = getSortedOutputPorts(workflow, modelId);
    if (sortedOutputs.length > 0) return `out:${sortedOutputs[0]}`;
    const sortedCommands = getSortedCommandPorts(workflow, modelId);
    return sortedCommands.length > 0 ? toCanonicalCommandHandle(sortedCommands[0]) : 'out:output';
};

const mergeNodeRuntime = (node: WorkflowNodeModel, runtimeOverrides: Record<string, unknown>): WorkflowNodeModel => {
    const mergedRuntime = {
        ...(node.runtime ?? {}),
        ...(node.properties ?? {}),
        ...runtimeOverrides
    };
    return {
        ...node,
        runtime: mergedRuntime,
        properties: mergedRuntime,
        inspector: node.inspector
            ? {
                  ...node.inspector,
                  properties: {
                      ...(node.inspector.properties ?? {}),
                      ...mergedRuntime
                  },
                  code: typeof mergedRuntime.code === 'string' ? mergedRuntime.code : node.inspector.code,
                  markdown: typeof mergedRuntime.markdown === 'string' ? mergedRuntime.markdown : node.inspector.markdown
              }
            : node.inspector
    };
};

const updateNodeById = (workflow: WorkflowDefinition, nodeId: string, updater: (node: WorkflowNodeModel) => WorkflowNodeModel): WorkflowDefinition => ({
    ...workflow,
    nodes: workflow.nodes.map((node) => (node.id === nodeId ? updater(node) : node))
});

const buildConnection = (workflow: WorkflowDefinition, sourceNodeId: string, targetNodeId: string, sourceHandle?: string | null, targetHandle?: string | null, warnings?: string[]): WorkflowDefinition => {
    const sourceNode = workflow.nodes.find((node) => node.id === sourceNodeId);
    const targetNode = workflow.nodes.find((node) => node.id === targetNodeId);
    if (!sourceNode || !targetNode) return workflow;
    let resolvedSourceHandle = sourceHandle ?? null;
    let resolvedTargetHandle = targetHandle ?? null;

    if (!resolvedSourceHandle || !resolvedTargetHandle) {
        const candidateSourceHandles = resolvedSourceHandle
            ? [resolvedSourceHandle]
            : [...getSortedOutputPorts(workflow, sourceNode.modelId).map((portId) => `out:${portId}`), ...getSortedCommandPorts(workflow, sourceNode.modelId).map((portId) => toCanonicalCommandHandle(portId))];
        let matchedConnection: Connection | null = null;
        let matchedScore = -1;
        for (const candidateSourceHandle of candidateSourceHandles) {
            const nextTargetHandle = resolvedTargetHandle ?? resolveInputHandleWithCompatibility(workflow, sourceNode, targetNode, candidateSourceHandle);
            const candidateConnection: Connection = {
                source: sourceNodeId,
                target: targetNodeId,
                sourceHandle: candidateSourceHandle,
                targetHandle: nextTargetHandle
            };
            if (!canAttachConnection(workflow, candidateConnection)) continue;
            const [, candidateSourcePort = 'output'] = candidateSourceHandle.split(':');
            const [, candidateTargetPort = 'input'] = (nextTargetHandle ?? '').split(':');
            const sourcePortType = getOutputPortType(workflow, sourceNode.modelId, candidateSourcePort);
            const targetPortType = getInputPortType(workflow, targetNode.modelId, candidateTargetPort);
            const score = sourcePortType && targetPortType && sourcePortType === targetPortType ? 2 : 1;
            if (!matchedConnection || score > matchedScore) {
                matchedConnection = candidateConnection;
                matchedScore = score;
            }
        }
        if (!matchedConnection) {
            warnings?.push(`Connection rejected for "${sourceNode.name}" -> "${targetNode.name}" due to port compatibility rules.`);
            return workflow;
        }
        resolvedSourceHandle = matchedConnection.sourceHandle ?? null;
        resolvedTargetHandle = matchedConnection.targetHandle ?? null;
    } else {
        const candidateConnection: Connection = {
            source: sourceNodeId,
            target: targetNodeId,
            sourceHandle: resolvedSourceHandle ?? undefined,
            targetHandle: resolvedTargetHandle ?? undefined
        };
        if (!canAttachConnection(workflow, candidateConnection)) {
            warnings?.push(`Connection rejected for "${sourceNode.name}" -> "${targetNode.name}" due to port compatibility rules.`);
            return workflow;
        }
    }
    return applyConnection(workflow, sourceNodeId, targetNodeId, resolvedSourceHandle ?? null, resolvedTargetHandle ?? null);
};

const makeConnectionWithInsertedNode = (workflow: WorkflowDefinition, insertedNodeId: string, actionRecord: Record<string, unknown>, warnings: string[]): WorkflowDefinition => {
    const connectFromNodeId = resolveFirstExistingNodeId(workflow, [actionRecord.connectFromNodeId, actionRecord.connect_from_node_id, actionRecord.connectFrom, actionRecord.from]);
    const connectToNodeId = resolveFirstExistingNodeId(workflow, [actionRecord.connectToNodeId, actionRecord.connect_to_node_id, actionRecord.connectTo, actionRecord.to]);
    let next = workflow;
    if (connectFromNodeId) {
        next = buildConnection(next, connectFromNodeId, insertedNodeId, toString(actionRecord.sourceHandle) || null, toString(actionRecord.targetHandle) || null, warnings);
    }
    if (connectToNodeId) {
        next = buildConnection(next, insertedNodeId, connectToNodeId, toString(actionRecord.sourceHandleToTarget) || null, toString(actionRecord.targetHandleToTarget) || null, warnings);
    }
    return next;
};

const normalizeReplacementNode = (existingNode: WorkflowNodeModel, replacement: Record<string, unknown>): WorkflowNodeModel => {
    const positionCandidate = toRecord(replacement.position);
    const x = toFiniteNumber(positionCandidate.x);
    const y = toFiniteNumber(positionCandidate.y);
    const runtimeCandidate = {
        ...toRecord(existingNode.runtime),
        ...toRecord(existingNode.properties),
        ...toRecord(replacement.runtime),
        ...toRecord(replacement.properties)
    };
    const inputCandidate = toRecord(replacement.input);
    const portsCandidate = toRecord(replacement.ports);
    const inPorts = toRecord(portsCandidate.in);
    const outPorts = toRecord(portsCandidate.out);
    const nextNode: WorkflowNodeModel = {
        ...existingNode,
        ...replacement,
        id: existingNode.id,
        modelId: toString(replacement.modelId) || existingNode.modelId,
        name: toString(replacement.name) || existingNode.name,
        description: toString(replacement.description) || existingNode.description,
        position: {
            x: x ?? existingNode.position.x,
            y: y ?? existingNode.position.y
        },
        status:
            toString(replacement.status) === WorkflowNodeStatusEnum.Passed ||
            toString(replacement.status) === WorkflowNodeStatusEnum.Failed ||
            toString(replacement.status) === WorkflowNodeStatusEnum.Warning ||
            toString(replacement.status) === WorkflowNodeStatusEnum.Running ||
            toString(replacement.status) === WorkflowNodeStatusEnum.Stopped
                ? (toString(replacement.status) as WorkflowNodeStatusEnum)
                : existingNode.status,
        runtime: runtimeCandidate,
        properties: runtimeCandidate,
        ports:
            Object.keys(inPorts).length || Object.keys(outPorts).length
                ? {
                      in: Object.keys(inPorts).length ? (inPorts as WorkflowNodeModel['ports']['in']) : existingNode.ports.in,
                      out: Object.keys(outPorts).length ? outPorts : existingNode.ports.out
                  }
                : existingNode.ports,
        input: Object.keys(inputCandidate).length ? inputCandidate : existingNode.input,
        output: Object.prototype.hasOwnProperty.call(replacement, 'output') ? replacement.output : existingNode.output,
        inspector: existingNode.inspector
            ? {
                  ...existingNode.inspector,
                  title: toString(replacement.name) || existingNode.inspector.title || existingNode.name,
                  properties: {
                      ...(existingNode.inspector.properties ?? {}),
                      ...runtimeCandidate
                  }
              }
            : existingNode.inspector
    };
    return nextNode;
};

const replaceNodeInWorkflow = (workflow: WorkflowDefinition, nodeId: string, replacement: Record<string, unknown>): WorkflowDefinition => ({
    ...workflow,
    nodes: workflow.nodes.map((node) => (node.id === nodeId ? normalizeReplacementNode(node, replacement) : node))
});

export const applyWorkflowAiActions = async (input: ApplyWorkflowAiActionsInput): Promise<WorkflowAiActionRunResult> => {
    const result: WorkflowAiActionRunResult = { applied: [], warnings: [] };
    if (!input.actions.length) return result;
    if (!input.workflow) {
        result.warnings.push('Workflow is not available.');
        return result;
    }

    let nextWorkflow = input.workflow;
    let workflowChanged = false;
    const deferredActions: Array<() => Promise<void>> = [];
    const nodeLibraryByModelId = new Map(input.nodeLibraryItems.map((item) => [item.modelId, item]));

    for (const action of input.actions) {
        const actionRecord = mergeActionRecord(toRecord(action));
        const actionType = toNormalizedActionType(actionRecord.type);
        if (!actionType) continue;

        if (['clear-workflow', 'clear'].includes(actionType)) {
            nextWorkflow = {
                ...nextWorkflow,
                nodes: [],
                connections: []
            };
            workflowChanged = true;
            result.applied.push('Cleared workflow canvas.');
            continue;
        }

        if (['apply-workflow-cypher'].includes(actionType)) {
            const cypher = toString(actionRecord.cypher);
            if (!cypher) {
                result.warnings.push('apply_workflow_cypher requires "cypher".');
                continue;
            }
            const parsed = await workflowFromCypher({
                cypher,
                baseWorkflow: nextWorkflow,
                nodeLibraryItems: input.nodeLibraryItems
            });
            nextWorkflow = parsed.workflow;
            workflowChanged = true;
            result.warnings.push(...parsed.warnings);
            result.applied.push('Applied workflow cypher.');
            continue;
        }

        if (['replace-workflow', 'create-workflow', 'import-workflow', 'update-workflow'].includes(actionType)) {
            const candidate = parseWorkflowCandidate(actionRecord);
            if (!candidate) {
                result.warnings.push('AI action replace_workflow did not include a valid workflow payload.');
                continue;
            }
            nextWorkflow = candidate;
            workflowChanged = true;
            result.applied.push('Replaced workflow from AI payload.');
            continue;
        }

        if (['add-node', 'create-node'].includes(actionType)) {
            const modelId = toString(actionRecord.modelId) || toString(actionRecord.nodeModelId) || toString(actionRecord.model_id) || toString(actionRecord.node_model_id);
            const libraryItem = nodeLibraryByModelId.get(modelId);
            if (!libraryItem) {
                result.warnings.push(`Node model "${modelId}" is not available in the current node catalog.`);
                continue;
            }
            const positionRecord = toRecord(actionRecord.position);
            const preferredPosition = isFinitePosition(positionRecord) ? { x: Number(positionRecord.x), y: Number(positionRecord.y) } : null;
            const resolvedPosition = resolveCollisionFreePosition(nextWorkflow, modelId, preferredPosition);
            const beforeNodeIds = new Set(nextWorkflow.nodes.map((node) => node.id));
            let updatedWorkflow = addDroppedNode(nextWorkflow, libraryItem, resolvedPosition);
            const insertedNode = updatedWorkflow.nodes.find((node) => !beforeNodeIds.has(node.id));
            if (!insertedNode) {
                result.warnings.push(`Unable to add node for model "${modelId}". The node sequence might be full.`);
                continue;
            }
            const runtimeOverrides = sanitizeRuntimeOverridesForNode(updatedWorkflow, insertedNode, toRuntimeOverrides(actionRecord), result.warnings);
            const nameOverride = toString(actionRecord.name);
            const descriptionOverride = toString(actionRecord.description);
            updatedWorkflow = updateNodeById(updatedWorkflow, insertedNode.id, (node) => {
                const runtimeMergedNode = mergeNodeRuntime(node, runtimeOverrides);
                return {
                    ...runtimeMergedNode,
                    name: nameOverride || runtimeMergedNode.name,
                    description: descriptionOverride || runtimeMergedNode.description
                };
            });
            updatedWorkflow = makeConnectionWithInsertedNode(updatedWorkflow, insertedNode.id, actionRecord, result.warnings);
            nextWorkflow = updatedWorkflow;
            workflowChanged = true;
            result.applied.push(`Added node "${nameOverride || insertedNode.name}" (${modelId}).`);
            continue;
        }

        if (['update-node', 'edit-node', 'configure-node', 'set-node-data', 'fill-code-node', 'set-node-code'].includes(actionType)) {
            let nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            if (!nodeId) {
                const modelHint = toString(actionRecord.modelId) || toString(actionRecord.nodeModelId) || toString(actionRecord.model_id);
                if (modelHint) {
                    const byModel = nextWorkflow.nodes.filter((node) => toComparable(node.modelId) === toComparable(modelHint));
                    if (byModel.length === 1) {
                        nodeId = byModel[0].id;
                    }
                }
            }
            const targetNode = nextWorkflow.nodes.find((node) => node.id === nodeId);
            if (!targetNode) {
                result.warnings.push(`Node "${toString(actionRecord.nodeId) || toString(actionRecord.node_id) || toString(actionRecord.id)}" was not found for update_node.`);
                continue;
            }
            const runtimeOverrides = sanitizeRuntimeOverridesForNode(nextWorkflow, targetNode, toRuntimeOverrides(actionRecord), result.warnings);
            const nameOverride = toString(actionRecord.name);
            const descriptionOverride = toString(actionRecord.description);
            const positionRecord = toRecord(actionRecord.position);
            const requestedPosition = isFinitePosition(positionRecord) ? { x: Number(positionRecord.x), y: Number(positionRecord.y) } : null;
            const resolvedPosition = requestedPosition ? resolveCollisionFreePosition(nextWorkflow, targetNode.modelId, requestedPosition, targetNode.id) : null;
            nextWorkflow = updateNodeById(nextWorkflow, nodeId, (node) => {
                const runtimeMergedNode = mergeNodeRuntime(node, runtimeOverrides);
                return {
                    ...runtimeMergedNode,
                    name: nameOverride || runtimeMergedNode.name,
                    description: descriptionOverride || runtimeMergedNode.description,
                    position: resolvedPosition ?? runtimeMergedNode.position
                };
            });
            workflowChanged = true;
            result.applied.push(`Updated node "${nodeId}".`);
            continue;
        }

        if (['replace-node'].includes(actionType)) {
            const nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            const replacement = toRecord(actionRecord.nodeModel ?? actionRecord.nodeData ?? actionRecord.node);
            if (!nodeId || !Object.keys(replacement).length) {
                result.warnings.push('replace_node requires "nodeId" and "node".');
                continue;
            }
            const targetNode = nextWorkflow.nodes.find((node) => node.id === nodeId);
            if (!targetNode) {
                result.warnings.push(`Node "${nodeId}" was not found for replace_node.`);
                continue;
            }
            nextWorkflow = replaceNodeInWorkflow(nextWorkflow, nodeId, replacement);
            workflowChanged = true;
            result.applied.push(`Replaced node "${nodeId}".`);
            continue;
        }

        if (['delete-node', 'remove-node'].includes(actionType)) {
            const nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            if (!nodeId) {
                result.warnings.push('delete_node requires "nodeId".');
                continue;
            }
            const exists = nextWorkflow.nodes.some((node) => node.id === nodeId);
            if (!exists) {
                result.warnings.push(`Node "${nodeId}" was not found for delete_node.`);
                continue;
            }
            nextWorkflow = removeNodeFromWorkflow(nextWorkflow, nodeId);
            workflowChanged = true;
            result.applied.push(`Deleted node "${nodeId}".`);
            continue;
        }

        if (['create-subworkflow'].includes(actionType)) {
            const nodeIds = resolveNodeIdsFromValue(nextWorkflow, actionRecord.nodeIds ?? actionRecord.node_ids ?? actionRecord.nodes ?? actionRecord.nodeId);
            const subworkflowId = toString(actionRecord.subworkflowId || actionRecord.subworkflow_id) || null;
            if (!nodeIds.length) {
                result.warnings.push('create_subworkflow requires at least one node id in "nodeIds".');
                continue;
            }
            nextWorkflow = createOrExtendSubworkflow(nextWorkflow, nodeIds, subworkflowId);
            workflowChanged = true;
            result.applied.push(subworkflowId ? `Added nodes to subworkflow "${subworkflowId}".` : 'Created subworkflow.');
            continue;
        }

        if (['connect-nodes', 'add-connection'].includes(actionType)) {
            const sourceNodeId = resolveConnectNodeId(nextWorkflow, actionRecord, 'sourceNodeId');
            const targetNodeId = resolveConnectNodeId(nextWorkflow, actionRecord, 'targetNodeId');
            if (!sourceNodeId || !targetNodeId) {
                const providedKeys = Object.keys(actionRecord).filter((key) => key !== 'type');
                result.warnings.push(`connect_nodes requires explicit "sourceNodeId" and "targetNodeId" keys (values can be node id or exact node name). Received: ${providedKeys.join(', ') || 'none'}.`);
                continue;
            }
            nextWorkflow = buildConnection(nextWorkflow, sourceNodeId, targetNodeId, toString(actionRecord.sourceHandle) || null, toString(actionRecord.targetHandle) || null, result.warnings);
            workflowChanged = true;
            result.applied.push(`Connected "${sourceNodeId}" -> "${targetNodeId}".`);
            continue;
        }

        if (['open-inspector'].includes(actionType)) {
            const nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            if (!nodeId) {
                result.warnings.push('open_inspector requires "nodeId".');
                continue;
            }
            deferredActions.push(async () => {
                input.openInspector(nodeId);
            });
            result.applied.push(`Opened inspector for "${nodeId}".`);
            continue;
        }

        if (['execute-node-step', 'run-node-step'].includes(actionType)) {
            const nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            if (!nodeId) {
                result.warnings.push('execute_node_step requires "nodeId".');
                continue;
            }
            deferredActions.push(async () => {
                await input.runNodeStep(nodeId);
            });
            result.applied.push(`Executed node step for "${nodeId}".`);
            continue;
        }

        if (['run-workflow-local', 'play-local'].includes(actionType)) {
            deferredActions.push(async () => {
                await input.runWorkflowLocal();
            });
            result.applied.push('Started local workflow run.');
            continue;
        }

        if (['run-workflow-server', 'play-server'].includes(actionType)) {
            deferredActions.push(async () => {
                await input.runWorkflowServer();
            });
            result.applied.push('Started server workflow run.');
            continue;
        }

        if (['show-logs', 'open-logs'].includes(actionType)) {
            deferredActions.push(async () => {
                input.showLogs();
            });
            result.applied.push('Opened workflow logs.');
            continue;
        }

        if (['export-workflow-with-data'].includes(actionType)) {
            deferredActions.push(async () => {
                input.exportWorkflowWithData?.();
            });
            result.applied.push('Exported workflow with data.');
            continue;
        }

        if (['export-workflow-only'].includes(actionType)) {
            deferredActions.push(async () => {
                input.exportWorkflowOnly?.();
            });
            result.applied.push('Exported workflow-only JSON.');
            continue;
        }

        if (['replace-node-connections'].includes(actionType)) {
            const nodeId = resolveNodeIdFromKeys(nextWorkflow, actionRecord, ACTION_NODE_ID_KEYS);
            const targetNode = nextWorkflow.nodes.find((node) => node.id === nodeId);
            if (!targetNode) {
                result.warnings.push(`Node "${nodeId}" was not found for replace_node_connections.`);
                continue;
            }
            const incomingConnections = toArray(actionRecord.incoming).map((entry) => toRecord(entry));
            const outgoingConnections = toArray(actionRecord.outgoing).map((entry) => toRecord(entry));
            const preservedConnections = nextWorkflow.connections.filter((connection) => connection.from !== nodeId && connection.to !== nodeId);
            const builtConnections: WorkflowConnectionModel[] = [];
            incomingConnections.forEach((connection, index) => {
                const from = resolveFirstExistingNodeId(nextWorkflow, [connection.from, connection.source, connection.sourceNodeId]);
                if (!from) return;
                const built = buildConnection(
                    { ...nextWorkflow, connections: [] },
                    from,
                    nodeId,
                    toString(connection.sourceHandle) || null,
                    toString(connection.targetHandle) || getDefaultInputHandle(nextWorkflow, targetNode.modelId),
                    result.warnings
                );
                const incomingConnection = built.connections[0];
                if (!incomingConnection) return;
                builtConnections.push({
                    ...incomingConnection,
                    id: incomingConnection.id || `connection_in_${nodeId}_${index + 1}`
                });
            });
            outgoingConnections.forEach((connection, index) => {
                const to = resolveFirstExistingNodeId(nextWorkflow, [connection.to, connection.target, connection.targetNodeId]);
                if (!to) return;
                const built = buildConnection(
                    { ...nextWorkflow, connections: [] },
                    nodeId,
                    to,
                    toString(connection.sourceHandle) || getDefaultOutputHandle(nextWorkflow, targetNode.modelId),
                    toString(connection.targetHandle) || null,
                    result.warnings
                );
                const outgoingConnection = built.connections[0];
                if (!outgoingConnection) return;
                builtConnections.push({
                    ...outgoingConnection,
                    id: outgoingConnection.id || `connection_out_${nodeId}_${index + 1}`
                });
            });
            nextWorkflow = {
                ...nextWorkflow,
                connections: [...preservedConnections, ...builtConnections]
            };
            workflowChanged = true;
            result.applied.push(`Replaced connections for node "${nodeId}".`);
            continue;
        }

        result.warnings.push(`Unknown action type "${actionType}".`);
    }

    if (workflowChanged) {
        result.warnings.push(...buildWorkflowGraphHealth(nextWorkflow));
        input.replaceWorkflow(nextWorkflow);
    }

    for (const deferred of deferredActions) {
        try {
            await deferred();
        } catch (error) {
            result.warnings.push(error instanceof Error ? error.message : 'An AI action failed to execute.');
        }
    }

    return result;
};
