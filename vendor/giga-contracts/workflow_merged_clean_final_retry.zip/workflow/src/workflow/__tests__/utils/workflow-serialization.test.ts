import { describe, expect, it } from 'vitest';
import { exportPayloadToWorkflow, workflowToExportPayload } from '@workflow/ui/workflow/utils/workflow-serialization.utils';
import { withNodeExecutors } from '@workflow/ui/workflow/utils/workflow-node-executors.utils';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('workflow serialization', () => {
    it('exports nodes and connections using node names as canonical references', () => {
        const workflow = createEmptyWorkflow('wf_export_names');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Transform', 2);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [start, code, end];
        workflow.connections = [createConnection('c1', start.id, code.id), createConnection('c2', code.id, end.id)];

        const payload = workflowToExportPayload(workflow, 'workflow-only');
        expect(Object.keys(payload.nodes)).toEqual(expect.arrayContaining(['Start', 'Transform', 'End']));
        expect(payload.connections.c1.from).toBe('Start');
        expect(payload.connections.c1.to).toBe('Transform');
        expect(payload.connections.c1.fromId).toBe(start.id);
        expect(payload.connections.c1.toId).toBe(code.id);
    });

    it('imports legacy id-referenced payloads', () => {
        const payload = {
            exportMode: 'workflow-only',
            metadata: { id: 'wf_legacy', name: 'Legacy' },
            nodes: {
                'StartNode:node_1': {
                    id: 'node_1',
                    gigaId: 'StartNode',
                    modelId: 'start',
                    type: 'workflowStep',
                    name: 'Start',
                    description: '',
                    status: 'running',
                    kind: 'process',
                    position: { x: 0, y: 100 },
                    runtime: {},
                    ports: { in: {}, out: {} }
                },
                'RespondEndNode:node_2': {
                    id: 'node_2',
                    gigaId: 'RespondEndNode',
                    modelId: 'respond-end',
                    type: 'workflowStep',
                    name: 'End',
                    description: '',
                    status: 'running',
                    kind: 'output',
                    position: { x: 320, y: 100 },
                    runtime: {},
                    ports: { in: {}, out: {} }
                }
            },
            connections: {
                c1: {
                    id: 'c1',
                    name: 'legacy edge',
                    from: 'node_1',
                    to: 'node_2',
                    sourceHandle: 'out:output',
                    targetHandle: 'in:input'
                }
            }
        } as const;

        const workflow = exportPayloadToWorkflow(payload);
        expect(workflow.nodes).toHaveLength(2);
        expect(workflow.connections).toHaveLength(1);
        expect(workflow.connections[0].from).toBe('node_1');
        expect(workflow.connections[0].to).toBe('node_2');
    });

    it('imports name-based payloads and preserves connection mapping', () => {
        const payload = {
            exportMode: 'workflow-only',
            metadata: { id: 'wf_names', name: 'Names' },
            nodes: {
                Start: {
                    id: 'node_1',
                    gigaId: 'StartNode',
                    modelId: 'start',
                    type: 'workflowStep',
                    name: 'Start',
                    description: '',
                    status: 'running',
                    kind: 'process',
                    position: { x: 0, y: 120 },
                    runtime: {},
                    ports: { in: {}, out: {} }
                },
                End: {
                    id: 'node_2',
                    gigaId: 'RespondEndNode',
                    modelId: 'respond-end',
                    type: 'workflowStep',
                    name: 'End',
                    description: '',
                    status: 'running',
                    kind: 'output',
                    position: { x: 320, y: 120 },
                    runtime: {},
                    ports: { in: {}, out: {} }
                }
            },
            connections: {
                edge_1: {
                    id: 'edge_1',
                    name: 'Start -> End',
                    from: 'Start',
                    to: 'End',
                    fromId: 'node_1',
                    toId: 'node_2'
                }
            }
        } as const;

        const workflow = exportPayloadToWorkflow(payload);
        expect(workflow.connections[0].from).toBe('node_1');
        expect(workflow.connections[0].to).toBe('node_2');
    });

    it('includes nodeModels documentation in with-data exports only', () => {
        const workflow = createEmptyWorkflow('wf_export_node_models');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const end = createWorkflowNode(workflow, 'respond-end', 'End', 2);
        workflow.nodes = [start, end];
        workflow.connections = [createConnection('c1', start.id, end.id)];

        const workflowOnlyPayload = workflowToExportPayload(workflow, 'workflow-only');
        expect(workflowOnlyPayload.nodeModels).toBeUndefined();

        const withDataPayload = workflowToExportPayload(workflow, 'with-data');
        expect(withDataPayload.nodeModels).toBeTruthy();
        expect(withDataPayload.nodeModels?.start?.documentation?.summary).toBeTruthy();

        const imported = exportPayloadToWorkflow(withDataPayload);
        expect(imported.nodeModels?.start?.documentation?.summary).toBe(withDataPayload.nodeModels?.start?.documentation?.summary);
    });

    it('includes NODE_EXECUTORS and signatures in with-data payload only', () => {
        const workflow = createEmptyWorkflow('wf_export_workers');
        const start = createWorkflowNode(workflow, 'start', 'Start', 1);
        const code = createWorkflowNode(workflow, 'code', 'Code', 2);
        workflow.nodes = [start, code];

        const withExecutors = withNodeExecutors(workflow);
        const workflowOnlyPayload = workflowToExportPayload(withExecutors, 'workflow-only');
        expect(workflowOnlyPayload.NODE_EXECUTORS).toBeUndefined();
        expect(workflowOnlyPayload.NODE_EXECUTOR_SIGNATURES).toBeUndefined();

        const withDataPayload = workflowToExportPayload(withExecutors, 'with-data');
        expect(withDataPayload.NODE_EXECUTORS).toBeTruthy();
        expect(withDataPayload.NODE_EXECUTOR_SIGNATURES).toBeTruthy();
        expect(Object.keys(withDataPayload.NODE_EXECUTORS ?? {})).toEqual(expect.arrayContaining(['start', 'code']));

        const imported = exportPayloadToWorkflow(withDataPayload);
        expect(imported.NODE_EXECUTORS).toEqual(withDataPayload.NODE_EXECUTORS);
        expect(imported.NODE_EXECUTOR_SIGNATURES).toEqual(withDataPayload.NODE_EXECUTOR_SIGNATURES);
    });

    it('exports runtime data after removing recursive values', () => {
        const workflow = createEmptyWorkflow('wf_export_clean');
        const code = createWorkflowNode(workflow, 'code', 'Code', 1);
        const recursive: Record<string, unknown> = { ok: true };
        recursive.self = recursive;
        code.runtime = { recursive };
        code.ports.out.output = recursive;
        workflow.nodes = [code];

        const payload = workflowToExportPayload(workflow, 'with-data');

        expect(payload.nodes.Code.runtime.recursive).toEqual({ ok: true });
        expect(payload.nodes.Code.ports.out.output).toEqual({ ok: true });
        expect(() => JSON.stringify(payload)).not.toThrow();
    });

    it('does not let stale inspector properties override current runtime on export', () => {
        const workflow = createEmptyWorkflow('wf_export_runtime_wins');
        const governor = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 1);
        governor.runtime = { selectionPromptMd: '{{code_5.query}}' };
        governor.properties = governor.runtime;
        governor.inspector = { ...(governor.inspector ?? { title: governor.name, input: {}, viewers: [] }), properties: { selectionPromptMd: '{{code\\_5.query}}', error: 'old' } };
        workflow.nodes = [governor];

        const payload = workflowToExportPayload(workflow, 'with-data');

        expect(payload.nodes['AI Governor'].runtime.selectionPromptMd).toBe('{{code_5.query}}');
        expect(payload.nodes['AI Governor'].runtime.error).toBeUndefined();
    });
});
