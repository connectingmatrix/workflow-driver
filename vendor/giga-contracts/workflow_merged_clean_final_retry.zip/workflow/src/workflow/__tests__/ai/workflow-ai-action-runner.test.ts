import { describe, expect, it, vi } from 'vitest';
import { applyWorkflowAiActions } from '@workflow/ui/workflow/ai/action-runner';
import { getNodeLibraryItems } from '@workflow/nodes/node-utils';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { WORKFLOW_AI_KNOWLEDGE } from '@workflow/ui/workflow/ai/knowledge';

describe('workflow-ai action runner', () => {
    it('adds a node and updates its runtime through AI actions', async () => {
        const workflow = createEmptyWorkflow('wf_ai_actions_add');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 2);
        workflow.nodes = [startNode, endNode];
        workflow.connections = [createConnection('c_1', startNode.id, endNode.id)];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'add_node',
                    modelId: 'code',
                    name: 'Code AI',
                    runtime: { code: 'return { ok: true };' },
                    connectFromNodeId: startNode.id,
                    connectToNodeId: endNode.id
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const addedNode = latestWorkflow.nodes.find((node) => node.modelId === 'code');
        expect(addedNode?.id).toBeTruthy();
        const updateResult = await applyWorkflowAiActions({
            workflow: latestWorkflow,
            actions: [
                {
                    type: 'update_node',
                    nodeId: addedNode?.id,
                    runtime: { failureMitigation: 'retry-node' }
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        expect(result.warnings).toEqual([]);
        expect(updateResult.warnings).toEqual([]);
        expect(addedNode?.name).toBe('Code AI');
        expect(latestWorkflow.nodes.find((node) => node.id === addedNode?.id)?.runtime?.code).toBe('return { ok: true };');
        expect(latestWorkflow.nodes.find((node) => node.id === addedNode?.id)?.runtime?.failureMitigation).toBe('retry-node');
        expect(latestWorkflow.connections.some((connection) => connection.to === addedNode?.id)).toBe(true);
        expect(latestWorkflow.connections.some((connection) => connection.from === addedNode?.id)).toBe(true);
    });

    it('runs side-effect actions for execute step and play modes', async () => {
        const workflow = createEmptyWorkflow('wf_ai_actions_side_effects');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        workflow.nodes = [startNode];

        const runNodeStep = vi.fn(async () => undefined);
        const runWorkflowLocal = vi.fn(async () => undefined);
        const runWorkflowServer = vi.fn(async () => undefined);
        const openInspector = vi.fn();
        const showLogs = vi.fn();

        await applyWorkflowAiActions({
            workflow,
            actions: [{ type: 'execute_node_step', nodeId: startNode.id }, { type: 'run_workflow_local' }, { type: 'run_workflow_server' }, { type: 'open_inspector', nodeId: startNode.id }, { type: 'show_logs' }],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: vi.fn(),
            runNodeStep,
            runWorkflowLocal,
            runWorkflowServer,
            openInspector,
            showLogs
        });

        expect(runNodeStep).toHaveBeenCalledWith(startNode.id);
        expect(runWorkflowLocal).toHaveBeenCalledTimes(1);
        expect(runWorkflowServer).toHaveBeenCalledTimes(1);
        expect(openInspector).toHaveBeenCalledWith(startNode.id);
        expect(showLogs).toHaveBeenCalledTimes(1);
    });

    it('applies workflow cypher as a full graph repair action', async () => {
        const workflow = createEmptyWorkflow('wf_ai_apply_cypher');
        const staleNode = createWorkflowNode(workflow, 'code', 'Stale', 1);
        workflow.nodes = [staleNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [{ type: 'apply_workflow_cypher', cypher: WORKFLOW_AI_KNOWLEDGE[0].solutionCypher }],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        expect(result.applied).toContain('Applied workflow cypher.');
        expect(latestWorkflow.nodes.some((node) => node.name === 'Threat Analysis Governor')).toBe(true);
        expect(latestWorkflow.nodes.some((node) => node.name === 'Stale')).toBe(false);
    });

    it('accepts exact node-name values in sourceNodeId/targetNodeId for connect actions', async () => {
        const workflow = createEmptyWorkflow('wf_ai_actions_aliases');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Wildcard Matcher', 2);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
        workflow.nodes = [startNode, codeNode, endNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'connect_nodes',
                    sourceNodeId: 'Start',
                    targetNodeId: 'Wildcard Matcher'
                },
                {
                    type: 'connect_nodes',
                    sourceNodeId: codeNode.id,
                    targetNodeId: 'End'
                },
                {
                    type: 'update_node',
                    node: 'Wildcard Matcher',
                    code: 'return { matched: true };'
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        expect(result.warnings).toEqual([]);
        expect(latestWorkflow.connections.some((connection) => connection.from === startNode.id && connection.to === codeNode.id)).toBe(true);
        expect(latestWorkflow.connections.some((connection) => connection.from === codeNode.id && connection.to === endNode.id)).toBe(true);
        expect(latestWorkflow.nodes.find((node) => node.id === codeNode.id)?.runtime?.code).toBe('return { matched: true };');
    });

    it('warns when connect_nodes omits sourceNodeId/targetNodeId', async () => {
        const workflow = createEmptyWorkflow('wf_ai_connect_strict_keys');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        workflow.nodes = [startNode, codeNode];
        workflow.connections = [];

        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'connect_nodes',
                    from: 'Start',
                    to: 'Code'
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: vi.fn(),
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        expect(result.warnings.some((entry) => entry.includes('connect_nodes requires explicit "sourceNodeId" and "targetNodeId" keys'))).toBe(true);
    });

    it('applies top-level runtime fields when adding a node', async () => {
        const workflow = createEmptyWorkflow('wf_ai_actions_add_top_level');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 2);
        workflow.nodes = [startNode, endNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'add_node',
                    model_id: 'code',
                    name: 'Matcher Node',
                    code: 'return { ok: true };',
                    forwardSessionLogs: true,
                    connectFromNodeId: 'Start',
                    connectToNodeId: endNode.id
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const addedNode = latestWorkflow.nodes.find((node) => node.name === 'Matcher Node');
        expect(result.warnings).toEqual([]);
        expect(addedNode?.runtime?.code).toBe('return { ok: true };');
        expect(addedNode?.runtime?.forwardSessionLogs).not.toBe(true);
        expect(latestWorkflow.connections.some((connection) => connection.from === startNode.id && connection.to === addedNode?.id)).toBe(true);
        expect(latestWorkflow.connections.some((connection) => connection.from === addedNode?.id && connection.to === endNode.id)).toBe(true);
    });

    it('infers AI Governor LLM input handle and enforces model-only compatibility', async () => {
        const workflow = createEmptyWorkflow('wf_ai_governor_connection_contract');
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 1);
        const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 3);
        workflow.nodes = [openAiNode, codeNode, governorNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'connect_nodes',
                    sourceNodeId: openAiNode.id,
                    targetNodeId: governorNode.id
                },
                {
                    type: 'connect_nodes',
                    sourceNodeId: codeNode.id,
                    targetNodeId: governorNode.id,
                    targetHandle: 'cmd:llm'
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const validConnection = latestWorkflow.connections.find((connection) => connection.from === openAiNode.id && connection.to === governorNode.id);
        const invalidConnection = latestWorkflow.connections.find((connection) => connection.from === codeNode.id && connection.to === governorNode.id);
        expect(validConnection?.targetHandle).toBe('cmd:llm');
        expect(invalidConnection).toBeUndefined();
        expect(result.warnings.some((entry) => entry.includes('port compatibility'))).toBe(true);
    });

    it('allows AI governor selection prompt updates without routing fields', async () => {
        const workflow = createEmptyWorkflow('wf_ai_governor_selection_prompt');
        const openAiNode = createWorkflowNode(workflow, 'openai', 'OpenAI', 1);
        const governorNode = createWorkflowNode(workflow, 'ai-governor', 'AI Governor', 2);
        workflow.nodes = [openAiNode, governorNode];
        workflow.connections = [createConnection('c1', openAiNode.id, governorNode.id, 'cmd:command', 'cmd:llm')];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                {
                    type: 'update_node',
                    nodeId: governorNode.id,
                    runtime: {
                        selectionPromptMd: 'Plan the connected actions.'
                    }
                }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const runtime = latestWorkflow.nodes.find((node) => node.id === governorNode.id)?.runtime ?? {};
        expect(runtime.selectionPromptMd).toBe('Plan the connected actions.');
        expect(runtime.selectedModels).toBeUndefined();
        expect(runtime.allowedModels).toBeUndefined();
        expect(result.warnings.some((entry) => entry.includes('provided values'))).toBe(false);
    });

    it('infers the AI Agent workflow port for workflow nodes before generic tool ports', async () => {
        const workflow = createEmptyWorkflow('wf_ai_agent_workflow_port');
        const workflowToolNode = createWorkflowNode(workflow, 'workflow', 'Workflow Tool', 1);
        const executeWorkflowNode = createWorkflowNode(workflow, 'execute-workflow', 'Execute Workflow', 2);
        const agentNode = createWorkflowNode(workflow, 'ai-agent', 'AI Agent', 3);
        workflow.nodes = [workflowToolNode, executeWorkflowNode, agentNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                { type: 'connect_nodes', sourceNodeId: workflowToolNode.id, targetNodeId: agentNode.id },
                { type: 'connect_nodes', sourceNodeId: executeWorkflowNode.id, targetNodeId: agentNode.id }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const workflowConnection = latestWorkflow.connections.find((connection) => connection.from === workflowToolNode.id && connection.to === agentNode.id);
        const executeConnection = latestWorkflow.connections.find((connection) => connection.from === executeWorkflowNode.id && connection.to === agentNode.id);
        expect(workflowConnection?.targetHandle).toBe('cmd:workflow');
        expect(executeConnection?.targetHandle).toBe('cmd:workflow');
        expect(result.warnings).toEqual([]);
    });

    it('auto-positions added nodes to avoid overlap when positions are omitted', async () => {
        const workflow = createEmptyWorkflow('wf_ai_auto_positioning');
        const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
        workflow.nodes = [startNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        await applyWorkflowAiActions({
            workflow,
            actions: [
                { type: 'add_node', modelId: 'code', name: 'Code One' },
                { type: 'add_node', modelId: 'code', name: 'Code Two' }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        const codeNodes = latestWorkflow.nodes.filter((node) => node.modelId === 'code');
        expect(codeNodes.length).toBe(2);
        const distanceX = Math.abs((codeNodes[0]?.position.x ?? 0) - (codeNodes[1]?.position.x ?? 0));
        const distanceY = Math.abs((codeNodes[0]?.position.y ?? 0) - (codeNodes[1]?.position.y ?? 0));
        expect(distanceX > 0 || distanceY > 0).toBe(true);
    });

    it('creates and connects grouped chat action chain using strict connect_nodes payloads', async () => {
        const workflow = createEmptyWorkflow('wf_ai_chatbot_chain');
        const staleNode = createWorkflowNode(workflow, 'code', 'Stale', 1);
        workflow.nodes = [staleNode];
        workflow.connections = [];

        let latestWorkflow = workflow;
        const result = await applyWorkflowAiActions({
            workflow,
            actions: [
                { type: 'clear_workflow' },
                { type: 'add_node', modelId: 'start', name: 'Start' },
                { type: 'add_node', modelId: 'run-chat-action', name: 'Chat', runtime: { action: 'search_cross_subject_knowledge' } },
                { type: 'add_node', modelId: 'ai-governor', name: 'AI Governor' },
                { type: 'add_node', modelId: 'output-format', name: 'Output Format' },
                { type: 'add_node', modelId: 'respond-end', name: 'Respond End' },
                { type: 'connect_nodes', sourceNodeId: 'Start', targetNodeId: 'AI Governor' },
                { type: 'connect_nodes', sourceNodeId: 'Chat', targetNodeId: 'AI Governor', targetHandle: 'cmd:tools' },
                { type: 'connect_nodes', sourceNodeId: 'AI Governor', targetNodeId: 'Output Format' },
                { type: 'connect_nodes', sourceNodeId: 'Output Format', targetNodeId: 'Respond End' }
            ],
            nodeLibraryItems: getNodeLibraryItems(),
            replaceWorkflow: (nextWorkflow) => {
                latestWorkflow = nextWorkflow;
            },
            runNodeStep: vi.fn(async () => undefined),
            runWorkflowLocal: vi.fn(async () => undefined),
            runWorkflowServer: vi.fn(async () => undefined),
            openInspector: vi.fn(),
            showLogs: vi.fn()
        });

        expect(result.warnings).toEqual([]);
        expect(latestWorkflow.nodes.some((node) => node.modelId === 'run-chat-action')).toBe(true);
        expect(
            latestWorkflow.connections.some((connection) => {
                const fromNode = latestWorkflow.nodes.find((node) => node.id === connection.from);
                const toNode = latestWorkflow.nodes.find((node) => node.id === connection.to);
                return fromNode?.name === 'Chat' && toNode?.name === 'AI Governor' && connection.targetHandle === 'cmd:tools';
            })
        ).toBe(true);
        expect(
            latestWorkflow.connections.some((connection) => {
                const fromNode = latestWorkflow.nodes.find((node) => node.id === connection.from);
                const toNode = latestWorkflow.nodes.find((node) => node.id === connection.to);
                return fromNode?.name === 'Output Format' && toNode?.name === 'Respond End';
            })
        ).toBe(true);
    });
});
