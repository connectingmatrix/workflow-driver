import { describe, expect, it } from 'vitest';
import { createNodeExecutorSignature, createWorkerNodeHandler } from '../executor/worker-runtime';
import { WorkflowNodeStatusEnum } from '../types';

const toBase64 = (source: string) => Buffer.from(source, 'utf8').toString('base64');
const LARGE_TEXT = 'x'.repeat(1024 * 1024);
const SOURCE = `
export const validate = async () => ({ ok: true, errors: [], warnings: [] });
export const init = async () => true;
export const onUpdate = async () => ({ ok: true });
export const execute = async () => ({ output: { text: ${JSON.stringify(LARGE_TEXT)} }, status: 'passed', logs: [] });
`;

describe('worker runtime ipc', () => {
    it('delivers large sandbox results before the child exits', async () => {
        const node = {
            id: 'node_1',
            gigaId: 'node_1',
            modelId: 'ipc-large-result',
            type: 'workflowStep',
            name: 'Large Result',
            description: '',
            kind: 'process',
            status: WorkflowNodeStatusEnum.Stopped,
            position: { x: 0, y: 0 },
            runtime: {},
            ports: { in: {}, out: {} }
        };
        const workflow = {
            metadata: { id: 'wf_ipc_large_result', name: 'IPC Large Result' },
            nodeModels: {},
            nodes: [node],
            connections: [],
            NODE_EXECUTORS: { 'ipc-large-result': toBase64(SOURCE) },
            NODE_EXECUTOR_SIGNATURES: { 'ipc-large-result': createNodeExecutorSignature('ipc-large-result', SOURCE) }
        };
        const result = await createWorkerNodeHandler({ modelId: 'ipc-large-result', runtimeEnvironment: 'node' })({
            node,
            workflow,
            settings: { graphqlUrl: 'http://localhost/graphql', authMode: 'none' },
            input: {},
            requestContext: { request: { headers: {} }, supabase: {}, userId: 'user_1' },
            hostContext: {}
        } as any);

        expect(result.status).toBe(WorkflowNodeStatusEnum.Passed);
        expect(String((result.output as Record<string, unknown>).text || '').length).toBe(LARGE_TEXT.length);
    }, 20000);
});
