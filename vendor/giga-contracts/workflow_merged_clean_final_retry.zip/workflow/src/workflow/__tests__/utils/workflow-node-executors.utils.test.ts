import { describe, expect, it } from 'vitest';
import { buildNodeExecutorPayload, withNodeExecutors } from '@workflow/ui/workflow/utils/workflow-node-executors.utils';
import { createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';

describe('workflow node executors utils', () => {
    it('builds NODE_EXECUTORS only for modelIds present in workflow nodes', () => {
        const workflow = createEmptyWorkflow('wf_worker_payload');
        workflow.nodes = [createWorkflowNode(workflow, 'start', 'Start', 1), createWorkflowNode(workflow, 'code', 'Code', 2)];

        const payload = buildNodeExecutorPayload(workflow);
        expect(payload.NODE_EXECUTORS.start).toBeTruthy();
        expect(payload.NODE_EXECUTORS.code).toBeTruthy();
        expect(payload.NODE_EXECUTOR_SIGNATURES.start).toMatch(/^wf-sign-v1-/);
        expect(payload.NODE_EXECUTOR_SIGNATURES.code).toMatch(/^wf-sign-v1-/);
    });

    it('attaches executors/signatures to workflow root', () => {
        const workflow = createEmptyWorkflow('wf_worker_attach');
        workflow.nodes = [createWorkflowNode(workflow, 'respond-end', 'End', 1)];
        const next = withNodeExecutors(workflow);
        expect(next.NODE_EXECUTORS?.['respond-end']).toBeTruthy();
        expect(next.NODE_EXECUTOR_SIGNATURES?.['respond-end']).toMatch(/^wf-sign-v1-/);
    });
});
