import { ExecuteWorkflowOptions, WorkflowDefinition, WorkflowExecutorAdapters, WorkflowExecutorMode, WorkflowExecutorResult, WorkflowNodeModel, WorkflowNodeStatusEnum, WorkflowStepOverrides } from '../../../types';
import { buildNodeInputContext, collectReachableNodeIdsFromStartNodes, shouldExecuteNodeInCurrentRun, sortWorkflowNodesTopologically } from '../graph/run-context';
import { createRunId, emitNodeFailed, emitNodeFinished, emitNodeLogs, emitNodeStarted, emitWorkflowCompleted, emitWorkflowStopped, emitWorkflowValidationFailed } from '../graph/log';
import { buildCompletedNodeState, buildFailedNodeState, buildRunningNodeState, markRunningNodesAsStopped, replaceNodeById } from '../graph/state';
import { buildWorkflowSummaryInput, createNodeExecutionTiming, WorkflowNodeExecutionTimingMap } from '../graph/summary';
import { buildRetryAttemptLog, resolveFailureMessageFromResult, resolveFailureRetryLimit, resolveResultStatus } from './failure-mitigation';
import { createEventCollector, getBiPeerNodeIds, isNodeEnabled, normalizeNodeStatus, publishBiControlState, toPortsIn, toPortsOut, toRunnerRecord as toRecord, toRuntimeError } from './runner-helpers';
import { buildExecutionWorkflow } from './public-context';
import { formatVariableFailureMessage, resolveNodeRuntimeVariables } from './variable-manager';
import { validateWorkflowConnectionCompatibility } from './port-compatibility';

const START_MODEL_ID = 'start';
const END_MODEL_ID = 'respond-end';

export interface WorkflowRunnerContext {
    mode: WorkflowExecutorMode;
    adapters: WorkflowExecutorAdapters;
}
const shouldForwardLogs = (workflow: WorkflowDefinition): boolean => workflow.nodes.some((node) => node.modelId === START_MODEL_ID && node.runtime?.forwardSessionLogs === true);

/** Purpose: executes the whole DAG once using canonical runtime+ports state and emits lifecycle events via callback. */
export const executeWorkflowWithContext = async (runtime: WorkflowRunnerContext, workflow: WorkflowDefinition, options: ExecuteWorkflowOptions): Promise<WorkflowExecutorResult> => {
    const runId = createRunId('run');
    let currentWorkflow: WorkflowDefinition = buildExecutionWorkflow(workflow, options.settings, options.workflowInput);

    const { events, sink } = createEventCollector(options);
    const startNodeIds = currentWorkflow.nodes.filter((node) => node.modelId === START_MODEL_ID).map((node) => node.id);
    const hasEndNode = currentWorkflow.nodes.some((node) => node.modelId === END_MODEL_ID);
    if (startNodeIds.length === 0 || !hasEndNode) {
        const missing = [startNodeIds.length === 0 ? 'Start node' : null, !hasEndNode ? 'Respond/End node' : null].filter((item): item is string => Boolean(item));
        emitWorkflowValidationFailed(sink, workflow.metadata.id, runId, `Workflow execution requires ${missing.join(' and ')}.`);
        return { workflow: currentWorkflow, stopped: false, events };
    }

    const compatibilityViolations = validateWorkflowConnectionCompatibility(currentWorkflow);
    if (compatibilityViolations.length > 0) {
        const details = compatibilityViolations.map((item) => item.message).join(' ');
        const message = `Workflow has incompatible connection(s): ${details}`;
        emitWorkflowValidationFailed(sink, workflow.metadata.id, runId, message);
        return { workflow: currentWorkflow, stopped: false, events };
    }

    const includeLogsInSummary = shouldForwardLogs(currentWorkflow);
    const reachableNodeIds = collectReachableNodeIdsFromStartNodes(currentWorkflow, startNodeIds);
    const orderedIds = sortWorkflowNodesTopologically(currentWorkflow).filter((nodeId) => reachableNodeIds.has(nodeId));
    const outputsByNode = new Map<string, Record<string, unknown>>();
    const currentRunOutputNodeIds = new Set<string>();
    const publishNodeOutputs = (node: WorkflowNodeModel): void => {
        currentRunOutputNodeIds.add(node.id);
        outputsByNode.set(node.id, toPortsOut(node));
    };
    const refreshOutputIndex = (): void => {
        currentWorkflow.nodes.forEach((node) => {
            if (currentRunOutputNodeIds.has(node.id)) outputsByNode.set(node.id, toPortsOut(node));
        });
    };
    const nodeExecutionTimings: WorkflowNodeExecutionTimingMap = {};
    const invocationStack = new Set<string>();

    const executeConnectedNodeById = async (connectedNodeId: string, overrideInput?: Record<string, Record<string, unknown>>, overrides?: WorkflowStepOverrides) => {
        if (invocationStack.has(connectedNodeId)) throw new Error(`Circular invocation detected for node "${connectedNodeId}".`);
        const connectedNode = currentWorkflow.nodes.find((item) => item.id === connectedNodeId);
        if (!connectedNode) throw new Error(`Connected node "${connectedNodeId}" was not found.`);
        if (!isNodeEnabled(connectedNode)) {
            const disabledNode = publishBiControlState(currentWorkflow, { ...connectedNode, status: WorkflowNodeStatusEnum.Stopped, runtime: { ...(connectedNode.runtime ?? {}), status: WorkflowNodeStatusEnum.Stopped } });
            currentWorkflow = replaceNodeById(currentWorkflow, disabledNode);
            publishNodeOutputs(disabledNode);
            return { node: disabledNode, result: { output: toPortsOut(connectedNode).output ?? null, status: WorkflowNodeStatusEnum.Stopped, logs: ['Node is disabled.'] } };
        }

        invocationStack.add(connectedNodeId);
        const runningNode = publishBiControlState(
            currentWorkflow,
            buildRunningNodeState(connectedNode, { runtime: { ...(connectedNode.runtime ?? {}), ...(overrides?.runtime ?? {}), ...(overrides?.properties ?? {}) } })
        );
        currentWorkflow = replaceNodeById(currentWorkflow, runningNode);
        options.onNodeStart?.(runningNode.id);
        emitNodeStarted(sink, workflow.metadata.id, runId, runningNode);
        const input = overrideInput ?? buildNodeInputContext(currentWorkflow, runningNode.id, outputsByNode, toPortsIn(runningNode));
        const startedAt = new Date().toISOString();
        const startedAtMs = performance.now();
        const retryLimit = resolveFailureRetryLimit(runningNode);
        const retryAttemptLogs: string[] = [];
        const canRunLocally = options.isNodeLocalCapable ? options.isNodeLocalCapable(runningNode.modelId) : true;
        const variableResolution = resolveNodeRuntimeVariables(currentWorkflow, runningNode, input, options.settings);
        if (!variableResolution.ok) {
            const message = formatVariableFailureMessage(variableResolution.failures, runningNode.name);
            const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
            currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
            publishNodeOutputs(failedNode);
            const finishedAt = new Date().toISOString();
            const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
            nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, finishedAt, durationMs);
            emitNodeFailed(sink, workflow.metadata.id, runId, runningNode.id, message);
            emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, [message]);
            options.onNodeFinish?.(failedNode);
            return {
                node: failedNode,
                result: {
                    output: { error: message, variableFailures: variableResolution.failures },
                    status: WorkflowNodeStatusEnum.Failed,
                    logs: [message]
                }
            };
        }
        const executableNode: WorkflowNodeModel = {
            ...runningNode,
            runtime: { ...(runningNode.runtime ?? {}), ...variableResolution.runtime }
        };
        const handler = runtime.adapters.getNodeHandler(executableNode.modelId);
        if (!canRunLocally && !options.executeNodeRemotely) {
            const message = `Node model "${runningNode.modelId}" requires server execution in "${runtime.mode}" mode.`;
            const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
            currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
            publishNodeOutputs(failedNode);
            const finishedAt = new Date().toISOString();
            const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
            nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, finishedAt, durationMs);
            emitNodeFailed(sink, workflow.metadata.id, runId, runningNode.id, message);
            options.onNodeFinish?.(failedNode);
            return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs: [message] } };
        }

        try {
            for (let attemptNumber = 1; attemptNumber <= retryLimit + 1; attemptNumber += 1) {
                if (!canRunLocally && options.executeNodeRemotely) {
                    const resolvedWorkflow = replaceNodeById(currentWorkflow, executableNode);
                    const remoteExecution = await options.executeNodeRemotely({ workflow: resolvedWorkflow, nodeId: runningNode.id, settings: options.settings, overrides, hostContext: options.hostContext });
                    currentWorkflow = remoteExecution.workflow;
                    refreshOutputIndex();
                    (remoteExecution.events ?? []).forEach(options.onEvent ?? (() => undefined));
                    const status = resolveResultStatus(remoteExecution.result, remoteExecution.node.status as WorkflowNodeStatusEnum);
                    const remoteNode = publishBiControlState(currentWorkflow, normalizeNodeStatus(remoteExecution.node, status));
                    currentWorkflow = replaceNodeById(currentWorkflow, remoteNode);
                    publishNodeOutputs(remoteNode);

                    if (status === WorkflowNodeStatusEnum.Failed) {
                        const message = resolveFailureMessageFromResult(remoteExecution.result, toRuntimeError(remoteNode) ?? 'Node execution failed.');
                        const terminalAttemptLogs = [...(remoteExecution.result.logs ?? [])];
                        if (attemptNumber <= retryLimit) {
                            const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                            const iterationLogs = [...terminalAttemptLogs, retryLog];
                            retryAttemptLogs.push(...iterationLogs);
                            emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, iterationLogs);
                            continue;
                        }

                        const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(remoteNode, message));
                        currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
                        publishNodeOutputs(failedNode);
                        const finishedAt = new Date().toISOString();
                        const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                        nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, finishedAt, durationMs);
                        emitNodeFailed(sink, workflow.metadata.id, runId, runningNode.id, message);
                        const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                        emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, terminalLogs);
                        const logs = [...retryAttemptLogs, ...terminalLogs];
                        options.onNodeFinish?.(failedNode);
                        return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs } };
                    }

                    const finishedAt = new Date().toISOString();
                    const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                    nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(remoteNode, remoteNode.status, startedAt, finishedAt, durationMs);
                    const terminalLogs = remoteExecution.result.logs ?? [];
                    emitNodeFinished(sink, workflow.metadata.id, runId, runningNode.id, remoteNode.status, durationMs, terminalLogs);
                    const logs = [...retryAttemptLogs, ...terminalLogs];
                    options.onNodeFinish?.(remoteNode);
                    return { node: remoteNode, result: { ...remoteExecution.result, status: remoteNode.status, logs } };
                }

                const result = await handler({
                    node: { ...executableNode, ports: { ...executableNode.ports, in: input } },
                    workflow: currentWorkflow,
                    settings: options.settings,
                    input,
                    signal: options.signal,
                    hostContext: options.hostContext,
                    invokeConnectedNode: async ({ nodeId, input: nextInput, overrides: nextOverrides }) => executeConnectedNodeById(nodeId, nextInput, nextOverrides)
                });
                refreshOutputIndex();
                const status = resolveResultStatus(result);
                if (status === WorkflowNodeStatusEnum.Failed) {
                    const message = resolveFailureMessageFromResult(result);
                    const terminalAttemptLogs = [...(result.logs ?? [])];
                    if (attemptNumber <= retryLimit) {
                        const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                        const iterationLogs = [...terminalAttemptLogs, retryLog];
                        retryAttemptLogs.push(...iterationLogs);
                        emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, iterationLogs);
                        continue;
                    }

                    const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
                    currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
                    publishNodeOutputs(failedNode);
                    const finishedAt = new Date().toISOString();
                    const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                    nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, finishedAt, durationMs);
                    emitNodeFailed(sink, workflow.metadata.id, runId, runningNode.id, message);
                    const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                    emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, terminalLogs);
                    const logs = [...retryAttemptLogs, ...terminalLogs];
                    options.onNodeFinish?.(failedNode);
                    return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs } };
                }

                const normalizedResult = { ...result, status: status as WorkflowNodeStatusEnum };
                const completedNode = publishBiControlState(currentWorkflow, buildCompletedNodeState(runningNode, input, normalizedResult));
                currentWorkflow = replaceNodeById(currentWorkflow, completedNode);
                publishNodeOutputs(completedNode);
                const finishedAt = new Date().toISOString();
                const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(completedNode, completedNode.status, startedAt, finishedAt, durationMs);
                const terminalLogs = result.logs ?? [];
                emitNodeFinished(sink, workflow.metadata.id, runId, runningNode.id, completedNode.status, durationMs, terminalLogs);
                const logs = [...retryAttemptLogs, ...terminalLogs];
                options.onNodeFinish?.(completedNode);
                return { node: completedNode, result: { ...normalizedResult, logs } };
            }

            throw new Error('Failure mitigation loop exited unexpectedly.');
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Node execution failed.';
            const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
            currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
            publishNodeOutputs(failedNode);
            const finishedAt = new Date().toISOString();
            const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
            nodeExecutionTimings[runningNode.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, finishedAt, durationMs);
            emitNodeFailed(sink, workflow.metadata.id, runId, runningNode.id, message);
            const terminalLogs = [...retryAttemptLogs, message];
            emitNodeLogs(sink, workflow.metadata.id, runId, runningNode.id, [message]);
            options.onNodeFinish?.(failedNode);
            return { node: failedNode, result: { output: { error: message }, status: WorkflowNodeStatusEnum.Failed, logs: terminalLogs } };
        } finally {
            invocationStack.delete(connectedNodeId);
        }
    };

    const invokeBiPeerNodes = async (originNodeId: string): Promise<void> => {
        const peerNodeIds = getBiPeerNodeIds(currentWorkflow, originNodeId);
        for (const peerNodeId of peerNodeIds) {
            await executeConnectedNodeById(peerNodeId);
        }
    };

    for (const nodeId of orderedIds) {
        if (options.signal?.aborted) {
            currentWorkflow = markRunningNodesAsStopped(currentWorkflow);
            emitWorkflowStopped(sink, workflow.metadata.id, runId);
            return { workflow: currentWorkflow, stopped: true, events };
        }
        const node = currentWorkflow.nodes.find((item) => item.id === nodeId);
        if (!node || !shouldExecuteNodeInCurrentRun(currentWorkflow, node.id, outputsByNode)) continue;
        if (!isNodeEnabled(node)) {
            const disabledNode = publishBiControlState(currentWorkflow, { ...node, status: WorkflowNodeStatusEnum.Stopped, runtime: { ...(node.runtime ?? {}), status: WorkflowNodeStatusEnum.Stopped } });
            currentWorkflow = replaceNodeById(currentWorkflow, disabledNode);
            publishNodeOutputs(disabledNode);
            options.onNodeFinish?.(disabledNode);
            continue;
        }
        if (node.status === WorkflowNodeStatusEnum.Passed && Object.keys(toPortsOut(node)).length > 0) continue;

        const runningNode = publishBiControlState(currentWorkflow, buildRunningNodeState(node));
        currentWorkflow = replaceNodeById(currentWorkflow, runningNode);
        options.onNodeStart?.(node.id);
        emitNodeStarted(sink, workflow.metadata.id, runId, runningNode);
        let input = buildNodeInputContext(currentWorkflow, node.id, outputsByNode, toPortsIn(runningNode));
        if (runningNode.modelId === END_MODEL_ID) input = { ...input, __workflow: buildWorkflowSummaryInput(runId, new Map(outputsByNode.entries()), nodeExecutionTimings, includeLogsInSummary ? events : []) };
        const startedAt = new Date().toISOString();
        const startedAtMs = performance.now();
        const retryLimit = resolveFailureRetryLimit(runningNode);
        const retryAttemptLogs: string[] = [];
        const canRunLocally = options.isNodeLocalCapable ? options.isNodeLocalCapable(runningNode.modelId) : true;
        const variableResolution = resolveNodeRuntimeVariables(currentWorkflow, runningNode, input);
        if (!variableResolution.ok) {
            const message = formatVariableFailureMessage(variableResolution.failures, runningNode.name);
            const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
            currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
            publishNodeOutputs(failedNode);
            const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
            nodeExecutionTimings[node.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, new Date().toISOString(), durationMs);
            emitNodeFailed(sink, workflow.metadata.id, runId, node.id, message);
            emitNodeLogs(sink, workflow.metadata.id, runId, node.id, [message]);
            options.onNodeFinish?.(failedNode);
            return { workflow: currentWorkflow, stopped: false, events };
        }
        const executableNode: WorkflowNodeModel = {
            ...runningNode,
            runtime: { ...(runningNode.runtime ?? {}), ...variableResolution.runtime }
        };
        const handler = runtime.adapters.getNodeHandler(executableNode.modelId);

        try {
            if (!canRunLocally && !options.executeNodeRemotely) throw new Error(`Node model "${runningNode.modelId}" requires server execution in "${runtime.mode}" mode.`);

            for (let attemptNumber = 1; attemptNumber <= retryLimit + 1; attemptNumber += 1) {
                if (!canRunLocally && options.executeNodeRemotely) {
                    const resolvedWorkflow = replaceNodeById(currentWorkflow, executableNode);
                    const remoteExecution = await options.executeNodeRemotely({ workflow: resolvedWorkflow, nodeId: runningNode.id, settings: options.settings, hostContext: options.hostContext });
                    currentWorkflow = remoteExecution.workflow;
                    refreshOutputIndex();
                    (remoteExecution.events ?? []).forEach(options.onEvent ?? (() => undefined));
                    const status = resolveResultStatus(remoteExecution.result, remoteExecution.node.status as WorkflowNodeStatusEnum);
                    const remoteNode = publishBiControlState(currentWorkflow, normalizeNodeStatus(remoteExecution.node, status));
                    currentWorkflow = replaceNodeById(currentWorkflow, remoteNode);
                    publishNodeOutputs(remoteNode);

                    if (status === WorkflowNodeStatusEnum.Failed) {
                        const message = resolveFailureMessageFromResult(remoteExecution.result, toRuntimeError(remoteNode) ?? 'Node execution failed.');
                        const terminalAttemptLogs = [...(remoteExecution.result.logs ?? [])];
                        if (attemptNumber <= retryLimit) {
                            const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                            const iterationLogs = [...terminalAttemptLogs, retryLog];
                            retryAttemptLogs.push(...iterationLogs);
                            emitNodeLogs(sink, workflow.metadata.id, runId, node.id, iterationLogs);
                            continue;
                        }

                        const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(remoteNode, message));
                        currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
                        publishNodeOutputs(failedNode);
                        const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                        nodeExecutionTimings[node.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, new Date().toISOString(), durationMs);
                        emitNodeFailed(sink, workflow.metadata.id, runId, node.id, message);
                        const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                        emitNodeLogs(sink, workflow.metadata.id, runId, node.id, terminalLogs);
                        options.onNodeFinish?.(failedNode);
                        return { workflow: currentWorkflow, stopped: false, events };
                    }

                    const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                    nodeExecutionTimings[node.id] = createNodeExecutionTiming(remoteNode, remoteNode.status, startedAt, new Date().toISOString(), durationMs);
                    const terminalLogs = remoteExecution.result.logs ?? [];
                    emitNodeFinished(sink, workflow.metadata.id, runId, node.id, remoteNode.status, durationMs, terminalLogs);
                    options.onNodeFinish?.(remoteNode);
                    if (remoteNode.status === WorkflowNodeStatusEnum.Stopped) {
                        emitWorkflowStopped(sink, workflow.metadata.id, runId);
                        return { workflow: currentWorkflow, stopped: true, events };
                    }
                    if (!remoteExecution.result.skipCommandPeerAutoRun) await invokeBiPeerNodes(node.id);
                    break;
                }

                const result = await handler({
                    node: { ...executableNode, ports: { ...executableNode.ports, in: input } },
                    workflow: currentWorkflow,
                    settings: options.settings,
                    input,
                    signal: options.signal,
                    hostContext: options.hostContext,
                    invokeConnectedNode: async ({ nodeId, input: nextInput, overrides }) => executeConnectedNodeById(nodeId, nextInput, overrides)
                });
                refreshOutputIndex();
                const status = resolveResultStatus(result);
                if (status === WorkflowNodeStatusEnum.Failed) {
                    const message = resolveFailureMessageFromResult(result);
                    const terminalAttemptLogs = [...(result.logs ?? [])];
                    if (attemptNumber <= retryLimit) {
                        const retryLog = buildRetryAttemptLog(attemptNumber, retryLimit, message);
                        const iterationLogs = [...terminalAttemptLogs, retryLog];
                        retryAttemptLogs.push(...iterationLogs);
                        emitNodeLogs(sink, workflow.metadata.id, runId, node.id, iterationLogs);
                        continue;
                    }

                    const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
                    currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
                    publishNodeOutputs(failedNode);
                    nodeExecutionTimings[node.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, new Date().toISOString(), Number((performance.now() - startedAtMs).toFixed(2)));
                    emitNodeFailed(sink, workflow.metadata.id, runId, node.id, message);
                    const terminalLogs = terminalAttemptLogs.length > 0 ? terminalAttemptLogs : [message];
                    emitNodeLogs(sink, workflow.metadata.id, runId, node.id, terminalLogs);
                    options.onNodeFinish?.(failedNode);
                    return { workflow: currentWorkflow, stopped: false, events };
                }

                const normalizedResult = { ...result, status: status as WorkflowNodeStatusEnum };
                const completedNode = publishBiControlState(currentWorkflow, buildCompletedNodeState(runningNode, input, normalizedResult));
                currentWorkflow = replaceNodeById(currentWorkflow, completedNode);
                publishNodeOutputs(completedNode);
                const durationMs = Number((performance.now() - startedAtMs).toFixed(2));
                nodeExecutionTimings[node.id] = createNodeExecutionTiming(completedNode, completedNode.status, startedAt, new Date().toISOString(), durationMs);
                const terminalLogs = result.logs ?? [];
                emitNodeFinished(sink, workflow.metadata.id, runId, node.id, completedNode.status, durationMs, terminalLogs);
                options.onNodeFinish?.(completedNode);
                if (completedNode.status === WorkflowNodeStatusEnum.Stopped) {
                    emitWorkflowStopped(sink, workflow.metadata.id, runId);
                    return { workflow: currentWorkflow, stopped: true, events };
                }
                if (!result.skipCommandPeerAutoRun) await invokeBiPeerNodes(node.id);
                break;
            }
        } catch (error) {
            const message = error instanceof Error ? error.message : 'Node execution failed.';
            const failedNode = publishBiControlState(currentWorkflow, buildFailedNodeState(runningNode, message));
            currentWorkflow = replaceNodeById(currentWorkflow, failedNode);
            nodeExecutionTimings[node.id] = createNodeExecutionTiming(failedNode, WorkflowNodeStatusEnum.Failed, startedAt, new Date().toISOString(), Number((performance.now() - startedAtMs).toFixed(2)));
            emitNodeFailed(sink, workflow.metadata.id, runId, node.id, message);
            emitNodeLogs(sink, workflow.metadata.id, runId, node.id, [message]);
            options.onNodeFinish?.(failedNode);
            return { workflow: currentWorkflow, stopped: false, events };
        }
    }

    emitWorkflowCompleted(sink, workflow.metadata.id, runId);
    return { workflow: currentWorkflow, stopped: false, events };
};
