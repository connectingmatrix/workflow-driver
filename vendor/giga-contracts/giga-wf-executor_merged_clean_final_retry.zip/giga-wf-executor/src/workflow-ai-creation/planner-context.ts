import { workflowNodeCatalog, workflowNodeDetails } from './catalog';

const CORE_NODE_IDS = ['start', 'code', 'respond-end'];
const CHAT_PARITY_NODE_IDS = [
  'ai-governor',
  'if-else',
  'merge',
  'output-format',
  'serp-search',
  'current-chat',
  'text-analysis',
  'action-router',
  'chat-plan-policy',
  'validate-workflow-cypher',
  'workflow',
  'execute-workflow',
  'run-channel-action',
  'run-category-action',
  'run-subject-action',
  'run-post-action',
  'run-user-tree-action',
  'run-chat-action',
];
const CHAT_PARITY_PATTERN = /\b(chat parity|chat pipeline|giga|agent action|action node|backend action|run-[a-z0-9-]+)\b/;

function addIds(target: Set<string>, ids: string[]) {
  for (const id of ids) target.add(id);
}

function selectedIds(message: string) {
  const text = String(message || '').toLowerCase();
  const ids = new Set<string>(CORE_NODE_IDS);
  const needsChatParity = CHAT_PARITY_PATTERN.test(text);
  if (/branch|if|condition/.test(text)) ids.add('if-else');
  if (/loop|array|items|dynamic programming|dp/.test(text)) ids.add('loop-over-items');
  if (/merge|combine|join/.test(text)) ids.add('merge');
  if (/news|web|search|serp/.test(text)) ids.add('serp-search');
  if (/cypher|validate/.test(text)) ids.add('validate-workflow-cypher');
  if (needsChatParity) addIds(ids, CHAT_PARITY_NODE_IDS);
  if (/model|llm|ai|govern/.test(text)) {
    ids.add('ai-governor');
    ids.add('openai');
    ids.add('output-format');
  }
  if (/channel/.test(text)) ids.add('run-channel-action');
  if (/category/.test(text)) ids.add('run-category-action');
  if (/post/.test(text)) ids.add('run-post-action');
  if (/subject/.test(text)) ids.add('run-subject-action');
  if (/user tree|tree/.test(text)) ids.add('run-user-tree-action');
  if (/chat/.test(text)) ids.add('run-chat-action');
  if (/workflow/.test(text)) {
    ids.add('workflow');
    ids.add('execute-workflow');
  }
  return Array.from(ids).slice(0, 24);
}

export function workflowPlannerContext(message: string) {
  if (!/\b(workflow|node|cypher|execute|run)\b/i.test(message)) return '';
  const ids = selectedIds(message);
  const details = workflowNodeDetails(ids);
  const catalog = workflowNodeCatalog().filter((node) => ids.includes(node.id));
  const text = String(message || '').toLowerCase();
  const chatParityHints = CHAT_PARITY_PATTERN.test(text)
    ? [
        'For chat action parity, use current-chat for input, context, history, and pending state bundles.',
        'Use text-analysis for confirmation, workflow-request, explanation, reference-sync, and workflow-followup detection.',
        'Use ai-governor with executionMode "plan-only"; it must not execute tools before Planner confirmation policy runs.',
        'Use grouped Action Router nodes as AI Governor tools only for Channel, Category, Subject, Post, User Tree, and Chat actions.',
        'Connect grouped action nodes into Action Router on cmd:actions. The approved plan should target router node ids and pass input.action plus input.actionInput.',
        'Use Workflow directly for list, get, save, delete, and publish operations. Use Execute Workflow directly for published execution.',
        'Use validate-workflow-cypher before workflow save operations when Cypher is generated or edited in the workflow graph.',
        'Mutating grouped action nodes must be behind an if-else confirmation gate before execution.',
        'For subject reference sync, use run-subject-action read_subject, code, serp-search, code, confirmation, then run-subject-action update_subject.',
        'Use output-format with AI formatting for chat responses, then respond-end.',
      ]
    : [];
  return [
    'Workflow Cypher authoring context:',
    'Use the Workflow node for workflow creation, update, publish, fetch, and delete operations. Use Execute Workflow for published execution.',
    'If the user asks to create and execute, plan Workflow with publishAfterSave=true, then Execute Workflow using workflowActionId that references the prior Workflow action id.',
    ...chatParityHints,
    'Cypher grammar:',
    '(alias:modelId {"name":"Name","runtime":{...}})',
    '(from)-[:CONNECT {"source":"out:output","target":"in:input"}]->(to)',
    'Executable workflows require exactly one start node and at least one respond-end node.',
    'Hello world template:',
    '(start:start {"name":"Start","runtime":{}})',
    '(hello:code {"name":"Hello World","runtime":{"code":"return \\"hello world\\";"}})',
    '(end:respond-end {"name":"Respond End","runtime":{}})',
    '(start)-[:CONNECT {"source":"out:output","target":"in:input"}]->(hello)',
    '(hello)-[:CONNECT {"source":"out:output","target":"in:input"}]->(end)',
    '',
    `Available node catalog: ${JSON.stringify(catalog)}`,
    `Selected node full files: ${JSON.stringify(details)}`,
  ].join('\n');
}
