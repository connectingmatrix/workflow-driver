import { describe, expect, it } from 'vitest';
import {
    createWorkflowExecutionTimeoutController,
    DEFAULT_WORKFLOW_MAX_EXECUTION_SECONDS,
    normalizeWorkflowMaxExecutionSeconds,
    resolveWorkflowExecutionTimeoutMs
} from '../executor/execution-timeout';

describe('workflow execution timeout helper', () => {
    it('normalizes missing values to the default timeout and accepts positive request values', () => {
        expect(normalizeWorkflowMaxExecutionSeconds(undefined)).toBe(DEFAULT_WORKFLOW_MAX_EXECUTION_SECONDS);
        expect(normalizeWorkflowMaxExecutionSeconds(123)).toBe(123);
        expect(resolveWorkflowExecutionTimeoutMs({ maxExecutionSeconds: 50 })).toBe(50_000);
    });

    it('propagates upstream abort signals', () => {
        const upstream = new AbortController();
        const timeout = createWorkflowExecutionTimeoutController({
            settings: { maxExecutionSeconds: 300 },
            signal: upstream.signal
        });

        upstream.abort(new Error('stopped'));

        expect(timeout.signal.aborted).toBe(true);
        timeout.cleanup();
    });
});
