import { afterEach, describe, expect, it, vi } from 'vitest';
import { executeLocal, validate } from '@workflow/nodes/nodes/graphql/worker';

const queryCatalog = {
    'chat-get-chat-messages': 'query GetChatMessages($chatId: ID!) { chat(id: $chatId) { messages { id text } } }',
    'workflow-catalog-records': 'query WorkflowCatalogRecords { workflowCatalogRecords { id name } }'
};

const payload = (runtime: Record<string, unknown>, settings: Record<string, unknown> = {}) =>
    ({
        NODE: { id: 'graphql_1', runtime },
        workflow: {
            metadata: {
                id: 'wf_graphql',
                runtime: {
                    settings: {
                        graphqlUrl: 'http://localhost/graphql',
                        authMode: 'none',
                        manualHeaders: {},
                        ...settings
                    }
                }
            }
        },
        self: { status: 'stopped', PORTS: {}, OUTPUT: null }
    }) as any;

describe('graphql worker query resolution', () => {
    afterEach(() => vi.unstubAllGlobals());

    it('resolves query text from runtime queryCatalog when queryText is empty', async () => {
        const result = await validate(payload({ queryKey: 'chat-get-chat-messages', queryText: '', variables: {}, queryCatalog }));
        expect(result.ok).toBe(true);
        expect(String(result.normalizedRuntime?.queryText)).toContain('GetChatMessages');
    });

    it('keeps worker queryKey resolution aligned with runtime catalog entries', async () => {
        for (const [queryKey, queryText] of Object.entries(queryCatalog)) {
            const result = await validate(payload({ queryKey, queryText: '', variables: {}, queryCatalog }));
            expect(result.ok, queryKey).toBe(true);
            expect(result.normalizedRuntime?.queryText, queryKey).toBe(queryText);
        }
    });

    it('keeps manual queryText ahead of queryKey defaults', async () => {
        let body = '';
        vi.stubGlobal('fetch', vi.fn(async (_url, init: RequestInit) => {
            body = String(init.body);
            return new Response(JSON.stringify({ data: { manual: true } }), { status: 200 });
        }));

        const manual = 'query Manual { viewer { id } }';
        const result = await executeLocal(payload({ queryKey: 'chat-get-chat-messages', queryText: manual, variables: {}, queryCatalog }));
        expect(result.status).toBe('passed');
        expect((result.output as any).querySource).toBe('manual');
        expect(JSON.parse(body).query).toBe(manual);
    });

    it('applies manual auth headers with node headers', async () => {
        let headers: Headers;
        vi.stubGlobal('fetch', vi.fn(async (_url, init: RequestInit) => {
            headers = new Headers(init.headers);
            return new Response(JSON.stringify({ data: { ok: true } }), { status: 200 });
        }));

        await executeLocal(
            payload(
                { queryText: 'query Manual { ok }', headers: { 'x-node': 'node' }, variables: {} },
                { authMode: 'manual', manualHeaders: { Authorization: 'Bearer manual' } }
            )
        );

        expect(headers!.get('Authorization')).toBe('Bearer manual');
        expect(headers!.get('x-node')).toBe('node');
    });

    it('surfaces GraphQL errors as failed output and logs', async () => {
        vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ errors: [{ message: 'Bad query' }] }), { status: 200 })));
        const result = await executeLocal(payload({ queryText: 'query Broken { missing }', variables: {} }));
        expect(result.status).toBe('failed');
        expect((result.output as any).ok).toBe(false);
        expect(result.logs).toContain('Bad query');
    });
});
