import React from 'react';
import type { WorkspaceHeaderModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import { WorkspaceGlyph } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceGlyph';
import { WorkspaceActionButton } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceActionButton';
import { WorkspaceRenderedIcon } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceRenderedIcon';

interface WorkspaceHeaderProps {
    model: WorkspaceHeaderModel;
    onAction: (actionId: string) => void;
    onRename?: (nextName: string) => void;
}

export const WorkspaceHeader: React.FC<WorkspaceHeaderProps> = ({ model, onAction, onRename }) => {
    const [isEditingTitle, setIsEditingTitle] = React.useState<boolean>(false);
    const [draftTitle, setDraftTitle] = React.useState<string>(model.title);

    React.useEffect(() => setDraftTitle(model.title), [model.title]);

    const commitRename = React.useCallback(() => {
        const nextName = draftTitle.trim();
        setIsEditingTitle(false);
        if (!nextName || nextName === model.title) return;
        onRename?.(nextName);
    }, [draftTitle, model.title, onRename]);

    return (
        <header className="cnw-header">
            <div className="cnw-header__identity">
                <div className="cnw-header__left">
                    <div className="cnw-header__glyph-shell">
                        <WorkspaceRenderedIcon
                            iconClass={model.iconClass}
                            iconColor={model.iconColor}
                            iconSvg={model.iconSvg}
                            className="cnw-header__glyph"
                            fallback={<WorkspaceGlyph name="node" className="cnw-header__glyph" />}
                        />
                    </div>
                    <div className="cnw-header__meta">
                        {model.breadcrumb ? <p className="cnw-header__breadcrumb">{model.breadcrumb}</p> : null}
                        <div className="cnw-header__title-row">
                            {isEditingTitle ? (
                                <input
                                    value={draftTitle}
                                    className="cnw-header__title-input"
                                    onChange={(event) => setDraftTitle(event.target.value)}
                                    onBlur={commitRename}
                                    onKeyDown={(event) => {
                                        if (event.key === 'Enter') {
                                            event.preventDefault();
                                            commitRename();
                                        }
                                        if (event.key === 'Escape') {
                                            event.preventDefault();
                                            setDraftTitle(model.title);
                                            setIsEditingTitle(false);
                                        }
                                    }}
                                    autoFocus
                                />
                            ) : (
                                <h1 className="cnw-header__title" onDoubleClick={() => onRename && setIsEditingTitle(true)}>{model.title}</h1>
                            )}
                        </div>
                        {model.subtitle ? <p className="cnw-header__subtitle">{model.subtitle}</p> : null}
                    </div>
                </div>
                <div className="cnw-header__right">
                    <div className="cnw-header__actions">
                        {model.previewAction ? <WorkspaceActionButton action={model.previewAction} onClick={onAction} /> : null}
                        {model.primaryAction ? <WorkspaceActionButton action={model.primaryAction} onClick={onAction} /> : null}
                        {model.utilityActions?.map((action) => <WorkspaceActionButton key={action.id} action={action} onClick={onAction} />)}
                    </div>
                </div>
            </div>
        </header>
    );
};
