import React, { useMemo } from 'react';
import { TabPanel, TabView } from 'primereact/tabview';
import JsonViewer from '@workflow/ui/workflow/components/viewers/JsonViewer';
import { WorkflowNodeDocumentation } from '@workflow/ui/workflow/types';

interface InspectorInputPaneProps {
    inputData: Record<string, unknown>;
    documentation?: WorkflowNodeDocumentation;
    nodeTypeLabel: string;
    controlNodes?: Record<string, unknown> | null;
}

const formatValue = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null || typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
};

const buildInputRows = (inputData: Record<string, unknown>): Array<{ key: string; value: string }> =>
    Object.entries(inputData).map(([key, value]) => ({
        key,
        value: formatValue(value)
    }));

const InspectorInputPane: React.FC<InspectorInputPaneProps> = ({ inputData, documentation, nodeTypeLabel, controlNodes }) => {
    const inputRows = useMemo(() => buildInputRows(inputData), [inputData]);
    const hasControlNodes = Boolean(controlNodes && Object.keys(controlNodes).length > 0);
    return (
        <section className="wf-inspector-pane wf-inspector-pane--input">
            <header className="wf-inspector-pane__header">
                <div className="wf-inspector-pane__title">Input</div>
                <div className="wf-inspector-pane__subtitle">Tabular input and node documentation.</div>
            </header>

            <div className="wf-inspector-pane__body">
                <TabView className="wf-inspector__tabview">
                    <TabPanel header="Table">
                        {inputRows.length ? (
                            <div className="wf-inspector__table-shell">
                                <table className="wf-inspector__table">
                                    <thead>
                                        <tr>
                                            <th>Key</th>
                                            <th>Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {inputRows.map((row) => (
                                            <tr key={row.key}>
                                                <td>{row.key}</td>
                                                <td>{row.value}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                            <div className="wf-inspector__hint">No input values yet.</div>
                        )}
                    </TabPanel>
                    <TabPanel header="JSON">
                        <div className="wf-inspector-pane__viewer">
                            <JsonViewer value={inputData} draggableKeys />
                        </div>
                    </TabPanel>
                    {hasControlNodes ? (
                        <TabPanel header="Control Nodes">
                            <div className="wf-inspector-pane__viewer">
                                <JsonViewer value={controlNodes ?? {}} rootPath="controlNodes" />
                            </div>
                        </TabPanel>
                    ) : null}
                    <TabPanel header="Document">
                        <div className="wf-inspector__doc">
                            <div className="wf-inspector__doc-title">{documentation?.nodeTypeLabel ?? nodeTypeLabel}</div>
                            <p className="wf-inspector__doc-copy">{documentation?.summary ?? `${nodeTypeLabel} workflow node.`}</p>
                            <p className="wf-inspector__doc-copy">{documentation?.usage ?? 'No usage notes provided for this node yet.'}</p>
                            <div className="wf-inspector__doc-section-title">Inputs</div>
                            {documentation?.inputs?.length ? (
                                <ul className="wf-inspector__doc-list">
                                    {documentation.inputs.map((input) => (
                                        <li key={input.key}>
                                            <strong>{input.label}</strong>
                                            {`: ${input.description}`}
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="wf-inspector__hint">No documented inputs.</div>
                            )}
                            <div className="wf-inspector__doc-section-title">Outputs</div>
                            {documentation?.outputs?.length ? (
                                <ul className="wf-inspector__doc-list">
                                    {documentation.outputs.map((output) => (
                                        <li key={output.key}>
                                            <strong>{output.label}</strong>
                                            {`: ${output.description}`}
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <div className="wf-inspector__hint">No documented outputs.</div>
                            )}
                            {documentation?.examples?.length ? (
                                <>
                                    <div className="wf-inspector__doc-section-title">Examples</div>
                                    <div className="wf-inspector__doc-list">
                                        {documentation.examples.map((example) => (
                                            <div key={example.title} className="wf-inspector__doc-copy">
                                                <strong>{example.title}</strong>
                                                {example.description ? <div>{example.description}</div> : null}
                                                {example.setup ? <pre>{example.setup}</pre> : null}
                                                {example.output ? <pre>{example.output}</pre> : null}
                                            </div>
                                        ))}
                                    </div>
                                </>
                            ) : null}
                            {documentation?.backend ? (
                                <>
                                    <div className="wf-inspector__doc-section-title">Backend Mapping</div>
                                    <div className="wf-inspector__doc-copy">
                                        Handler: <strong>{documentation.backend.handler ?? 'n/a'}</strong>
                                    </div>
                                    {documentation.backend.action ? <div className="wf-inspector__doc-copy">Action: {documentation.backend.action}</div> : null}
                                    {documentation.backend.service ? <div className="wf-inspector__doc-copy">Service: {documentation.backend.service}</div> : null}
                                </>
                            ) : null}
                            {documentation?.failureCases?.length ? (
                                <>
                                    <div className="wf-inspector__doc-section-title">Failure Cases</div>
                                    <ul className="wf-inspector__doc-list">
                                        {documentation.failureCases.map((failure) => (
                                            <li key={failure}>{failure}</li>
                                        ))}
                                    </ul>
                                </>
                            ) : null}
                        </div>
                    </TabPanel>
                </TabView>
            </div>
        </section>
    );
};

export default InspectorInputPane;
