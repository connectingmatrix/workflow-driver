import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWorkflowMcpRuntimeManager } from '../executor/mcp-runtime.manager';

const originalFetch = globalThis.fetch;

const createResponse = (body: unknown, status = 200, headers: Record<string, string> = {}): Response =>
    new Response(body ? JSON.stringify(body) : '', { status, headers });

afterEach(() => {
    globalThis.fetch = originalFetch;
    vi.restoreAllMocks();
});

describe('mcp runtime manager', () => {
    it('initializes servers and lists tools through streamable-http', async () => {
        const fetchMock = vi
            .fn()
            .mockResolvedValueOnce(
                createResponse(
                    {
                        jsonrpc: '2.0',
                        id: 'mcp-1',
                        result: {
                            protocolVersion: '2024-11-05',
                            serverInfo: { name: 'Demo MCP Server', version: '1.0.0' },
                            capabilities: { tools: { list: true, call: true } }
                        }
                    },
                    200,
                    { 'mcp-session-id': 'session-1' }
                )
            )
            .mockResolvedValueOnce(createResponse(null, 202, { 'mcp-session-id': 'session-1' }))
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-2',
                    result: { tools: [{ name: 'GreetMe' }, { name: 'mockmcpStatus' }] }
                })
            );
        globalThis.fetch = fetchMock as typeof fetch;

        const manager = createWorkflowMcpRuntimeManager([{ key: 'demo', url: 'https://demo.example.com/mcp' }]);
        const result = await manager.listTools({ serverKey: 'demo' });

        expect(result.protocolVersion).toBe('2024-11-05');
        expect(result.serverInfo.name).toBe('Demo MCP Server');
        expect(result.tools.map((tool) => tool.name)).toEqual(['GreetMe', 'mockmcpStatus']);
        expect(JSON.parse(String(fetchMock.mock.calls[0][1].body)).method).toBe('initialize');
        expect(JSON.parse(String(fetchMock.mock.calls[1][1].body)).method).toBe('notifications/initialized');
        expect(JSON.parse(String(fetchMock.mock.calls[2][1].body)).method).toBe('tools/list');
        expect((fetchMock.mock.calls[2][1].headers as Record<string, string>)['mcp-session-id']).toBe('session-1');
    });

    it('lists tools before calling a tool', async () => {
        const fetchMock = vi
            .fn()
            .mockResolvedValueOnce(
                createResponse(
                    {
                        jsonrpc: '2.0',
                        id: 'mcp-1',
                        result: {
                            protocolVersion: '2024-11-05',
                            serverInfo: { name: 'Demo MCP Server', version: '1.0.0' },
                            capabilities: { tools: { list: true, call: true } }
                        }
                    },
                    200,
                    { 'mcp-session-id': 'session-1' }
                )
            )
            .mockResolvedValueOnce(createResponse(null, 202, { 'mcp-session-id': 'session-1' }))
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-2',
                    result: { tools: [{ name: 'GreetMe' }] }
                })
            )
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-3',
                    result: { content: [{ type: 'text', text: 'Hello Abeer!' }] }
                })
            );
        globalThis.fetch = fetchMock as typeof fetch;

        const manager = createWorkflowMcpRuntimeManager([{ key: 'demo', url: 'https://demo.example.com/mcp' }]);
        await manager.listTools({ serverKey: 'demo' });
        const result = await manager.callTool({
            serverKey: 'demo',
            toolName: 'GreetMe',
            toolArguments: { name: 'Abeer' }
        });

        expect(result.toolCall.name).toBe('GreetMe');
        expect(result.toolCall.arguments).toEqual({ name: 'Abeer' });
        expect(result.toolResult).toEqual({ content: [{ type: 'text', text: 'Hello Abeer!' }] });
        expect(JSON.parse(String(fetchMock.mock.calls[2][1].body)).method).toBe('tools/list');
        expect(JSON.parse(String(fetchMock.mock.calls[3][1].body)).method).toBe('tools/call');
    });

    it('maps json-rpc errors from the server', async () => {
        const fetchMock = vi
            .fn()
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-1',
                    result: {
                        protocolVersion: '2024-11-05',
                        serverInfo: { name: 'Demo MCP Server', version: '1.0.0' },
                        capabilities: { tools: { list: true, call: true } }
                    }
                })
            )
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-2',
                    result: { tools: [{ name: 'GreetMe' }] }
                })
            )
            .mockResolvedValueOnce(
                createResponse(
                    {
                        jsonrpc: '2.0',
                        id: 'mcp-3',
                        error: { code: -32601, message: "Tool 'MissingTool' not found" }
                    },
                    404
                )
            );
        globalThis.fetch = fetchMock as typeof fetch;

        const manager = createWorkflowMcpRuntimeManager([{ key: 'demo', url: 'https://demo.example.com/mcp' }]);
        await manager.listTools({ serverKey: 'demo' });
        await expect(manager.callTool({ serverKey: 'demo', toolName: 'MissingTool' })).rejects.toThrow("Tool 'MissingTool' not found");
    });

    it('resets cached sessions', async () => {
        const fetchMock = vi
            .fn()
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-1',
                    result: {
                        protocolVersion: '2024-11-05',
                        serverInfo: { name: 'Demo MCP Server', version: '1.0.0' },
                        capabilities: { tools: { list: true, call: true } }
                    }
                })
            )
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-2', result: { tools: [{ name: 'GreetMe' }] } }))
            .mockResolvedValueOnce(
                createResponse({
                    jsonrpc: '2.0',
                    id: 'mcp-3',
                    result: {
                        protocolVersion: '2024-11-05',
                        serverInfo: { name: 'Demo MCP Server', version: '1.0.0' },
                        capabilities: { tools: { list: true, call: true } }
                    }
                })
            )
            .mockResolvedValueOnce(createResponse(null, 202))
            .mockResolvedValueOnce(createResponse({ jsonrpc: '2.0', id: 'mcp-4', result: { tools: [{ name: 'GreetMe' }] } }));
        globalThis.fetch = fetchMock as typeof fetch;

        const manager = createWorkflowMcpRuntimeManager([{ key: 'demo', url: 'https://demo.example.com/mcp' }]);
        await manager.listTools({ serverKey: 'demo' });
        manager.resetSession('demo');
        await manager.listTools({ serverKey: 'demo' });

        expect(fetchMock).toHaveBeenCalledTimes(6);
        expect(JSON.parse(String(fetchMock.mock.calls[3][1].body)).method).toBe('initialize');
    });
});
