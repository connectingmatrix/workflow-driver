import { Edge, EdgeChange } from '@xyflow/react';
import { getAllNodeSchemas, getNodeModule, resolveNodeSchema } from '@workflow/nodes/node-utils';
import { WorkflowDefinition, WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';
import { getSortedCommandPortIds, getNormalizedCommandPorts, toCanonicalCommandHandle } from '@workflow/ui/workflow/utils/workflow-command-ports.utils';
import { createWorkflowConnection } from '@workflow/ui/workflow/utils/workflow-graph.utils';
import { buildUniqueNodeName, normalizeNodeName } from '@workflow/ui/workflow/utils/workflow-node-name.utils';

export const renameNodeInWorkflow = (workflow: WorkflowDefinition, nodeId: string, nextName: string): WorkflowDefinition => {
    const uniqueName = buildUniqueNodeName(workflow, nextName, nodeId);
    return {
        ...workflow,
        nodes: workflow.nodes.map((node) => (node.id === nodeId ? { ...node, name: uniqueName } : node))
    };
};

export const updateNodeInspectorInWorkflow = (workflow: WorkflowDefinition, nodeId: string, inspector: WorkflowDefinition['nodes'][number]['inspector'], properties: Record<string, unknown> | undefined): WorkflowDefinition => {
    const existingNode = workflow.nodes.find((node) => node.id === nodeId);
    const requestedName = properties?.name ?? existingNode?.name;
    const nextName = buildUniqueNodeName(workflow, requestedName, nodeId);
    const nextRuntime = {
        ...(existingNode?.runtime ?? {}),
        ...(existingNode?.properties ?? {}),
        ...(properties ?? {})
    };
    if (typeof inspector?.code === 'string') nextRuntime.code = inspector.code;
    if (typeof inspector?.markdown === 'string') nextRuntime.markdown = inspector.markdown;
    return {
        ...workflow,
        nodes: workflow.nodes.map((node) =>
            node.id === nodeId
                ? {
                      ...node,
                      name: nextName,
                      description: String(properties?.description ?? node.description ?? ''),
                      runtime: nextRuntime,
                      properties: nextRuntime,
                      inspector: inspector
                          ? {
                                title: nextName,
                                input: inspector.input,
                                properties: nextRuntime,
                                fields: inspector.fields,
                                code: inspector.code,
                                markdown: inspector.markdown,
                                viewers: inspector.viewers
                            }
                          : inspector
                  }
                : node
        )
    };
};

export const addDroppedNode = (workflow: WorkflowDefinition, nodeLibraryItem: WorkflowNodeLibraryItem, position: { x: number; y: number }): WorkflowDefinition => {
    const node = buildNodeFromLibraryItem(workflow, nodeLibraryItem, position);
    if (!node) return workflow;
    return {
        ...workflow,
        nodes: [...workflow.nodes, node]
    };
};

const buildNodeFromLibraryItem = (workflow: WorkflowDefinition, nodeLibraryItem: WorkflowNodeLibraryItem, position: { x: number; y: number }) => {
    const nextSequence = resolveNextNodeSequence(workflow);
    if (nextSequence === null) {
        return null;
    }
    const nextNodeCount = workflow.nodes.length + 1;
    const nodeTypeSegment = buildNodeIdSegment(nodeLibraryItem.modelId || nodeLibraryItem.label);
    const nodeId = `${nodeTypeSegment}-${nextSequence}`;
    const nodeModule = getNodeModule(nodeLibraryItem.modelId);
    const nodeSchema = resolveNodeSchema(nodeLibraryItem.modelId, workflow.nodeModels ?? getAllNodeSchemas());
    const nodeName = buildUniqueNodeName(workflow, `${normalizeNodeName(nodeLibraryItem.label)} ${nextNodeCount}`);
    return nodeModule.buildInitialNode({
        nodeId,
        nodeName,
        schema: nodeSchema,
        libraryItem: nodeLibraryItem,
        position
    });
};

const MAX_NODE_SEQUENCE = 999;

const buildNodeIdSegment = (value: string): string => {
    const normalized = normalizeNodeName(value, 'node')
        .toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9-]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-+|-+$/g, '');
    return normalized || 'node';
};

const resolveNextNodeSequence = (workflow: WorkflowDefinition): number | null => {
    let maxValue = 0;
    workflow.nodes.forEach((node) => {
        const match = node.id.match(/(\d+)$/);
        if (!match) return;
        const parsed = Number(match[1]);
        if (!Number.isFinite(parsed)) return;
        maxValue = Math.max(maxValue, parsed);
    });
    const nextValue = maxValue + 1;
    return nextValue <= MAX_NODE_SEQUENCE ? nextValue : null;
};

const getFirstInputHandle = (workflow: WorkflowDefinition, modelId: string): string => {
    const schema = resolveNodeSchema(modelId, workflow.nodeModels ?? getAllNodeSchemas());
    const commands = getNormalizedCommandPorts(schema);
    const inputPorts = Object.entries(schema.inputs).filter(([portId]) => !commands[portId]);
    const firstInputPort = inputPorts[0]?.[0];
    if (firstInputPort) return `in:${firstInputPort}`;
    const firstCommandPort = getSortedCommandPortIds(schema)[0];
    return firstCommandPort ? toCanonicalCommandHandle(firstCommandPort) : 'in:input';
};

const getFirstOutputHandle = (workflow: WorkflowDefinition, modelId: string): string => {
    const schema = resolveNodeSchema(modelId, workflow.nodeModels ?? getAllNodeSchemas());
    const commands = getNormalizedCommandPorts(schema);
    const outputPorts = Object.entries(schema.outputs).filter(([portId]) => !commands[portId]);
    const firstOutputPort = outputPorts[0]?.[0];
    if (firstOutputPort) return `out:${firstOutputPort}`;
    const firstCommandPort = getSortedCommandPortIds(schema)[0];
    return firstCommandPort ? toCanonicalCommandHandle(firstCommandPort) : 'out:output';
};

const findConnectionById = (workflow: WorkflowDefinition, edgeId: string) => workflow.connections.find((item) => item.id === edgeId);

export const insertNodeAfterOutputPort = (workflow: WorkflowDefinition, sourceNodeId: string, outputPortId: string, nodeLibraryItem: WorkflowNodeLibraryItem): WorkflowDefinition => {
    const sourceNode = workflow.nodes.find((node) => node.id === sourceNodeId);
    if (!sourceNode) return workflow;
    const position = {
        x: sourceNode.position.x + 300,
        y: sourceNode.position.y
    };
    const node = buildNodeFromLibraryItem(workflow, nodeLibraryItem, position);
    if (!node) return workflow;
    const sourceHandle = `out:${outputPortId}`;
    const targetHandle = getFirstInputHandle(workflow, node.modelId);
    return {
        ...workflow,
        nodes: [...workflow.nodes, node],
        connections: [
            ...workflow.connections,
            createWorkflowConnection({
                source: sourceNode.id,
                target: node.id,
                sourceHandle,
                targetHandle
            })
        ]
    };
};

export const insertNodeOnEdge = (workflow: WorkflowDefinition, edgeId: string, nodeLibraryItem: WorkflowNodeLibraryItem): WorkflowDefinition => {
    const connection = findConnectionById(workflow, edgeId);
    if (!connection) return workflow;
    const sourceNode = workflow.nodes.find((node) => node.id === connection.from);
    const targetNode = workflow.nodes.find((node) => node.id === connection.to);
    if (!sourceNode || !targetNode) return workflow;
    const position = {
        x: Math.round((sourceNode.position.x + targetNode.position.x) / 2),
        y: Math.round((sourceNode.position.y + targetNode.position.y) / 2)
    };
    const node = buildNodeFromLibraryItem(workflow, nodeLibraryItem, position);
    if (!node) return workflow;
    const firstInputHandle = getFirstInputHandle(workflow, node.modelId);
    const firstOutputHandle = getFirstOutputHandle(workflow, node.modelId);
    const sourceToNew = createWorkflowConnection({
        source: connection.from,
        target: node.id,
        sourceHandle: connection.sourceHandle ?? null,
        targetHandle: firstInputHandle
    });
    const newToTarget = createWorkflowConnection({
        source: node.id,
        target: connection.to,
        sourceHandle: firstOutputHandle,
        targetHandle: connection.targetHandle ?? null
    });
    return {
        ...workflow,
        nodes: [...workflow.nodes, node],
        connections: [...workflow.connections.filter((item) => item.id !== edgeId), sourceToNew, newToTarget]
    };
};

export const applyConnection = (workflow: WorkflowDefinition, source: string, target: string, sourceHandle: string | null, targetHandle: string | null): WorkflowDefinition => ({
    ...workflow,
    connections: [...workflow.connections, createWorkflowConnection({ source, target, sourceHandle, targetHandle })]
});

type EdgeRemoveChange = Extract<EdgeChange<Edge>, { type: 'remove' }> & { id: string };

const isEdgeRemoveChange = (change: EdgeChange<Edge>): change is EdgeRemoveChange => {
    return change.type === 'remove' && typeof change.id === 'string';
};

export const applyEdgeRemovals = (workflow: WorkflowDefinition, changes: EdgeChange<Edge>[]): WorkflowDefinition => {
    const removedIds = new Set(changes.filter(isEdgeRemoveChange).map((change) => change.id));
    if (!removedIds.size) return workflow;
    return {
        ...workflow,
        connections: workflow.connections.filter((connection) => !removedIds.has(connection.id))
    };
};

export const updateNodePosition = (workflow: WorkflowDefinition, nodeId: string, position: { x: number; y: number }): WorkflowDefinition => {
    const x = Number(position.x);
    const y = Number(position.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
        return workflow;
    }
    return {
        ...workflow,
        nodes: workflow.nodes.map((node) =>
            node.id === nodeId
                ? {
                      ...node,
                      position: { x, y }
                  }
                : node
        )
    };
};

export const removeNodeFromWorkflow = (workflow: WorkflowDefinition, nodeId: string): WorkflowDefinition => {
    return {
        ...workflow,
        nodes: workflow.nodes.filter((node) => node.id !== nodeId),
        connections: workflow.connections.filter((connection) => connection.from !== nodeId && connection.to !== nodeId)
    };
};

export const toggleNodeEnabled = (workflow: WorkflowDefinition, nodeId: string, nextEnabled: boolean): WorkflowDefinition => {
    return {
        ...workflow,
        nodes: workflow.nodes.map((node) => {
            if (node.id !== nodeId) return node;
            const runtime = {
                ...(node.runtime ?? {}),
                ...(node.properties ?? {}),
                enabled: nextEnabled
            };
            return {
                ...node,
                runtime,
                properties: runtime,
                inspector: node.inspector
                    ? {
                          ...node.inspector,
                          properties: {
                              ...(node.inspector.properties ?? {}),
                              enabled: nextEnabled
                          }
                      }
                    : node.inspector
            };
        })
    };
};
