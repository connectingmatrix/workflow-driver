import React from 'react';
import { Button } from 'primereact/button';
import type { WorkflowNodeFileValue } from '@workflow/ui/workflow/types';
import { parseWorkflowFileValue } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';

interface WorkspaceFileFieldProps {
    fieldKey: string;
    value: unknown;
    editable: boolean;
    accept?: string;
    onChange: (fieldKey: string, value: unknown) => void;
}

const formatFileSize = (size: number): string => {
    if (!Number.isFinite(size) || size <= 0) return '0 KB';
    if (size >= 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    return `${Math.max(1, Math.round(size / 1024))} KB`;
};

const isWorkflowNodeFileValue = (value: unknown): value is WorkflowNodeFileValue =>
    typeof value === 'object' &&
    value !== null &&
    typeof (value as WorkflowNodeFileValue).name === 'string' &&
    typeof (value as WorkflowNodeFileValue).mimeType === 'string' &&
    typeof (value as WorkflowNodeFileValue).size === 'number';

export const WorkspaceFileField: React.FC<WorkspaceFileFieldProps> = ({ fieldKey, value, editable, accept, onChange }) => {
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const fileValue = isWorkflowNodeFileValue(value) ? value : null;

    return (
        <div className="cnw-file-field">
            <div className="cnw-file-field__summary">
                <span className="cnw-file-field__title">{fileValue?.name ?? 'No file selected'}</span>
                <span className="cnw-file-field__meta">{fileValue ? `${fileValue.mimeType} • ${formatFileSize(fileValue.size)}` : 'Attach a file to populate this node.'}</span>
            </div>
            <div className="cnw-file-field__actions">
                <Button type="button" label={fileValue ? 'Replace' : 'Upload'} icon="pi pi-paperclip" outlined disabled={!editable} onClick={() => inputRef.current?.click()} />
                {fileValue ? (
                    <Button
                        type="button"
                        label="Clear"
                        icon="pi pi-times"
                        text
                        disabled={!editable}
                        onClick={() => onChange(fieldKey, undefined)}
                    />
                ) : null}
            </div>
            <input
                ref={inputRef}
                type="file"
                className="cnw-file-field__input"
                accept={accept}
                onChange={async (event) => {
                    const file = event.target.files?.[0];
                    event.target.value = '';
                    if (!file) return;
                    const nextValue = await parseWorkflowFileValue(file);
                    onChange(fieldKey, nextValue);
                }}
            />
        </div>
    );
};
