import { defineConfig } from 'cypress';

export default defineConfig({
    viewportWidth: 1600,
    viewportHeight: 950,
    video: false,
    chromeWebSecurity: false,
    e2e: {
        baseUrl: 'http://127.0.0.1:4173',
        specPattern: 'playground/cypress/e2e/**/*.cy.ts',
        supportFile: 'playground/cypress/support/e2e.ts',
        screenshotsFolder: 'playground/cypress/screenshots',
        videosFolder: 'playground/cypress/videos',
        fixturesFolder: false,
        setupNodeEvents(on) {
            on('task', {
                log(message: string) {
                    console.log(message);
                    return null;
                }
            });
        }
    }
});
