import { WorkflowControlNodeExecuteInputsArgs, WorkflowNodeHandlerContext, WorkflowNodeModel } from '../../../types';
import { buildNodeInputContext } from '../graph/run-context';
import { isCommandConnection } from '../graph/command-ports';
import { getControlPeerNode } from './control-node-peer-execution';
import { buildControlNodeSnapshot } from './control-node-facade';

const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as T)
        : ({} as T);

const buildOutputsByNode = (workflow: WorkflowNodeHandlerContext['workflow']): Map<string, Record<string, unknown>> =>
    new Map(workflow.nodes.map((node) => [node.id, toRecord(node.ports?.out)]));

const hasMaterializedOutput = (node: WorkflowNodeModel): boolean => Object.keys(toRecord(node.ports?.out)).length > 0;

const persistPreparedInput = (
    workflow: WorkflowNodeHandlerContext['workflow'],
    nodeId: string,
    input: Record<string, Record<string, unknown>>
): WorkflowNodeModel => {
    const currentNode = getControlPeerNode(workflow, nodeId);
    const nextNode: WorkflowNodeModel = {
        ...currentNode,
        ports: {
            in: input,
            out: toRecord(currentNode.ports?.out)
        }
    };
    const index = workflow.nodes.findIndex((entry) => entry.id === nodeId);
    workflow.nodes[index] = nextNode;
    return nextNode;
};

const getDataPredecessorIds = (workflow: WorkflowNodeHandlerContext['workflow'], nodeId: string): string[] => {
    const predecessors = new Set<string>();
    workflow.connections.forEach((connection) => {
        if (connection.to !== nodeId) return;
        if (isCommandConnection(workflow, connection)) return;
        predecessors.add(connection.from);
    });
    return [...predecessors];
};

export interface ExecuteControlPeerInputsArgs {
    context: WorkflowNodeHandlerContext;
    nodeId: string;
    args?: WorkflowControlNodeExecuteInputsArgs;
    executePeer: (args: { nodeId: string }) => Promise<{ node: WorkflowNodeModel }>;
}

export const executeControlPeerInputs = async (args: ExecuteControlPeerInputsArgs): Promise<ReturnType<typeof buildControlNodeSnapshot>> => {
    const executionStack = new Set<string>();

    const materializeNodeInputs = async (nodeId: string): Promise<void> => {
        if (executionStack.has(nodeId)) {
            throw new Error(`Circular upstream input execution detected for control node "${nodeId}".`);
        }
        executionStack.add(nodeId);

        try {
            const predecessorIds = getDataPredecessorIds(args.context.workflow, nodeId);
            for (const predecessorId of predecessorIds) {
                await materializeNodeInputs(predecessorId);
                const predecessorNode = getControlPeerNode(args.context.workflow, predecessorId);
                if (predecessorNode.status !== 'passed' || !hasMaterializedOutput(predecessorNode)) {
                    await args.executePeer({ nodeId: predecessorId });
                }
            }

            const preparedNode = getControlPeerNode(args.context.workflow, nodeId);
            const preparedInput = buildNodeInputContext(
                args.context.workflow,
                nodeId,
                buildOutputsByNode(args.context.workflow),
                toRecord<Record<string, Record<string, unknown>>>(preparedNode.ports?.in)
            );
            persistPreparedInput(args.context.workflow, nodeId, preparedInput);
        } finally {
            executionStack.delete(nodeId);
        }
    };

    await materializeNodeInputs(args.nodeId);
    return buildControlNodeSnapshot(args.context.workflow, args.nodeId);
};
