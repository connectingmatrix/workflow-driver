import React, { useEffect, useRef } from 'react';
import { Editor } from 'primereact/editor';

export type RichEditorFieldSelection = { index: number; length: number } | null;
export type RichEditorFieldSelectionChangeHandler = (selection: RichEditorFieldSelection) => void;
export type RichEditorFieldLoadHandler = (quill: unknown) => void;

interface RichEditorFieldProps {
    id?: string;
    value?: string;
    readOnly?: boolean;
    onChange?: (value: string) => void;
    onSelectionChange?: RichEditorFieldSelectionChangeHandler;
    onEditorLoad?: RichEditorFieldLoadHandler;
    label?: string;
    placeholder?: string;
    fieldClassName?: string;
}

interface QuillLikeEditor {
    root: HTMLElement;
    clipboard: { convert: (value: { html: string; text: string }) => unknown };
    setContents: (delta: unknown, source?: string) => void;
    setText: (textValue: string, source?: string) => void;
    hasFocus: () => boolean;
}

const applyEditorValue = (editor: QuillLikeEditor, nextValue: string): void => {
    if (!nextValue) {
        editor.setText('', 'api');
        return;
    }
    editor.setContents(editor.clipboard.convert({ html: nextValue, text: '' }), 'api');
};

const renderHeader = () => (
    <span className="ql-formats">
        <button className="ql-bold" aria-label="Bold"></button>
        <button className="ql-italic" aria-label="Italic"></button>
        <button className="ql-underline" aria-label="Underline"></button>
        <button className="ql-strike" aria-label="Strike"></button>
        <button className="ql-blockquote" aria-label="Blockquote"></button>
        <button className="ql-list" value="ordered" aria-label="Ordered List"></button>
        <button className="ql-list" value="bullet" aria-label="Bullet List"></button>
        <button className="ql-link" aria-label="Link"></button>
        <button className="ql-code-block" aria-label="Code Block"></button>
    </span>
);

const RichEditorField: React.FC<RichEditorFieldProps> = ({ id = 'workflow-rich-editor', value = '', readOnly = false, onChange, onSelectionChange, onEditorLoad, placeholder = 'Write markdown...' }) => {
    const editorRef = useRef<QuillLikeEditor | null>(null);

    useEffect(() => {
        const editor = editorRef.current;
        if (!editor || editor.hasFocus()) return;
        applyEditorValue(editor, value);
    }, [value]);

    return (
        <Editor
            id={id}
            value={value}
            onTextChange={(event) => {
                if (event.source === 'api') return;
                onChange?.(event.htmlValue || '');
            }}
            onSelectionChange={(event) => {
                const range = event?.range;
                if (!range || typeof range.index !== 'number') {
                    onSelectionChange?.(null);
                    return;
                }
                onSelectionChange?.({
                    index: range.index,
                    length: typeof range.length === 'number' ? range.length : 0
                });
            }}
            onLoad={(quill) => {
                const editor = quill as QuillLikeEditor;
                editorRef.current = editor;
                applyEditorValue(editor, value);
                onEditorLoad?.(quill);
            }}
            headerTemplate={renderHeader()}
            placeholder={placeholder}
            readOnly={readOnly}
            style={{ minHeight: '260px' }}
            pt={{
                root: { className: 'border-round-lg overflow-hidden' },
                content: { style: { minHeight: '220px', fontSize: '0.95rem' } }
            }}
        />
    );
};

export default RichEditorField;
export type { RichEditorFieldProps };
