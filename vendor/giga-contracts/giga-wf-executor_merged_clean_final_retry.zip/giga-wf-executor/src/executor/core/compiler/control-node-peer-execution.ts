import {
    WorkerExecuteHelpers,
    WorkerRuntimeEnvironment,
    WorkflowControlNodePatch,
    WorkflowNodeHandlerContext,
    WorkflowNodeHandlerResult,
    WorkflowNodeModel
} from '../../../types';
import { executeControlPeerInputs } from './control-node-input-execution';
import { buildRuntimeControlNodeGroups } from './control-node-runtime';
import { TypeScriptModuleLoader } from './typescript-compiler';
import {
    createRegisteredWorkerRuntimeHelpers,
    createWorkerHelperId,
    executeLoadedWorkerModuleLifecycle,
    loadPreviewValidator,
    loadWorkerModule,
    registerWorkerRuntimeHelpers,
    resolveNodeSourceFilesFromHelper,
    unregisterWorkerRuntimeHelpers,
    WorkerCompiledModuleLoader
} from './worker-module-loader';
import { buildCompletedNodeState, buildFailedNodeState } from '../graph/state';
import { applyControlNodePatch } from './control-node-facade';

const toRecord = <T = Record<string, unknown>>(value: unknown): T =>
    value && typeof value === 'object' && !Array.isArray(value)
        ? (value as T)
        : ({} as T);

const applyTransientControlPatch = (node: WorkflowNodeModel, patch?: WorkflowControlNodePatch): WorkflowNodeModel => {
    if (!patch) return node;
    return applyControlNodePatch(node, patch);
};

export const getControlPeerNode = (workflow: WorkflowNodeHandlerContext['workflow'], nodeId: string): WorkflowNodeModel => {
    const node = workflow.nodes.find((entry) => entry.id === nodeId);
    if (!node) {
        throw new Error(`Control node "${nodeId}" was not found.`);
    }
    return node;
};

export const buildControlPeerContext = (
    context: WorkflowNodeHandlerContext,
    nodeId: string,
    input?: Record<string, Record<string, unknown>>,
    patch?: WorkflowControlNodePatch
): WorkflowNodeHandlerContext => {
    const node = applyTransientControlPatch(getControlPeerNode(context.workflow, nodeId), patch);
    return {
        ...context,
        node,
        input: input ?? toRecord<Record<string, Record<string, unknown>>>(node.ports?.in)
    };
};

export const persistControlPeerResult = (
    workflow: WorkflowNodeHandlerContext['workflow'],
    nodeId: string,
    input: Record<string, Record<string, unknown>>,
    result: WorkflowNodeHandlerResult
): WorkflowNodeModel => {
    const currentNode = getControlPeerNode(workflow, nodeId);
    const nextNode = buildCompletedNodeState(currentNode, input, result);
    const index = workflow.nodes.findIndex((entry) => entry.id === nodeId);
    workflow.nodes[index] = nextNode;
    return nextNode;
};

export const persistControlPeerFailure = (
    workflow: WorkflowNodeHandlerContext['workflow'],
    nodeId: string,
    error: unknown
): WorkflowNodeModel => {
    const currentNode = getControlPeerNode(workflow, nodeId);
    const message = error instanceof Error ? error.message : String(error ?? 'Control node execution failed.');
    const nextNode = buildFailedNodeState(currentNode, message);
    const index = workflow.nodes.findIndex((entry) => entry.id === nodeId);
    workflow.nodes[index] = nextNode;
    return nextNode;
};

export interface ExecuteControlPeerArgs {
    context: WorkflowNodeHandlerContext;
    nodeId: string;
    input?: Record<string, Record<string, unknown>>;
    patch?: WorkflowControlNodePatch;
    runtimeEnvironment: WorkerRuntimeEnvironment;
    executeHelpers?: WorkerExecuteHelpers;
    typescriptModuleLoader?: TypeScriptModuleLoader;
    loadCompiledModule: WorkerCompiledModuleLoader;
}

export const executeControlPeer = async (args: ExecuteControlPeerArgs): Promise<{ node: WorkflowNodeModel; result: WorkflowNodeHandlerResult }> => {
    const peerContext = buildControlPeerContext(args.context, args.nodeId, args.input, args.patch);
    const peerHelperId = createWorkerHelperId(peerContext);
    registerWorkerRuntimeHelpers(
        peerHelperId,
        createRegisteredWorkerRuntimeHelpers({
            executeHelpers: args.executeHelpers,
            context: peerContext
        })
    );
    try {
        const resolvedSourceFiles = await resolveNodeSourceFilesFromHelper({
            executeHelpers: args.executeHelpers,
            context: peerContext,
            modelId: peerContext.node.modelId
        });
        const controlNodes = await buildRuntimeControlNodeGroups({
            context: peerContext,
            helperId: peerHelperId,
            runtimeEnvironment: args.runtimeEnvironment,
            executeHelpers: args.executeHelpers,
            typescriptModuleLoader: args.typescriptModuleLoader,
            loadCompiledModule: args.loadCompiledModule,
            executePeerInputs: async ({ nodeId, args: executeInputsArgs }) =>
                executeControlPeerInputs({
                    context: peerContext,
                    nodeId,
                    args: executeInputsArgs,
                    executePeer: async ({ nodeId: upstreamNodeId }) => {
                        const executed = await executeControlPeer({
                            ...args,
                            context: peerContext,
                            nodeId: upstreamNodeId
                        });
                        return { node: executed.node };
                    }
                }),
            executePeer: async ({ nodeId, input, patch }) =>
                executeControlPeer({
                    ...args,
                    context: peerContext,
                    nodeId,
                    input,
                    patch
                })
        });
        const module = await loadWorkerModule({
            modelId: peerContext.node.modelId,
            workflow: peerContext.workflow,
            helperId: peerHelperId,
            runtimeEnvironment: args.runtimeEnvironment,
            typescriptModuleLoader: args.typescriptModuleLoader,
            resolvedSourceFiles,
            loadCompiledModule: args.loadCompiledModule
        });
        const previewValidator = await loadPreviewValidator({
            modelId: peerContext.node.modelId,
            workflow: peerContext.workflow,
            helperId: peerHelperId,
            runtimeEnvironment: args.runtimeEnvironment,
            typescriptModuleLoader: args.typescriptModuleLoader,
            resolvedSourceFiles,
            loadCompiledModule: args.loadCompiledModule
        });
        const result = await executeLoadedWorkerModuleLifecycle({
            context: peerContext,
            runtimeEnvironment: args.runtimeEnvironment,
            module,
            previewValidator,
            controlNodes
        });
        const nextNode = persistControlPeerResult(peerContext.workflow, args.nodeId, peerContext.input, result);
        return {
            node: nextNode,
            result
        };
    } catch (error) {
        const failedNode = persistControlPeerFailure(peerContext.workflow, args.nodeId, error);
        throw Object.assign(error instanceof Error ? error : new Error(String(error)), {
            node: failedNode
        });
    } finally {
        unregisterWorkerRuntimeHelpers(peerHelperId);
    }
};
