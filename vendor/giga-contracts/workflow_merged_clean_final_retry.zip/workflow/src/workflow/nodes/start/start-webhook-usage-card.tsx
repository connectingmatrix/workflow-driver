import { Button } from 'primereact/button';
import { buildWorkflowWebhookCurl } from '@workflow/ui/workflow/services/workflow-webhook.utils';

interface StartWebhookUsageCardProps {
    method: 'GET' | 'POST';
    onCopy: (value: string) => void;
    publishedUrl: string;
    secret: string;
    testUrl: string;
}

const StartWebhookUsageCard = ({ method, onCopy, publishedUrl, secret, testUrl }: StartWebhookUsageCardProps) => (
    <div className="surface-ground border-round-xl p-3 mb-3" data-cy="start-webhook-usage-card">
        <div className="font-semibold text-900 mb-2">Webhook Usage</div>
        <div className="text-sm text-700 mb-3">
            Send the workflow secret in the <code>x-workflow-secret</code> header for published URLs. The test URL only works while the designer is open.
        </div>
        <div className="text-xs text-700 mb-1">Test URL</div>
        <div data-cy="start-webhook-test-url" className="text-sm text-700 mb-2" style={{ wordBreak: 'break-all' }}>
            {testUrl || 'Unavailable'}
        </div>
        <div className="flex gap-2 mb-3">
            <Button data-cy="start-copy-test-url" label="Copy URL" size="small" text onClick={() => void onCopy(testUrl)} />
            <Button data-cy="start-copy-test-curl" label="Copy cURL" size="small" text onClick={() => void onCopy(buildWorkflowWebhookCurl({ method, routeType: 'test', secret, testUrl }))} />
        </div>
        <div className="text-xs text-700 mb-1">Published URL</div>
        <div data-cy="start-webhook-published-url" className="text-sm text-700 mb-2" style={{ wordBreak: 'break-all' }}>
            {publishedUrl || 'Unavailable'}
        </div>
        <div className="flex gap-2">
            <Button data-cy="start-copy-published-url" label="Copy URL" size="small" text onClick={() => void onCopy(publishedUrl)} />
            <Button data-cy="start-copy-published-curl" label="Copy cURL" size="small" text onClick={() => void onCopy(buildWorkflowWebhookCurl({ method, routeType: 'published', secret, publishedUrl }))} />
        </div>
    </div>
);

export default StartWebhookUsageCard;
