import { describe, expect, it } from 'vitest';
import { resolveWorkflowMcpToolCall } from '../executor/mcp-node-runtime';

describe('resolveWorkflowMcpToolCall', () => {
    it('reads a flat tool payload', () => {
        const result = resolveWorkflowMcpToolCall({ toolName: 'GreetMe', toolArguments: { name: 'Abeer' } });
        expect(result.toolName).toBe('GreetMe');
        expect(result.toolArguments).toEqual({ name: 'Abeer' });
        expect(result.error).toBe('');
    });

    it('reads a payload envelope', () => {
        const result = resolveWorkflowMcpToolCall({ payload: { toolName: 'GreetMe', toolArguments: { name: 'Abeer' } } });
        expect(result.toolName).toBe('GreetMe');
        expect(result.toolArguments).toEqual({ name: 'Abeer' });
        expect(result.error).toBe('');
    });

    it('reads a workflow input bucket', () => {
        const result = resolveWorkflowMcpToolCall({
            build_greet_request: {
                toolName: 'GreetMe',
                toolArguments: { name: 'Abeer' }
            }
        });
        expect(result.toolName).toBe('GreetMe');
        expect(result.toolArguments).toEqual({ name: 'Abeer' });
        expect(result.error).toBe('');
    });

    it('reads inspector current input', () => {
        const result = resolveWorkflowMcpToolCall({
            current: {
                toolName: 'GreetMe',
                toolArguments: { name: 'Abeer' }
            }
        });
        expect(result.toolName).toBe('GreetMe');
        expect(result.toolArguments).toEqual({ name: 'Abeer' });
        expect(result.error).toBe('');
    });

    it('fails when multiple upstream tool calls are present', () => {
        const result = resolveWorkflowMcpToolCall({
            first_node: {
                toolName: 'GreetMe',
                toolArguments: { name: 'Abeer' }
            },
            second_node: {
                toolName: 'GenerateBike',
                toolArguments: {}
            }
        });
        expect(result.toolName).toBe('');
        expect(result.error).toContain('multiple MCP tool call candidates');
    });
});
