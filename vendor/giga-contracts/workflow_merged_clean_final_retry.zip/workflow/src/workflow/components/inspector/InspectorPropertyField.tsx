import React from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { InputSwitch } from 'primereact/inputswitch';
import { MultiSelect } from 'primereact/multiselect';
import { Slider } from 'primereact/slider';
import { classNames } from 'primereact/utils';
import FloatingFieldShell from '@workflow/ui/workflow/components/form/floating-field-shell';
import DependingField, { clampDependingFieldNumberValue, resolveDependingFieldDefinition } from '@workflow/ui/workflow/components/form/depending-field';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';
import InspectorObjectArrayField from '@workflow/ui/workflow/components/inspector/fields/InspectorObjectArrayField';
import InstructionMarkdownEditor from '@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor';
import VariableTextField from '@workflow/ui/workflow/components/inspector/VariableTextField';
import { WorkflowInspectorFieldLayoutPreset, WorkflowNodeFieldDefinition, WorkflowNodeFieldTypeEnum, WorkflowNodeFileValue } from '@workflow/ui/workflow/types';
import { parseWorkflowFileValue } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';
import { WorkflowVariableSuggestion, resolveFieldAllowVariables } from '@workflow/ui/workflow/utils/workflow-variables.utils';
import { formatPropertyLabel } from '@workflow/ui/workflow/utils/value-utils';

export { formatPropertyLabel };

interface WorkflowInspectorCompanionField {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    visible?: boolean;
}

interface InspectorPropertyFieldProps {
    fieldKey: string;
    definition: WorkflowNodeFieldDefinition;
    value: unknown;
    onChange: (key: string, value: unknown) => void;
    propertiesEditorState?: Record<string, unknown>;
    layoutPreset?: WorkflowInspectorFieldLayoutPreset;
    inspectorColumns?: number;
    companionField?: WorkflowInspectorCompanionField;
    dependingField?: WorkflowInspectorCompanionField;
    showBooleanState?: boolean;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowVariableSuggestion[];
}

const GRID_MAX_COLUMNS = 12;

const parseInputString = (value: unknown): string => {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value === null || typeof value === 'undefined') return '';
    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return String(value);
    }
};

const parseNumberValue = (value: unknown): number | null => {
    const parsed = Number(String(value ?? '').trim());
    return Number.isFinite(parsed) ? parsed : null;
};

const formatFileLabel = (value: unknown): string => {
    if (!value || typeof value !== 'object') return 'No file selected';
    const fileValue = value as WorkflowNodeFileValue;
    if (!fileValue.name) return 'No file selected';
    return `${fileValue.name} (${Math.ceil((fileValue.size ?? 0) / 1024)} KB)`;
};

const parseSelectArrayValue = (value: unknown): string[] => {
    if (!Array.isArray(value)) {
        return [];
    }
    return value.map((item) => (typeof item === 'string' ? item : String(item ?? '').trim())).filter((item) => item.length > 0);
};

const isPromptField = (fieldKey: string): boolean => fieldKey.toLowerCase() === 'prompt';
const resolveInputId = (fieldKey: string, definition: WorkflowNodeFieldDefinition): string => (definition.type === WorkflowNodeFieldTypeEnum.Boolean ? `wf-field-${fieldKey}-switch` : `wf-field-${fieldKey}`);

const clampColumns = (value: number | undefined, fallback: number): number => {
    if (!Number.isFinite(value)) return fallback;
    const rounded = Math.trunc(Number(value));
    if (rounded < 1) return 1;
    if (rounded > GRID_MAX_COLUMNS) return GRID_MAX_COLUMNS;
    return rounded;
};

const toPrimeColClass = (columns: number): string => `col-12 md:col-${clampColumns(columns, GRID_MAX_COLUMNS)}`;

const resolveDefaultLabelCols = (layoutPreset: WorkflowInspectorFieldLayoutPreset, totalColumns: number): number => {
    if (layoutPreset === 'switch') {
        return Math.max(totalColumns - 3, 2);
    }
    return Math.max(Math.floor(totalColumns / 3), 3);
};

const resolveFieldSpan = (requested: number | undefined, fallback: number, maxAllowed: number): number => {
    if (maxAllowed <= 1) return 1;
    return Math.min(clampColumns(requested, fallback), maxAllowed);
};

const InspectorPropertyField: React.FC<InspectorPropertyFieldProps> = ({
    fieldKey,
    definition,
    value,
    onChange,
    propertiesEditorState = {},
    layoutPreset = 'inline',
    inspectorColumns = GRID_MAX_COLUMNS,
    companionField,
    dependingField,
    showBooleanState = true,
    variableContext = {},
    variableSuggestions = []
}) => {
    const resolvedDefinition = React.useMemo(() => resolveDependingFieldDefinition(definition, propertiesEditorState), [definition, propertiesEditorState]);
    const label = resolvedDefinition.label ?? formatPropertyLabel(fieldKey);
    const totalColumns = clampColumns(inspectorColumns, GRID_MAX_COLUMNS);

    React.useEffect(() => {
        if (resolvedDefinition.type !== WorkflowNodeFieldTypeEnum.Number) return;
        const parsedValue = parseNumberValue(value);
        if (parsedValue === null) return;
        const nextValue = clampDependingFieldNumberValue(parsedValue, resolvedDefinition);
        if (nextValue !== parsedValue) {
            onChange(fieldKey, nextValue);
        }
    }, [fieldKey, onChange, resolvedDefinition, value]);

    const renderFieldInput = (
        targetFieldKey: string,
        targetDefinition: WorkflowNodeFieldDefinition,
        targetValue: unknown,
        options: { rowsPreset?: 'default' | 'expanded'; showBooleanState?: boolean; floatingLabel?: string } = {}
    ): React.ReactNode => {
        const editable = targetDefinition.editable !== false && !targetDefinition.auto;
        const allowVariables = resolveFieldAllowVariables(targetFieldKey, targetDefinition);
        const normalizedKey = targetFieldKey.toLowerCase();
        const isGraphqlQueryField = normalizedKey === 'querytext';
        const isGraphqlVariablesField = normalizedKey === 'variables';
        const booleanValue = targetValue === true || String(targetValue).trim().toLowerCase() === 'true';
        const rows = isGraphqlQueryField ? 8 : options.rowsPreset === 'expanded' ? 5 : 3;

        if (isPromptField(targetFieldKey)) {
            return (
                <InstructionMarkdownEditor
                    id={`wf-field-${targetFieldKey}-markdown`}
                    value={parseInputString(targetValue)}
                    onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                    allowVariables={allowVariables}
                    variableSuggestions={variableSuggestions}
                    label={options.floatingLabel}
                />
            );
        }

        switch (targetDefinition.type) {
            case WorkflowNodeFieldTypeEnum.Boolean:
                return (
                    <div className={classNames('wf-inspector__boolean-toggle flex justify-content-end', { 'wf-inspector__boolean-toggle--switch-only': options.showBooleanState === false })}>
                        <InputSwitch inputId={`wf-field-${targetFieldKey}-switch`} checked={booleanValue} onChange={(event) => onChange(targetFieldKey, event.value === true)} disabled={!editable} />
                        {options.showBooleanState !== false && <span className={`wf-inspector__boolean-toggle-state${booleanValue ? ' is-on' : ' is-off'}`}>{booleanValue ? 'On' : 'Off'}</span>}
                    </div>
                );
            case WorkflowNodeFieldTypeEnum.Number: {
                const numberValue = parseNumberValue(targetValue);
                const min = typeof targetDefinition.min === 'number' ? targetDefinition.min : undefined;
                const max = typeof targetDefinition.max === 'number' ? targetDefinition.max : undefined;
                const step = typeof targetDefinition.step === 'number' ? targetDefinition.step : 1;
                const showSlider = targetDefinition.styles?.showSlider !== false && !options.floatingLabel;
                const hasRangeSlider = showSlider && typeof min === 'number' && typeof max === 'number' && max > min;
                const compact = targetDefinition.styles?.compact === true;
                const numberInputId = `wf-field-${targetFieldKey}`;

                if (hasRangeSlider) {
                    const sliderValue = numberValue ?? min;
                    return (
                        <div className="wf-inspector__number-range flex align-items-center gap-2 w-full">
                            <Slider
                                value={sliderValue}
                                onChange={(event) => {
                                    const nextValue = Array.isArray(event.value) ? event.value[0] : event.value;
                                    if (typeof nextValue === 'number' && Number.isFinite(nextValue)) {
                                        onChange(targetFieldKey, nextValue);
                                    }
                                }}
                                min={min}
                                max={max}
                                step={step}
                                disabled={!editable}
                                className="flex-1"
                            />
                            <InputNumber
                                inputId={numberInputId}
                                value={numberValue}
                                onValueChange={(event) => {
                                    if (typeof event.value === 'number' && Number.isFinite(event.value)) {
                                        onChange(targetFieldKey, event.value);
                                    }
                                }}
                                min={min}
                                max={max}
                                step={step}
                                useGrouping={false}
                                minFractionDigits={0}
                                maxFractionDigits={step >= 1 ? 0 : 2}
                                disabled={!editable}
                                inputClassName={classNames('wf-inspector__number-input', { 'wf-inspector__number-input--compact': compact })}
                            />
                        </div>
                    );
                }

                const numberInput = (
                    <InputNumber
                        inputId={numberInputId}
                        value={numberValue}
                        onValueChange={(event) => {
                            if (typeof event.value === 'number' && Number.isFinite(event.value)) {
                                onChange(targetFieldKey, event.value);
                            }
                        }}
                        min={min}
                        max={max}
                        step={step}
                        useGrouping={false}
                        minFractionDigits={0}
                        maxFractionDigits={step >= 1 ? 0 : 2}
                        disabled={!editable}
                        className="w-full"
                        inputClassName={classNames('wf-inspector__number-input', { 'wf-inspector__number-input--compact': compact })}
                    />
                );

                if (!options.floatingLabel) {
                    return numberInput;
                }

                return (
                    <FloatingFieldShell id={numberInputId} label={options.floatingLabel} active={numberValue !== null} disabled={!editable}>
                        {numberInput}
                    </FloatingFieldShell>
                );
            }
            case WorkflowNodeFieldTypeEnum.Markdown:
                return (
                    <InstructionMarkdownEditor
                        id={`wf-field-${targetFieldKey}-markdown`}
                        value={parseInputString(targetValue)}
                        onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                        allowVariables={allowVariables}
                        variableSuggestions={variableSuggestions}
                        label={options.floatingLabel}
                    />
                );
            case WorkflowNodeFieldTypeEnum.Json:
                return (
                    <div className={classNames('wf-inspector__json-editor', { 'wf-inspector__graphql-editor': isGraphqlVariablesField })}>
                        <CodeEditor
                            value={parseInputString(targetValue)}
                            onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                            language="json"
                            readOnly={!editable}
                            allowVariables={allowVariables}
                            variableContext={variableContext}
                            variableSuggestions={variableSuggestions}
                        />
                    </div>
                );
            case WorkflowNodeFieldTypeEnum.Headers:
                return (
                    <div className="wf-inspector__json-editor">
                        <CodeEditor
                            value={parseInputString(targetValue)}
                            onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                            language="json"
                            readOnly={!editable}
                            allowVariables={allowVariables}
                            variableContext={variableContext}
                            variableSuggestions={variableSuggestions}
                        />
                    </div>
                );
            case WorkflowNodeFieldTypeEnum.Method: {
                const methodDropdown = (
                    <Dropdown
                        inputId={`wf-field-${targetFieldKey}`}
                        className="w-full"
                        value={parseInputString(targetValue ?? 'GET')}
                        options={['GET', 'POST', 'OPTIONS'].map((item) => ({ label: item, value: item }))}
                        onChange={(event) => onChange(targetFieldKey, event.value)}
                        disabled={!editable}
                    />
                );
                if (!options.floatingLabel) {
                    return methodDropdown;
                }
                return (
                    <FloatingFieldShell id={`wf-field-${targetFieldKey}`} label={options.floatingLabel} active={parseInputString(targetValue ?? 'GET').trim().length > 0} disabled={!editable}>
                        {methodDropdown}
                    </FloatingFieldShell>
                );
            }
            case WorkflowNodeFieldTypeEnum.Textarea:
                return (
                    <VariableTextField
                        id={`wf-field-${targetFieldKey}`}
                        value={parseInputString(targetValue)}
                        onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                        rows={rows}
                        className={classNames('w-full', { 'wf-inspector__graphql-editor': isGraphqlQueryField })}
                        disabled={!editable}
                        multiline
                        allowVariables={allowVariables}
                        variableContext={variableContext}
                        variableSuggestions={variableSuggestions}
                        label={options.floatingLabel}
                    />
                );
            case WorkflowNodeFieldTypeEnum.Select: {
                if (targetDefinition.multi) {
                    const multiSelect = (
                        <MultiSelect
                            className="w-full"
                            value={parseSelectArrayValue(targetValue)}
                            options={(targetDefinition.options ?? []).map((item) => ({ label: item.label, value: item.value }))}
                            onChange={(event) => onChange(targetFieldKey, parseSelectArrayValue(event.value))}
                            disabled={!editable}
                            display="chip"
                            appendTo={document.body}
                        />
                    );
                    if (!options.floatingLabel) {
                        return multiSelect;
                    }
                    return (
                        <FloatingFieldShell id={`wf-field-${targetFieldKey}`} label={options.floatingLabel} active={parseSelectArrayValue(targetValue).length > 0} disabled={!editable}>
                            {multiSelect}
                        </FloatingFieldShell>
                    );
                }
                const selectValue = parseInputString(targetValue);
                const selectDropdown = (
                    <Dropdown
                        inputId={`wf-field-${targetFieldKey}`}
                        className="w-full"
                        value={selectValue}
                        options={(targetDefinition.options ?? []).map((item) => ({ label: item.label, value: item.value }))}
                        onChange={(event) => onChange(targetFieldKey, event.value)}
                        disabled={!editable}
                        appendTo={document.body}
                    />
                );
                if (!options.floatingLabel) {
                    return selectDropdown;
                }
                return (
                    <FloatingFieldShell id={`wf-field-${targetFieldKey}`} label={options.floatingLabel} active={selectValue.trim().length > 0} disabled={!editable}>
                        {selectDropdown}
                    </FloatingFieldShell>
                );
            }
            case WorkflowNodeFieldTypeEnum.File:
                return (
                    <div className="wf-inspector__file-field">
                        <div className="wf-inspector__file-label">{formatFileLabel(targetValue)}</div>
                        <Button icon="pi pi-paperclip" outlined className="p-button-sm" onClick={() => document.getElementById(`wf-field-file-${targetFieldKey}`)?.click()} disabled={!editable} aria-label={`Attach file to ${label}`} />
                        <input
                            id={`wf-field-file-${targetFieldKey}`}
                            type="file"
                            className="hidden"
                            onChange={async (event) => {
                                const file = event.target.files?.[0];
                                event.target.value = '';
                                if (!file) return;
                                const fileValue = await parseWorkflowFileValue(file);
                                onChange(targetFieldKey, fileValue);
                            }}
                        />
                    </div>
                );
            case WorkflowNodeFieldTypeEnum.FileList:
                return (
                    <div className="wf-inspector__file-field">
                        <div className="wf-inspector__file-label">{Array.isArray(targetValue) ? `${targetValue.length} file(s)` : 'No files selected'}</div>
                        <Button icon="pi pi-paperclip" outlined className="p-button-sm" onClick={() => document.getElementById(`wf-field-files-${targetFieldKey}`)?.click()} disabled={!editable} aria-label={`Attach files to ${label}`} />
                        <input
                            id={`wf-field-files-${targetFieldKey}`}
                            type="file"
                            className="hidden"
                            multiple
                            accept={targetDefinition.accept}
                            onChange={async (event) => {
                                const files = Array.from(event.target.files ?? []);
                                event.target.value = '';
                                if (!files.length) return;
                                const fileValues = await Promise.all(files.map((file) => parseWorkflowFileValue(file)));
                                onChange(targetFieldKey, fileValues);
                            }}
                        />
                    </div>
                );
            case WorkflowNodeFieldTypeEnum.ObjectArray:
                return (
                    <InspectorObjectArrayField
                        fieldKey={targetFieldKey}
                        definition={targetDefinition}
                        value={targetValue}
                        onChange={onChange}
                        variableContext={variableContext}
                        variableSuggestions={variableSuggestions}
                    />
                );
            case WorkflowNodeFieldTypeEnum.Timestamp:
            case WorkflowNodeFieldTypeEnum.String:
            default:
                return (
                    <VariableTextField
                        id={`wf-field-${targetFieldKey}`}
                        value={parseInputString(targetValue)}
                        onChange={(nextValue) => onChange(targetFieldKey, nextValue)}
                        className="w-full"
                        disabled={!editable || targetDefinition.type === WorkflowNodeFieldTypeEnum.Timestamp}
                        allowVariables={allowVariables}
                        variableContext={variableContext}
                        variableSuggestions={variableSuggestions}
                        label={options.floatingLabel}
                    />
                );
        }
    };

    if (dependingField) {
        const dependingLabel = dependingField.definition.label ?? formatPropertyLabel(dependingField.fieldKey);
        return (
            <div className="wf-inspector__property-row wf-inspector__property-row--depending grid formgrid col-12">
                <div className={toPrimeColClass(totalColumns)}>
                    <DependingField
                        primary={renderFieldInput(fieldKey, resolvedDefinition, value, { showBooleanState, floatingLabel: label })}
                        dependent={renderFieldInput(dependingField.fieldKey, dependingField.definition, dependingField.value, { showBooleanState, floatingLabel: dependingLabel })}
                    />
                </div>
            </div>
        );
    }

    if (layoutPreset === 'mitigation') {
        const companionVisible = companionField?.visible !== false;
        const labelCols = resolveFieldSpan(resolvedDefinition.styles?.labelCols, Math.max(Math.floor(totalColumns / 3), 3), totalColumns - 2);
        const remainingAfterLabel = totalColumns - labelCols;
        const controlCols = resolveFieldSpan(resolvedDefinition.styles?.controlCols, Math.max(Math.floor(totalColumns / 3), 4), remainingAfterLabel - 1);
        const companionCols = resolveFieldSpan(companionField?.definition.styles?.companionCols ?? resolvedDefinition.styles?.companionCols, Math.max(remainingAfterLabel - controlCols, 2), totalColumns - labelCols - controlCols);

        return (
            <div className="wf-inspector__property-row wf-inspector__property-row--mitigation grid formgrid col-12 align-items-center">
                <div className={toPrimeColClass(labelCols)}>
                    <label htmlFor={resolveInputId(fieldKey, resolvedDefinition)} className="auth-label wf-inspector__property-label">
                        {label}
                    </label>
                </div>
                <div className={classNames(toPrimeColClass(controlCols), 'wf-inspector__property-control')}>{renderFieldInput(fieldKey, resolvedDefinition, value)}</div>
                <div className={classNames(toPrimeColClass(companionCols), 'wf-inspector__property-companion')}>
                    {companionField && companionVisible ? (
                        renderFieldInput(companionField.fieldKey, companionField.definition, companionField.value, { showBooleanState })
                    ) : (
                        <span className="wf-inspector__property-companion-placeholder" aria-hidden />
                    )}
                </div>
            </div>
        );
    }

    const useFloatingLabel =
        resolvedDefinition.styles?.floatingLabel === true ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.String ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Textarea ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Markdown ||
        isPromptField(fieldKey);

    if (useFloatingLabel) {
        return (
            <div className="wf-inspector__property-row wf-inspector__property-row--floating grid formgrid col-12">
                <div className={toPrimeColClass(totalColumns)}>
                    {renderFieldInput(fieldKey, resolvedDefinition, value, {
                        rowsPreset: 'expanded',
                        showBooleanState,
                        floatingLabel: label
                    })}
                </div>
            </div>
        );
    }

    const forceSeparateRow =
        layoutPreset === 'full' ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Textarea ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Markdown ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Json ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Headers ||
        resolvedDefinition.type === WorkflowNodeFieldTypeEnum.ObjectArray ||
        isPromptField(fieldKey);

    const labelCols = forceSeparateRow ? totalColumns : resolveFieldSpan(resolvedDefinition.styles?.labelCols, resolveDefaultLabelCols(layoutPreset, totalColumns), totalColumns - 1);
    const controlCols = forceSeparateRow ? totalColumns : resolveFieldSpan(resolvedDefinition.styles?.controlCols, totalColumns - labelCols, totalColumns - labelCols);

    return (
        <div
            className={classNames('wf-inspector__property-row grid formgrid col-12', {
                'wf-inspector__property-row--stacked': forceSeparateRow,
                'wf-inspector__property-row--full': forceSeparateRow,
                'wf-inspector__property-row--switch': layoutPreset === 'switch',
                'wf-inspector__property-row--inline': !forceSeparateRow && layoutPreset !== 'switch'
            })}
        >
            <div className={toPrimeColClass(labelCols)}>
                <label htmlFor={resolveInputId(fieldKey, resolvedDefinition)} className="auth-label wf-inspector__property-label">
                    {label}
                </label>
            </div>
            <div
                className={classNames(toPrimeColClass(controlCols), 'wf-inspector__property-control', {
                    'wf-inspector__property-control--align-right': layoutPreset === 'switch' || resolvedDefinition.type === WorkflowNodeFieldTypeEnum.Boolean
                })}
            >
                {renderFieldInput(fieldKey, resolvedDefinition, value, { rowsPreset: forceSeparateRow ? 'expanded' : 'default', showBooleanState })}
            </div>
        </div>
    );
};

export default InspectorPropertyField;
