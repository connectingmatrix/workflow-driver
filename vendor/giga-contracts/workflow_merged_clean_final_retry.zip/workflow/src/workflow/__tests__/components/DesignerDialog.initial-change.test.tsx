/** @vitest-environment jsdom */
import React from 'react';
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createEmptyWorkflow } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';

vi.mock('@workflow/ui/workflow/components/toolbar/Toolbar', () => ({ default: () => <div data-testid="workflow-toolbar" /> }));
vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({ default: () => null }));
vi.mock('@/common/components/logs/JsonlLogsDialog', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({ default: () => null }));
vi.mock('primereact/dialog', () => ({ Dialog: (props: { visible: boolean; children: React.ReactNode }) => (props.visible ? <div>{props.children}</div> : null) }));
vi.mock('primereact/toast', () => ({ Toast: React.forwardRef(() => null) }));
vi.mock('primereact/overlaypanel', () => ({ OverlayPanel: React.forwardRef((props: { children: React.ReactNode }, ref) => (React.useImperativeHandle(ref, () => ({ hide: () => undefined })), <div>{props.children}</div>)) }));
vi.mock('primereact/contextmenu', () => ({ ContextMenu: React.forwardRef((_: unknown, ref) => (React.useImperativeHandle(ref, () => ({ show: () => undefined, hide: () => undefined })), null)) }));
vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({ default: (props: { onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number } }) => void }) => (React.useEffect(() => props.onInit({ screenToFlowPosition: ({ x, y }) => ({ x, y }) }), [props.onInit]), <div data-testid="workflow-canvas" />) }));
vi.mock('@workflow/ui/workflow/executor/runtime', () => ({ workflowExecutor: { executeWorkflow: vi.fn(), executeNodeStep: vi.fn() }, workflowExecutorHostContext: { mcp: { registerServer: vi.fn(), removeServer: vi.fn(), getServer: vi.fn(), listServers: vi.fn(() => []), queryCapabilities: vi.fn(), resolveNodeServer: vi.fn() } } }));
vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (importOriginal) => ({ ...(await importOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>()), prewarmJavascriptRuntimeFrame: vi.fn(async () => undefined) }));
vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({ listWorkflowUserNodes: vi.fn(async () => []) }));

const driver: WorkflowUiDriver = {
    createRequestId: () => 'req_1',
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({ connect: vi.fn(), disconnect: vi.fn(), startPreview: vi.fn(async () => undefined), cancelPreview: vi.fn(), addPreviewLogHandler: vi.fn(() => () => undefined), addPreviewStateHandler: vi.fn(() => () => undefined), addPreviewResultHandler: vi.fn(() => () => undefined), addPreviewErrorHandler: vi.fn(() => () => undefined), addPreviewStopHandler: vi.fn(() => () => undefined) }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: createEmptyWorkflow('wf_1'), logs: [] })),
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};

const nodeCatalog: WorkflowNodeCatalog = { modules: [], getAllNodeSchemas: () => ({}), getNodeLibraryItems: () => [], getNodeModuleById: () => null, resolveNodeSchema: () => ({ documentation: {} }) as never, isLocalCapableNodeModel: () => true };

afterEach(() => cleanup());

describe('DesignerDialog initial change tracking', () => {
    it('does not emit a workflow change on first open before the user edits', async () => {
        const handleWorkflowChange = vi.fn();
        render(<DesignerDialog visible workflow={createEmptyWorkflow('wf_initial')} driver={driver} nodeCatalog={nodeCatalog} onHide={vi.fn()} onWorkflowChange={handleWorkflowChange} />);

        await waitFor(() => expect(screen.getByTestId('workflow-canvas')).toBeTruthy());

        expect(handleWorkflowChange).not.toHaveBeenCalled();
    });
});
