import type { WorkflowRunLogEvent } from '@workflow/ui/workflow/types';

export interface JsonlLogsDialogProps {
    visible: boolean;
    onHide: () => void;
    jsonl: string;
    header?: string;
    fileNamePrefix?: string;
    events?: WorkflowRunLogEvent[];
}

export type WorkflowLogsFilter = 'all' | 'info' | 'warn' | 'error';

export interface WorkflowLogsRecord {
    id: string;
    lineNumber: number;
    raw: string;
    formatted: string;
    level: 'info' | 'warn' | 'error';
    timestamp?: string;
    event?: string;
    nodeId?: string;
    runId?: string;
    data?: unknown;
    searchableText: string;
}
