import React from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import type { WorkflowCanvasEdgeStyle, WorkflowCanvasLayoutEngine } from '@workflow/ui/workflow/types';
import WorkflowSettingsSectionCard from '@workflow/ui/workflow/components/dialogs/workspace/settings/WorkflowSettingsSectionCard';

interface WorkflowSettingsCanvasCardProps {
    readOnly?: boolean;
    layoutEngine: WorkflowCanvasLayoutEngine;
    edgeStyle: WorkflowCanvasEdgeStyle;
    layoutEngineOptions: Array<{ label: string; value: string }>;
    edgeStyleOptions: Array<{ label: string; value: string }>;
    onLayoutEngineChange: (value: WorkflowCanvasLayoutEngine) => void;
    onEdgeStyleChange: (value: WorkflowCanvasEdgeStyle) => void;
    onResetLayout?: () => void;
}

export const WorkflowSettingsCanvasCard: React.FC<WorkflowSettingsCanvasCardProps> = ({ readOnly = false, layoutEngine, edgeStyle, layoutEngineOptions, edgeStyleOptions, onLayoutEngineChange, onEdgeStyleChange, onResetLayout }) => (
    <WorkflowSettingsSectionCard icon="pi pi-share-alt" title="Canvas" description="Layout engine and edge styling for this workflow.">
        <label className="wf-workspace-settings__field-label">Layout engine</label>
        <Dropdown data-cy="workflow-settings-layout-engine" value={layoutEngine} options={layoutEngineOptions} onChange={(event) => onLayoutEngineChange(String(event.value) as WorkflowCanvasLayoutEngine)} disabled={readOnly} className="wf-workspace-settings__select" />
        <span className="wf-workspace-settings__field-note">ELK uses handle-aware layered routing for arrange actions.</span>
        <label className="wf-workspace-settings__field-label">Edge style</label>
        <Dropdown data-cy="workflow-settings-edge-style" value={edgeStyle} options={edgeStyleOptions} onChange={(event) => onEdgeStyleChange(String(event.value) as WorkflowCanvasEdgeStyle)} disabled={readOnly} className="wf-workspace-settings__select" />
        <span className="wf-workspace-settings__field-note">Applies to rendered edges and connection previews without removing edge actions.</span>
        <label className="wf-workspace-settings__field-label">Reset Layout</label>
        <span className="wf-workspace-settings__field-note">Reset Layout will update the layout.</span>
        <Button data-cy="workflow-settings-reset-layout" label="Reset Layout" icon="pi pi-sort-alt" outlined onClick={() => onResetLayout?.()} disabled={readOnly} />
    </WorkflowSettingsSectionCard>
);
