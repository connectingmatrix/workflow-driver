import { WorkflowDefinition, WorkflowSubworkflowUiModel } from '@workflow/ui/workflow/types';

export const SUBWORKFLOW_COLLAPSED_PREFIX = 'subworkflow:collapsed:';
export const SUBWORKFLOW_BOX_PREFIX = 'subworkflow:box:';
export const COLLAPSED_SUBWORKFLOW_WIDTH = 210;
export const COLLAPSED_SUBWORKFLOW_HEIGHT = 92;

export interface SubworkflowBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface WorkflowSubworkflowLayout {
    hiddenNodeIds: Set<string>;
    collapsedSubworkflowByNodeId: Map<string, string>;
    collapsedNodes: Array<{ id: string; name: string; bounds: SubworkflowBounds }>;
    expandedBoxes: Array<{ id: string; name: string; bounds: SubworkflowBounds }>;
}

const unique = (values: unknown): string[] => {
    if (!Array.isArray(values)) return [];
    return Array.from(new Set(values.map((value) => (typeof value === 'string' ? value.trim() : '')).filter(Boolean)));
};

const isFiniteNumber = (value: unknown): value is number => Number.isFinite(value);

const getExistingNodeIdSet = (workflow: WorkflowDefinition): Set<string> => new Set(workflow.nodes.map((node) => node.id));

const sanitizeSelectedNodeIds = (workflow: WorkflowDefinition, selectedNodeIds: string[]): string[] => {
    const existingNodeIds = getExistingNodeIdSet(workflow);
    const selectedIds = Array.isArray(selectedNodeIds) ? selectedNodeIds : [];
    return unique(selectedIds.filter((nodeId) => !nodeId.startsWith('subworkflow:'))).filter((nodeId) => existingNodeIds.has(nodeId));
};

export const getCollapsedSubworkflowPosition = (bounds: SubworkflowBounds): { x: number; y: number } => ({
    x: bounds.x + bounds.width / 2 - COLLAPSED_SUBWORKFLOW_WIDTH / 2,
    y: bounds.y + bounds.height / 2 - COLLAPSED_SUBWORKFLOW_HEIGHT / 2
});

export const getExpandedSubworkflowPosition = (bounds: SubworkflowBounds): { x: number; y: number } => ({
    x: bounds.x,
    y: bounds.y
});

const getSubworkflowById = (workflow: WorkflowDefinition, subworkflowId: string): WorkflowSubworkflowUiModel | null => {
    const current = getWorkflowSubworkflows(workflow);
    return current.find((item) => item.id === subworkflowId) ?? null;
};

const withUiState = (workflow: WorkflowDefinition, subworkflows: WorkflowSubworkflowUiModel[]): WorkflowDefinition => ({
    ...workflow,
    metadata: {
        ...workflow.metadata,
        ui: {
            ...(typeof workflow.metadata.ui === 'object' && workflow.metadata.ui ? workflow.metadata.ui : {}),
            subworkflows
        }
    }
});

export const getWorkflowSubworkflows = (workflow: WorkflowDefinition): WorkflowSubworkflowUiModel[] => {
    const values = workflow.metadata.ui?.subworkflows;
    if (!Array.isArray(values)) return [];
    return values
        .filter((item): item is WorkflowSubworkflowUiModel => Boolean(item?.id))
        .map((item) => ({
            ...item,
            nodeIds: unique(item.nodeIds ?? []),
            collapsed: Boolean(item.collapsed)
        }));
};

export const createOrExtendSubworkflow = (workflow: WorkflowDefinition, selectedNodeIds: string[], existingSubworkflowId?: string | null): WorkflowDefinition => {
    const realNodeIds = sanitizeSelectedNodeIds(workflow, selectedNodeIds);
    if (!realNodeIds.length) return workflow;
    const current = getWorkflowSubworkflows(workflow);
    if (typeof existingSubworkflowId === 'string' && existingSubworkflowId.trim()) {
        const existing = current.find((item) => item.id === existingSubworkflowId);
        if (!existing) return workflow;
        const next = current.map((item) => {
            if (item.id !== existing.id) return item;
            return {
                ...item,
                nodeIds: unique([...item.nodeIds, ...realNodeIds])
            };
        });
        return withUiState(workflow, next);
    }
    const nextId = `sw_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
    return withUiState(workflow, [
        ...current,
        {
            id: nextId,
            name: `Subworkflow ${current.length + 1}`,
            nodeIds: realNodeIds,
            collapsed: false
        }
    ]);
};

export const toggleSubworkflowCollapsed = (workflow: WorkflowDefinition, subworkflowId: string, collapsed: boolean): WorkflowDefinition => {
    if (!getSubworkflowById(workflow, subworkflowId)) return workflow;
    const current = getWorkflowSubworkflows(workflow);
    const next = current.map((item) => (item.id === subworkflowId ? { ...item, collapsed } : item));
    return withUiState(workflow, next);
};

export const ungroupSubworkflow = (workflow: WorkflowDefinition, subworkflowId: string): WorkflowDefinition => {
    if (!getSubworkflowById(workflow, subworkflowId)) return workflow;
    const current = getWorkflowSubworkflows(workflow);
    const next = current.filter((item) => item.id !== subworkflowId);
    return withUiState(workflow, next);
};

const getBounds = (workflow: WorkflowDefinition, nodeIds: string[]): SubworkflowBounds | null => {
    const nodes = workflow.nodes.filter((node) => nodeIds.includes(node.id));
    if (!nodes.length) return null;
    const minX = Math.min(...nodes.map((node) => node.position.x));
    const minY = Math.min(...nodes.map((node) => node.position.y));
    const maxX = Math.max(...nodes.map((node) => node.position.x + 236));
    const maxY = Math.max(...nodes.map((node) => node.position.y + 248));
    return { x: minX - 24, y: minY - 28, width: maxX - minX + 48, height: maxY - minY + 56 };
};

export const buildSubworkflowLayout = (workflow: WorkflowDefinition): WorkflowSubworkflowLayout => {
    const hiddenNodeIds = new Set<string>();
    const collapsedSubworkflowByNodeId = new Map<string, string>();
    const collapsedNodes: WorkflowSubworkflowLayout['collapsedNodes'] = [];
    const expandedBoxes: WorkflowSubworkflowLayout['expandedBoxes'] = [];
    getWorkflowSubworkflows(workflow).forEach((subworkflow) => {
        const bounds = getBounds(workflow, subworkflow.nodeIds);
        if (!bounds) return;
        if (subworkflow.collapsed) {
            subworkflow.nodeIds.forEach((nodeId) => {
                hiddenNodeIds.add(nodeId);
                collapsedSubworkflowByNodeId.set(nodeId, subworkflow.id);
            });
            collapsedNodes.push({
                id: `${SUBWORKFLOW_COLLAPSED_PREFIX}${subworkflow.id}`,
                name: subworkflow.name,
                bounds
            });
            return;
        }
        expandedBoxes.push({
            id: `${SUBWORKFLOW_BOX_PREFIX}${subworkflow.id}`,
            name: subworkflow.name,
            bounds
        });
    });
    return { hiddenNodeIds, collapsedSubworkflowByNodeId, collapsedNodes, expandedBoxes };
};

export const moveSubworkflowNodes = (workflow: WorkflowDefinition, subworkflowId: string, delta: { x: number; y: number }): WorkflowDefinition => {
    const xDelta = Number(delta.x);
    const yDelta = Number(delta.y);
    if (!isFiniteNumber(xDelta) || !isFiniteNumber(yDelta)) return workflow;
    if (xDelta === 0 && yDelta === 0) return workflow;

    const target = getSubworkflowById(workflow, subworkflowId);
    if (!target || target.nodeIds.length === 0) return workflow;
    const memberIds = new Set(target.nodeIds);
    return {
        ...workflow,
        nodes: workflow.nodes.map((node) => {
            if (!memberIds.has(node.id)) return node;
            const x = Number(node.position?.x ?? 0);
            const y = Number(node.position?.y ?? 0);
            return {
                ...node,
                position: {
                    x: (isFiniteNumber(x) ? x : 0) + xDelta,
                    y: (isFiniteNumber(y) ? y : 0) + yDelta
                }
            };
        })
    };
};

export const findExpandedSubworkflowIdAtPosition = (workflow: WorkflowDefinition, position: { x: number; y: number }): string | null => {
    const x = Number(position.x);
    const y = Number(position.y);
    if (!isFiniteNumber(x) || !isFiniteNumber(y)) return null;

    const subworkflows = getWorkflowSubworkflows(workflow);
    for (let index = subworkflows.length - 1; index >= 0; index -= 1) {
        const subworkflow = subworkflows[index];
        if (subworkflow.collapsed) continue;
        const bounds = getBounds(workflow, subworkflow.nodeIds);
        if (!bounds) continue;
        if (x < bounds.x || y < bounds.y || x > bounds.x + bounds.width || y > bounds.y + bounds.height) continue;
        return subworkflow.id;
    }
    return null;
};

export const extractSubworkflowIdFromNodeId = (nodeId: string): string | null => {
    if (nodeId.startsWith(SUBWORKFLOW_COLLAPSED_PREFIX)) return nodeId.slice(SUBWORKFLOW_COLLAPSED_PREFIX.length);
    if (nodeId.startsWith(SUBWORKFLOW_BOX_PREFIX)) return nodeId.slice(SUBWORKFLOW_BOX_PREFIX.length);
    return null;
};
