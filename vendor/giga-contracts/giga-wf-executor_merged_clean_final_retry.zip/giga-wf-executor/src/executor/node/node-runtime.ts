import { WorkerExecuteHelpers, WorkflowNodeHandler } from '../../types';
import { TypeScriptModuleLoader } from '../core/compiler/typescript-compiler';
import { createSandboxedNodeWorkerNodeRunner, prewarmSandboxedNodeWorkerPool } from './node-sandbox-runner';

export interface NodeWorkerNodeHandlerArgs {
    modelId: string;
    executeHelpers?: WorkerExecuteHelpers;
    typescriptModuleLoader?: TypeScriptModuleLoader;
}

export const createNodeWorkerNodeHandler = (args: NodeWorkerNodeHandlerArgs): WorkflowNodeHandler =>
    createSandboxedNodeWorkerNodeRunner({
        modelId: args.modelId,
        executeHelpers: args.executeHelpers
    });

export const prewarmNodeWorkerPool = prewarmSandboxedNodeWorkerPool;
