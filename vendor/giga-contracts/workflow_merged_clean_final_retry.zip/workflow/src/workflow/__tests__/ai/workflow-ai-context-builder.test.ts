import { describe, expect, it } from 'vitest';
import { getNodeLibraryItems } from '@workflow/nodes/node-utils';
import { resolveNodeSchema } from '@workflow/nodes/node-utils';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import { buildWorkflowAiHiddenContext, buildWorkflowAiPrompt } from '@workflow/ui/workflow/ai';

describe('workflow-ai hidden context and prompt contract', () => {
    it('includes compact node contracts with port and ai-write metadata', () => {
        const workflow = createEmptyWorkflow('wf_ai_context_contract');
        workflow.nodes = [createWorkflowNode(workflow, 'start', 'Start', 1)];
        const context = buildWorkflowAiHiddenContext({
            workflow,
            scope: { mode: 'workflow' },
            recentLogs: [],
            nodeLibraryItems: getNodeLibraryItems(),
            capabilities: ['create_workflow'],
            resolveNodeSchema
        });

        const aiAgentContract = context.nodeContracts?.find((entry) => entry.modelId === 'ai-agent');
        const governorContract = context.nodeContracts?.find((entry) => entry.modelId === 'ai-governor');
        expect(aiAgentContract).toBeTruthy();
        expect(governorContract).toBeTruthy();
        const workflowCommandPort = aiAgentContract?.ports.commands.find((port) => port.id === 'workflow');
        const llmCommandPort = governorContract?.ports.commands.find((port) => port.id === 'llm');
        expect(workflowCommandPort?.label).toBe('Workflow');
        expect(workflowCommandPort?.acceptedSourceModelIds).toEqual(['workflow', 'execute-workflow']);
        expect(llmCommandPort?.label).toBe('Planner LLM');
        expect(llmCommandPort?.portType).toBe('bi-directional');
        expect(llmCommandPort?.acceptedSourceGroups).toEqual(['AI Models']);
        const workflowToolAllowlistField = aiAgentContract?.fields.find((field) => field.key === 'workflowToolAllowlist');
        const selectionPromptField = governorContract?.fields.find((field) => field.key === 'selectionPromptMd');
        const selectedModelsField = governorContract?.fields.find((field) => field.key === 'selectedModels');
        const serpContract = context.nodeContracts?.find((entry) => entry.modelId === 'serp-search');
        const outputFormatContract = context.nodeContracts?.find((entry) => entry.modelId === 'output-format');
        expect(workflowToolAllowlistField?.type).toBe('select');
        expect(selectionPromptField?.type).toBe('markdown');
        expect(selectedModelsField).toBeUndefined();
        expect(serpContract?.fields.some((field) => field.key === 'query' && field.allowVariables === true)).toBe(true);
        expect(outputFormatContract?.fields.some((field) => field.key === 'format' && field.options?.some((option) => option.value === 'markdown'))).toBe(true);
        expect(context.workflowCypher).toContain(':');
        expect(context.knowledge.some((entry) => entry.id === 'news-threat-analysis-governor-code-table')).toBe(true);
    });

    it('embeds strict group and governor port rules in system prompt', () => {
        const workflow = createEmptyWorkflow('wf_ai_prompt_contract');
        const context = buildWorkflowAiHiddenContext({
            workflow,
            scope: { mode: 'workflow' },
            recentLogs: [],
            nodeLibraryItems: getNodeLibraryItems(),
            capabilities: ['create_workflow'],
            resolveNodeSchema
        });
        const prompt = buildWorkflowAiPrompt('Create workflow', context);
        expect(prompt.includes('Respect requested node groups strictly')).toBe(true);
        expect(prompt.includes('apply_workflow_cypher')).toBe(true);
        expect(prompt.includes('cmd:llm')).toBe(true);
        expect(prompt.includes('cmd:workflow')).toBe(true);
        expect(prompt.includes('ai-agent')).toBe(true);
        expect(prompt.includes('Use grouped Giga action nodes with an explicit `action` value')).toBe(true);
    });

    it('describes invalid workflow-tool connections with node names and handles', () => {
        const workflow = createEmptyWorkflow('wf_ai_context_graph_health');
        const routerNode = createWorkflowNode(workflow, 'action-router', 'Router', 1);
        const agentNode = createWorkflowNode(workflow, 'ai-agent', 'AI Agent', 2);
        workflow.nodes = [routerNode, agentNode];
        workflow.connections = [createConnection('c1', routerNode.id, agentNode.id, 'cmd:command', 'cmd:workflow')];

        const context = buildWorkflowAiHiddenContext({
            workflow,
            scope: { mode: 'workflow' },
            recentLogs: [],
            nodeLibraryItems: getNodeLibraryItems(),
            capabilities: ['create_workflow'],
            resolveNodeSchema
        });

        expect(context.graphHealth).toContain('Invalid connection "Router" -> "AI Agent" (cmd:command -> cmd:workflow).');
    });
});
