import React from 'react';
import { WORKFLOW_FAILURE_MITIGATION_FIELD, WORKFLOW_FAILURE_MITIGATION_RETRY, WORKFLOW_RETRY_COUNT_FIELD } from '@workflow/ui/workflow/utils/workflow-failure-mitigation.utils';
import type { WorkspaceFieldModel, WorkspaceParameterSectionModel } from '@workflow/ui/workflow/components/inspector/workspace/types';
import type { WorkflowInspectorVariableSuggestion } from '@workflow/ui/workflow/components/inspector/types';
import type { WorkflowNodeFieldDefinition } from '@workflow/ui/workflow/types';
import { WorkspaceFieldHost } from '@workflow/ui/workflow/components/inspector/workspace/components/WorkspaceFieldHost';

interface WorkspaceParametersSectionProps {
    section: WorkspaceParameterSectionModel;
    allFields: WorkspaceFieldModel[];
    readOnly?: boolean;
    propertiesEditorState: Record<string, unknown>;
    onFieldChange: (fieldKey: string, value: unknown) => void;
    variableContext?: Record<string, unknown>;
    variableSuggestions?: WorkflowInspectorVariableSuggestion[];
    inspectorColumns?: number;
}

export const WorkspaceParametersSection: React.FC<WorkspaceParametersSectionProps> = ({
    section,
    allFields,
    readOnly = false,
    propertiesEditorState,
    onFieldChange,
    variableContext,
    variableSuggestions,
    inspectorColumns
}) => {
    const fieldMap = React.useMemo(() => new Map(allFields.map((field) => [field.key, field])), [allFields]);
    const dependingFieldMap = React.useMemo(() => {
        const map = new Map<string, { fieldKey: string; definition: WorkflowNodeFieldDefinition; value: unknown }>();
        allFields.forEach((field) => {
            const dependencyFieldKey = field.definition.dependsOn?.field;
            if (!dependencyFieldKey || field.definition.dependsOn?.entityField !== true) {
                return;
            }
            const dependencyField = fieldMap.get(dependencyFieldKey);
            if (!dependencyField || dependencyField.key === field.key) {
                return;
            }
            map.set(field.key, {
                fieldKey: dependencyField.key,
                definition: dependencyField.definition,
                value: propertiesEditorState[dependencyField.key]
            });
        });
        return map;
    }, [allFields, fieldMap, propertiesEditorState]);
    const dependencyFieldKeys = React.useMemo(() => new Set(Array.from(dependingFieldMap.values()).map((entry) => entry.fieldKey)), [dependingFieldMap]);
    const retryField = fieldMap.get(WORKFLOW_RETRY_COUNT_FIELD);
    const showRetryCompanion = String(propertiesEditorState[WORKFLOW_FAILURE_MITIGATION_FIELD] ?? '').trim() === WORKFLOW_FAILURE_MITIGATION_RETRY;
    const visibleFields = section.fields.filter((field) => {
        if (dependencyFieldKeys.has(field.key) && !dependingFieldMap.has(field.key)) {
            return false;
        }
        if (field.key === WORKFLOW_RETRY_COUNT_FIELD && retryField) {
            return false;
        }
        return true;
    });

    if (visibleFields.length === 0) {
        return null;
    }

    const fieldsGridClassName = [
        'cnw-fields-grid',
        section.variant === 'execution-grid' ? 'cnw-fields-grid--execution' : '',
        visibleFields.length === 1 ? 'cnw-fields-grid--single' : ''
    ]
        .filter(Boolean)
        .join(' ');

    return (
        <div className={`cnw-section-block${section.variant === 'execution-grid' ? ' cnw-section-block--execution' : ''}`}>
            <div className="cnw-section-block__header">
                <h4 className="cnw-section-block__title">{section.title}</h4>
                {section.description ? <p className="cnw-section-block__description">{section.description}</p> : null}
            </div>
            <div className={fieldsGridClassName}>
                {visibleFields.map((field) => (
                    <WorkspaceFieldHost
                        key={field.id}
                        field={field}
                        readOnly={readOnly}
                        propertiesEditorState={propertiesEditorState}
                        onChange={onFieldChange}
                        inspectorColumns={inspectorColumns}
                        variableContext={variableContext}
                        variableSuggestions={variableSuggestions}
                        companionField={
                            field.key === WORKFLOW_FAILURE_MITIGATION_FIELD && retryField
                                ? {
                                      fieldKey: retryField.key,
                                      definition: retryField.definition,
                                      value: propertiesEditorState[retryField.key],
                                      visible: showRetryCompanion
                                  }
                                : undefined
                        }
                        dependingField={dependingFieldMap.get(field.key)}
                    />
                ))}
            </div>
        </div>
    );
};
