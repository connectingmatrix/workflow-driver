/** @vitest-environment jsdom */
import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import type { WorkflowDefinition } from '@workflow/ui/workflow/types';

const fitView = vi.fn();

vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({ default: () => null }));
vi.mock('@/common/components/logs/JsonlLogsDialog', () => ({ default: () => null }));
vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({
    default: (props: { visible: boolean; onResetLayout?: (canvasSettings: { layoutEngine: string; edgeStyle: string }) => void }) =>
        props.visible ? <button type="button" onClick={() => props.onResetLayout?.({ layoutEngine: 'legacy', edgeStyle: 'legacy' })}>Reset Layout</button> : null
}));
vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({ default: () => null }));
vi.mock('primereact/dialog', () => ({ Dialog: (props: { visible: boolean; children: React.ReactNode }) => (props.visible ? <div>{props.children}</div> : null) }));
vi.mock('primereact/toast', () => ({ Toast: React.forwardRef(() => null) }));
vi.mock('primereact/tooltip', () => ({ Tooltip: () => null }));
vi.mock('primereact/menu', () => ({ Menu: React.forwardRef((_: unknown, ref) => (React.useImperativeHandle(ref, () => ({ toggle: () => undefined })), null)) }));
vi.mock('primereact/overlaypanel', () => ({ OverlayPanel: React.forwardRef((props: { children: React.ReactNode }, ref) => (React.useImperativeHandle(ref, () => ({ hide: () => undefined })), <div>{props.children}</div>)) }));
vi.mock('primereact/contextmenu', () => ({ ContextMenu: React.forwardRef((_: unknown, ref) => (React.useImperativeHandle(ref, () => ({ show: () => undefined, hide: () => undefined })), null)) }));
vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({ default: (props: { onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number }; fitView: typeof fitView; setCenter: () => void }) => void }) => (React.useEffect(() => props.onInit({ screenToFlowPosition: ({ x, y }) => ({ x, y }), fitView, setCenter: () => undefined }), [props.onInit]), <div data-testid="workflow-canvas" />) }));
vi.mock('@workflow/ui/workflow/executor/runtime', () => ({ workflowExecutor: { executeWorkflow: vi.fn(), executeNodeStep: vi.fn() }, workflowExecutorHostContext: { mcp: { registerServer: vi.fn(), removeServer: vi.fn(), getServer: vi.fn(), listServers: vi.fn(() => []), queryCapabilities: vi.fn(), resolveNodeServer: vi.fn() } } }));
vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (readOriginal) => ({ ...(await readOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>()), prewarmJavascriptRuntimeFrame: vi.fn(async () => undefined) }));
vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({ listWorkflowUserNodes: vi.fn(async () => []) }));

const driver: WorkflowUiDriver = {
    createRequestId: () => 'req_arrange',
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({ connect: vi.fn(), disconnect: vi.fn(), startPreview: vi.fn(async () => undefined), cancelPreview: vi.fn(), addPreviewLogHandler: vi.fn(() => () => undefined), addPreviewStateHandler: vi.fn(() => () => undefined), addPreviewResultHandler: vi.fn(() => () => undefined), addPreviewErrorHandler: vi.fn(() => () => undefined), addPreviewStopHandler: vi.fn(() => () => undefined) }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: createEmptyWorkflow('wf_arrange'), logs: [] })),
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};

const nodeCatalog: WorkflowNodeCatalog = { modules: [], getAllNodeSchemas: () => ({}), getNodeLibraryItems: () => [], getNodeModuleById: () => null, resolveNodeSchema: () => ({ documentation: {} }) as never, isLocalCapableNodeModel: () => true };

const createStripWorkflow = (): WorkflowDefinition => {
    const workflow = createEmptyWorkflow('wf_arrange');
    const start = { ...createWorkflowNode(workflow, 'start', 'Start', 1), position: { x: 400, y: 260 } };
    const branch = { ...createWorkflowNode(workflow, 'if-else', 'Branch', 2), position: { x: 1100, y: 260 } };
    const left = { ...createWorkflowNode(workflow, 'code', 'Left', 3), position: { x: 1800, y: 260 }, runtime: { code: 'return 1;' }, properties: { code: 'return 1;' } };
    const right = { ...createWorkflowNode(workflow, 'code', 'Right', 4), position: { x: 2500, y: 260 } };
    const end = { ...createWorkflowNode(workflow, 'respond-end', 'End', 5), position: { x: 3200, y: 260 } };
    workflow.nodes = [start, branch, left, right, end];
    workflow.connections = [createConnection('c1', start.id, branch.id), createConnection('c2', branch.id, left.id, 'out:true', 'in:input'), createConnection('c3', branch.id, right.id, 'out:false', 'in:input'), createConnection('c4', left.id, end.id)];
    return workflow;
};

describe('DesignerDialog reset layout', () => {
    it('reflows the workflow, preserves content, and fits the canvas', async () => {
        fitView.mockReset();
        let latestWorkflow: WorkflowDefinition | null = null;
        render(<DesignerDialog visible mode="execution" workflow={createStripWorkflow()} driver={driver} nodeCatalog={nodeCatalog} onHide={vi.fn()} onWorkflowChange={(workflow) => { latestWorkflow = workflow; }} />);
        await waitFor(() => expect(screen.getByTestId('workflow-canvas')).toBeTruthy());
        await waitFor(() => expect(fitView).toHaveBeenCalled());
        fitView.mockClear();

        fireEvent.click(screen.getByRole('button', { name: 'Workflow settings' }));
        fireEvent.click(screen.getByRole('button', { name: 'Reset Layout' }));

        await waitFor(() => expect(fitView).toHaveBeenCalledTimes(1));
        await waitFor(() => expect(latestWorkflow?.nodes.some((node) => node.position.y !== 260)).toBe(true));
        expect(latestWorkflow?.connections.map((connection) => connection.id)).toEqual(['c1', 'c2', 'c3', 'c4']);
        expect(latestWorkflow?.nodes.find((node) => node.name === 'Left')?.runtime?.code).toBe('return 1;');
    });
});
