import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWorkflowQueueScheduler } from '../queue/createWorkflowQueueScheduler';
import type { WorkflowQueueRequest } from '../queue/types';

const createDeferred = () => {
  let resolve!: () => void;
  const promise = new Promise<void>((nextResolve) => {
    resolve = nextResolve;
  });
  return { promise, resolve };
};

const createRequest = (queueKey: string, executionId: string): WorkflowQueueRequest => ({
  executionId,
  runId: `run-${executionId}`,
  queueKey,
  userId: queueKey,
  broadcastId: queueKey,
  broadcastChannelName: 'workflow-socket',
  triggerType: 'chat',
  workflowReference: {
    workflowId: `wf-${executionId}`,
    scope: 'user',
    ownerUserId: queueKey,
  },
  workflowVersionId: null,
  workflow: {
    metadata: { id: `wf-${executionId}`, name: `Workflow ${executionId}` },
    nodes: [],
    connections: [],
  },
  settings: {
    graphqlUrl: 'http://localhost:3001/api/v2/graphql',
    authMode: 'auto-from-current-session',
    maxConcurrentExecutionsPerUser: 2,
  },
  requestContext: {
    mode: 'user',
    userId: queueKey,
    headers: {},
  },
  metadata: null,
});

describe('createWorkflowQueueScheduler', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('runs queued jobs in FIFO order per user queue', async () => {
    const scheduler = createWorkflowQueueScheduler();
    const first = createDeferred();
    const second = createDeferred();
    const third = createDeferred();
    const started: string[] = [];
    const finished: string[] = [];

    scheduler.enqueue({
      request: createRequest('user-a', 'first'),
      execute: async () => {
        started.push('first');
        await first.promise;
        finished.push('first');
      },
    });
    scheduler.enqueue({
      request: createRequest('user-a', 'second'),
      execute: async () => {
        started.push('second');
        await second.promise;
        finished.push('second');
      },
    });
    scheduler.enqueue({
      request: createRequest('user-a', 'third'),
      execute: async () => {
        started.push('third');
        await third.promise;
        finished.push('third');
      },
    });

    await vi.waitFor(() => {
      expect(started).toEqual(['first', 'second']);
      expect(scheduler.getActiveCount('user-a')).toBe(2);
      expect(scheduler.getPendingCount('user-a')).toBe(1);
    });

    first.resolve();
    await vi.waitFor(() => {
      expect(finished).toContain('first');
      expect(started).toEqual(['first', 'second', 'third']);
      expect(scheduler.getActiveCount('user-a')).toBe(2);
      expect(scheduler.getPendingCount('user-a')).toBe(0);
    });
    second.resolve();
    third.resolve();
    await scheduler.close();

    expect(finished).toEqual(['first', 'second', 'third']);
  });

  it('allows different users to execute in parallel on separate queues', async () => {
    const scheduler = createWorkflowQueueScheduler();
    const userA = createDeferred();
    const userB = createDeferred();
    const started = new Set<string>();

    scheduler.enqueue({
      request: createRequest('user-a', 'job-a'),
      execute: async () => {
        started.add('user-a');
        await userA.promise;
      },
    });
    scheduler.enqueue({
      request: createRequest('user-b', 'job-b'),
      execute: async () => {
        started.add('user-b');
        await userB.promise;
      },
    });

    await vi.waitFor(() => {
      expect(started).toEqual(new Set(['user-a', 'user-b']));
      expect(scheduler.getActiveCount('user-a')).toBe(1);
      expect(scheduler.getActiveCount('user-b')).toBe(1);
    });

    userA.resolve();
    userB.resolve();
    await scheduler.close();
  });
});
