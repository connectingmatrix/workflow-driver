import React from 'react';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import DesignerDialog from '@workflow/ui/workflow/DesignerDialog';
import { createConnection, createEmptyWorkflow, createWorkflowNode } from '@workflow/ui/workflow/__tests__/workflow-test-utils';
import type { WorkflowNodeCatalog, WorkflowUiDriver } from '@workflow/ui/workflow/driver';
import { WorkflowDefinition, WorkflowNodeStatusEnum } from '@workflow/ui/workflow/types';

const { executeWorkflowMock, prewarmJavascriptRuntimeFrameMock } = vi.hoisted(() => ({
    executeWorkflowMock: vi.fn(),
    prewarmJavascriptRuntimeFrameMock: vi.fn(async () => undefined)
}));

vi.mock('@workflow/ui/workflow/components/toolbar/Toolbar', () => ({
    default: (props: { playLifecycle: string; onPlayLocal: () => void; onShowLogs: () => void }) => (
        <div data-testid="workflow-toolbar">
            <span data-testid="toolbar-play-lifecycle">{props.playLifecycle}</span>
            <button type="button" onClick={props.onPlayLocal}>
                Play Local
            </button>
            <button type="button" onClick={props.onShowLogs}>
                Show Logs
            </button>
        </div>
    )
}));

vi.mock('@workflow/ui/workflow/components/node-library/NodeLibrary', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/MetadataDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/logs/JsonlLogsDialog', () => ({
    default: (props: { events?: Array<{ message?: string }>; visible?: boolean }) =>
        props.visible ? <div data-testid="workflow-logs-dialog">{(props.events || []).map((event) => event.message || '').join(' | ')}</div> : null
}));

vi.mock('@workflow/ui/workflow/components/dialogs/SettingsDialog', () => ({
    default: () => null
}));

vi.mock('@workflow/ui/workflow/components/inspector/NodeInspector', () => ({
    default: () => null
}));

vi.mock('primereact/contextmenu', () => {
    const ReactModule = require('react') as typeof React;
    const MockContextMenu = ReactModule.forwardRef((_: unknown, ref) => {
        ReactModule.useImperativeHandle(ref, () => ({
            show: () => undefined,
            hide: () => undefined
        }));
        return null;
    });
    MockContextMenu.displayName = 'MockContextMenu';
    return { ContextMenu: MockContextMenu };
});

vi.mock('@workflow/ui/workflow/components/canvas/Canvas', () => ({
    default: (props: { onInit: (instance: { screenToFlowPosition: (point: { x: number; y: number }) => { x: number; y: number }; fitView?: () => void; setCenter?: () => void }) => void }) => {
        React.useEffect(() => {
            props.onInit({
                screenToFlowPosition: ({ x, y }) => ({ x, y }),
                fitView: () => undefined,
                setCenter: () => undefined
            });
        }, [props.onInit]);
        return <div data-testid="workflow-canvas" />;
    }
}));

vi.mock('@workflow/ui/workflow/executor/runtime', () => ({
    workflowExecutor: {
        executeWorkflow: executeWorkflowMock,
        executeNodeStep: vi.fn()
    },
    workflowExecutorHostContext: {
        mcp: {
            registerServer: vi.fn(),
            removeServer: vi.fn(),
            getServer: vi.fn(),
            listServers: vi.fn(() => []),
            queryCapabilities: vi.fn(),
            resolveNodeServer: vi.fn()
        }
    }
}));

vi.mock('@workflow/ui/workflow/browser-runtime/js-runtime-iframe', async (importOriginal) => {
    const originalModule = await importOriginal<typeof import('@workflow/ui/workflow/browser-runtime/js-runtime-iframe')>();
    return {
        ...originalModule,
        prewarmJavascriptRuntimeFrame: prewarmJavascriptRuntimeFrameMock
    };
});

vi.mock('@workflow/ui/workflow/services/workflow-user-nodes.service', () => ({
    listWorkflowUserNodes: vi.fn(async () => [])
}));

const driver: WorkflowUiDriver = {
    createRequestId: () => 'req_1',
    getDefaultRuntimeSettings: () => ({ graphqlUrl: '', authMode: 'none', manualHeaders: {}, maxExecutionSeconds: 300 }),
    createRealtimeClient: () => ({ connect: vi.fn(), disconnect: vi.fn(), startPreview: vi.fn(async () => undefined), cancelPreview: vi.fn(), addPreviewLogHandler: vi.fn(() => () => undefined), addPreviewStateHandler: vi.fn(() => () => undefined), addPreviewResultHandler: vi.fn(() => () => undefined), addPreviewErrorHandler: vi.fn(() => () => undefined), addPreviewStopHandler: vi.fn(() => () => undefined) }),
    buildWorkflowWebhookUrls: () => ({ testUrl: '', publishedUrl: '' }),
    executeWorkflowOnServer: vi.fn(async () => ({ accepted: true, run_id: 'run_1', stopped: false, workflow: createEmptyWorkflow('wf_1'), logs: [] })),
    requestWorkflowAi: vi.fn(async () => ({ reply: '', actions: [] })),
    fetchCredentials: vi.fn(async () => []),
    fetchCredentialById: vi.fn(async () => null),
    openCredentialManager: vi.fn(),
    fetchExecutableWorkflows: vi.fn(async () => []),
    listWorkflowUserNodes: vi.fn(async () => []),
    createWorkflowUserNode: vi.fn(),
    updateWorkflowUserNode: vi.fn(),
    deleteWorkflowUserNode: vi.fn(async () => true)
};
const nodeCatalog: WorkflowNodeCatalog = { modules: [], getAllNodeSchemas: () => ({}), getNodeLibraryItems: () => [], getNodeModuleById: () => null, resolveNodeSchema: () => ({ documentation: {} }) as never, isLocalCapableNodeModel: () => true };

const createWorkflowFixture = (): WorkflowDefinition => {
    const workflow = createEmptyWorkflow('wf_local_compat');
    const startNode = createWorkflowNode(workflow, 'start', 'Start', 1);
    const codeNode = createWorkflowNode(workflow, 'code', 'Code', 2);
    const endNode = createWorkflowNode(workflow, 'respond-end', 'End', 3);
    workflow.nodes = [startNode, codeNode, endNode];
    workflow.connections = [createConnection('c_1', startNode.id, codeNode.id), createConnection('c_2', codeNode.id, endNode.id)];
    return workflow;
};

beforeEach(() => {
    executeWorkflowMock.mockReset();
    prewarmJavascriptRuntimeFrameMock.mockReset();
    prewarmJavascriptRuntimeFrameMock.mockResolvedValue(undefined);

    executeWorkflowMock.mockImplementation(async (workflow: WorkflowDefinition, options: { logger?: { push?: (event: unknown) => void; entries?: unknown[] } }) => {
        options.logger?.push?.({
            workflowId: workflow.metadata.id,
            runId: 'run_legacy_logger',
            event: 'node.started',
            level: 'info',
            nodeId: workflow.nodes[0]?.id,
            message: 'Running Start'
        });
        return {
            workflow,
            stopped: false,
            logs: Array.isArray(options.logger?.entries) ? options.logger?.entries : []
        };
    });
});

afterEach(() => cleanup());

describe('DesignerDialog local play compatibility', () => {
    it('passes legacy logger to executor so old logger.push contract does not crash', async () => {
        render(<DesignerDialog visible workflow={createWorkflowFixture()} driver={driver} nodeCatalog={nodeCatalog} onHide={vi.fn()} onWorkflowChange={vi.fn()} />);

        fireEvent.click(screen.getByRole('button', { name: 'Play Local' }));

        await waitFor(() => {
            expect(executeWorkflowMock).toHaveBeenCalledTimes(1);
        });

        const callOptions = executeWorkflowMock.mock.calls[0]?.[1] as { logger?: { push?: (...args: unknown[]) => unknown } };
        expect(callOptions?.logger).toBeTruthy();
        expect(typeof callOptions?.logger?.push).toBe('function');

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('idle');
        });
    });

    it('replays execution snapshots with the stored request payload', async () => {
        render(
            <DesignerDialog
                visible
                mode="execution"
                executionRequestPayload={{ input: { message: 'hello' } }}
                workflow={createWorkflowFixture()}
                driver={driver}
                nodeCatalog={nodeCatalog}
                onHide={vi.fn()}
                onWorkflowChange={vi.fn()}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Play Local' }));

        await waitFor(() => {
            expect(executeWorkflowMock).toHaveBeenCalledTimes(1);
        });

        const callOptions = executeWorkflowMock.mock.calls[0]?.[1] as { workflowInput?: Record<string, unknown> };
        expect(callOptions.workflowInput).toEqual({ input: { message: 'hello' } });
    });

    it('keeps the execution log dialog bound to stored run logs during replay', async () => {
        render(
            <DesignerDialog
                visible
                mode="execution"
                executionLogs={[
                    {
                        workflowId: 'wf_local_compat',
                        runId: 'run_original',
                        event: 'node.finished',
                        level: 'info',
                        nodeId: 'node_2',
                        message: 'Original run log'
                    }
                ]}
                executionRequestPayload={{ input: { message: 'hello' } }}
                workflow={createWorkflowFixture()}
                driver={driver}
                nodeCatalog={nodeCatalog}
                onHide={vi.fn()}
                onWorkflowChange={vi.fn()}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Play Local' }));

        await waitFor(() => {
            expect(executeWorkflowMock).toHaveBeenCalledTimes(1);
        });

        fireEvent.click(screen.getByRole('button', { name: 'Show Logs' }));
        expect(screen.getByTestId('workflow-logs-dialog').textContent).toContain('Original run log');
        expect(screen.getByTestId('workflow-logs-dialog').textContent).not.toContain('Running Start');
    });

    it('fails fast when node.failed is emitted and returns to idle lifecycle', async () => {
        let latestWorkflow: WorkflowDefinition | null = null;
        executeWorkflowMock.mockImplementationOnce(async (workflow: WorkflowDefinition, options: { onEvent?: (event: unknown) => void; logger?: { push?: (event: unknown) => void } }) => {
            const failedEvent = {
                workflowId: workflow.metadata.id,
                runId: 'run_fail_fast',
                event: 'node.failed',
                level: 'error',
                nodeId: workflow.nodes[1]?.id,
                message: 'Code node failed.',
                data: { error: 'Code node failed.' }
            };
            options.logger?.push?.(failedEvent);
            options.onEvent?.(failedEvent);
            return {
                workflow,
                stopped: true,
                logs: []
            };
        });

        render(
            <DesignerDialog
                visible
                workflow={createWorkflowFixture()}
                driver={driver}
                nodeCatalog={nodeCatalog}
                onHide={vi.fn()}
                onWorkflowChange={(workflow) => {
                    latestWorkflow = workflow;
                }}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Play Local' }));

        await waitFor(() => {
            expect(screen.getByTestId('toolbar-play-lifecycle').textContent).toBe('idle');
        });

        expect(latestWorkflow?.nodes.find((node) => node.id === 'node_2')?.status).toBe('failed');
    });

    it('resets previously passed node state before invoking local executor so workflows can rerun', async () => {
        const completedWorkflow = createWorkflowFixture();
        completedWorkflow.nodes = completedWorkflow.nodes.map((node) => ({
            ...node,
            status: WorkflowNodeStatusEnum.Passed,
            output: { stale: true },
            ports: {
                ...(node.ports ?? { in: {}, out: {} }),
                out: {
                    ...((node.ports?.out as Record<string, unknown>) ?? {}),
                    output: { stale: true },
                    __activeOutputs: ['output']
                }
            }
        }));

        render(<DesignerDialog visible workflow={completedWorkflow} driver={driver} nodeCatalog={nodeCatalog} onHide={vi.fn()} onWorkflowChange={vi.fn()} />);
        fireEvent.click(screen.getByRole('button', { name: 'Play Local' }));

        await waitFor(() => {
            expect(executeWorkflowMock).toHaveBeenCalledTimes(1);
        });

        const executionWorkflow = executeWorkflowMock.mock.calls[0]?.[0] as WorkflowDefinition;
        expect(executionWorkflow.nodes.every((node) => node.status === WorkflowNodeStatusEnum.Stopped)).toBe(true);
        expect(executionWorkflow.nodes.every((node) => node.output === null)).toBe(true);
        expect(executionWorkflow.nodes.every((node) => ((node.ports?.out as Record<string, unknown> | undefined)?.output ?? null) === null)).toBe(true);
    });
});
