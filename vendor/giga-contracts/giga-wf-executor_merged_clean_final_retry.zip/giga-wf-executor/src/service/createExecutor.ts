import { readWorkflowActionCatalog } from "../api/readWorkflowActionCatalog";
import {
  readWorkflowEditorUrl,
  readWorkflowExcerpt,
  readWorkflowShape,
} from "../api/readWorkflowSummary";
import {
  compileWorkflowCypher,
  compileWorkflowFromAgentPrompt,
  createDynamicNodeOperation,
} from "../workflow-ai-creation";
import {
  workflowNodeCatalog,
  workflowNodeDetails,
} from "../workflow-ai-creation";
import { workflowPlannerContext } from "../workflow-ai-creation";
import {
  createQueuedWorkflowRequestExecutor,
  createWorkflowQueueEventApplier,
  createWorkflowQueueRequestContextSnapshot,
  createWorkflowQueueTimingPayload,
  isWorkflowQueueExecutionStalled,
  mergeWorkflowQueueTimingPayload,
  normalizeWorkflowQueueDefinition,
  normalizeWorkflowQueueLogEvent,
  normalizeWorkflowQueueLogs,
  resolveWorkflowQueueCompletion,
  resolveWorkflowQueueTiming,
  waitForWorkflowQueueCompletion,
  withWorkflowQueueExecutionStarted,
  withWorkflowQueueTimingPayload,
} from "../queue";
import { readWorkflowQueueRedpandaConfig } from "../queue";
import {
  consumeWorkflowExecutionEvents,
  createWorkflowPubsub,
  queueWorkflowForExecution,
  runWorkflowExecutionQueue,
  startWorkflowExecutionPubsub,
  workflowCatalogRoom,
  workflowExecutionRoom,
  workflowLogsRoom,
  workflowUserRoom,
} from "../pubsub";
import { createWorkflowTransportServer } from "./workflowTransportServer";
import { readWorkflowChatAdapter } from "./workflowChatAction";
import type {
  WorkflowDefinition,
  WorkflowExecutorResult,
  WorkflowNodeModel,
  WorkflowStepExecutorResult,
} from "../types";
import type {
  ExecuteNodeStepWithNodeOptions,
  ExecuteNodeStepWithWorkflowOptions,
  ExecutorPublishEventName,
  ExecutorRunningState,
  ExecutorSetup,
  ExecutorStepOptions,
} from "./types";

const workflowId = (workflow: WorkflowDefinition) =>
  String(workflow?.metadata?.id || "").trim();
const runId = (value: unknown) =>
  String((value as Record<string, unknown>)?.runId || "").trim();
const errorText = (error: unknown) =>
  (error instanceof Error
    ? error.message
    : String(error || "Workflow execution failed.")
  ).trim() || "Workflow execution failed.";
const silentLogger = () => ({
  entries: [] as unknown[],
  push: () => undefined,
});
const noop = () => undefined;
const stepMetadataId = () => `single-node-step-${Date.now().toString(36)}`;

const isWorkflowStepOptions = (
  options: ExecutorStepOptions,
): options is ExecuteNodeStepWithWorkflowOptions =>
  "workflow" in options && "nodeId" in options;

const buildSingleNodeWorkflowStep = (
  options: ExecuteNodeStepWithNodeOptions,
): ExecuteNodeStepWithWorkflowOptions => {
  const metadataId = options.metadata?.id || options.node.id || stepMetadataId();
  const metadataName =
    options.metadata?.name || options.node.name || "Single Node Step";
  const runtimeInput = options.runtimeInput || {};
  const mergedNode: WorkflowNodeModel = {
    ...options.node,
    runtime: { ...options.node.runtime, ...runtimeInput },
    properties: options.node.properties
      ? { ...options.node.properties, ...runtimeInput }
      : options.node.properties,
  };
  const workflow: WorkflowDefinition = {
    metadata: { ...options.metadata, id: metadataId, name: metadataName },
    input: options.workflowInput || {},
    nodeModels: options.nodeModels,
    nodes: [mergedNode],
    connections: [],
  };
  return {
    ...options,
    workflow,
    nodeId: mergedNode.id,
  };
};

const normalizeNodeStepOptions = (
  options: ExecutorStepOptions,
): ExecuteNodeStepWithWorkflowOptions => {
  if (isWorkflowStepOptions(options)) {
    return options;
  }
  if (!("node" in options)) {
    throw new Error(
      "Step execution requires either workflow+nodeId or node options.",
    );
  }
  return buildSingleNodeWorkflowStep(options);
};

export const createExecutor = () => {
  const active = new Map<
    string,
    { controller: AbortController; state: ExecutorRunningState }
  >();
  const pubsub = createWorkflowPubsub();
  const eventHandlers = new Map<
    ExecutorPublishEventName,
    Set<
      (event: {
        eventName: ExecutorPublishEventName;
        payload: unknown;
        roomName: string;
      }) => void
    >
  >();
  let setupState: ExecutorSetup | null = null;
  let executionRequestPublisher: Awaited<
    ReturnType<typeof queueWorkflowForExecution>
  > | null = null;
  let transportServer: { start: () => void; stop: () => void } | null = null;
  const readWorkflowExecutionQueueConfig = () =>
    setupState?.executeBackend.workflowExecutionQueue?.config ||
    readWorkflowQueueRedpandaConfig(process.env);
  const workflowExecutionPubsub = startWorkflowExecutionPubsub({
    createEventConsumer: () =>
      consumeWorkflowExecutionEvents({
        applyExecutionEvent: async (event) => {
          if (setupState?.executeBackend.workflowExecutionQueue) {
            await setupState.executeBackend.workflowExecutionQueue.applyExecutionEvent(
              event,
            );
          }
        },
        config: readWorkflowExecutionQueueConfig(),
        handleExecutionEventError: (params) =>
          setupState?.executeBackend.workflowExecutionQueue?.handleExecutionEventError?.(
            params,
          ),
      }),
    createRequestRunner: () =>
      runWorkflowExecutionQueue({
        config: readWorkflowExecutionQueueConfig(),
        runExecutionRequest: (request, helpers) =>
          setupState?.executeBackend.workflowExecutionQueue?.runExecutionRequest(
            request,
            helpers,
          ) || Promise.resolve(),
      }),
  });
  const requireExecutorSetup = () => {
    if (!setupState)
      throw new Error("Executor.setup(...) must be called first.");
    return setupState;
  };
  const requireWorkflowExecutionQueue = () => {
    const executorSetup = requireExecutorSetup();
    const workflowExecutionQueue = executorSetup.executeBackend.workflowExecutionQueue;
    if (!workflowExecutionQueue)
      throw new Error("Queue execution is not configured.");
    return workflowExecutionQueue;
  };
  const ensureExecutionRequestPublisher = async () => {
    requireWorkflowExecutionQueue();
    if (!executionRequestPublisher) {
      executionRequestPublisher = queueWorkflowForExecution(
        readWorkflowExecutionQueueConfig(),
      );
      await executionRequestPublisher.connect();
    }
    await workflowExecutionPubsub.start();
    if (!executionRequestPublisher) {
      throw new Error("Workflow queue request publisher is not available.");
    }
    return executionRequestPublisher;
  };
  const stopActiveRuns = async (
    params: { runId?: string; workflowId?: string } = {},
  ) => {
    let stopped = 0;
    active.forEach((entry, key) => {
      if (params.runId && entry.state.runId !== params.runId) return;
      if (params.workflowId && entry.state.workflowId !== params.workflowId)
        return;
      stopped += 1;
      entry.controller.abort();
      active.delete(key);
    });
    return stopped;
  };
  const stopServices = async () => {
    await stopActiveRuns();
    transportServer?.stop();
    if (executionRequestPublisher) {
      await executionRequestPublisher.disconnect();
      executionRequestPublisher = null;
    }
    await workflowExecutionPubsub.stop({ force: true });
    pubsub.clear();
  };
  const stopRun = async (targetRunId: string) =>
    Number(await stopActiveRuns({ runId: targetRunId })) +
    workflowExecutionPubsub.cancelRun(targetRunId);
  const run = async (
    kind: "execute" | "executeBrowser",
    id: string,
    options: Record<string, unknown>,
    workflow: WorkflowDefinition,
  ): Promise<WorkflowExecutorResult> => {
    const executorSetup = requireExecutorSetup();
    const nextOptions = options as Record<string, any>;
    const execute =
      kind === "executeBrowser"
        ? executorSetup.executeBackend.executeBrowser
        : executorSetup.executeBackend.execute;
    if (!execute) throw new Error(`${kind} is not configured.`);
    const controller = new AbortController();
    const state = {
      id,
      runId: runId(options) || `run:${Date.now()}`,
      status: "running" as const,
      workflowId: workflowId(workflow),
    };
    active.set(state.runId, { controller, state });
    try {
      return await execute(
        id,
        {
          ...options,
          logger: nextOptions.logger || silentLogger(),
          onNodeFinish: nextOptions.onNodeFinish || noop,
          onNodeStart: nextOptions.onNodeStart || noop,
        },
        workflow,
        controller.signal,
      );
    } finally {
      active.delete(state.runId);
    }
  };
  const enqueueWorkflowExecution = async (
    id: string,
    options: Record<string, unknown>,
    workflow: WorkflowDefinition,
  ) => {
    const workflowExecutionQueue = requireWorkflowExecutionQueue();
    const executionRequestPublisher = await ensureExecutionRequestPublisher();
    const executionRequest = workflowExecutionQueue.createExecutionRequest(
      id,
      options,
      workflow,
    );
    await executionRequestPublisher.publish(executionRequest);
    return {
      executionId: executionRequest.executionId,
      runId: executionRequest.runId,
      status: "queued" as const,
      workflowId: executionRequest.workflowReference.workflowId,
    };
  };
  const executeStep = async (
    id: string,
    options: ExecutorStepOptions,
  ): Promise<WorkflowStepExecutorResult> => {
    const executorSetup = requireExecutorSetup();
    const normalizedOptions = normalizeNodeStepOptions(options);
    const nextOptions =
      normalizedOptions as ExecuteNodeStepWithWorkflowOptions &
        Record<string, any>;
    if (!executorSetup.executeBackend.executeStep)
      throw new Error("Step execution is not configured.");
    const controller = new AbortController();
    try {
      return await executorSetup.executeBackend.executeStep(
        id,
        {
          ...normalizedOptions,
          logger: nextOptions.logger || silentLogger(),
          onPreviewLogLine: nextOptions.onPreviewLogLine || noop,
          onPreviewState: nextOptions.onPreviewState || noop,
        },
        controller.signal,
      );
    } finally {
      controller.abort();
    }
  };
  const publish = (
    roomName: string,
    eventName: ExecutorPublishEventName,
    payload: unknown,
  ) => {
    pubsub.publish(roomName, eventName, payload);
    (eventHandlers.get(eventName) || new Set()).forEach((handler) =>
      handler({ eventName, payload, roomName }),
    );
    return undefined;
  };
  const on = (
    eventName: ExecutorPublishEventName,
    handler: (event: {
      eventName: ExecutorPublishEventName;
      payload: unknown;
      roomName: string;
    }) => void,
  ) => {
    const handlers = eventHandlers.get(eventName) || new Set();
    handlers.add(handler);
    eventHandlers.set(eventName, handlers);
    return () => {
      const current = eventHandlers.get(eventName);
      if (!current) return;
      current.delete(handler);
      if (!current.size) eventHandlers.delete(eventName);
    };
  };
  const api = {
    setup: (next: ExecutorSetup) => {
      setupState = next;
      return undefined;
    },
    start: async () => {
      const executorSetup = requireExecutorSetup();
      if (executorSetup.callbacks?.transport) {
        transportServer?.stop();
        transportServer = createWorkflowTransportServer(
          api,
          executorSetup.callbacks.transport,
        );
        transportServer.start();
      }
      if (!executorSetup.executeBackend.workflowExecutionQueue) return;
      await ensureExecutionRequestPublisher();
    },
    stop: async (targetRunId?: string) =>
      targetRunId ? stopRun(targetRunId) : stopServices(),
    restart: async () => {
      await stopServices();
      const executorSetup = requireExecutorSetup();
      if (executorSetup.callbacks?.transport) {
        transportServer = createWorkflowTransportServer(
          api,
          executorSetup.callbacks.transport,
        );
        transportServer.start();
      }
      if (!executorSetup.executeBackend.workflowExecutionQueue) return;
      executionRequestPublisher = queueWorkflowForExecution(
        readWorkflowExecutionQueueConfig(),
      );
      await executionRequestPublisher.connect();
      await workflowExecutionPubsub.start();
    },
    createQueuedWorkflowRequestExecutor,
    createWorkflowQueueEventApplier,
    createWorkflowQueueRequestContextSnapshot,
    createWorkflowQueueTimingPayload,
    consumeWorkflowExecutionEvents,
    execute: (
      id: string,
      options: Record<string, unknown>,
      workflow: WorkflowDefinition,
    ) => run("execute", id, options, workflow),
    executeBrowser: (
      id: string,
      options: Record<string, unknown>,
      workflow: WorkflowDefinition,
    ) => run("executeBrowser", id, options, workflow),
    compileWorkflowCypher: (input: Record<string, unknown>) =>
      compileWorkflowCypher(
        input as Parameters<typeof compileWorkflowCypher>[0],
      ),
    compileWorkflow: (input: Record<string, unknown>) =>
      compileWorkflowFromAgentPrompt(input),
    compileNode: (input: Record<string, unknown>) =>
      createDynamicNodeOperation(input),
    isWorkflowQueueExecutionStalled,
    mergeWorkflowQueueTimingPayload,
    normalizeWorkflowQueueDefinition,
    normalizeWorkflowQueueLogEvent,
    normalizeWorkflowQueueLogs,
    readWorkflowActionCatalog,
    readWorkflowEditorUrl,
    readWorkflowExcerpt,
    readWorkflowNodeCatalog: workflowNodeCatalog,
    readWorkflowNodeDetails: (modelIds: string[]) =>
      workflowNodeDetails(modelIds),
    readWorkflowPlannerContext: (message: string) =>
      workflowPlannerContext(message),
    readWorkflowShape,
    resolveWorkflowQueueCompletion,
    resolveWorkflowQueueTiming,
    executeStep,
    enqueue: enqueueWorkflowExecution,
    runWorkflowExecutionQueue,
    startWorkflowExecutionPubsub,
    stopRun,
    stopWorkflow: async (targetWorkflowId: string) =>
      Number(await stopActiveRuns({ workflowId: targetWorkflowId })) +
      workflowExecutionPubsub.cancelWorkflow(targetWorkflowId),
    getRunning: (targetWorkflowId?: string) =>
      Array.from(active.values())
        .map((entry) => entry.state)
        .concat(
          workflowExecutionPubsub.getRunning(
            targetWorkflowId,
          ) as ExecutorRunningState[],
        )
        .filter(
          (entry) => !targetWorkflowId || entry.workflowId === targetWorkflowId,
        ),
    listen: pubsub.listen,
    on,
    publish,
    catalogRoom: workflowCatalogRoom,
    workflowRoom: workflowExecutionRoom,
    logsRoom: workflowLogsRoom,
    userRoom: workflowUserRoom,
    validateCypher: (input: Record<string, unknown>) =>
      compileWorkflowCypher(
        input as Parameters<typeof compileWorkflowCypher>[0],
      ),
    validateJSON: (input: string) => JSON.parse(String(input || "null")),
    waitForWorkflowQueueCompletion,
    withWorkflowQueueExecutionStarted,
    withWorkflowQueueTimingPayload,
    errorMessage: errorText,
    readChatAdapter: () =>
      readWorkflowChatAdapter({
        catalog: readWorkflowActionCatalog,
        executeHostAction:
          requireExecutorSetup().callbacks?.chatAdapter?.execute,
      }),
  };
  return api;
};
