import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import UserNodeCodeToolbar, { buildInputOptions, buildRuntimeOptions } from '@workflow/ui/workflow/components/user-node-designer/UserNodeCodeToolbar';

vi.mock('primereact/button', () => ({
    Button: ({ onClick, disabled, 'aria-label': ariaLabel }: { onClick?: () => void; disabled?: boolean; 'aria-label'?: string }) => (
        <button type="button" aria-label={ariaLabel} onClick={onClick} disabled={disabled}>
            {ariaLabel}
        </button>
    )
}));

vi.mock('primereact/dropdown', () => ({
    Dropdown: ({ 'data-cy': dataCy }: { 'data-cy'?: string }) => <div data-cy={dataCy} />
}));

describe('UserNodeCodeToolbar option guards', () => {
    it('disables browser runtime option when current editor context is not browser-compatible', () => {
        const disabledOptions = buildRuntimeOptions(false);
        const browserOption = disabledOptions.find((option) => option.value === 'browser');
        expect(browserOption?.disabled).toBe(true);

        const enabledOptions = buildRuntimeOptions(true);
        const enabledBrowserOption = enabledOptions.find((option) => option.value === 'browser');
        expect(enabledBrowserOption?.disabled).toBe(false);
    });

    it('disables upstream input option when workflow upstream context is unavailable', () => {
        const disabledOptions = buildInputOptions(false);
        const upstreamOption = disabledOptions.find((option) => option.value === 'upstream');
        expect(upstreamOption?.disabled).toBe(true);

        const enabledOptions = buildInputOptions(true);
        const enabledUpstreamOption = enabledOptions.find((option) => option.value === 'upstream');
        expect(enabledUpstreamOption?.disabled).toBe(false);
    });

    it('renders icon-action buttons with accessible labels and wired callbacks', () => {
        const onRun = vi.fn();
        const onRunOnServer = vi.fn();
        const onStop = vi.fn();
        const onSave = vi.fn();
        const onRevert = vi.fn();
        const onClearLogs = vi.fn();

        render(
            <UserNodeCodeToolbar
                browserRuntimeAllowed
                canRun
                inputMode="sample"
                isRunning={false}
                onClearLogs={onClearLogs}
                onInputModeChange={() => undefined}
                onRevert={onRevert}
                onRun={onRun}
                onRunOnServer={onRunOnServer}
                onSave={onSave}
                onStop={onStop}
                runtimeMode="auto"
                runtimeFallbackReason={null}
                runtimeResolved="browser"
                setRuntimeMode={() => undefined}
                upstreamInputAvailable={false}
            />
        );

        fireEvent.click(screen.getByRole('button', { name: 'Run node' }));
        fireEvent.click(screen.getByRole('button', { name: 'Run node on server' }));
        fireEvent.click(screen.getByRole('button', { name: 'Revert code changes' }));
        fireEvent.click(screen.getByRole('button', { name: 'Save node' }));
        fireEvent.click(screen.getByRole('button', { name: 'Clear logs' }));

        expect(onRun).toHaveBeenCalledTimes(1);
        expect(onRunOnServer).toHaveBeenCalledTimes(1);
        expect(onRevert).toHaveBeenCalledTimes(1);
        expect(onSave).toHaveBeenCalledTimes(1);
        expect(onClearLogs).toHaveBeenCalledTimes(1);
        expect(onStop).not.toHaveBeenCalled();
        expect((screen.getByRole('button', { name: 'Stop node run' }) as HTMLButtonElement).disabled).toBe(true);
    });
});
