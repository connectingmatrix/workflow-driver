import { WORKFLOW_LAYOUT_LANE_GAP, WORKFLOW_LAYOUT_STAGE_GAP, WORKFLOW_LAYOUT_START_X, WORKFLOW_LAYOUT_START_Y } from './layout-constants';
import type { WorkflowLayoutGraph } from './layout-graph';

type WorkflowMainLayout = {
  stages: Record<string, number>;
  lanes: Record<string, number>;
  positions: Record<string, { x: number; y: number }>;
};

const siblingOffset = (count: number, index: number) => {
  if (count <= 1) return 0;
  const split = Math.floor(count / 2);
  return count % 2 ? index - split : index < split ? index - split : index - split + 1;
};

const nearestLane = (used: Set<number>, preferred: number) => {
  const rounded = Math.round(preferred);
  if (!used.has(rounded)) return rounded;
  for (let step = 1; step < 32; step += 1) {
    const left = rounded - step;
    if (!used.has(left)) return left;
    const right = rounded + step;
    if (!used.has(right)) return right;
  }
  return rounded + used.size + 1;
};

const readStages = (graph: WorkflowLayoutGraph) => {
  const cache: Record<string, number> = {};
  const visit = (nodeId: string): number => {
    if (typeof cache[nodeId] === 'number') return cache[nodeId];
    const parents = graph.parentsById[nodeId] || [];
    cache[nodeId] = parents.length ? Math.max(...parents.map(visit)) + 1 : 0;
    return cache[nodeId];
  };
  graph.mainNodeIds.forEach((nodeId) => visit(nodeId));
  return cache;
};

export function placeMainNodes(graph: WorkflowLayoutGraph): WorkflowMainLayout {
  const stages = readStages(graph);
  const roots = graph.roots.reduce<Record<string, number>>((record, nodeId, index) => ({ ...record, [nodeId]: index * 2 }), {});
  const stageIds = [...new Set(graph.mainNodeIds.map((nodeId) => stages[nodeId] || 0))].sort((left, right) => left - right);
  const lanes: Record<string, number> = {};

  stageIds.forEach((stage) => {
    const used = new Set<number>();
    const nodes = graph.mainNodeIds.filter((nodeId) => (stages[nodeId] || 0) === stage);
    const preferred = (nodeId: string) => {
      const parents = graph.parentsById[nodeId] || [];
      if (!parents.length) return roots[nodeId] || 0;
      if (parents.length > 1) return parents.reduce((sum, parentId) => sum + (lanes[parentId] || 0), 0) / parents.length;
      const siblings = (graph.childrenById[parents[0]] || []).filter((childId) => (stages[childId] || 0) === stage).sort((left, right) => (graph.orderById[left] || 0) - (graph.orderById[right] || 0));
      return (lanes[parents[0]] || 0) + siblingOffset(siblings.length, siblings.indexOf(nodeId));
    };

    nodes
      .sort((left, right) => preferred(left) - preferred(right) || (graph.orderById[left] || 0) - (graph.orderById[right] || 0))
      .forEach((nodeId) => {
        const lane = nearestLane(used, preferred(nodeId));
        used.add(lane);
        lanes[nodeId] = lane;
      });
  });

  const minLane = Math.min(...Object.values(lanes), 0);
  const positions = graph.mainNodeIds.reduce<Record<string, { x: number; y: number }>>((record, nodeId) => {
    record[nodeId] = {
      x: WORKFLOW_LAYOUT_START_X + (lanes[nodeId] - minLane) * WORKFLOW_LAYOUT_LANE_GAP,
      y: WORKFLOW_LAYOUT_START_Y + (stages[nodeId] || 0) * WORKFLOW_LAYOUT_STAGE_GAP,
    };
    return record;
  }, {});

  return { stages, lanes, positions };
}
