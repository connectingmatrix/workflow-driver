import { WorkflowDefinition, WorkflowNodeLibraryItem } from '@workflow/ui/workflow/types';

export interface WorkflowCypherNodeSpec {
    alias: string;
    modelId: string;
    name?: string;
    runtime: Record<string, unknown>;
}

export interface WorkflowCypherEdgeSpec {
    from: string;
    to: string;
    source: string;
    target: string;
}

export interface WorkflowCypherGraph {
    nodes: WorkflowCypherNodeSpec[];
    edges: WorkflowCypherEdgeSpec[];
}

export interface WorkflowCypherResult {
    workflow: WorkflowDefinition;
    warnings: string[];
}

export interface WorkflowCypherBuildInput {
    cypher: string;
    baseWorkflow: WorkflowDefinition;
    nodeLibraryItems: WorkflowNodeLibraryItem[];
}
