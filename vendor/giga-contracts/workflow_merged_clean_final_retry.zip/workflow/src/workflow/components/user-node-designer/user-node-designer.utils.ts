import { WorkflowDefinition, WorkflowNodeLibraryItem, WorkflowNodeSchema, WorkflowNodeStatusEnum, WorkflowRuntimeSettings, WorkflowUserNodeDefinition } from '@workflow/ui/workflow/types';
import { resolveIconRenderer } from '@workflow/ui/workflow/utils/workflow-icon-render.utils';

const toRecord = (value: unknown): Record<string, unknown> => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : {});
const createLocalId = (): string => `wf_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
const resolveRenderConfig = (schema: Record<string, unknown>): NonNullable<WorkflowNodeSchema['render']> & { iconClass: string } => {
    const render = toRecord(schema.render);
    const iconClass = typeof render.iconClass === 'string' && render.iconClass.trim() ? render.iconClass : typeof schema.iconClass === 'string' && schema.iconClass.trim() ? schema.iconClass : 'pi pi-code';
    const iconColor = typeof render.iconColor === 'string' && render.iconColor.trim() ? render.iconColor : typeof schema.iconColor === 'string' && schema.iconColor.trim() ? schema.iconColor : undefined;
    const iconSvg = typeof render.iconSvg === 'string' && render.iconSvg.trim() ? render.iconSvg : typeof schema.iconSvg === 'string' && schema.iconSvg.trim() ? schema.iconSvg : undefined;
    const iconMode: 'prime' | 'svg' = render.iconMode === 'svg' || render.iconMode === 'prime' ? render.iconMode : schema.iconMode === 'svg' || schema.iconMode === 'prime' ? schema.iconMode : iconSvg ? 'svg' : 'prime';
    return {
        ...render,
        iconClass,
        ...(iconColor ? { iconColor } : {}),
        ...(iconSvg ? { iconSvg } : {}),
        iconMode
    };
};

export const toUserNodeLibraryItem = (node: WorkflowUserNodeDefinition): WorkflowNodeLibraryItem => {
    const schema = toRecord(node.nodeSchema);
    const render = resolveRenderConfig(schema);
    return {
        id: node.id,
        label: node.name,
        description: node.description ?? 'User-authored workflow node',
        gigaId: node.modelId,
        modelId: node.modelId,
        nodeType: 'workflowStep',
        group: node.groupName ?? 'User Nodes',
        iconClass: render.iconClass,
        iconColor: render.iconColor,
        renderIcon: resolveIconRenderer(render)
    };
};

export const toUserNodeSchema = (node: WorkflowUserNodeDefinition): WorkflowNodeSchema => {
    const schema = toRecord(node.nodeSchema);
    const render = resolveRenderConfig(schema);
    const inputs = toRecord(schema.inputs);
    const outputs = toRecord(schema.outputs);
    const commands = toRecord(schema.commands);
    return {
        id: node.modelId,
        group: node.groupName ?? 'User Nodes',
        iconClass: render.iconClass,
        ...(render.iconColor ? { iconColor: render.iconColor } : {}),
        ...(render.iconSvg ? { iconSvg: render.iconSvg } : {}),
        ...(render.iconMode ? { iconMode: render.iconMode } : {}),
        render: {
            ...render
        },
        name: { type: 'string', editable: true, autoGenerate: true },
        instruction: { code: false, markdown: false },
        fields: toRecord(schema.fields) as WorkflowNodeSchema['fields'],
        inputs: Object.keys(inputs).length ? (inputs as WorkflowNodeSchema['inputs']) : { input: { allowMultipleArrows: true } },
        outputs: Object.keys(outputs).length ? (outputs as WorkflowNodeSchema['outputs']) : { output: { allowMultipleArrows: true } },
        commands: Object.keys(commands).length ? (commands as WorkflowNodeSchema['commands']) : undefined,
        outputViewers: [{ id: 'json', label: 'JSON', type: 'json' }]
    };
};

export const mergeWorkflowUserNodeSchemas = (workflow: WorkflowDefinition, userNodes: WorkflowUserNodeDefinition[]): WorkflowDefinition => {
    const nextNodeModels = { ...(workflow.nodeModels ?? {}) };
    userNodes.forEach((node) => {
        nextNodeModels[node.modelId] = toUserNodeSchema(node);
    });
    return {
        ...workflow,
        nodeModels: nextNodeModels
    };
};

export const workflowNeedsUserNodeSchemaSync = (workflow: WorkflowDefinition, userNodes: WorkflowUserNodeDefinition[]): boolean =>
    userNodes.some((node) => {
        const current = workflow.nodeModels?.[node.modelId];
        if (!current) return true;
        return JSON.stringify(current) !== JSON.stringify(toUserNodeSchema(node));
    });

export const buildUserNodePreviewWorkflow = (params: { runtime: Record<string, unknown>; schema: WorkflowNodeSchema; settings: WorkflowRuntimeSettings; userNode: WorkflowUserNodeDefinition }): WorkflowDefinition => ({
    metadata: {
        id: `wf_preview_${createLocalId()}`,
        name: `Preview ${params.userNode.name}`,
        runtime: { settings: params.settings }
    },
    nodeModels: {
        [params.userNode.modelId]: params.schema
    },
    nodes: [
        {
            id: 'node_preview_1',
            gigaId: 'node_preview_1',
            modelId: params.userNode.modelId,
            type: 'workflowStep',
            name: params.userNode.name,
            description: params.userNode.description ?? '',
            kind: 'process',
            status: WorkflowNodeStatusEnum.Stopped,
            position: { x: 120, y: 80 },
            runtime: params.runtime,
            ports: {
                in: {},
                out: {}
            }
        }
    ],
    connections: []
});
