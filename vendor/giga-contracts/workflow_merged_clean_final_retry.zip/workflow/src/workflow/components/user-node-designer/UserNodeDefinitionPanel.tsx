import React from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { WorkflowUserNodeDefinition } from '@workflow/ui/workflow/types';

interface UserNodeDefinitionPanelProps {
    description: string;
    groupName: string;
    name: string;
    nodes: WorkflowUserNodeDefinition[];
    onCreateNew: () => void;
    onDelete: () => void;
    onDescriptionChange: (value: string) => void;
    onGroupNameChange: (value: string) => void;
    onNameChange: (value: string) => void;
    onSelectNode: (value: string) => void;
    selectedNodeId: string | null;
    slug: string;
}

const UserNodeDefinitionPanel: React.FC<UserNodeDefinitionPanelProps> = ({ description, groupName, name, nodes, onCreateNew, onDelete, onDescriptionChange, onGroupNameChange, onNameChange, onSelectNode, selectedNodeId, slug }) => (
    <div className="grid p-2 gap-2">
        <div className="col-12">
            <label className="text-sm mb-1 block">User Node</label>
            <div className="flex gap-2">
                <Dropdown
                    value={selectedNodeId}
                    options={nodes.map((node) => ({ label: node.name, value: node.id }))}
                    onChange={(event) => onSelectNode(event.value)}
                    placeholder="Select a saved user node"
                    className="w-full"
                    data-cy="user-node-select"
                />
                <Button
                    icon="pi pi-plus"
                    text
                    rounded
                    className="p-button-sm wf-user-node-icon-btn"
                    onClick={onCreateNew}
                    data-cy="user-node-new"
                    aria-label="Create user node"
                    tooltip="New Node"
                    tooltipOptions={{ position: 'bottom' }}
                />
                <Button
                    icon="pi pi-trash"
                    text
                    rounded
                    className="p-button-sm wf-user-node-icon-btn p-button-danger"
                    onClick={onDelete}
                    disabled={!selectedNodeId}
                    data-cy="user-node-delete"
                    aria-label="Delete selected user node"
                    tooltip="Delete Node"
                    tooltipOptions={{ position: 'bottom' }}
                />
            </div>
        </div>
        <div className="col-12">
            <label className="text-sm mb-1 block">Name</label>
            <InputText value={name} onChange={(event) => onNameChange(event.target.value)} className="w-full" data-cy="user-node-name" />
        </div>
        <div className="col-12 md:col-6">
            <label className="text-sm mb-1 block">Slug (read-only)</label>
            <InputText value={slug} disabled className="w-full" data-cy="user-node-slug" />
        </div>
        <div className="col-12 md:col-6">
            <label className="text-sm mb-1 block">Group</label>
            <InputText value={groupName} onChange={(event) => onGroupNameChange(event.target.value)} className="w-full" data-cy="user-node-group" />
        </div>
        <div className="col-12">
            <label className="text-sm mb-1 block">Description</label>
            <InputTextarea value={description} onChange={(event) => onDescriptionChange(event.target.value)} rows={4} className="w-full" data-cy="user-node-description" />
        </div>
    </div>
);

export default UserNodeDefinitionPanel;
