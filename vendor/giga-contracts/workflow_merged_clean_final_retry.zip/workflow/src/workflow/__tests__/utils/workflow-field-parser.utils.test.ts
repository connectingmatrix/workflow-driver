import { describe, expect, it } from 'vitest';
import { WorkflowNodeFieldTypeEnum } from '@workflow/ui/workflow/types';
import { parseEditorPropertyValues } from '@workflow/ui/workflow/utils/workflow-field-parser.utils';

describe('workflow-field-parser.utils', () => {
    it('preserves variable templates for variable-enabled fields', () => {
        const fields = {
            prompt: {
                type: WorkflowNodeFieldTypeEnum.Textarea,
                editable: true,
                allowVariables: true
            },
            payload: {
                type: WorkflowNodeFieldTypeEnum.Json,
                editable: true,
                allowVariables: true
            }
        };

        const parsed = parseEditorPropertyValues(fields, {
            prompt: 'Summarize {{node_1.title}}',
            payload: '{"title":"{{node_1.title}}"}'
        });

        expect(parsed.prompt).toBe('Summarize {{node_1.title}}');
        expect(parsed.payload).toBe('{"title":"{{node_1.title}}"}');
    });

    it('keeps existing coercion for non-templated values', () => {
        const fields = {
            temperature: {
                type: WorkflowNodeFieldTypeEnum.Number,
                editable: true,
                allowVariables: false
            },
            enabled: {
                type: WorkflowNodeFieldTypeEnum.Boolean,
                editable: true,
                allowVariables: false
            }
        };

        const parsed = parseEditorPropertyValues(fields, {
            temperature: '3.2',
            enabled: 'true'
        });

        expect(parsed.temperature).toBe(3.2);
        expect(parsed.enabled).toBe(true);
    });
});
