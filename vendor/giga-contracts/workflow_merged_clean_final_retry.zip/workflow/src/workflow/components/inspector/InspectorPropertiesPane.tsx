import React, { useMemo, useState } from 'react';
import { Button } from 'primereact/button';
import { TabPanel, TabView } from 'primereact/tabview';
import CodeEditor from '@workflow/ui/workflow/components/inspector/CodeEditor';
import GraphqlQuerySection from '@workflow/ui/workflow/components/form/graphql-query-section';
import InstructionMarkdownEditor from '@workflow/ui/workflow/components/inspector/InstructionMarkdownEditor';
import InspectorPropertyField from '@workflow/ui/workflow/components/inspector/InspectorPropertyField';
import { buildVisibleInspectorFields, resolveInspectorBooleanStateVisibility, resolveInspectorLayoutPreset } from '@workflow/ui/workflow/components/inspector/inspector-properties-pane.utils';
import { getWorkflowInspectorModule } from '@workflow/ui/workflow/components/inspector/modules/inspector-module.registry';
import { WorkflowNodeFieldDefinition, WorkflowNodeFieldMap, WorkflowNodeInstructionConfig } from '@workflow/ui/workflow/types';
import { WORKFLOW_FAILURE_MITIGATION_FIELD, WORKFLOW_FAILURE_MITIGATION_RETRY, WORKFLOW_RETRY_COUNT_FIELD } from '@workflow/ui/workflow/utils/workflow-failure-mitigation.utils';
import { buildVariableSuggestionsFromContext } from '@workflow/ui/workflow/utils/workflow-variables.utils';

interface InspectorPropertiesPaneProps {
    modelId?: string;
    nodeId: string;
    instruction: WorkflowNodeInstructionConfig;
    fields: WorkflowNodeFieldMap;
    propertiesEditorState: Record<string, unknown>;
    inputData?: Record<string, unknown>;
    workflowVariableData?: Record<string, unknown>;
    workflowData?: Record<string, unknown>;
    hiddenFieldKeys?: string[];
    instructionOnly?: boolean;
    showGraphqlQuerySection?: boolean;
    inspectorColumns?: number;
    codeAllowVariables?: boolean;
    editorSessionKey?: number;
    code: string;
    markdown: string;
    onPropertyChange: (key: string, value: unknown) => void;
    onCodeChange: (nextCode: string) => void;
    onMarkdownChange: (nextMarkdown: string) => void;
    onExecuteStep: () => void;
    isExecuting: boolean;
}

type InspectorTabKey = 'properties' | 'instruction';
type InstructionTabKey = 'code' | 'markdown';

const InspectorPropertiesPane: React.FC<InspectorPropertiesPaneProps> = ({
    modelId = '',
    nodeId,
    instruction,
    fields,
    propertiesEditorState,
    inputData = {},
    workflowVariableData = {},
    workflowData = {},
    hiddenFieldKeys = [],
    instructionOnly = false,
    showGraphqlQuerySection = false,
    inspectorColumns = 12,
    codeAllowVariables = true,
    editorSessionKey = 0,
    code,
    markdown,
    onPropertyChange,
    onCodeChange,
    onMarkdownChange,
    onExecuteStep,
    isExecuting
}) => {
    const moduleDefinition = useMemo(() => getWorkflowInspectorModule(modelId), [modelId]);
    const ModuleAppendSection = moduleDefinition?.appendSection;
    const [activeTab, setActiveTab] = useState<InspectorTabKey>('properties');
    const [activeInstructionTab, setActiveInstructionTab] = useState<InstructionTabKey>('code');
    const visibleFields = useMemo(
        () =>
            buildVisibleInspectorFields({
                fields,
                values: propertiesEditorState,
                hiddenFieldKeys,
                propertyOrder: moduleDefinition?.propertyOrder,
                shouldDisplayField: moduleDefinition?.shouldDisplayField
            }),
        [fields, hiddenFieldKeys, moduleDefinition?.propertyOrder, moduleDefinition?.shouldDisplayField, propertiesEditorState]
    );
    const showInstruction = Boolean(instruction.code || instruction.markdown);
    const isInstructionOnlyNode = instructionOnly && instruction.code;
    const visibleInstructionTabs = [instruction.code, instruction.markdown].filter(Boolean).length;
    const activeTabIndex = activeTab === 'properties' ? 0 : 1;
    const activeInstructionTabIndex = activeInstructionTab === 'code' ? 0 : instruction.code ? 1 : 0;
    const retryDefinition = fields[WORKFLOW_RETRY_COUNT_FIELD] ?? visibleFields.find(([key]) => key === WORKFLOW_RETRY_COUNT_FIELD)?.[1];
    const showRetryCompanion = String(propertiesEditorState[WORKFLOW_FAILURE_MITIGATION_FIELD] ?? '').trim() === WORKFLOW_FAILURE_MITIGATION_RETRY;
    const variableContext = useMemo<Record<string, unknown>>(
        () => ({
            ...(inputData || {}),
            workflow: workflowVariableData || {}
        }),
        [inputData, workflowVariableData]
    );
    const variableSuggestions = useMemo(() => buildVariableSuggestionsFromContext(variableContext), [variableContext]);
    const visibleFieldMap = useMemo(() => new Map<string, WorkflowNodeFieldDefinition>(visibleFields), [visibleFields]);
    const dependingFieldMap = useMemo(() => {
        const map = new Map<string, { fieldKey: string; definition: WorkflowNodeFieldDefinition; value: unknown }>();
        visibleFields.forEach(([fieldKey, definition]) => {
            if (!definition.dependsOn?.entityField || !definition.dependsOn.field) return;
            const dependencyFieldKey = definition.dependsOn.field;
            const dependencyDefinition = visibleFieldMap.get(dependencyFieldKey);
            if (!dependencyDefinition || dependencyFieldKey === fieldKey) return;
            map.set(fieldKey, {
                fieldKey: dependencyFieldKey,
                definition: dependencyDefinition,
                value: propertiesEditorState[dependencyFieldKey]
            });
        });
        return map;
    }, [propertiesEditorState, visibleFieldMap, visibleFields]);
    const dependencyFieldKeys = useMemo(() => new Set(Array.from(dependingFieldMap.values()).map((entry) => entry.fieldKey)), [dependingFieldMap]);
    const renderPropertiesContent = (): React.ReactNode => (
        <div className="wf-inspector__section">
            <div className="wf-inspector__properties">
                {visibleFields.length === 0 && <div className="wf-inspector__hint">No editable node properties available.</div>}
                {visibleFields.map(([fieldKey, definition]) => {
                    if (dependencyFieldKeys.has(fieldKey) && !dependingFieldMap.has(fieldKey)) {
                        return null;
                    }
                    if (fieldKey === WORKFLOW_RETRY_COUNT_FIELD && Boolean(retryDefinition)) return null;
                    const layoutPreset = resolveInspectorLayoutPreset(definition);
                    const dependingField = dependingFieldMap.get(fieldKey);
                    if (layoutPreset === 'mitigation') {
                        return (
                            <InspectorPropertyField
                                key={fieldKey}
                                fieldKey={fieldKey}
                                definition={definition}
                                value={propertiesEditorState[fieldKey]}
                                onChange={onPropertyChange}
                                propertiesEditorState={propertiesEditorState}
                                layoutPreset="mitigation"
                                inspectorColumns={inspectorColumns}
                                companionField={
                                    retryDefinition
                                        ? {
                                              fieldKey: WORKFLOW_RETRY_COUNT_FIELD,
                                              definition: retryDefinition,
                                              value: propertiesEditorState[WORKFLOW_RETRY_COUNT_FIELD],
                                              visible: showRetryCompanion
                                          }
                                        : undefined
                                }
                                variableContext={variableContext}
                                variableSuggestions={variableSuggestions}
                            />
                        );
                    }
                    return (
                        <InspectorPropertyField
                            key={fieldKey}
                            fieldKey={fieldKey}
                            definition={definition}
                            value={propertiesEditorState[fieldKey]}
                            onChange={onPropertyChange}
                            propertiesEditorState={propertiesEditorState}
                            layoutPreset={layoutPreset}
                            inspectorColumns={definition.styles?.columns ?? inspectorColumns}
                            dependingField={dependingField}
                            showBooleanState={resolveInspectorBooleanStateVisibility(definition)}
                            variableContext={variableContext}
                            variableSuggestions={variableSuggestions}
                        />
                    );
                })}
                {ModuleAppendSection ? (
                    <ModuleAppendSection
                        modelId={modelId}
                        fields={fields}
                        propertiesEditorState={propertiesEditorState}
                        workflowData={workflowData}
                        onPropertyChange={onPropertyChange}
                        variableContext={variableContext}
                        variableSuggestions={variableSuggestions}
                    />
                ) : null}
                {showGraphqlQuerySection && <GraphqlQuerySection queryText={propertiesEditorState.queryText} variables={propertiesEditorState.variables} />}
            </div>
        </div>
    );

    return (
        <section className="wf-inspector-pane wf-inspector-pane--properties">
            <header className="wf-inspector-pane__header wf-inspector-pane__header--split">
                <div>
                    <div className="wf-inspector-pane__title">Parameters</div>
                    <div className="wf-inspector-pane__subtitle">Configure node properties and run a single step.</div>
                </div>
                <Button
                    icon={isExecuting ? 'pi pi-spin pi-spinner' : 'pi pi-play'}
                    text
                    className="p-button-sm wf-inspector__icon-button wf-inspector__icon-button--execute"
                    onClick={onExecuteStep}
                    disabled={isExecuting}
                    aria-label={isExecuting ? 'Executing step' : 'Execute step'}
                    tooltip={isExecuting ? 'Executing...' : 'Execute Step'}
                    tooltipOptions={{ position: 'bottom' }}
                />
            </header>

            <div className={`wf-inspector-pane__body${moduleDefinition?.bodyClassName ? ` ${moduleDefinition.bodyClassName}` : ''}`}>
                {isInstructionOnlyNode && (
                    <div className="wf-inspector__section wf-inspector__section--stretch">
                        <div className="wf-inspector__code-panel">
                            <CodeEditor key={`wf-code-editor-${nodeId}-${editorSessionKey}`} value={code} onChange={onCodeChange} allowVariables={codeAllowVariables} variableContext={variableContext} variableSuggestions={variableSuggestions} />
                            <div className="wf-inspector__hint">Use `NODE_ID.key` for upstream outputs, `workflow.runtime`, `workflow.input`, and `properties` for node properties.</div>
                        </div>
                    </div>
                )}
                {!showInstruction && renderPropertiesContent()}
                {showInstruction && !isInstructionOnlyNode && (
                    <TabView activeIndex={activeTabIndex} onTabChange={(event) => setActiveTab(event.index === 0 ? 'properties' : 'instruction')} className="wf-inspector__tabview">
                        <TabPanel header="Properties">{renderPropertiesContent()}</TabPanel>

                        <TabPanel header="Instruction">
                            <TabView
                                activeIndex={activeInstructionTabIndex}
                                onTabChange={(event) => {
                                    if (visibleInstructionTabs === 1) return;
                                    setActiveInstructionTab(event.index === 0 ? 'code' : 'markdown');
                                }}
                                className="wf-inspector__tabview wf-inspector__tabview--nested"
                            >
                                {instruction.code && (
                                    <TabPanel header="Code">
                                        <div className="wf-inspector__section wf-inspector__section--stretch">
                                            <div className="wf-inspector__code-panel">
                                                <CodeEditor
                                                    key={`wf-code-editor-${nodeId}-${editorSessionKey}`}
                                                    value={code}
                                                    onChange={onCodeChange}
                                                    allowVariables={codeAllowVariables}
                                                    variableContext={variableContext}
                                                    variableSuggestions={variableSuggestions}
                                                />
                                                <div className="wf-inspector__hint">Use `NODE_ID.key` for upstream outputs, `workflow.runtime`, `workflow.input`, and `properties` for node properties.</div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                )}

                                {instruction.markdown && (
                                    <TabPanel header="Markdown">
                                        <div className="wf-inspector__section wf-inspector__section--stretch">
                                            <div className="wf-inspector__code-panel">
                                                <InstructionMarkdownEditor id="wf-instruction-markdown" value={markdown} onChange={onMarkdownChange} allowVariables variableSuggestions={variableSuggestions} />
                                                <div className="wf-inspector__hint">{'Drag JSON tree keys here to insert template tokens like {{code_1.output}}.'}</div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                )}
                            </TabView>
                        </TabPanel>
                    </TabView>
                )}
            </div>
        </section>
    );
};

export default InspectorPropertiesPane;
