const EDITABLE_SHORTCUT_SELECTOR = 'input, textarea, select, [contenteditable="true"], .monaco-editor';
const INSPECTOR_SELECTOR = '.wf-inspector-dialog';

const getShortcutElement = (value: EventTarget | Node | null): HTMLElement | null => {
    if (!value) {
        return null;
    }
    if (value instanceof HTMLElement) {
        return value;
    }
    if (value instanceof Node && value.parentElement) {
        return value.parentElement;
    }
    return null;
};

const matchesShortcutSelector = (element: HTMLElement | null, selector: string): boolean => {
    if (!element) {
        return false;
    }
    return Boolean(element.closest(selector));
};

export const isWorkflowClipboardShortcutBlocked = (target: EventTarget | null): boolean => {
    const targetElement = getShortcutElement(target);
    if (matchesShortcutSelector(targetElement, EDITABLE_SHORTCUT_SELECTOR)) {
        return true;
    }

    const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (matchesShortcutSelector(activeElement, EDITABLE_SHORTCUT_SELECTOR)) {
        return true;
    }

    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.toString().trim()) {
        return false;
    }

    const anchorElement = getShortcutElement(selection.anchorNode);
    if (matchesShortcutSelector(anchorElement, INSPECTOR_SELECTOR)) {
        return true;
    }

    const focusElement = getShortcutElement(selection.focusNode);
    return matchesShortcutSelector(focusElement, INSPECTOR_SELECTOR);
};
