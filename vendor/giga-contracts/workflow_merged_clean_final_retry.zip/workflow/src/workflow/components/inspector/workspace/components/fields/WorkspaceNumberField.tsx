import React from 'react';
import { InputNumber } from 'primereact/inputnumber';

interface WorkspaceNumberFieldProps {
    id: string;
    value: number | null;
    editable: boolean;
    min?: number;
    max?: number;
    step?: number;
    onChange: (nextValue: number | null) => void;
}

export const WorkspaceNumberField: React.FC<WorkspaceNumberFieldProps> = ({ id, value, editable, min, max, step, onChange }) => {
    return (
        <InputNumber
            inputId={id}
            value={value}
            min={min}
            max={max}
            step={step}
            useGrouping={false}
            onValueChange={(event) => onChange(typeof event.value === 'number' ? event.value : null)}
            disabled={!editable}
            className="w-full"
            inputClassName="cnw-prime-input"
        />
    );
};
